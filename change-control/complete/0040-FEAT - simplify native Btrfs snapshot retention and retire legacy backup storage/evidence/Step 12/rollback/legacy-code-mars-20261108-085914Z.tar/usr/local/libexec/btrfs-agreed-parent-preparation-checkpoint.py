#!/usr/bin/python3
"""0040 Step 12 3H.5w: manual receiver/source preparation checkpoint.

NO send/receive, promote, prune, release, deletion or legacy sender fallback.
Root-only CLI. Deployment and first state-changing execution require separate review.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/usr/local/libexec')
PUSH = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
STATE = Path('/media/usb/@snapshots/.agreed-parent.json')


def load(name):
    path = ROOT / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('step12_3h5w_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_authorities(reply):
    if type(reply) is not dict or any(reply.get(key) is not False for key in
            ('authorizes_prepare', 'authorizes_promote', 'authorizes_transfer',
             'authorizes_prune', 'authorizes_release')):
        raise RuntimeError('untrusted receiver observation')
    return reply['receiver']


def checkpoint(timestamp, *, execute=False, deps=None):
    """Hold push lock for whole transaction; manager lock only in scoped sections.

    Any uncertain prepare is reconciled with authenticated get-state. Never retry
    prepare. Source mutation requires a second receiver read while manager locked.
    """
    d = deps or {name: load(name) for name in (
        'locked-get-state', 'state', 'source-evidence', 'transfer-plan',
        'get-state-transport', 'prepare-transport', 'prepare-transport-contract',
        'source-transition', 'source-recovery-integration', 'recovery-decision')}
    lock, state, evidence, transfer = (d[k] for k in ('locked-get-state','state','source-evidence','transfer-plan'))
    get, prepare, contract = (d[k] for k in ('get-state-transport','prepare-transport','prepare-transport-contract'))
    with ExitStack() as push_stack:
        lock.acquire(push_stack, PUSH)
        with ExitStack() as manager_stack:
            lock.acquire(manager_stack, MANAGER)
            source = state.load(STATE, require_root=True)
            state.validate(source)
            if source['pending'] is not None or source['previous'] is not None:
                raise RuntimeError('source transition already active; do not retry')
            candidate = transfer.target_identity(timestamp)
            for ident in (source['established'], candidate):
                if evidence.verify_source(ident) != dict(ident, verified=True):
                    raise RuntimeError('source Btrfs identity mismatch')
            before = verify_authorities(get.get_state(timestamp, source_lock_held=True))
            if source != before:
                raise RuntimeError('source and receiver durable states differ')
            request = contract.prepare_request(source, before, candidate)
            expected = contract.expected_after(request)
            if not execute:
                return {'schema':1, 'status':'review-only', 'request':request,
                        'expected_receiver_after':expected, 'state_changed':False,
                        'transfer_executed':False, 'release_executed':False}
            # Manager lock is held during authenticated receiver prepare.
            # Do not retry even if SSH returned a failure after durable commit.
            try:
                prepare.invoke(request, locks_held=True, source_verified=True)
            except prepare.PrepareUncertain:
                pass
            observed = verify_authorities(get.get_state(timestamp, source_lock_held=True))
            if observed != expected:
                raise RuntimeError('receiver prepare not confirmed: STOP, no automatic retry')
        # Release manager lock before source core, which acquires it itself.
        # Keep the push lock throughout; source transition observes the peer again
        # inside the manager lock, immediately before a durable source write.
        def fresh_receiver(tid):
            return get.get_state(tid, source_lock_held=True)
        result = d['source-recovery-integration'].prepare_source(
            source_before=source, candidate=candidate, state_path=STATE,
            manager_lock=MANAGER, push_lock_held=True,
            acquire_manager=lock.acquire, verify_source=evidence.verify_source,
            read_receiver=fresh_receiver, transition=d['source-transition'],
            recovery=d['recovery-decision'])
        if result.get('status') != 'source-prepared-verified' or result.get('source') != state.prepare(source,candidate):
            raise RuntimeError('source prepare not confirmed; stop and inspect durable state')
        return {'schema':1, 'status':'prepared-checkpoint', 'source':result['source'],
                'receiver':expected, 'transfer_executed':False,
                'release_executed':False, 'authorizes_transfer':False,
                'authorizes_promote':False, 'authorizes_prune':False,
                'authorizes_release':False}


def main():
    parser = argparse.ArgumentParser(description='Agreed-parent preparation checkpoint; no transfer')
    parser.add_argument('--target', required=True)
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument('--review-only', action='store_true')
    selection.add_argument('--execute-preparation', action='store_true')
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(checkpoint(args.target, execute=args.execute_preparation), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        print('agreed-parent checkpoint refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
