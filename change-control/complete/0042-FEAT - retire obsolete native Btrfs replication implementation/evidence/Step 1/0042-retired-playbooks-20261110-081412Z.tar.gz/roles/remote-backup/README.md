# remote-backup — 0034/0035 native Btrfs replication

The authoritative replication flow is **mars-initiated push** to `backup`.
`btrfs-replication.yaml` installs the manual `btrfs-native-push` operator command on `mars`,
its `btrfs-native-push-receiver` on `backup`, and the shared restricted Btrfs endpoint.
Ordinary deployment does not initiate a transfer. Step 11.4 installs an opt-in systemd timer; it remains disabled unless `btrfs_native_push_schedule_enabled: true` is explicitly supplied for `mars`.

- Source snapshots: `/media/usb/@snapshots/@data/YYYYMMDD-HHmmssZ`
- Destination snapshots: `/@data/mars-received/@data/YYYYMMDD-HHmmssZ`
- Receiver receipts: `/@data/mars-received/.replication-state/`
- Source protection: `/media/usb/@snapshots/.replication-protection.json`
- Example: `btrfs-native-push --snapshot 20261013-150014Z --preflight`

The standard `remote-backup` role delegates timestamp-named snapshot management to
`roles/snapshots`. The old opt-in `whole-backup-pull` rsync mirror and native
backup-initiated pull have been retired from source/deployment tasks.

**Safe transition:** This source change does not delete existing snapshots, receipts,
replicas or installed binaries. After deployment and verification, explicitly
inspect installed legacy services/helpers before retiring them from hosts.
Never delete historical read-only received snapshots or `/@data/backup` as cleanup.

## 0034 Step 11.4 unattended source push

The source-side timer runs `btrfs-native-push --latest`. `--latest` uses the constrained
root endpoint only to enumerate validated read-only `@data` snapshots, refuses any
implicit full reseed, requires an already accepted common parent, and returns success
without retransmission when the newest snapshot is already accepted. This makes the
timer idempotent while preserving the manual `--snapshot` recovery interface.

Suggested Step 11.4 sequencing is production publication at 00:30 UTC, verified
`pluto` pull at 01:30 UTC, the existing hourly native snapshot schedule, then native
off-site push at 03:30 UTC. These are role defaults only; all three new application/
replication timers are default-off and production inventory remains authoritative.
Before enabling the native push timer, disable the historical `mars -> backup` rsync
phase through `legacy_remote_rsync_push_enabled: false`; Step 11.4 verification treats
dual off-site transports as a failure. Systemd journal/service status is the audit trail.
