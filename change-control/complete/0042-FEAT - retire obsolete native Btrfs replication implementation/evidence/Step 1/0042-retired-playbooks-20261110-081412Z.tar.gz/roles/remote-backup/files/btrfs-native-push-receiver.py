#!/usr/bin/env python3
"""0034 push receiver. Invoked over outbound SSH from mars; opt-in, no scheduling."""

# MODULE GUIDE: Receiver-side control protocol for mars-initiated native Btrfs replication.
# Runs on backup after an outbound SSH request from mars. Validates received subvolumes and
# persisted receipts, coordinates native receive under the writer lock, and exposes constrained
# read-only retention/coordination checks. Current Step 3 transaction helpers are internal, not
# a public permission to prune.  Failure is deliberately fail-closed: incomplete journals,
# mismatched UUIDs, missing holds or an unverifiable challenge must not authorize deletion.
# This file is the older remote-backup role copy; document it as deployed legacy code, not as
# the current Step 3 implementation.

import argparse
import datetime
import fcntl
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

# STAMP: Canonical UTC snapshot timestamp pattern; filters names before treating them as managed
# snapshots.
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
# ROOT: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
ROOT = Path('/@data/mars-received/@data')
# STATE: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
STATE = Path('/@data/mars-received/.replication-state')
# LOCK: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
LOCK = STATE / 'writer.lock'
# ENDPOINT: Restricted remote/privileged transport and endpoint; not general command forwarding.
ENDPOINT = '/usr/local/libexec/btrfs-native-endpoint'
# SOURCE_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
# RECEIVER_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
RECEIVER_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'



# FUNCTION require: Check a security or consistency precondition; reject immediately rather than
# continuing with unsafe state. Inputs: value, reason.
def require(value, reason):
    if not value:
        raise RuntimeError(reason)



# FUNCTION inspect: Collect validated subvolume identity for a specific timestamp without
# modifying snapshots. Inputs: stamp.
def inspect(stamp):
    result = subprocess.run(['sudo', '-n', ENDPOINT, '--role', 'inspect-receiver', '--snapshot', stamp],
                            capture_output=True, text=True, check=True)
    return json.loads(result.stdout)



# FUNCTION receipt: Read an accepted receiver receipt for a timestamp and verify it is shaped as
# expected. Inputs: stamp.
def receipt(stamp):
    path = STATE / (stamp + '.json')
    if path.is_symlink() or not path.is_file():
        return None
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        value = json.loads(path.read_text())
        if (value.get('schema') != 1 or value.get('snapshot') != stamp or
            value.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
            value.get('source_filesystem_uuid') != SOURCE_FS or
            value.get('receiver_filesystem_uuid') != RECEIVER_FS or
            value.get('destination') != str(ROOT / stamp) or
            value.get('read_only_verified') is not True or
            value.get('source_send_exit') != 0 or value.get('receiver_receive_exit') != 0 or
            not value.get('source_uuid') or value.get('source_uuid') != value.get('received_uuid')):
            return None
        observed = inspect(stamp)
        return value if observed.get('flags') == 'readonly' and observed.get('received_uuid') == value['source_uuid'] else None
    except (ValueError, OSError, subprocess.CalledProcessError, KeyError):
        return None



# FUNCTION check_protected_parent: Verify the designated common parent against stored receipt
# and Btrfs metadata. Inputs: stamp, source_uuid.
def check_protected_parent(stamp, source_uuid):
    """Observe a receiver parent under writer.lock; never authorise deletion.

    The caller must hold the sender's native-push lock and must have established
    a durable source-side protection pin before calling this operation.
    """
    require(isinstance(stamp, str) and STAMP.fullmatch(stamp), 'Invalid protected-parent timestamp')
    require(isinstance(source_uuid, str) and
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', source_uuid),
            'Invalid protected-parent source UUID')
    require(not (STATE / '.receiver-prune-pending.json').exists() and
            not (STATE / '.receiver-prune-pending.json').is_symlink(),
            'Pending receiver prune transaction')
    accepted = receipt(stamp)
    require(accepted is not None and accepted['source_uuid'] == source_uuid,
            'Protected parent receipt or received identity mismatch')
    result = {'snapshot': stamp, 'source_uuid': source_uuid,
              'receiver_verified_under_lock': True, 'source_pin_claimed_by_caller': True,
              'authorizes_prune': False}
    return result



# FUNCTION validate: Validate the candidate, source identity and receiver prerequisites for an
# incoming replication request. Inputs: stamp, uuid, parent, parent_uuid, full, reseed.
def validate(stamp, uuid, parent, parent_uuid, full, reseed):
    require(STAMP.fullmatch(stamp), 'Invalid snapshot')
    require(re.fullmatch(r'[0-9a-f-]{36}', uuid), 'Invalid source UUID')
    require(not (ROOT / stamp).exists() and not (ROOT / stamp).is_symlink(), 'Destination already exists')
    require(not (STATE / (stamp + '.json')).exists(), 'Receipt already exists')
    require(not (reseed and not full), 'Reseed requires full')
    existing = list(STATE.glob('[0-9]*.json'))
    if full:
        require(parent is None and parent_uuid is None, 'Full send must not have parent')
        require(not existing or reseed, 'Existing receipts: explicit reseed required')
    else:
        require(parent and STAMP.fullmatch(parent) and parent < stamp, 'Invalid incremental parent')
        require(parent_uuid and re.fullmatch(r'[0-9a-f-]{36}', parent_uuid), 'Invalid parent UUID')
        old = receipt(parent)
        require(old is not None and old['source_uuid'] == parent_uuid, 'Parent is not a verified accepted receiver')
    return {'snapshot': stamp, 'source_uuid': uuid, 'parent': parent, 'parent_uuid': parent_uuid,
            'action': 'full-baseline' if full else 'incremental'}



# FUNCTION atomic_receipt: Write the completed receive receipt through a temporary file and
# atomic rename so partial state is not accepted. Inputs: data.
def atomic_receipt(data):
    target = STATE / (data['snapshot'] + '.json')
    require(not target.exists() and not target.is_symlink(), 'Receipt collision')
    fd, name = tempfile.mkstemp(prefix='.push-receipt-', dir=STATE)
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        with os.fdopen(fd, 'w') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(data, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, target)
        fd_dir = os.open(STATE, os.O_DIRECTORY)
        try: os.fsync(fd_dir)
        finally: os.close(fd_dir)
    finally:
        if os.path.exists(name): os.unlink(name)
    return target



# FUNCTION main: Parse the allowlisted command interface; validate inputs, acquire required
# locks and dispatch roles.
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--check-protected-parent', action='store_true', help='lock-held receipt verification; never approves deletion')
    parser.add_argument('--snapshot')
    parser.add_argument('--source-uuid')
    parser.add_argument('--parent')
    parser.add_argument('--parent-uuid')
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--reseed', action='store_true')
    parser.add_argument('--accept', action='store_true', help='Read native Btrfs stream from stdin')
    args = parser.parse_args()
    require(os.geteuid() != 0, 'Must run as unprivileged operator')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for directory in (ROOT, STATE):
        require(directory.is_dir() and not directory.is_symlink(), 'Missing safe repository path')
    require(LOCK.is_file() and not LOCK.is_symlink() and LOCK.stat().st_nlink == 1, 'Unsafe receiver lock')
    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with LOCK.open('r+') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.check_protected_parent:
            require(args.snapshot and args.source_uuid and not any((args.list, args.parent, args.parent_uuid, args.full, args.reseed, args.accept)),
                    'Protected-parent check accepts only snapshot and source UUID')
            print(json.dumps(check_protected_parent(args.snapshot, args.source_uuid), sort_keys=True))
            return
        if args.list:
            require(not any((args.snapshot, args.source_uuid, args.parent, args.parent_uuid, args.full, args.reseed, args.accept)), 'List accepts no transfer arguments')
            values = []
            for path in sorted(STATE.glob('*.json'), reverse=True):
                if STAMP.fullmatch(path.stem):
                    item = receipt(path.stem)
                    if item: values.append({'snapshot': path.stem, 'source_uuid': item['source_uuid']})
            print(json.dumps(values))
            return
        require(args.snapshot and args.source_uuid, 'Snapshot and UUID required')
        plan = validate(args.snapshot, args.source_uuid, args.parent, args.parent_uuid, args.full, args.reseed)
        if not args.accept:
            print(json.dumps(plan))
            return
        # No cleanup on failure; an incomplete destination must be investigated manually.
        command = ['sudo', '-n', ENDPOINT, '--role', 'receiver', '--snapshot', args.snapshot]
        rc = subprocess.run(command, stdin=sys.stdin.buffer).returncode
        require(rc == 0, f'Receive failed (exit={rc}); UNACCEPTED')
        received = inspect(args.snapshot)
        require(received.get('flags') == 'readonly', 'Received snapshot is not read-only')
        require(received.get('received_uuid') == args.source_uuid, 'Received source UUID mismatch')
        record = {'schema': 1, 'transport': 'btrfs-full' if args.full else 'btrfs-incremental',
                  'snapshot': args.snapshot, 'source_uuid': args.source_uuid,
                  'received_uuid': received['received_uuid'], 'parent_snapshot': args.parent,
                  'parent_source_uuid': args.parent_uuid, 'destination': str(ROOT / args.snapshot),
                  'source_filesystem_uuid': SOURCE_FS, 'receiver_filesystem_uuid': RECEIVER_FS,
                  'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'read_only_verified': True, 'source_send_exit': 0, 'receiver_receive_exit': 0}
        target = atomic_receipt(record)
        print('ACCEPTED: ' + str(target), flush=True)


if __name__ == '__main__':
    try: main()
    except (RuntimeError, OSError, ValueError, subprocess.CalledProcessError, BlockingIOError) as exc:
        print('btrfs-native-push-receiver: ' + str(exc), file=sys.stderr)
        sys.exit(1)
