#!/usr/bin/env python3
"""0034 source-initiated Btrfs push. Manual snapshot selection or Step 11.4 --latest scheduling."""

# MODULE GUIDE: Source-initiated native Btrfs snapshot replication controller.  Runs on mars and
# drives a constrained receiver over outbound SSH to backup. Chooses a source snapshot and
# verified common parent, protects the parent against local pruning, and coordinates safe native
# send/receive. Private Step 3 challenge helpers exercise cross-host deletion coordination but
# are NOT a public deletion command or proof that production receiver pruning is enabled.  A
# source lock serializes this controller; pin state protects incremental ancestry; receiver
# receipts identify accepted snapshots. Failure/timeouts must preserve protection rather than
# guess that a remote operation finished.  This file is the older remote-backup role copy;
# document it as deployed legacy code, not as the current Step 3 implementation.

import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import subprocess
import sys

# STAMP: Canonical UTC snapshot timestamp pattern; filters names before treating them as managed
# snapshots.
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
# ENDPOINT: Restricted remote/privileged transport and endpoint; not general command forwarding.
ENDPOINT = '/usr/local/libexec/btrfs-native-endpoint'
# REMOTE: Restricted remote/privileged transport and endpoint; not general command forwarding.
REMOTE = '/usr/local/bin/btrfs-native-push-receiver'
# SSH: Restricted remote/privileged transport and endpoint; not general command forwarding.
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1']
# LOCK: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
LOCK = Path('/media/usb/@snapshots/.native-push.lock')
# SOURCE_PARENT: Pinned filesystem or replication ancestry identity; mismatches must fail
# closed.
SOURCE_PARENT = 'fc4585b5-1649-b94c-bcb6-a9253c9cf080'



# FUNCTION require: Check a security or consistency precondition; reject immediately rather than
# continuing with unsafe state. Inputs: value, message.
def require(value, message):
    if not value:
        raise RuntimeError(message)



# FUNCTION local: Call a specific privileged source endpoint role and decode its structured
# result. Inputs: role, snapshot, expected.
def local(role, snapshot, expected=None):
    args = ['sudo', '-n', ENDPOINT, '--role', role, '--snapshot', snapshot]
    if expected:
        args += ['--expected-uuid', expected]
    return json.loads(subprocess.run(args, capture_output=True, text=True, check=True).stdout)



# FUNCTION local_sources: Ask the source endpoint for managed snapshots rather than trusting
# arbitrary directory names.
def local_sources():
    result = subprocess.run(
        ['sudo', '-n', ENDPOINT, '--role', 'list-source'],
        capture_output=True, text=True, check=True,
    )
    values = json.loads(result.stdout)
    require(isinstance(values, list), 'Invalid local source list')
    return values



# FUNCTION remote: Invoke the constrained remote receiver over the configured outbound SSH
# transport.
def remote(*args):
    return subprocess.run(SSH + [REMOTE] + list(args), capture_output=True, text=True, check=True).stdout



# FUNCTION receiver_values: Parse a receiver response and enforce mandatory typed
# identity/receipt fields.
def receiver_values():
    values = json.loads(remote('--list'))
    require(isinstance(values, list), 'Invalid receiver parent list')
    return values



# FUNCTION choose_latest_source: Select the most recent validated source snapshot for unattended
# invocation.
def choose_latest_source():
    values = local_sources()
    candidates = [item for item in values if isinstance(item, dict) and STAMP.fullmatch(str(item.get('snapshot', '')))]
    require(candidates, 'No valid local source snapshots are available')
    latest = max(candidates, key=lambda item: item['snapshot'])
    require(re.fullmatch(r'[0-9a-f-]{36}', str(latest.get('uuid', ''))), 'Latest source has invalid UUID')
    return latest['snapshot'], latest['uuid']



# FUNCTION choose_parent: Select the best common ancestor whose source UUID agrees with a
# received receipt. Inputs: stamp, values.
def choose_parent(stamp, values=None):
    values = receiver_values() if values is None else values
    require(isinstance(values, list), 'Invalid receiver parent list')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for candidate in sorted(values, key=lambda item: item['snapshot'], reverse=True):
        previous = candidate['snapshot']
        if not STAMP.fullmatch(previous) or previous >= stamp:
            continue
        try:
            info = local('inspect-source', previous)
        except (subprocess.CalledProcessError, OSError, ValueError):
            continue
        if (info.get('flags') == 'readonly' and info.get('parent_uuid') == SOURCE_PARENT and
                info.get('received_uuid') in (None, '-') and info.get('uuid') == candidate['source_uuid']):
            return previous, info['uuid']
    return None, None




# FUNCTION inspect_common_parent: Independently verify the selected parent on both sides before
# an incremental transfer. Inputs: values.
def inspect_common_parent(values=None):
    """Read-only, current candidate common to accepted receiver and local source.

    Only a diagnostic observation. It is NOT a durable deletion approval: the
    sender lock used by main() is released after reporting and source pruning
    could then remove the snapshot. Receiver deletion must not trust this alone.
    """
    values = receiver_values() if values is None else values
    require(isinstance(values, list), 'Invalid receiver parent list')
    candidates = []
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for candidate in values:
        if not isinstance(candidate, dict):
            raise RuntimeError('Invalid receiver candidate')
        stamp = candidate.get('snapshot')
        uuid = candidate.get('source_uuid')
        require(isinstance(stamp, str) and STAMP.fullmatch(stamp), 'Invalid receiver snapshot')
        require(isinstance(uuid, str) and re.fullmatch(r'[0-9a-f-]{36}', uuid), 'Invalid receiver UUID')
        candidates.append((stamp, uuid))
    require(len({stamp for stamp, _ in candidates}) == len(candidates), 'Duplicate receiver snapshot')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for stamp, uuid in sorted(candidates, reverse=True):
        try:
            info = local('inspect-source', stamp)
        except (subprocess.CalledProcessError, OSError, ValueError):
            continue
        if (info.get('flags') == 'readonly' and info.get('parent_uuid') == SOURCE_PARENT and
                info.get('received_uuid') in (None, '-') and info.get('uuid') == uuid):
            return {'snapshot': stamp, 'source_uuid': uuid, 'verified': True,
                    'authorizes_prune': False}
    raise RuntimeError('No verified common replication parent; pruning prohibited')




# FUNCTION protect_common_parent: Persist the chosen source-side parent pin before any operation
# that depends on it. Inputs: values.
def protect_common_parent(values=None):
    """Persistently pin a verified common parent on mars, without authorising prune.

    This intentionally leaves the pin in place. The privileged source endpoint
    serialises its pin update with source pruning via the manager lock. A failed
    follow-up receiver check must not release the pin automatically.
    """
    observed = inspect_common_parent(values)
    stamp, uuid = observed['snapshot'], observed['source_uuid']
    pinned = local('protect-source', stamp)
    require(pinned.get('source_uuid') == uuid, 'Common-parent pin UUID mismatch')
    # Revalidate both ends after source pinning. Any failure leaves the pin
    # installed for operator review; no deletion permission is issued.
    checked = inspect_common_parent()
    require(checked['snapshot'] == stamp and checked['source_uuid'] == uuid,
            'Common-parent identity changed after pinning; source pin retained')
    return {'snapshot': stamp, 'source_uuid': uuid, 'source_pinned': True,
            'receiver_verified_at_check': True, 'authorizes_prune': False}



# FUNCTION prepare_prune_parent: Prepare source protection for a possible receiver-retention
# operation without authorizing deletion.
def prepare_prune_parent():
    """Pin on source, then independently validate receiver under its writer lock.

    This is a non-destructive cross-host readiness check, not a prune lease.
    The durable pin remains until deliberately released by a later protocol.
    """
    pinned = protect_common_parent()
    stamp, uuid = pinned['snapshot'], pinned['source_uuid']
    checked = json.loads(remote('--check-protected-parent', '--snapshot', stamp,
                                '--source-uuid', uuid))
    require(checked.get('snapshot') == stamp and checked.get('source_uuid') == uuid and
            checked.get('receiver_verified_under_lock') is True and
            checked.get('authorizes_prune') is False,
            'Receiver did not verify protected parent under lock; pin retained')
    return {'snapshot': stamp, 'source_uuid': uuid, 'source_pinned': True,
            'receiver_verified_under_lock': True, 'authorizes_prune': False}



# FUNCTION accepted: Interpret receiver acceptance only after verifying the status and agreed
# snapshot identity. Inputs: values, stamp, uuid.
def accepted(values, stamp, uuid):
    return any(item.get('snapshot') == stamp and item.get('source_uuid') == uuid for item in values)



# FUNCTION main: Parse the allowlisted command interface; validate inputs, acquire required
# locks and dispatch roles.
def main():
    parser = argparse.ArgumentParser()
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument('--snapshot')
    selection.add_argument('--latest', action='store_true', help='Push newest valid local snapshot incrementally; never reseed')
    selection.add_argument('--check-common-parent', action='store_true', help='Read-only parent observation; not a prune approval')
    selection.add_argument('--protect-common-parent', action='store_true', help='Persistently pin a verified common parent on mars; not a prune approval')
    selection.add_argument('--prepare-prune-parent', action='store_true', help='pin on mars, validate receiver under lock; no deletion approval')
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--reseed', action='store_true')
    args = parser.parse_args()
    require(os.geteuid() != 0, 'Run as ordinary operator')
    require(not args.reseed or args.full, '--reseed requires --full')
    require(not (args.check_common_parent or args.protect_common_parent or args.prepare_prune_parent) or
            (not args.preflight and not args.full and not args.reseed),
            'Common-parent operations accept no transfer options')
    require(not args.latest or (not args.full and not args.reseed),
            '--latest is incremental-only; establish/reseed a baseline with explicit --snapshot')
    require(LOCK.is_file() and not LOCK.is_symlink() and LOCK.stat().st_nlink == 1, 'Unsafe push lock')
    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with LOCK.open('r+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.check_common_parent:
            print(json.dumps(inspect_common_parent(), sort_keys=True, indent=2))
            return
        if args.protect_common_parent:
            print(json.dumps(protect_common_parent(), sort_keys=True, indent=2))
            return
        if args.prepare_prune_parent:
            print(json.dumps(prepare_prune_parent(), sort_keys=True, indent=2))
            return
        if args.latest:
            snapshot, listed_uuid = choose_latest_source()
        else:
            snapshot, listed_uuid = args.snapshot, None
        require(snapshot is not None and STAMP.fullmatch(snapshot), 'Invalid timestamp')
        current = local('inspect-source', snapshot)
        require(current.get('flags') == 'readonly' and current.get('parent_uuid') == SOURCE_PARENT
                and current.get('received_uuid') in ('-', None), 'Invalid source snapshot')
        uuid = current['uuid']
        require(re.fullmatch(r'[0-9a-f-]{36}', uuid), 'Invalid source UUID')
        if listed_uuid is not None:
            require(uuid == listed_uuid, 'Latest-source UUID changed during selection')
        values = receiver_values()
        if accepted(values, snapshot, uuid):
            print(json.dumps({'source': snapshot, 'source_uuid': uuid, 'parent': None,
                              'action': 'already-accepted', 'dry_run': args.preflight,
                              'receiver': '10.254.22.1:39263'}, indent=2), flush=True)
            return
        parent, parent_uuid = (None, None) if args.full else choose_parent(snapshot, values)
        if args.latest:
            require(parent is not None,
                    '--latest requires an accepted common parent; use explicit --snapshot --full/--reseed for recovery')
        require(parent or args.full or not args.reseed, 'Invalid reseed selection')
        extra = ['--full'] if args.full or not parent else ['--parent', parent, '--parent-uuid', parent_uuid]
        if args.reseed:
            extra += ['--reseed']
        common = ['--snapshot', snapshot, '--source-uuid', uuid] + extra
        # Always ask receiver to validate its own receipts, parent, and destination.
        plan = json.loads(remote(*common))
        require(plan['snapshot'] == snapshot and plan['source_uuid'] == uuid, 'Receiver plan mismatch')
        print(json.dumps({'source': snapshot, 'source_uuid': uuid, 'parent': parent,
                          'action': plan['action'], 'dry_run': args.preflight,
                          'receiver': '10.254.22.1:39263'}, indent=2), flush=True)
        if args.preflight:
            return
        candidate = local('protect-source', snapshot)
        require(candidate['source_uuid'] == uuid, 'Candidate protection UUID mismatch')
        if parent:
            pinned = local('protect-source', parent)
            require(pinned['source_uuid'] == parent_uuid, 'Parent protection UUID mismatch')
        send = ['sudo', '-n', ENDPOINT, '--role', 'incremental-source' if parent else 'source', '--snapshot', snapshot]
        if parent:
            send += ['--parent', parent]
        with subprocess.Popen(send, stdout=subprocess.PIPE) as sender:
            with subprocess.Popen(SSH + [REMOTE] + common + ['--accept'], stdin=sender.stdout) as receiver:
                sender.stdout.close()
                receiver_rc = receiver.wait()
                send_rc = sender.wait()
        require(send_rc == 0 and receiver_rc == 0,
                f'Btrfs send/receive failed (send={send_rc}, receive={receiver_rc}); candidate stays protected')
        # A receiver receipt is authoritative; do not release parent on an absent receipt.
        listing = receiver_values()
        require(accepted(listing, snapshot, uuid),
                'Receiver has not accepted candidate; both snapshots stay protected')
        print('ACCEPTED: ' + snapshot, flush=True)
        if parent:
            try:
                local('release-source', parent, parent_uuid)
            except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
                print('WARNING: previous parent remains protected: ' + str(exc), file=sys.stderr)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, subprocess.CalledProcessError, BlockingIOError, KeyError) as exc:
        print('btrfs-native-push: ' + str(exc), file=sys.stderr)
        sys.exit(1)
