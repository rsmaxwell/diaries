#!/usr/bin/env python3
"""0034 Step 10.3: constrained privileged Btrfs send/receive endpoints.

Installed independently on mars (--role source) and backup (--role receiver).
No generic command forwarding; both roles validate pinned filesystem identities.
Step 11.4 also exposes a constrained read-only source listing for unattended selection.
"""

# MODULE GUIDE: Constrained privileged endpoint for native Btrfs snapshot replication.  The
# source-side role runs on mars; the receiving role runs on backup. Each operation is chosen
# from a fixed allowlist and checks path, filesystem and snapshot identity instead of forwarding
# arbitrary shell commands. The endpoint is a privileged boundary: callers cannot select
# arbitrary paths or programs.  The receiver's writer lock and source protection state are
# different safety mechanisms: one serializes receiver writes, the other prevents pruning the
# common parent while it may still be used for incremental send/receive.  This file is the older
# remote-backup role copy; document it as deployed legacy code, not as the current Step 3
# implementation.

import argparse
import fcntl
import json
import tempfile
import stat
import os
from pathlib import Path
import re
import subprocess
import sys

# STAMP: Canonical UTC snapshot timestamp pattern; filters names before treating them as managed
# snapshots.
STAMP = re.compile(r"^[0-9]{8}-[0-9]{6}Z$")
# SOURCE_DIR: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
SOURCE_DIR = Path('/media/usb/@snapshots/@data')
# SOURCE_MOUNT: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
SOURCE_MOUNT = Path('/media/usb')
# RECEIVE_DIR: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
RECEIVE_DIR = Path('/@data/mars-received/@data')
# RECEIVE_MOUNT: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
RECEIVE_MOUNT = Path('/')
# SOURCE_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
# RECEIVE_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
RECEIVE_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'
# PROTECTION: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
PROTECTION = Path('/media/usb/@snapshots/.replication-protection.json')
# MANAGER_LOCK: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
# EXPECTED_ORIGIN: Pinned filesystem or replication ancestry identity; mismatches must fail
# closed.
EXPECTED_ORIGIN = 'fc4585b5-1649-b94c-bcb6-a9253c9cf080'



# FUNCTION run: Invoke a fixed subprocess and return captured output; failures propagate to the
# caller.
def run(*args):
    return subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout



# FUNCTION require: Check a security or consistency precondition; reject immediately rather than
# continuing with unsafe state. Inputs: condition, message.
def require(condition, message):
    if not condition:
        raise RuntimeError(message)



# FUNCTION safe_path: Validate that the requested path stays within the fixed managed Btrfs
# directories. Inputs: path, parent.
def safe_path(path, parent):
    require(path.parent == parent, 'Unexpected location')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for item in (parent, *reversed(parent.parents)):
        if item == Path('/'):
            continue
        require(item.is_dir() and not item.is_symlink(), f'Unsafe directory {item}')
    if path.exists() or path.is_symlink():
        require(not path.is_symlink(), f'Symlink forbidden: {path}')



# FUNCTION show: Read Btrfs subvolume metadata (UUID, parent/received identity and flags) for
# identity checks. Inputs: path.
def show(path):
    output = run('btrfs', 'subvolume', 'show', str(path))
    result = {}
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for line in output.splitlines():
        if ':' in line:
            key, value = line.strip().split(':', 1)
            result[key.strip()] = value.strip()
    return result



# FUNCTION fs_check: Check the filesystem/mount identity before any privileged Btrfs operation.
# Inputs: path, expected.
def fs_check(path, expected):
    output = run('btrfs', 'filesystem', 'show', str(path))
    require(re.search(r'\buuid:\s*' + re.escape(expected) + r'\b', output, re.I) is not None,
            'Wrong Btrfs filesystem UUID')



# FUNCTION source: Resolve the named source snapshot only after checking its timestamp and
# managed location. Inputs: snapshot, parent_stamp.
def source(snapshot, parent_stamp=None):
    parent = SOURCE_DIR
    path = parent / snapshot
    safe_path(path, parent)
    fs_check(SOURCE_MOUNT, SOURCE_FS)
    require(path.is_dir(), 'Source snapshot absent')
    info = show(path)
    require(info.get('Flags') == 'readonly', 'Source must be read-only')
    require(info.get('Parent UUID') == EXPECTED_ORIGIN, 'Source is not @data snapshot')
    require(info.get('Received UUID') in ('-', None), 'Unexpected received snapshot')
    # Send binary stream straight to stdout; never print text on stdout.
    command = ['btrfs', 'send']
    if parent_stamp is not None:
        require(STAMP.fullmatch(parent_stamp) is not None and parent_stamp < snapshot,
                'Invalid incremental parent timestamp')
        parent_path = parent / parent_stamp
        safe_path(parent_path, parent)
        require(parent_path.is_dir(), 'Incremental parent absent')
        parent_info = show(parent_path)
        require(parent_info.get('Flags') == 'readonly', 'Parent must be read-only')
        require(parent_info.get('Parent UUID') == EXPECTED_ORIGIN, 'Parent has unexpected lineage')
        require(parent_info.get('Received UUID') in ('-', None), 'Unexpected parent received lineage')
        command.extend(['-p', str(parent_path)])
    command.append(str(path))
    os.execvp('btrfs', command)



# FUNCTION inspect: Collect validated subvolume identity for a specific timestamp without
# modifying snapshots. Inputs: snapshot, role.
def inspect(snapshot, role):
    parent = SOURCE_DIR if role == 'inspect-source' else RECEIVE_DIR
    fs_check(SOURCE_MOUNT if role == 'inspect-source' else RECEIVE_MOUNT,
             SOURCE_FS if role == 'inspect-source' else RECEIVE_FS)
    path = parent / snapshot
    safe_path(path, parent)
    require(path.is_dir(), 'Snapshot absent')
    info = show(path)
    require(info.get('Flags') == 'readonly', 'Snapshot not read-only')
    if role == 'inspect-source':
        require(info.get('Parent UUID') == EXPECTED_ORIGIN, 'Unexpected source lineage')
    import json
    print(json.dumps({'uuid': info.get('UUID'), 'received_uuid': info.get('Received UUID'), 'flags': info.get('Flags'), 'parent_uuid': info.get('Parent UUID')}))



# FUNCTION receive: Accept a constrained Btrfs receive stream into the configured receiver tree.
# Inputs: snapshot.
def receive(snapshot):
    parent = RECEIVE_DIR
    path = parent / snapshot
    safe_path(path, parent)
    fs_check(RECEIVE_MOUNT, RECEIVE_FS)
    require(not path.exists() and not path.is_symlink(), 'Destination already exists')
    # btrfs receive creates a subvolume named by the send stream; for this
    # endpoint source names must be exact timestamps. A failure leaves an
    # unaccepted destination for explicit operator inspection (no auto delete).
    os.execvp('btrfs', ['btrfs', 'receive', str(parent)])





# FUNCTION list_source: List eligible source snapshot timestamps from the fixed managed source
# collection.
def list_source():
    fs_check(SOURCE_MOUNT, SOURCE_FS)
    require(SOURCE_DIR.is_dir() and not SOURCE_DIR.is_symlink(), 'Source snapshot directory missing/unsafe')
    values = []
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for path in sorted(SOURCE_DIR.iterdir(), key=lambda item: item.name, reverse=True):
        if not STAMP.fullmatch(path.name) or not path.is_dir() or path.is_symlink():
            continue
        safe_path(path, SOURCE_DIR)
        try:
            info = show(path)
        except subprocess.CalledProcessError:
            continue
        if (info.get('Flags') == 'readonly' and info.get('Parent UUID') == EXPECTED_ORIGIN and
                info.get('Received UUID') in ('-', None) and info.get('UUID')):
            values.append({'snapshot': path.name, 'uuid': info.get('UUID')})
    print(json.dumps(values))



# FUNCTION protection_update: Persist source snapshot pin state under the manager lock using
# guarded atomic replacement. Inputs: stamp, operation, expected_uuid.
def protection_update(stamp, *, operation, expected_uuid=None):
    """Serialize with 0035 prune using its existing manager lock."""
    require(PROTECTION.parent.is_dir() and not PROTECTION.parent.is_symlink(), 'Unsafe protection parent')
    require(MANAGER_LOCK.exists() and not MANAGER_LOCK.is_symlink(), 'Snapshot manager lock absent')
    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with MANAGER_LOCK.open('r+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        require(PROTECTION.is_file() and not PROTECTION.is_symlink(), 'Protection state missing')
        metadata = PROTECTION.stat()
        require(metadata.st_uid == 0 and not metadata.st_mode & 0o022, 'Unsafe protection permissions')
        state = json.loads(PROTECTION.read_text())
        require(state.get('schema') == 1 and isinstance(state.get('protected'), dict), 'Bad protection state')
        pins = state['protected']
        if operation == 'protect':
            source_path = SOURCE_DIR / stamp
            safe_path(source_path, SOURCE_DIR)
            require(source_path.is_dir(), 'Source snapshot absent')
            fs_check(SOURCE_MOUNT, SOURCE_FS)
            info = show(source_path)
            require(info.get('Flags') == 'readonly' and info.get('Parent UUID') == EXPECTED_ORIGIN,
                    'Invalid protected source')
            value = info.get('UUID')
            require(bool(value) and (stamp not in pins or pins[stamp] == value), 'Protection UUID conflict')
            pins[stamp] = value
        else:
            require(expected_uuid and pins.get(stamp) == expected_uuid, 'Release requires matching protected UUID')
            del pins[stamp]
        fd, temp = tempfile.mkstemp(prefix='.replication-protection-', dir=PROTECTION.parent)
        try:
            with os.fdopen(fd, 'w') as output:
                os.fchmod(output.fileno(), 0o600)
                json.dump(state, output, indent=2, sort_keys=True)
                output.write('\n')
                output.flush()
                os.fsync(output.fileno())
            os.replace(temp, PROTECTION)
            directory_fd = os.open(PROTECTION.parent, os.O_DIRECTORY)
            try: os.fsync(directory_fd)
            finally: os.close(directory_fd)
        finally:
            if os.path.exists(temp): os.unlink(temp)
        print(json.dumps({'operation': operation, 'snapshot': stamp,
                          'source_uuid': pins.get(stamp, expected_uuid)}))


# FUNCTION main: Parse the allowlisted command interface; validate inputs, acquire required
# locks and dispatch roles.
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--role', required=True, choices=('source', 'incremental-source', 'receiver', 'inspect-source', 'inspect-receiver', 'protect-source', 'release-source', 'list-source'))
    parser.add_argument('--snapshot')
    parser.add_argument('--parent')
    parser.add_argument('--expected-uuid')
    args = parser.parse_args()
    require(os.geteuid() == 0, 'Requires root')
    if args.role == 'list-source':
        require(args.snapshot is None and args.parent is None and args.expected_uuid is None,
                'list-source accepts no snapshot arguments')
        list_source()
        return
    require(args.snapshot is not None and STAMP.fullmatch(args.snapshot) is not None, 'Invalid snapshot name')
    require((args.parent is not None) == (args.role == 'incremental-source'),
            'Parent only permitted for incremental-source')
    require((args.expected_uuid is not None) == (args.role == 'release-source'), 'Expected UUID only permitted on release')
    if args.role == 'protect-source':
        protection_update(args.snapshot, operation='protect')
    elif args.role == 'release-source':
        protection_update(args.snapshot, operation='release', expected_uuid=args.expected_uuid)
    elif args.role == 'source':
        source(args.snapshot)
    elif args.role == 'incremental-source':
        source(args.snapshot, args.parent)
    elif args.role == 'receiver':
        receive(args.snapshot)
    else:
        inspect(args.snapshot, args.role)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, subprocess.CalledProcessError, OSError) as exc:
        print(f'btrfs-native-endpoint: {exc}', file=sys.stderr)
        sys.exit(1)
