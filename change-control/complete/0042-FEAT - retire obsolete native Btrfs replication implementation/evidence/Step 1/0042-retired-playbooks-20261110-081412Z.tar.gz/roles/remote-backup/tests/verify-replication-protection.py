#!/usr/bin/env python3
"""Offline regression: protection state must fail closed and be maintained by push."""
import importlib.util
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace

base = Path(__file__).resolve().parents[2]
p = base / 'snapshots/files/btrfs-snapshot-manager.py'
spec = importlib.util.spec_from_file_location('snapshot_manager', p)
import sys
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as directory:
    path = Path(directory) / 'protection.json'
    config = mod.Config(snapshot_root=Path(directory), lock_path=Path('/run/lock/x'), writer_lock_path=None,
                        sources=(), retention=None, verification=None,
                        replication_protection_required=True, replication_protection_file=path)
    try:
        mod.replication_pins(config)
        raise AssertionError('Missing protection file must block prune')
    except mod.SnapshotError:
        pass
    path.write_text('not valid json')
    try:
        mod.replication_pins(config)
        raise AssertionError('Malformed file must block prune')
    except mod.SnapshotError:
        pass
    stamp='20261009-170001Z'
    path.write_text(json.dumps({'schema':1,'protected':{stamp:'052c9376-0616-8b4a-9d28-f757b86fdec8'}}))
    # The test runs as an ordinary user on mango, unlike the root-owned
    # production protection file. Check that real non-root ownership is rejected,
    # then emulate only the root-owned metadata for content-validation tests.
    if path.stat().st_uid != 0:
        try:
            mod.replication_pins(config)
            raise AssertionError('Non-root-owned protection state must block prune')
        except mod.SnapshotError:
            pass

    real_stat = Path.stat
    def trusted_stat(self, *args, **kwargs):
        result = real_stat(self, *args, **kwargs)
        if self == path:
            return SimpleNamespace(st_uid=0, st_mode=result.st_mode & ~0o022)
        return result

    with patch.object(Path, 'stat', trusted_stat):
        assert mod.replication_pins(config) == {stamp}
        path.write_text(json.dumps({'schema':1,'protected':{'../../outside':'052c9376-0616-8b4a-9d28-f757b86fdec8'}}))
        try:
            mod.replication_pins(config)
            raise AssertionError('Unsafe stamp must block prune')
        except mod.SnapshotError:
            pass
push=(base/'remote-backup/files/btrfs-native-push.py').read_text()
endpoint=(base/'remote-backup/files/btrfs-native-endpoint.py').read_text()
assert "local('protect-source', snapshot)" in push
assert "local('protect-source', parent)" in push
assert "local('release-source', parent, parent_uuid)" in push
assert "fcntl.flock(lock, fcntl.LOCK_EX)" in endpoint
assert "--reseed" in push
print('PASS: missing/invalid protection fails closed and push pin lifecycle is wired')
