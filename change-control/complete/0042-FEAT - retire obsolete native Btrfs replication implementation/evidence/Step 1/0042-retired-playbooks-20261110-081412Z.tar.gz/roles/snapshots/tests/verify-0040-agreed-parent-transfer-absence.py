#!/usr/bin/env python3
import importlib.util
import tempfile
import unittest
from pathlib import Path

path=Path(__file__).resolve().parents[1]/'files/btrfs-agreed-parent-transfer-absence.py'
spec=importlib.util.spec_from_file_location('absence_test',path); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
A={'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B={'timestamp':'20261030-170009Z','uuid':'a9b78fb9-4da6-cf4f-b242-13909f574193'}
S={'schema':1,'established':A,'pending':B,'previous':None}
class State:
 def snapshot(self,item):
  if set(item)!={'timestamp','uuid'}: raise ValueError('identity')
 def validate(self,value):
  if set(value)!={'schema','established','pending','previous'}:raise ValueError('state')
class Cases(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); root=Path(self.tmp.name);self.snap=root/'snap';self.receipt=root/'receipt';self.snap.mkdir();self.receipt.mkdir()
 def tearDown(self):self.tmp.cleanup()
 def run_check(self,state=S):return m.verify(A,B,state,state=State(),snapshot_dir=self.snap,receipt_dir=self.receipt)
 def test_absent_pass(self):
  v=self.run_check();self.assertTrue(v['destination_absent']);self.assertFalse(v['authorizes_transfer'])
 def test_pending_mismatch(self):
  with self.assertRaises(RuntimeError):self.run_check(dict(S,pending=None))
 def test_existing_directory(self):
  (self.snap/B['timestamp']).mkdir()
  with self.assertRaisesRegex(RuntimeError,'already exists'):self.run_check()
 def test_existing_receipt(self):
  (self.receipt/(B['timestamp']+'.json')).write_text('{}')
  with self.assertRaisesRegex(RuntimeError,'already exists'):self.run_check()
 def test_broken_link(self):
  (self.snap/B['timestamp']).symlink_to('/missing')
  with self.assertRaises(RuntimeError):self.run_check()
 def test_partial_artifact(self):
  (self.snap/(B['timestamp']+'.partial')).mkdir()
  with self.assertRaisesRegex(RuntimeError,'artifacts'):self.run_check()
 def test_prune_journal(self):
  (self.receipt/'.receiver-prune-pending.json').write_text('x')
  with self.assertRaisesRegex(RuntimeError,'journal'):self.run_check()
 def test_previous_refused(self):
  with self.assertRaises(RuntimeError):self.run_check(dict(S,previous=A))
if __name__=='__main__':unittest.main(verbosity=2)
