#!/usr/bin/python3
import importlib.util
import json
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parents[1] / 'files'
spec = importlib.util.spec_from_file_location('inspect_3h4f', BASE / 'btrfs-agreed-parent-inspection.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
T = '20261031-030015Z'
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp': T, 'uuid': '11111111-2222-3333-4444-555555555555'}
S = {'schema': 1, 'established': A, 'pending': None, 'previous': None}

def reply(state=S, transaction=T, status='success', operation='get-state'):
    return json.dumps({'schema': 1, 'operation': operation, 'transaction_id': transaction,
                       'status': status, 'state': state})

class Tests(unittest.TestCase):
    def test_match(self):
        v = m.inspect(local_state=S, receiver_reply=reply(), transaction_id=T)
        self.assertEqual(v['status'], 'matched')
        self.assertFalse(v['authorizes_transition'])
        self.assertFalse(v['authorizes_prune'])
    def test_diverged(self):
        other = dict(S, pending=B)
        self.assertEqual(m.inspect(local_state=S, receiver_reply=reply(other), transaction_id=T)['status'], 'diverged')
    def test_nonzero(self):
        with self.assertRaises(Exception):m.inspect(local_state=S, receiver_reply=reply(), transaction_id=T, receiver_exit_code=1)
    def test_stale_transaction(self):
        with self.assertRaises(Exception):m.inspect(local_state=S, receiver_reply=reply(transaction='20261028-150014Z'), transaction_id=T)
    def test_wrong_operation(self):
        with self.assertRaises(Exception):m.inspect(local_state=S, receiver_reply=reply(operation='promote'), transaction_id=T)
    def test_false_success(self):
        with self.assertRaises(Exception):m.inspect(local_state=S, receiver_reply=reply(status='failure'), transaction_id=T)
    def test_invalid_json(self):
        with self.assertRaises(Exception):m.inspect(local_state=S, receiver_reply='{', transaction_id=T)
    def test_invalid_state(self):
        with self.assertRaises(Exception):m.inspect(local_state=dict(S, schema=2), receiver_reply=reply(), transaction_id=T)
    def test_no_io(self):
        self.assertFalse(hasattr(m, 'main'))
        self.assertFalse(hasattr(m, 'request'))

if __name__ == '__main__':
    unittest.main(verbosity=2)
