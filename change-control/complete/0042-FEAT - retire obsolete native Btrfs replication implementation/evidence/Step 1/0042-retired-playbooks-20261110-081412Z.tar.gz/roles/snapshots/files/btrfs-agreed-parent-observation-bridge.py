#!/usr/bin/python3
"""0040 3H.4g dormant observation bridge. No state mutation or authorisation.

Accepts two independently captured, fixed-endpoint outputs. The caller must
implement SSH authentication, source locking and privileged read-only commands.
"""
import json
import importlib.util
from pathlib import Path


def _state_module():
    path = Path(__file__).with_name('btrfs-agreed-parent-state.py')
    spec = importlib.util.spec_from_file_location('bridge_state', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class ObservationError(RuntimeError):
    pass


def inspect(source_state, receiver_stdout, *, ssh_exit):
    if type(ssh_exit) is not int or ssh_exit != 0:
        raise ObservationError('SSH failed or result uncertain')
    if type(receiver_stdout) is not str or not 0 < len(receiver_stdout.encode('utf-8')) <= 65536:
        raise ObservationError('missing or oversized receiver response')
    state = _state_module()
    state.validate(source_state)
    try:
        result = json.loads(receiver_stdout)
    except (ValueError, TypeError) as exc:
        raise ObservationError('invalid receiver JSON') from exc
    if type(result) is not dict or set(result) != {'schema','host','state','verified','authorizes_transition','authorizes_prune'}:
        raise ObservationError('unexpected receiver observation fields')
    if type(result['schema']) is not int or result['schema'] != 1 or result['host'] != 'backup':
        raise ObservationError('wrong receiver identity')
    if result['authorizes_transition'] is not False or result['authorizes_prune'] is not False:
        raise ObservationError('unsafe authority claimed')
    state.validate(result['state'])
    expected = [{'timestamp': k, 'uuid': v} for k,v in sorted({item['timestamp']: item['uuid'] for item in (result['state']['established'], result['state']['previous']) if item is not None}.items())]
    if type(result['verified']) is not list or result['verified'] != expected:
        raise ObservationError('receiver protected snapshot evidence incomplete')
    return {'schema':1, 'comparison': 'matched' if source_state == result['state'] else 'diverged',
            'source': source_state, 'receiver': result['state'],
            'authorizes_transition':False,'authorizes_prune':False}
