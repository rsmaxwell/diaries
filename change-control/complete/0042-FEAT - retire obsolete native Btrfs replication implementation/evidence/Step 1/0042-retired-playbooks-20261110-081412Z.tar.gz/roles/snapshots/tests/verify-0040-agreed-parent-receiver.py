#!/usr/bin/python3
"""Disposable read-only receiver endpoint core tests; no Btrfs changes."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1] / 'files'

def load(name):
    spec = importlib.util.spec_from_file_location('test_0040_' + name, BASE / ('btrfs-agreed-parent-' + name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

receiver = load('receiver')
state = load('state')
UUID = '01234567-89ab-cdef-0123-456789abcdef'
STAMP = '20261030-130000Z'

class Regression(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.records = root / 'receipts'; self.records.mkdir(mode=0o700)
        self.snapshots = root / 'snapshots'; self.snapshots.mkdir(mode=0o700)
        (self.snapshots / STAMP).mkdir()
        self.manager = root / 'manager.lock'; self.manager.touch(mode=0o600)
        self.writer = self.records / 'writer.lock'; self.writer.touch(mode=0o600)
        self.state_path = root / 'state.json'
        state.save(self.state_path, state.initial({'timestamp': STAMP, 'uuid': UUID}))
        self.receipt = {'schema': 1, 'snapshot': STAMP, 'source_uuid': UUID,
                        'received_uuid': UUID, 'destination': str(self.snapshots / STAMP),
                        'source_filesystem_uuid': 'source-fs', 'receiver_filesystem_uuid': 'receiver-fs',
                        'transport': 'btrfs-incremental', 'read_only_verified': True,
                        'source_send_exit': 0, 'receiver_receive_exit': 0}
        self.write_receipt()
    def write_receipt(self):
        (self.records / (STAMP + '.json')).write_text(json.dumps(self.receipt))
    def call(self, **overrides):
        kw = dict(state_path=self.state_path, receipt_dir=self.records, snapshot_dir=self.snapshots,
                  manager_lock=self.manager, writer_lock=self.writer, source_fs='source-fs',
                  receiver_fs='receiver-fs', inspect=lambda s: {'flags': 'readonly', 'received_uuid': UUID})
        kw.update(overrides)
        return receiver.observe(**kw)
    def test_valid_read_only_observation(self):
        value = self.call()
        self.assertEqual(value['verified'], [{'timestamp': STAMP, 'uuid': UUID}])
        self.assertFalse(value['authorizes_prune'])
        self.assertFalse(value['authorizes_transition'])
    def test_missing_state_fails_closed(self):
        self.state_path.unlink()
        with self.assertRaises(receiver.StateError): self.call()
    def test_bad_receipt_fails_closed(self):
        self.receipt['source_uuid'] = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; self.write_receipt()
        with self.assertRaises(receiver.StateError): self.call()
    def test_wrong_received_uuid_fails_closed(self):
        with self.assertRaises(receiver.StateError): self.call(inspect=lambda s: {'flags': 'readonly', 'received_uuid': 'wrong'})
    def test_pending_deletion_fails_closed(self):
        (self.records / '.receiver-prune-pending.json').touch()
        with self.assertRaises(receiver.StateError): self.call()
    def test_unsafe_lock_fails_closed(self):
        self.writer.unlink(); self.writer.symlink_to(self.manager)
        with self.assertRaises(receiver.StateError): self.call()
    def test_missing_snapshot_fails_closed(self):
        (self.snapshots / STAMP).rmdir()
        with self.assertRaises(receiver.StateError): self.call()
    def test_pending_unreceived_requires_no_receipt_or_snapshot(self):
        b = {'timestamp': '20261030-140000Z', 'uuid': 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'}
        state.save(self.state_path, state.validate(dict(state.load(self.state_path), pending=b)))
        result = self.call(inspect=lambda stamp: {'flags': 'readonly', 'received_uuid': UUID} if stamp == STAMP else self.fail('pending must not be inspected'))
        self.assertEqual(result['state']['pending'], b)
        self.assertEqual(result['verified'], [{'timestamp': STAMP, 'uuid': UUID}])
        self.assertFalse(result['authorizes_transition'])
        self.assertFalse(result['authorizes_prune'])
    def test_established_receipt_still_mandatory_with_pending(self):
        b = {'timestamp': '20261030-140000Z', 'uuid': 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'}
        state.save(self.state_path, state.validate(dict(state.load(self.state_path), pending=b)))
        (self.records / (STAMP + '.json')).unlink()
        with self.assertRaises(receiver.StateError): self.call()
    def test_missing_previous_parent_fails_closed(self):
        other = {'timestamp':'20261029-130000Z','uuid':'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'}
        state.save(self.state_path, state.validate(dict(state.load(self.state_path), previous=other)))
        with self.assertRaises(receiver.StateError): self.call()

if __name__ == '__main__': unittest.main(verbosity=2)
