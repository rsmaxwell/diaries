#!/usr/bin/python3
"""Offline contract tests: no SSH, Btrfs, snapshots or production mutation."""
import importlib.util
import pathlib
import sys
import unittest

FILES = pathlib.Path(__file__).resolve().parents[1] / 'files'
# Accepted 04L module must exist in the Playbooks checkout for these tests.
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

framing = load(FILES / 'btrfs-agreed-parent-completion-framing.py', 'framing')
protocol = load(FILES / 'btrfs-agreed-parent-sender-completion-protocol.py', 'completion_protocol')
A = {'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp':'20261030-170009Z','uuid':'a9b78fb9-4da6-cf4f-b242-13909f574193'}

class Cases(unittest.TestCase):
    def session(self):
        return framing.CompletionSession(A, B, protocol, authenticated_channel=True)

    def valid_reply(self, session):
        challenge = framing.decode(session.challenge_frame())
        return framing.encode(protocol.completion_request(challenge, exit_status=0, stream_finished=True))

    def test_framed_roundtrip(self):
        self.assertEqual(framing.decode(framing.encode({'a':1})), {'a':1})

    def test_length_mismatch(self):
        with self.assertRaises(framing.FrameRefused): framing.decode(framing.encode({'a':1}) + b'x')

    def test_oversize(self):
        with self.assertRaises(framing.FrameRefused): framing.encode({'blob':'x'*5000})

    def test_duplicate_fields(self):
        with self.assertRaises(framing.FrameRefused): framing.decode(b'\x00\x00\x00\x0d'+b'{"x":1,"x":2}')

    def test_invalid_utf8(self):
        with self.assertRaises(framing.FrameRefused): framing.decode(b'\x00\x00\x00\x01\xff')

    def test_no_auth_channel(self):
        with self.assertRaises(framing.FrameRefused): framing.CompletionSession(A,B,protocol)

    def test_unique_nonce(self):
        self.assertNotEqual(framing.decode(self.session().challenge_frame())['nonce'],framing.decode(self.session().challenge_frame())['nonce'])

    def test_completed_once(self):
        session=self.session(); reply=self.valid_reply(session)
        result=session.complete(reply,receiver_locks_held=True,authenticated_channel=True)
        self.assertFalse(result['receipt_written'])
        with self.assertRaises(framing.FrameRefused): session.complete(reply,receiver_locks_held=True,authenticated_channel=True)

    def test_wrong_nonce_consumes_session(self):
        session=self.session(); challenge=framing.decode(session.challenge_frame())
        bad=protocol.completion_request(challenge,exit_status=0,stream_finished=True);bad['nonce']='a'*64
        with self.assertRaises(protocol.CompletionRefused): session.complete(framing.encode(bad),receiver_locks_held=True,authenticated_channel=True)
        with self.assertRaises(framing.FrameRefused): session.complete(self.valid_reply(session),receiver_locks_held=True,authenticated_channel=True)

    def test_failed_sender(self):
        session=self.session(); challenge=framing.decode(session.challenge_frame())
        with self.assertRaises(protocol.CompletionRefused): session.complete(framing.encode(protocol.completion_request(challenge,exit_status=1,stream_finished=True)),receiver_locks_held=True,authenticated_channel=True)

    def test_lost_locks_consumes_challenge(self):
        session=self.session(); reply=self.valid_reply(session)
        with self.assertRaises(framing.FrameRefused): session.complete(reply,authenticated_channel=True)
        with self.assertRaises(framing.FrameRefused): session.complete(reply,receiver_locks_held=True,authenticated_channel=True)

    def test_no_executable_entrypoint(self):
        self.assertFalse(hasattr(framing, 'main'))

if __name__=='__main__': unittest.main(verbosity=2)
