#!/usr/bin/python3
"""0040-FEAT: dormant sender-side verification of receiver SSH replies.

This module does not execute a replication transaction or mutate state.
The caller supplies a fixed command; an executable coordinator must separately
hold source locks, validate identities, and reconcile ambiguous outcomes.
"""
import json
import re
import subprocess

STAMP = re.compile(r"^[0-9]{8}-[0-9]{6}Z$")
UUID = re.compile(r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
OPS = frozenset(('get-state', 'prepare', 'promote', 'acknowledge-previous'))

class ProtocolError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise ProtocolError(message)


def identity(value):
    require(type(value) is dict and set(value) == {'timestamp', 'uuid'}, 'invalid snapshot fields')
    require(type(value['timestamp']) is str and STAMP.fullmatch(value['timestamp']), 'invalid timestamp')
    require(type(value['uuid']) is str and UUID.fullmatch(value['uuid']), 'invalid UUID')
    return value


def state(value):
    require(type(value) is dict and set(value) == {'schema', 'established', 'pending', 'previous'}, 'invalid state fields')
    require(type(value['schema']) is int and value['schema'] == 1, 'invalid state schema')
    require(value['established'] is not None, 'missing established parent')
    stamps = []
    for key in ('established', 'pending', 'previous'):
        if value[key] is not None:
            identity(value[key]); stamps.append(value[key]['timestamp'])
    require(len(stamps) == len(set(stamps)), 'duplicate parent snapshot')
    require(value['pending'] is None or value['previous'] is None, 'invalid transition state')
    return value


def validate_response(stdout, *, operation, transaction_id, expected_state):
    """Check success JSON in addition to the separately checked SSH exit status.

    No successful response is trusted without exact postcondition equality.
    """
    require(operation in OPS, 'unsupported operation')
    require(type(transaction_id) is str and STAMP.fullmatch(transaction_id), 'invalid transaction ID')
    state(expected_state)
    require(type(stdout) is str and 0 < len(stdout) <= 65536, 'missing/oversized JSON response')
    try:
        result = json.loads(stdout)
    except (ValueError, TypeError) as exc:
        raise ProtocolError('malformed response JSON') from exc
    require(type(result) is dict and set(result) == {'schema', 'operation', 'transaction_id', 'status', 'state'}, 'unexpected response fields')
    require(type(result['schema']) is int and result['schema'] == 1, 'invalid response schema')
    require(result['operation'] == operation and result['transaction_id'] == transaction_id, 'stale or unrelated response')
    require(result['status'] == 'success', 'receiver did not report success')
    require(state(result['state']) == expected_state, 'receiver postcondition mismatch')
    return result


def request(command, *, operation, transaction_id, expected_state, run=subprocess.run, timeout=30):
    """Fixed-command transport adapter; never retries ambiguous failures automatically.

    A nonzero exit (even with valid JSON), timeout, missing output, or mismatched
    state is an error. Caller must observe remote durable state after ambiguity.
    """
    require(type(command) in (list, tuple) and bool(command) and
            all(type(part) is str and part for part in command), 'invalid command')
    require(type(timeout) in (int, float) and not isinstance(timeout, bool) and 0 < timeout <= 120,
            'invalid timeout')
    try:
        completed = run(list(command), capture_output=True, text=True, timeout=timeout, check=False)
    except (subprocess.TimeoutExpired, OSError) as exc:
        raise ProtocolError('transport uncertain; reconcile receiver state') from exc
    require(type(completed.returncode) is int and completed.returncode == 0,
            'receiver SSH command failed; reconcile receiver state')
    return validate_response(completed.stdout, operation=operation,
                             transaction_id=transaction_id, expected_state=expected_state)
