#!/usr/bin/python3
"""Integration 04D receiver attestation contract regression."""
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest

file = Path(__file__).resolve().parents[1] / 'files/btrfs-agreed-parent-transfer-attestation.py'
spec = importlib.util.spec_from_file_location('attest04d', file)
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
A = {'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp':'20261030-170009Z','uuid':'a9b78fb9-4da6-cf4f-b242-13909f574193'}

class Tests(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        base = Path(t.name)
        self.old = a.STATE_DIR,a.SNAPSHOTS,a.STATE_PATH,a.MANAGER_LOCK,a.WRITER_LOCK
        self.addCleanup(self.restore)
        a.STATE_DIR,a.SNAPSHOTS = base/'state',base/'snapshots'
        a.STATE_DIR.mkdir(); a.SNAPSHOTS.mkdir()
        a.STATE_PATH,a.MANAGER_LOCK,a.WRITER_LOCK = a.STATE_DIR/'.agreed-parent.json',base/'manager.lock',a.STATE_DIR/'writer.lock'
        self.current = {'schema':1,'established':A,'pending':B,'previous':None}
        self.evidence = {i['timestamp']:{'flags':'readonly','received_uuid':i['uuid']} for i in (A,B)}
        for i in (A,B):
            (a.SNAPSHOTS/i['timestamp']).mkdir()
            self.receipt(i)
        self.deps = {'state':types.SimpleNamespace(snapshot=lambda x:x,load=lambda path:self.current),
                     'receiver':types.SimpleNamespace(_lock=lambda stack,path:None),
                     'endpoint':types.SimpleNamespace(validate_filesystem=lambda:None,
                       inspect_snapshot=lambda stamp:self.evidence[stamp])}
    def restore(self):
        a.STATE_DIR,a.SNAPSHOTS,a.STATE_PATH,a.MANAGER_LOCK,a.WRITER_LOCK = self.old
    def receipt(self,i,**kw):
        s,u = i['timestamp'],i['uuid']
        r = dict(schema=1,snapshot=s,source_uuid=u,received_uuid=u,
                 destination=str(a.SNAPSHOTS/s),source_filesystem_uuid=a.SOURCE_FS,
                 receiver_filesystem_uuid=a.RECEIVER_FS,transport='btrfs-incremental',
                 read_only_verified=True,source_send_exit=0,receiver_receive_exit=0,
                 parent_snapshot=A['timestamp'],parent_source_uuid=A['uuid'])
        r.update(kw)
        p=a.STATE_DIR/(s+'.json');p.write_text(json.dumps(r));p.chmod(0o600)
        return p
    def run_case(self): return a.attest(A,B,deps=self.deps)
    def test_success(self):
        r=self.run_case()
        self.assertEqual(r['status'],'transfer-attested')
        self.assertEqual(r['verified'],[A,B])
        self.assertFalse(r['authorizes_promote'])
    def test_not_prepared(self):
        self.current['pending']=None
        with self.assertRaisesRegex(RuntimeError,'prepared'): self.run_case()
    def test_missing_receipt(self):
        (a.STATE_DIR/(B['timestamp']+'.json')).unlink()
        with self.assertRaisesRegex(RuntimeError,'receipt'): self.run_case()
    def test_wrong_parent(self):
        self.receipt(B,parent_snapshot='20261029-030003Z')
        with self.assertRaisesRegex(RuntimeError,'exact parent'): self.run_case()
    def test_wrong_parent_uuid(self):
        self.receipt(B,parent_source_uuid=B['uuid'])
        with self.assertRaisesRegex(RuntimeError,'exact parent'): self.run_case()
    def test_wrong_received_identity(self):
        self.evidence[B['timestamp']]['received_uuid']=A['uuid']
        with self.assertRaisesRegex(RuntimeError,'Btrfs identity'): self.run_case()
    def test_failed_send(self):
        self.receipt(B,source_send_exit=1)
        with self.assertRaisesRegex(RuntimeError,'status mismatch'): self.run_case()
    def test_failed_receive(self):
        self.receipt(B,receiver_receive_exit=1)
        with self.assertRaisesRegex(RuntimeError,'status mismatch'): self.run_case()
    def test_unsafe_receipt(self):
        (a.STATE_DIR/(B['timestamp']+'.json')).chmod(0o644)
        with self.assertRaisesRegex(RuntimeError,'unsafe receipt'): self.run_case()
    def test_pending_prune(self):
        (a.STATE_DIR/'.receiver-prune-pending.json').touch()
        with self.assertRaisesRegex(RuntimeError,'prune'): self.run_case()
    def test_missing_snapshot(self):
        (a.SNAPSHOTS/B['timestamp']).rmdir()
        with self.assertRaisesRegex(RuntimeError,'subvolume'): self.run_case()

if __name__=='__main__': unittest.main(verbosity=2)
