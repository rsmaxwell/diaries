#!/usr/bin/python3
"""Source-only 0040 3H.5g regressions. No remote operations."""
import importlib.util
import json
from pathlib import Path
import unittest

PATH = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-get-state-endpoint.py'
if not PATH.is_file():
    PATH = Path(__file__).resolve().with_name('btrfs-agreed-parent-get-state-endpoint.py')
sp = importlib.util.spec_from_file_location('get_state_3h5g', PATH)
m = importlib.util.module_from_spec(sp)
sp.loader.exec_module(m)
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
S = {'schema': 1, 'established': A, 'pending': None, 'previous': None}
REQ = {'schema': 1, 'operation': 'get-state', 'transaction_id': '20261030-170009Z', 'expected_before': None, 'candidate': None}
OBS = {'schema': 1, 'host': 'backup', 'state': S, 'verified': [A], 'authorizes_transition': False, 'authorizes_prune': False}


class Tests(unittest.TestCase):
    def test_valid(self):
        r = m.dispatch(m.parse_request(json.dumps(REQ)), observe=lambda: OBS)
        self.assertEqual(r, {'schema': 1, 'operation': 'get-state', 'transaction_id': REQ['transaction_id'], 'status': 'success', 'state': S})
    def test_pending_without_receipt_is_observable(self):
        b = {'timestamp': '20261030-170009Z', 'uuid': 'a9b78fb9-4da6-cf4f-b242-13909f574193'}
        pending = dict(S, pending=b)
        observed = dict(OBS, state=pending)
        self.assertEqual(m.dispatch(REQ, observe=lambda: observed)['state'], pending)
    def test_pending_receipt_not_claimed_verified(self):
        b = {'timestamp': '20261030-170009Z', 'uuid': 'a9b78fb9-4da6-cf4f-b242-13909f574193'}
        with self.assertRaises(ValueError):
            m.dispatch(REQ, observe=lambda: dict(OBS, state=dict(S, pending=b), verified=[A, b]))
    def test_expected_match(self):
        r = dict(REQ, expected_before=S)
        self.assertEqual(m.dispatch(m.parse_request(json.dumps(r)), observe=lambda: OBS)['state'], S)
    def test_expected_conflict(self):
        b = dict(A, timestamp='20261031-030033Z')
        r = dict(REQ, expected_before=dict(S, established=b))
        with self.assertRaises(ValueError): m.dispatch(m.parse_request(json.dumps(r)), observe=lambda: OBS)
    def test_reject_mutation(self):
        for op in ('prepare', 'promote', 'acknowledge-previous', 'prune'):
            with self.subTest(op=op), self.assertRaises(ValueError):m.parse_request(json.dumps(dict(REQ, operation=op)))
    def test_reject_candidate(self):
        with self.assertRaises(ValueError):m.parse_request(json.dumps(dict(REQ,candidate=A)))
    def test_bad_transaction(self):
        with self.assertRaises(ValueError):m.parse_request(json.dumps(dict(REQ,transaction_id='../../tmp')))
    def test_extra_fields(self):
        with self.assertRaises(ValueError):m.parse_request(json.dumps(dict(REQ, root='/tmp')))
    def test_bool_schema(self):
        with self.assertRaises(ValueError):m.parse_request(json.dumps(dict(REQ, schema=True)))
    def test_incomplete_evidence(self):
        with self.assertRaises(ValueError):m.dispatch(REQ, observe=lambda:dict(OBS,verified=[]))
    def test_mutation_authority_rejected(self):
        with self.assertRaises(ValueError):m.dispatch(REQ, observe=lambda:dict(OBS,authorizes_transition=True))
    def test_oversize(self):
        with self.assertRaises(ValueError):m.parse_request('a' * 65537)
    def test_invalid_json(self):
        with self.assertRaises(ValueError):m.parse_request('{bad')
    def test_no_transition_core(self):
        src = PATH.read_text()
        self.assertNotIn("module('transition')",src)
        self.assertNotIn('state.save(',src)
        self.assertNotIn('subprocess.',src)

if __name__ == '__main__':unittest.main(verbosity=2)
