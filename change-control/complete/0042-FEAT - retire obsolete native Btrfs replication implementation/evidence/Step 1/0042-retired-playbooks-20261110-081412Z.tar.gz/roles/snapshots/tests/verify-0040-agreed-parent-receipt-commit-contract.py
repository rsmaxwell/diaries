#!/usr/bin/python3
"""Source regression for dormant receiver receipt commit evidence contract."""
import importlib.util
from pathlib import Path
import unittest

path = Path(__file__).resolve().parents[1] / 'files/btrfs-agreed-parent-receipt-commit-contract.py'
spec = importlib.util.spec_from_file_location('commit04k', path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp': '20261030-170009Z', 'uuid': 'a9b78fb9-4da6-cf4f-b242-13909f574193'}


def evidence():
    return {'parent': A, 'candidate': B, 'receiver_receive_exit': 0,
            'readonly_verified': True, 'received_uuid': B['uuid'],
            'incremental_parent_verified': True, 'state_unchanged': True}


def completion():
    return {'transaction_id': B['timestamp'], 'parent': A, 'candidate': B,
            'source_send_exit': 0, 'authenticated': True, 'stream_finished': True}


class Tests(unittest.TestCase):
    def run_good(self, **overrides):
        options = dict(manager_lock_held=True, writer_lock_held=True,
                       source_session_authenticated=True)
        options.update(overrides)
        return m.validate_completion(A, B, evidence(), completion(), **options)

    def test_success_does_not_write(self):
        result = self.run_good()
        self.assertEqual(result['status'], 'receipt-commit-evidence-validated')
        self.assertFalse(result['receipt_written'])
        self.assertFalse(result['authorizes_release'])

    def test_manager_lock_required(self):
        with self.assertRaises(m.CommitRefused): self.run_good(manager_lock_held=False)

    def test_writer_lock_required(self):
        with self.assertRaises(m.CommitRefused): self.run_good(writer_lock_held=False)

    def test_authenticated_session_required(self):
        with self.assertRaises(m.CommitRefused): self.run_good(source_session_authenticated=False)

    def test_sender_completion_missing(self):
        with self.assertRaises(m.CommitRefused): m.validate_completion(A, B, evidence(), None, manager_lock_held=True, writer_lock_held=True, source_session_authenticated=True)

    def test_sender_failed(self):
        item = completion(); item['source_send_exit'] = 1
        with self.assertRaises(m.CommitRefused): m.validate_completion(A, B, evidence(), item, manager_lock_held=True, writer_lock_held=True, source_session_authenticated=True)

    def test_bool_exit_rejected(self):
        item = completion(); item['source_send_exit'] = False
        with self.assertRaises(m.CommitRefused): m.validate_completion(A, B, evidence(), item, manager_lock_held=True, writer_lock_held=True, source_session_authenticated=True)

    def test_receiver_failed(self):
        item = evidence(); item['receiver_receive_exit'] = 2
        with self.assertRaises(m.CommitRefused): m.validate_completion(A, B, item, completion(), manager_lock_held=True, writer_lock_held=True, source_session_authenticated=True)

    def test_wrong_received_uuid(self):
        item = evidence(); item['received_uuid'] = A['uuid']
        with self.assertRaises(m.CommitRefused): m.validate_completion(A, B, item, completion(), manager_lock_held=True, writer_lock_held=True, source_session_authenticated=True)

    def test_wrong_transaction(self):
        item = completion(); item['transaction_id'] = A['timestamp']
        with self.assertRaises(m.CommitRefused): m.validate_completion(A, B, evidence(), item, manager_lock_held=True, writer_lock_held=True, source_session_authenticated=True)

    def test_no_cli_or_io(self):
        self.assertFalse(hasattr(m, 'main'))
        self.assertFalse(hasattr(m, 'atomic_receipt'))


if __name__ == '__main__':
    unittest.main(verbosity=2)
