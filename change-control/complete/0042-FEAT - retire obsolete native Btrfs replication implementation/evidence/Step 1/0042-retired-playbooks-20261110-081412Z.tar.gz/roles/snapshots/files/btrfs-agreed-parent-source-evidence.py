#!/usr/bin/python3
"""0040 3H.4d: dormant source evidence adapters; no CLI or state writes.

Call only inside a coordinator which already holds the source push lock and
serialises source state changes against the snapshot-manager lock.
"""
import json
from pathlib import Path
import re
import subprocess

SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
SOURCE_PARENT = Path('/media/usb/@snapshots/@data')
MOUNT = Path('/media/usb')
UUID = re.compile(r'^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$')
STAMP = re.compile(r'^\d{8}-\d{6}Z$')


class EvidenceError(RuntimeError):
    pass


def require(ok, reason):
    if not ok:
        raise EvidenceError(reason)


def parse_subvolume(raw, expected):
    require(isinstance(raw, str) and len(raw) <= 65536, 'invalid Btrfs response')
    fields = {}
    for line in raw.splitlines():
        if ':' in line:
            key, value = line.strip().split(':', 1)
            fields[key.strip()] = value.strip()
    require(fields.get('UUID') == expected and fields.get('Flags') == 'readonly',
            'source UUID/read-only mismatch')
    require(fields.get('Received UUID') in ('-', 'none', None), 'source snapshot is received')
    return fields


def verify_source(snapshot, *, runner=subprocess.run, snapshot_dir=SOURCE_PARENT,
                  mount=MOUNT, expected_fs=SOURCE_FS):
    """Validate source identity; runner is injected only for source regression tests."""
    require(type(snapshot) is dict and set(snapshot) == {'timestamp', 'uuid'}, 'invalid identity fields')
    stamp, uuid = snapshot['timestamp'], snapshot['uuid']
    require(isinstance(stamp, str) and STAMP.fullmatch(stamp) and
            isinstance(uuid, str) and UUID.fullmatch(uuid), 'invalid source identity')
    require(snapshot_dir.is_dir() and not snapshot_dir.is_symlink(), 'unsafe snapshot root')
    path = snapshot_dir / stamp
    require(path.is_dir() and not path.is_symlink(), 'missing/unsafe source snapshot')
    def run(argv):
        outcome = runner(argv, capture_output=True, text=True, timeout=20, check=False)
        require(outcome.returncode == 0, 'Btrfs inspection failed')
        require(type(outcome.stdout) is str and len(outcome.stdout) <= 65536, 'oversized Btrfs output')
        return outcome.stdout
    filesystem = run(['btrfs', 'filesystem', 'show', str(mount)])
    require(re.search(r'\buuid:\s*' + re.escape(expected_fs) + r'\b', filesystem, re.I) is not None,
            'source filesystem identity mismatch')
    parse_subvolume(run(['btrfs', 'subvolume', 'show', str(path)]), uuid)
    return {'timestamp': stamp, 'uuid': uuid, 'verified': True}


def validate_receiver_reply(*, stdout, returncode, operation, transaction_id,
                            expected_state, rpc_module):
    """Require SSH exit 0 AND exact 3H.1 receiver postcondition JSON.

    Caller must obtain stdout and returncode from the fixed authenticated SSH
    request, never from caller-controlled JSON or a boolean success flag.
    """
    require(type(returncode) is int and returncode == 0, 'SSH status uncertain; reconcile receiver')
    try:
        result = rpc_module.validate_response(stdout, operation=operation,
                                               transaction_id=transaction_id,
                                               expected_state=expected_state)
    except (ValueError, RuntimeError, TypeError) as exc:
        raise EvidenceError('receiver reply mismatch; reconcile receiver') from exc
    return result['state']
