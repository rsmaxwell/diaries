#!/usr/bin/python3
"""Non-production unit tests for dormant 0040 3H.4c source transitions."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1] / 'files'
p = BASE / 'btrfs-agreed-parent-source-transition.py'
spec = importlib.util.spec_from_file_location('source_3h4c', p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
A = {'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp':'20261031-030015Z','uuid':'a901ddd2-66c7-0b42-b26c-ab6886273b7a'}

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / '.agreed-parent.json'
        self.before = m.state.initial(A)
        m.state.save(self.path, self.before)
        self.observed=[]
        self.peer_ok=True
    def act(self, op='get-state', *, expected=None, candidate=None, locked=True, verifier=None):
        def lock(stack, path):
            self.observed.append('manager-lock')
        def source(snap):
            self.observed.append(('source', snap['timestamp']))
        def peer(op,c,b,a):
            self.observed.append(('peer',op))
            if not self.peer_ok: raise RuntimeError('missing receiver proof')
        return m.transition(operation=op, transaction_id=(candidate or B)['timestamp'],
                            expected_before=expected, candidate=candidate, state_path=self.path,
                            manager_lock=Path(self.tmp.name)/'manager.lock',push_lock_held=locked,
                            acquire_manager=lock,verify_source=verifier or source,
                            verify_peer=peer,require_root=False)
    def test_get_state_recovery(self):
        self.assertEqual(self.act()['state'],self.before)
    def test_lock_required(self):
        with self.assertRaisesRegex(Exception,'push lock'):self.act(locked=False)
    def test_prepare_and_idempotence(self):
        after=self.act('prepare',expected=self.before,candidate=B)['state']
        self.assertEqual(after['pending'],B)
        self.assertEqual(self.act('prepare',expected=self.before,candidate=B)['state'],after)
    def test_prepare_requires_peer_proof(self):
        self.peer_ok=False
        with self.assertRaisesRegex(RuntimeError,'receiver proof'):self.act('prepare',expected=self.before,candidate=B)
        self.assertEqual(m.state.load(self.path),self.before)
    def test_promote(self):
        prepared=self.act('prepare',expected=self.before,candidate=B)['state']
        promoted=self.act('promote',expected=prepared,candidate=B)['state']
        self.assertEqual(promoted['established'],B)
        self.assertEqual(promoted['previous'],A)
    def test_stale_conflict(self):
        self.act('prepare',expected=self.before,candidate=B)
        other=m.state.initial({'timestamp':'20261029-030003Z','uuid':'b901ddd2-66c7-0b42-b26c-ab6886273b7a'})
        with self.assertRaisesRegex(Exception,'stale/conflicting'):self.act('prepare',expected=other,candidate=B)
    def test_source_evidence_failure(self):
        def bad(_): raise RuntimeError('bad source snapshot')
        with self.assertRaisesRegex(RuntimeError,'bad source'):self.act('prepare',expected=self.before,candidate=B,verifier=bad)
        self.assertEqual(m.state.load(self.path),self.before)
    def test_ack_forbidden(self):
        with self.assertRaisesRegex(Exception,'unsupported'):self.act('acknowledge-previous')
    def test_missing_expected(self):
        with self.assertRaisesRegex(Exception,'expected state required'):self.act('prepare',candidate=B)
    def test_get_state_conflict(self):
        with self.assertRaisesRegex(Exception,'unexpected persisted'):self.act(expected=m.state.initial(B))
    def test_no_second_push_lock(self):
        self.act('prepare',expected=self.before,candidate=B)
        self.assertEqual(self.observed[0],'manager-lock')
        self.assertEqual(self.observed.count('manager-lock'),1)
    def test_no_implicit_io(self):
        self.assertNotIn('subprocess',m.__dict__)
    def test_durable_readback_failure(self):
        original=m.state.load
        count=[0]
        def fake(*args,**kwargs):
            count[0]+=1
            if count[0]>=2: return self.before
            return original(*args,**kwargs)
        m.state.load=fake
        try:
            with self.assertRaisesRegex(Exception,'read-back mismatch'):self.act('prepare',expected=self.before,candidate=B)
        finally:m.state.load=original

if __name__=='__main__': unittest.main(verbosity=2)
