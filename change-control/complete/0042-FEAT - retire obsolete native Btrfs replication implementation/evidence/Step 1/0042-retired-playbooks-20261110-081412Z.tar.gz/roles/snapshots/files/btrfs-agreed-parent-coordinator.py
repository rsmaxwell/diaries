#!/usr/bin/python3
"""0040 3H.4a: dormant deterministic sender coordination decision core.

No SSH, subprocess, filesystem access or state mutation. An external locked
coordinator must validate Btrfs identities and receipts before acting on a decision.
No previous-parent acknowledgement is issued by this module.
"""
from __future__ import annotations

import re

STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
UUID = re.compile(r'^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$')

class CoordinationError(RuntimeError):
    pass

def fail(message):
    raise CoordinationError(message)

def snapshot(obj):
    if type(obj) is not dict or set(obj) != {'timestamp', 'uuid'} or not isinstance(obj['timestamp'], str) or not STAMP.fullmatch(obj['timestamp']) or not isinstance(obj['uuid'], str) or not UUID.fullmatch(obj['uuid']):
        fail('invalid snapshot identity')
    return obj

def validate(s):
    if type(s) is not dict or set(s) != {'schema', 'established', 'pending', 'previous'} or type(s['schema']) is not int or s['schema'] != 1:
        fail('invalid agreed-parent schema')
    items = []
    for field in ('established', 'pending', 'previous'):
        value = s[field]
        if field == 'established' and value is None:
            fail('missing established parent')
        if value is not None:
            snapshot(value)
            items.append(value['timestamp'])
    if len(set(items)) != len(items) or (s['pending'] is not None and s['previous'] is not None):
        fail('invalid transition state')
    return s

def decision(source, receiver, candidate, *, receiver_has_candidate=False, source_candidate_verified=False):
    """Return an inert next-action instruction, never permission to mutate.

    Inputs must be independently observed durable states. Booleans are *not*
    verification: the future caller must prove Btrfs source identity and the
    receiver's durable receipt under appropriate locks.
    """
    validate(source); validate(receiver); snapshot(candidate)
    if type(receiver_has_candidate) is not bool or type(source_candidate_verified) is not bool:
        fail('invalid evidence flags')
    if not source_candidate_verified:
        fail('source candidate identity not independently verified')
    if source['previous'] is not None or receiver['previous'] is not None:
        # No parent release in this increment, even if the promoted states match.
        if source == receiver and source['pending'] is None and source['established'] == candidate:
            return {'next': 'await-cross-endpoint-acknowledgement', 'safe_to_release_previous': False}
        if (source['pending'] == candidate and receiver['established'] == candidate and
                receiver['previous'] == source['established'] and source['previous'] is None):
            if not receiver_has_candidate:
                fail('cannot confirm receiver candidate evidence')
            return {'next': 'promote-source', 'safe_to_release_previous': False}
        fail('divergent promoted state requires reconciliation')
    a = source['established']
    if receiver['established'] != a:
        fail('established parent mismatch')
    if candidate['timestamp'] <= a['timestamp'] or candidate == a:
        fail('candidate not newer than established parent')
    sp, rp = source['pending'], receiver['pending']
    if sp not in (None, candidate) or rp not in (None, candidate):
        fail('different pending candidates')
    if rp is None and sp is None:
        return {'next': 'prepare-receiver', 'safe_to_release_previous': False}
    if rp == candidate and sp is None:
        return {'next': 'prepare-source', 'safe_to_release_previous': False}
    if rp is None and sp == candidate:
        fail('source prepared without receiver durable confirmation')
    if receiver_has_candidate:
        return {'next': 'promote-receiver', 'safe_to_release_previous': False}
    return {'next': 'replicate-candidate', 'parent': a, 'safe_to_release_previous': False}
