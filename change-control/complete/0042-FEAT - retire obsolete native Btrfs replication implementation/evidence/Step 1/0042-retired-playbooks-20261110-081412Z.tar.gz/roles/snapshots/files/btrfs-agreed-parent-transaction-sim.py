#!/usr/bin/python3
"""0040 3H.4e: inert cross-endpoint transaction simulation.

Models durable postconditions and interruption boundaries. No SSH, Btrfs,
filesystem writes, command line, or previous-parent release authority.
Evidence flags in this model are simulated, never production proof.
"""
import importlib.util
from pathlib import Path


def load(name):
    path = Path(__file__).with_name('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('agreed_3h4e_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

coordinator = load('coordinator')
orchestrator = load('orchestrator')

class Interrupted(RuntimeError):
    pass


class Simulation:
    """Durable endpoint snapshots; a simulated message can be lost after commit."""
    def __init__(self, established, candidate):
        coordinator.snapshot(established)
        coordinator.snapshot(candidate)
        if candidate['timestamp'] <= established['timestamp']:
            raise ValueError('candidate must follow established')
        self.source = {'schema': 1, 'established': dict(established), 'pending': None, 'previous': None}
        self.receiver = {'schema': 1, 'established': dict(established), 'pending': None, 'previous': None}
        self.candidate = dict(candidate)
        self.receiver_has_candidate = False
        self.transfer_count = 0
        self.actions = []

    def choose(self):
        return coordinator.decision(self.source, self.receiver, self.candidate,
                                    source_candidate_verified=True,
                                    receiver_has_candidate=self.receiver_has_candidate)['next']

    def step(self, *, interrupt_after=None):
        """One simulated boundary; optionally lose its acknowledgement after commit.

        The caller must subsequently observe both durable states and choose again.
        No network retries are performed here.
        """
        action = self.choose()
        self.actions.append(action)
        if action == 'prepare-receiver':
            self.receiver = orchestrator.expected_receiver_after('prepare', self.receiver, self.candidate)
        elif action == 'prepare-source':
            if self.receiver['pending'] != self.candidate:
                raise ValueError('receiver durable prepare confirmation missing')
            self.source = orchestrator.expected_receiver_after('prepare', self.source, self.candidate)
        elif action == 'replicate-candidate':
            if (self.source['pending'] != self.candidate or
                    self.receiver['pending'] != self.candidate or
                    self.source['established'] != self.receiver['established']):
                raise ValueError('transfer preconditions absent')
            self.receiver_has_candidate = True
            self.transfer_count += 1
        elif action == 'promote-receiver':
            if not self.receiver_has_candidate:
                raise ValueError('receiver verified receipt required')
            self.receiver = orchestrator.expected_receiver_after('promote', self.receiver, self.candidate)
        elif action == 'promote-source':
            if (self.receiver['established'] != self.candidate or
                    self.receiver['previous'] != self.source['established']):
                raise ValueError('receiver durable promotion required')
            self.source = orchestrator.expected_receiver_after('promote', self.source, self.candidate)
        elif action == 'await-cross-endpoint-acknowledgement':
            return action
        else:
            raise ValueError('unknown decision: ' + str(action))
        if interrupt_after == action:
            raise Interrupted('response lost after simulated durable boundary: ' + action)
        return action

    def finish(self):
        for _ in range(6):
            action = self.step()
            if action == 'await-cross-endpoint-acknowledgement':
                return self.source, self.receiver
        raise RuntimeError('transition did not converge')
