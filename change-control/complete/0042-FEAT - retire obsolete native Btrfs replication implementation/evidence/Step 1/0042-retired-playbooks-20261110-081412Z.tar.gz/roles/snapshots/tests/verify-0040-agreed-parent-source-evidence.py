#!/usr/bin/python3
"""Source-only regression tests; zero Btrfs, SSH or state writes."""
import importlib.util
from pathlib import Path
import tempfile
import types
import unittest

SRC = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-source-evidence.py'
spec = importlib.util.spec_from_file_location('evidence3h4d', SRC)
e = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)
STAMP = '20261030-030033Z'
UUID = 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / STAMP).mkdir()
        self.invocations = []

    def runner(self, command, **kwargs):
        self.invocations.append(command)
        if command[1] == 'filesystem':
            output = 'Label: none  uuid: ' + e.SOURCE_FS
        else:
            output = 'UUID: ' + UUID + '\nFlags: readonly\nReceived UUID: -\n'
        return types.SimpleNamespace(returncode=0, stdout=output)

    def test_good_source(self):
        self.assertTrue(e.verify_source({'timestamp': STAMP, 'uuid': UUID},
                          runner=self.runner, snapshot_dir=self.root)['verified'])
        self.assertEqual(len(self.invocations), 2)

    def test_bad_uuid(self):
        with self.assertRaises(e.EvidenceError):
            e.verify_source({'timestamp': STAMP, 'uuid': 'f'*8+'-'+UUID[9:]},
                            runner=self.runner, snapshot_dir=self.root)

    def test_symlinked_snapshot(self):
        (self.root / STAMP).rmdir()
        (self.root / STAMP).symlink_to(self.root)
        with self.assertRaises(e.EvidenceError):
            e.verify_source({'timestamp': STAMP, 'uuid': UUID}, runner=self.runner, snapshot_dir=self.root)
        self.assertEqual(self.invocations, [])

    def test_wrong_filesystem(self):
        def wrong(cmd, **kw):
            return types.SimpleNamespace(returncode=0, stdout='uuid: wrong')
        with self.assertRaises(e.EvidenceError):
            e.verify_source({'timestamp': STAMP, 'uuid': UUID}, runner=wrong, snapshot_dir=self.root)

    def test_failed_btrfs(self):
        def failed(cmd, **kw):
            return types.SimpleNamespace(returncode=1, stdout='')
        with self.assertRaises(e.EvidenceError):
            e.verify_source({'timestamp': STAMP, 'uuid': UUID}, runner=failed, snapshot_dir=self.root)

    def test_ssh_failure_even_valid_json(self):
        rpc = types.SimpleNamespace(validate_response=lambda *a, **k: {'state': {}})
        with self.assertRaises(e.EvidenceError):
            e.validate_receiver_reply(stdout='{}', returncode=255, operation='prepare',
                                      transaction_id=STAMP, expected_state={}, rpc_module=rpc)

    def test_exact_peer_response(self):
        expected = {'schema': 1}
        rpc = types.SimpleNamespace(validate_response=lambda *a, **k: {'state': expected})
        self.assertEqual(e.validate_receiver_reply(stdout='{}', returncode=0, operation='prepare',
                         transaction_id=STAMP, expected_state=expected, rpc_module=rpc), expected)

    def test_reject_malformed_peer_response(self):
        def reject(*a, **k):
            raise ValueError('bad JSON')
        rpc = types.SimpleNamespace(validate_response=reject)
        with self.assertRaises(e.EvidenceError):
            e.validate_receiver_reply(stdout='bad', returncode=0, operation='prepare',
                                      transaction_id=STAMP, expected_state={}, rpc_module=rpc)

if __name__ == '__main__':
    unittest.main(verbosity=2)
