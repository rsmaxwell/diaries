#!/usr/bin/python3
"""Pure regression tests; no SSH connections, state writes or Btrfs commands."""
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import subprocess
import unittest

p = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-rpc.py'
spec = importlib.util.spec_from_file_location('agreed_parent_rpc', p)
rpc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rpc)
A = {'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp':'20261031-030015Z','uuid':'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'}
STATE = {'schema':1,'established':B,'pending':None,'previous':A}
T = B['timestamp']
def payload(**changes):
    return json.dumps(dict({'schema':1,'operation':'promote','transaction_id':T,
                            'status':'success','state':STATE}, **changes))
def run_for(stdout, rc=0):
    return lambda *args, **kwargs: SimpleNamespace(stdout=stdout, stderr='', returncode=rc)
class Tests(unittest.TestCase):
    def check(self, stdout=None, rc=0, **kw):
        return rpc.request(['ssh','backup','fixed-endpoint'], operation='promote', transaction_id=T,
                           expected_state=STATE, run=run_for(payload() if stdout is None else stdout, rc), **kw)
    def test_success(self): self.assertEqual(self.check()['state'],STATE)
    def test_nonzero_with_valid_json(self):
        with self.assertRaises(rpc.ProtocolError): self.check(rc=1)
    def test_malformed(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout='{')
    def test_stale_transaction(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout=payload(transaction_id='20261029-030003Z'))
    def test_wrong_operation(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout=payload(operation='prepare'))
    def test_wrong_state(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout=payload(state=dict(STATE, previous=None)))
    def test_false_success(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout=payload(status='failure'))
    def test_extra_fields(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout=payload(debug='unexpected'))
    def test_timeout(self):
        def timeout(*args, **kwargs): raise subprocess.TimeoutExpired(['ssh'], 3)
        with self.assertRaisesRegex(rpc.ProtocolError,'reconcile'): rpc.request(['ssh'], operation='promote', transaction_id=T, expected_state=STATE, run=timeout)
    def test_missing_stdout(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout='')
    def test_invalid_state_shape(self):
        with self.assertRaises(rpc.ProtocolError): self.check(stdout=payload(state=dict(STATE, pending=A)))
    def test_no_implicit_retry(self):
        calls=[]
        def fails(*args, **kwargs): calls.append(1); return SimpleNamespace(returncode=255, stdout=payload())
        with self.assertRaises(rpc.ProtocolError): rpc.request(['ssh'], operation='promote', transaction_id=T, expected_state=STATE, run=fails)
        self.assertEqual(len(calls),1)
if __name__ == '__main__': unittest.main(verbosity=2)
