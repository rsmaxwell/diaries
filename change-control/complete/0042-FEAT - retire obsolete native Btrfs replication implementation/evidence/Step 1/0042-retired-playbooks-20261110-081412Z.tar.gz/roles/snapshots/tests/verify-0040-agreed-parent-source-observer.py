#!/usr/bin/python3
"""Offline source/receiver observation orchestration regression."""
import importlib.util
from pathlib import Path
import subprocess
import unittest

PATH = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-source-observer.py'
spec = importlib.util.spec_from_file_location('observer', PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
A = {'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
STATE = {'schema':1,'established':A,'pending':None,'previous':None}


class Tests(unittest.TestCase):
    def process(self, *, returncode=0, stdout='{}', fail_at=None):
        events = []
        def acquire(stack, path):
            events.append(('lock', path.name))
            if fail_at == 'lock': raise RuntimeError('busy lock')
        def load():
            events.append(('load',))
            if fail_at == 'load': raise RuntimeError('invalid state')
            return STATE
        def verify(item):
            events.append(('verify', item['timestamp']))
            if fail_at == 'verify': raise RuntimeError('bad source')
        def run(argv, **kwargs):
            events.append(('ssh', tuple(argv)))
            self.assertEqual(tuple(argv), mod.SSH_AS_RICHARD + mod.SSH + mod.RECEIVER_COMMAND)
            self.assertTrue(kwargs['capture_output'] and kwargs['text'])
            self.assertFalse(kwargs['check'])
            if fail_at == 'ssh': raise subprocess.TimeoutExpired(argv, kwargs['timeout'])
            return subprocess.CompletedProcess(argv, returncode, stdout)
        def compare(source, reply, *, ssh_exit):
            events.append(('compare',))
            if fail_at == 'compare': raise RuntimeError('bad receiver')
            return {'schema':1,'comparison':'matched','source':source,'receiver':source,
                    'authorizes_transition':False,'authorizes_prune':False}
        return events, lambda: mod.observe(acquire=acquire,load=load,verify=verify,run=run,compare=compare)

    def test_success_order(self):
        events, fn = self.process()
        self.assertEqual(fn()['comparison'],'matched')
        self.assertEqual([e[0] for e in events],['lock','lock','load','verify','ssh','compare'])
        self.assertEqual(events[0][1],'.native-push.lock')
    def test_lock_failure(self):
        events, fn = self.process(fail_at='lock')
        with self.assertRaises(RuntimeError):fn()
        self.assertEqual(len(events),1)
    def test_bad_source(self):
        events, fn = self.process(fail_at='verify')
        with self.assertRaises(RuntimeError):fn()
        self.assertNotIn('ssh',[e[0] for e in events])
    def test_bad_state(self):
        events, fn = self.process(fail_at='load')
        with self.assertRaises(RuntimeError):fn()
        self.assertNotIn('ssh',[e[0] for e in events])
    def test_receiver_nonzero(self):
        events,fn=self.process(returncode=1)
        with self.assertRaises(RuntimeError):fn()
        self.assertNotIn('compare',[e[0] for e in events])
    def test_receiver_timeout(self):
        events,fn=self.process(fail_at='ssh')
        with self.assertRaises(subprocess.TimeoutExpired):fn()
    def test_receiver_bad_reply(self):
        _,fn=self.process(fail_at='compare')
        with self.assertRaises(RuntimeError):fn()
    def test_no_mutation_authority(self):
        _,fn=self.process()
        answer=fn()
        self.assertIs(answer['authorizes_transition'],False)
        self.assertIs(answer['authorizes_prune'],False)
    def test_ssh_uses_unprivileged_identity(self):
        events,fn=self.process()
        fn()
        argv=next(x[1] for x in events if x[0]=='ssh')
        self.assertEqual(argv[:4],('/usr/sbin/runuser','-u','richard','--'))
        self.assertEqual(argv[4],'ssh')

    def test_fail_closed_when_drop_fails(self):
        events,fn=self.process(returncode=1)
        with self.assertRaisesRegex(RuntimeError,'SSH failed'):
            fn()
        self.assertNotIn('compare',[e[0] for e in events])

    def test_no_external_cli_paths(self):
        self.assertEqual(mod.RECEIVER_COMMAND[2],'/usr/local/libexec/btrfs-agreed-parent-endpoint.py')
        self.assertEqual(mod.SSH_AS_RICHARD,('/usr/sbin/runuser','-u','richard','--'))
        self.assertEqual(mod.SSH[0],'ssh')
        self.assertNotIn('StrictHostKeyChecking=no',mod.SSH)
        self.assertNotIn('shell',mod.observe.__code__.co_varnames)

if __name__=='__main__':unittest.main(verbosity=2)
