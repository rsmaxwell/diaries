#!/usr/bin/python3
"""0040 3H.4j: read-only source/receiver observation command.

Local checks retain root; the SSH subprocess runs under richard's existing
login identity and known_hosts. No mutation or pruning authority.
"""
import argparse
from contextlib import ExitStack
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

BASE = Path(__file__).resolve().parent
PUSH_LOCK = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
STATE_PATH = Path('/media/usb/@snapshots/.agreed-parent.json')
SSH = ('ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1')
RECEIVER_COMMAND = ('sudo', '-n', '/usr/local/libexec/btrfs-agreed-parent-endpoint.py', '--observe-receiver')
# runuser drops UID/GID and initializes the target account's login context before SSH.
# Keep these values fixed; never use a shell or change SSH host-key checking.
SSH_AS_RICHARD = ('/usr/sbin/runuser', '-u', 'richard', '--')


def module(name):
    path = BASE / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('observation_' + name.replace('-', '_'), path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def lock(stack, path):
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise RuntimeError('missing or unsafe source lock')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_mode & 0o022:
        raise RuntimeError('unsafe source lock permissions')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    handle = stack.enter_context(os.fdopen(fd, 'rb'))
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)


def observe(*, run=subprocess.run, verify=None, load=None, compare=None, acquire=lock):
    """Fixed observation sequence; injectable dependencies are for offline tests only."""
    state = module('state')
    evidence = module('source-evidence')
    bridge = module('observation-bridge')
    with ExitStack() as stack:
        acquire(stack, PUSH_LOCK)
        acquire(stack, MANAGER_LOCK)
        source = (load or (lambda: state.load(STATE_PATH, require_root=True)))()
        state.validate(source)
        for stamp, uuid in sorted(state.protected(source).items()):
            (verify or evidence.verify_source)({'timestamp': stamp, 'uuid': uuid})
        result = run(list(SSH_AS_RICHARD + SSH + RECEIVER_COMMAND), capture_output=True, text=True,
                     timeout=60, check=False)
        if type(result.returncode) is not int or result.returncode != 0:
            raise RuntimeError('receiver observation SSH failed')
        answer = (compare or bridge.inspect)(source, result.stdout, ssh_exit=result.returncode)
        if answer.get('authorizes_transition') is not False or answer.get('authorizes_prune') is not False:
            raise RuntimeError('unexpected observation authority')
        return answer


def main():
    parser = argparse.ArgumentParser(description='Read-only agreed-parent observation (dormant)')
    parser.add_argument('--observe', action='store_true', required=True)
    args = parser.parse_args()
    if not args.observe or os.geteuid() != 0:
        raise RuntimeError('root and --observe required')
    print(json.dumps(observe(), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(f'agreed-parent source observation refused: {exc}', file=sys.stderr)
        raise SystemExit(1)
