#!/usr/bin/python3
"""0040 Increment 2: lock-held, fail-closed two-endpoint transition primitive.

NOT a network transport or production entrypoint. Callers must hold both endpoint
locks, validate live Btrfs snapshot identities and receiver receipts, and make
both state files durable. Never treat a returned plan as deletion authority.
"""
import importlib.util
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "agreed_parent_state_0040", Path(__file__).with_name("btrfs-agreed-parent-state.py"))
state_api = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(state_api)
StateError = state_api.StateError


def _read(source, receiver):
    """Missing or corrupt file fails closed; neither endpoint is initialised here."""
    return state_api.load(source), state_api.load(receiver)


def _equal(a, b):
    return a == b


def plan(source, receiver):
    """Read-only, reconciliation-first state of replication protection.

    Different phases are expected after a crash and are never auto-repaired.
    """
    src, dst = _read(source, receiver)
    protected = set(state_api.protected(src)) | set(state_api.protected(dst))
    return {"source": src, "receiver": dst,
            "protected_union": sorted(protected), "synchronised": _equal(src, dst),
            "authorizes_prune": False}


def prepare_endpoint(path, candidate, *, established_verified, candidate_pinned):
    """Persist pending on one endpoint; independent source/receiver checks required."""
    if established_verified is not True or candidate_pinned is not True:
        raise StateError("parent verification and candidate pin required")
    current = state_api.load(path)
    newer = state_api.snapshot(candidate)
    if newer["timestamp"] <= current["established"]["timestamp"]:
        raise StateError("candidate must be later than established")
    state_api.save(path, state_api.prepare(current, newer))


def promote_endpoint(path, *, receipt_verified, peer_pending_verified):
    """Promote only after durable peer pending and identity-checked receiver receipt."""
    if receipt_verified is not True or peer_pending_verified is not True:
        raise StateError("receiver receipt and peer pending record required")
    current = state_api.load(path)
    state_api.save(path, state_api.promote(current))


def clear_previous_endpoint(path, *, both_promoted_verified):
    """Release old state protection only when both durable promotions verified.

    This does not remove any legacy source pins and never deletes a snapshot.
    """
    if both_promoted_verified is not True:
        raise StateError("both endpoint promotions must be verified")
    state_api.save(path, state_api.acknowledge_previous(state_api.load(path)))


def verify_both_promoted(source, receiver):
    """Read-only consensus check, not a substitute for live Btrfs verification."""
    src, dst = _read(source, receiver)
    if (src["pending"] is not None or dst["pending"] is not None or
            src["previous"] is None or dst["previous"] is None or
            src["established"] != dst["established"] or
            src["previous"] != dst["previous"]):
        raise StateError("both endpoints have not durably promoted identical parents")
    return {"established": src["established"], "previous": src["previous"]}
