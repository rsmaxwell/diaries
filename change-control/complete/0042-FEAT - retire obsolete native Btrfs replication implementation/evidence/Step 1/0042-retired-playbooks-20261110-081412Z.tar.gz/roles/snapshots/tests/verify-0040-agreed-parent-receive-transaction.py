#!/usr/bin/python3
"""0040 Step 12.3 Integration 04J local locked transaction tests."""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import Mock

FILE = Path(__file__).resolve().parents[1] / 'files/btrfs-agreed-parent-receive-transaction.py'
spec = importlib.util.spec_from_file_location('receive04j', FILE)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp': '20261030-170009Z', 'uuid': 'a9b78fb9-4da6-cf4f-b242-13909f574193'}
STATE = {'schema': 1, 'established': A, 'pending': B, 'previous': None}


class Locks:
    def __init__(self):
        self.depth = 0
        self.calls = []
    def _lock(self, stack, path):
        self.depth += 1
        self.calls.append(str(path))
        stack.callback(self.release)
    def release(self):
        self.depth -= 1


class Tests(unittest.TestCase):
    def setUp(self):
        self.locks = Locks()
        self.state = Mock()
        self.state.load.return_value = STATE
        self.state.snapshot.side_effect = lambda x: x
        self.absence = Mock()
        self.absence.verify.return_value = {'destination_absent': True, 'receipt_absent': True}
        self.boundary = Mock()
        self.endpoint = Mock()
        self.mods = {'state': self.state, 'receiver': self.locks,
                     'endpoint': self.endpoint, 'transfer-absence': self.absence,
                     'receive-boundary': self.boundary}
    def test_read_only_review(self):
        result = m.transaction(A, B, modules=self.mods)
        self.assertEqual(result['status'], 'receive-transaction-review')
        self.assertFalse(result['transfer_executed'])
        self.assertFalse(result['authorizes_transfer'])
        self.assertEqual(self.locks.depth, 0)
        self.assertEqual(len(self.locks.calls), 2)
        self.boundary.verify_before_receive.assert_called_once()
    def test_order_manager_writer(self):
        m.transaction(A, B, modules=self.mods)
        self.assertEqual(self.locks.calls, [str(m.MANAGER), str(m.WRITER)])
    def test_receive_callback_inside_locks(self):
        callback = Mock(side_effect=lambda a,b: self.assertEqual(self.locks.depth, 2) or {'verified': True})
        m.transaction(A, B, modules=self.mods, receive=callback)
        self.assertEqual(callback.call_count, 1)
        self.boundary.verify_after_receive.assert_called_once()
        self.assertEqual(self.locks.depth, 0)
    def test_receive_failure_releases_locks_and_does_not_retry(self):
        callback = Mock(side_effect=RuntimeError('stream uncertain'))
        with self.assertRaisesRegex(RuntimeError, 'stream uncertain'):
            m.transaction(A, B, modules=self.mods, receive=callback)
        self.assertEqual(callback.call_count, 1)
        self.assertEqual(self.locks.depth, 0)
    def test_absence_refused_before_receive(self):
        self.absence.verify.side_effect = RuntimeError('B exists')
        callback = Mock()
        with self.assertRaisesRegex(RuntimeError, 'B exists'):
            m.transaction(A, B, modules=self.mods, receive=callback)
        callback.assert_not_called()
        self.assertEqual(self.locks.depth, 0)
    def test_invalid_candidate_refused(self):
        with self.assertRaises(RuntimeError):
            m.transaction(B, A, modules=self.mods)
        self.assertEqual(self.locks.calls, [])
    def test_invalid_callback_refused(self):
        with self.assertRaises(RuntimeError):
            m.transaction(A, B, modules=self.mods, receive=True)
        self.assertEqual(self.locks.depth, 0)
    def test_state_change_refused_by_boundary(self):
        self.boundary.verify_after_receive.side_effect = RuntimeError('state changed')
        with self.assertRaisesRegex(RuntimeError, 'state changed'):
            m.transaction(A, B, modules=self.mods, receive=lambda a,b: {})
        self.assertEqual(self.locks.depth, 0)
    def test_cli_no_execute_transfer_flag(self):
        source = FILE.read_text()
        self.assertNotIn('execute-transfer', source)
        self.assertIn("parser.add_argument('--review-only'", source)

if __name__ == '__main__':
    unittest.main(verbosity=2)
