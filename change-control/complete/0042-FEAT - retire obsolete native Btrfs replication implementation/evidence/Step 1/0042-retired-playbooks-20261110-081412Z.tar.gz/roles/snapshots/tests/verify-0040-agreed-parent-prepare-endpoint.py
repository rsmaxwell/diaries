#!/usr/bin/python3
"""Offline regressions for dormant receiver prepare-only endpoint."""
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1] / 'files'
FILE = ROOT / 'btrfs-agreed-parent-prepare-endpoint.py'
spec = importlib.util.spec_from_file_location('prepare_endpoint', FILE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
STATE = {'schema': 1, 'established': {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}, 'pending': None, 'previous': None}
CANDIDATE = {'timestamp': '20261030-170009Z', 'uuid': 'a9b78fb9-4da6-cf4f-b242-13909f574193'}
REQUEST = {'schema': 1, 'operation': 'prepare', 'transaction_id': CANDIDATE['timestamp'], 'expected_before': STATE, 'candidate': CANDIDATE}

class FakeCore:
    def __init__(self, response=None): self.calls=[]; self.response=response
    def transition(self, **kw):
        self.calls.append(kw)
        return self.response or {'schema':1, 'operation':'prepare', 'transaction_id':REQUEST['transaction_id'], 'status':'success', 'state':dict(STATE, pending=CANDIDATE)}

class Tests(unittest.TestCase):
    def parse(self, **changes): return mod.parse_request(json.dumps(dict(REQUEST, **changes)))
    def test_valid(self): self.assertEqual(self.parse(), REQUEST)
    def test_no_promote(self):
        for op in ('promote', 'get-state', 'acknowledge-previous'):
            with self.subTest(op=op), self.assertRaises(ValueError): self.parse(operation=op)
    def test_wrong_schema(self):
        with self.assertRaises(ValueError): self.parse(schema=True)
    def test_bad_transaction(self):
        with self.assertRaises(ValueError): self.parse(transaction_id='20261030-180000Z')
    def test_pending_rejected(self):
        with self.assertRaises(ValueError): self.parse(expected_before=dict(STATE,pending=CANDIDATE))
    def test_previous_rejected(self):
        with self.assertRaises(ValueError): self.parse(expected_before=dict(STATE,previous={'timestamp':'20261029-000000Z','uuid':CANDIDATE['uuid']}))
    def test_old_candidate(self):
        with self.assertRaises(ValueError): self.parse(candidate=STATE['established'],transaction_id='20261030-030033Z')
    def test_extra_field(self):
        with self.assertRaises(ValueError): mod.parse_request(json.dumps(dict(REQUEST, unsafe=True)))
    def test_oversized(self):
        with self.assertRaises(ValueError): mod.parse_request('x'*65537)
    def test_malformed(self):
        with self.assertRaises(ValueError): mod.parse_request('{')
    def test_dispatch_fixed_paths(self):
        core=FakeCore(); result=mod.dispatch(self.parse(),core=core,verify=lambda *args:None)
        self.assertEqual(result['state']['pending'], CANDIDATE)
        kw=core.calls[0]
        self.assertEqual(kw['operation'],'prepare')
        self.assertEqual(kw['state_path'],mod.STATE_FILE)
        self.assertEqual(kw['manager_lock'],mod.MANAGER_LOCK)
        self.assertEqual(kw['writer_lock'],mod.WRITER_LOCK)
    def test_bad_postcondition_rejected(self):
        bad={'schema':1,'operation':'prepare','transaction_id':REQUEST['transaction_id'],'status':'success','state':STATE}
        with self.assertRaises(RuntimeError): mod.dispatch(self.parse(),core=FakeCore(bad),verify=lambda *args:None)
    def test_no_deployment_or_cli_mutation_shortcut(self):
        source=FILE.read_text()
        self.assertNotIn('subprocess.run(',source)
        self.assertNotIn('os.system(',source)
        self.assertNotIn('acknowledge_previous(',source)
        self.assertNotIn('state.save(',source)

if __name__=='__main__': unittest.main(verbosity=2)
