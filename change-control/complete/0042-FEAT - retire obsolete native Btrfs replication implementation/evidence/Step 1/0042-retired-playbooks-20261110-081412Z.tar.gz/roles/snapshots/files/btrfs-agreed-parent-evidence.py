#!/usr/bin/python3
"""0040 Increment 3: read-only validation of endpoint evidence.

Caller collects snapshots through the existing allowlisted inspect-source and
inspect-receiver commands, and a receiver receipt through its locked reader.
This module performs NO network, filesystem mutation, pin release or prune.
Returned booleans MUST NOT be used as production authorisation: evidence can
be stale between collection and subsequent mutations.
"""
import importlib.util
from pathlib import Path

_spec = importlib.util.spec_from_file_location('agreed_parent_0040', Path(__file__).with_name('btrfs-agreed-parent-state.py'))
_state = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_state)
StateError = _state.StateError


def verify_snapshot_pair(identity, source, receiver, receipt, *, source_parent_uuid, destination, source_fs, receiver_fs):
    """Validate captured endpoint output, receiver receipt and Btrfs lineage.

    The caller must acquire the existing sender/receiver locks, protect both
    parents first, and collect evidence under those locks before acting.
    """
    item = _state.snapshot(identity)
    stamp, uuid = item['timestamp'], item['uuid']
    for record in (source, receiver, receipt):
        if not isinstance(record, dict):
            raise StateError('missing or invalid endpoint evidence')
    if not all(isinstance(x, str) and x for x in (source_parent_uuid, destination, source_fs, receiver_fs)):
        raise StateError('missing configured identity')
    if (source.get('uuid') != uuid or source.get('flags') != 'readonly' or
            source.get('parent_uuid') != source_parent_uuid or
            source.get('received_uuid') not in ('-', None)):
        raise StateError('source Btrfs identity mismatch')
    if (receiver.get('flags') != 'readonly' or receiver.get('received_uuid') != uuid or
            not isinstance(receiver.get('uuid'), str) or not receiver['uuid']):
        raise StateError('receiver Btrfs identity mismatch')
    if (type(receipt.get('schema')) is not int or receipt['schema'] != 1 or
            receipt.get('snapshot') != stamp or receipt.get('source_uuid') != uuid or
            receipt.get('received_uuid') != uuid or receipt.get('destination') != destination or
            receipt.get('source_filesystem_uuid') != source_fs or
            receipt.get('receiver_filesystem_uuid') != receiver_fs or
            receipt.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
            receipt.get('read_only_verified') is not True or
            type(receipt.get('source_send_exit')) is not int or receipt['source_send_exit'] != 0 or
            type(receipt.get('receiver_receive_exit')) is not int or receipt['receiver_receive_exit'] != 0):
        raise StateError('receiver receipt mismatch')
    return {'snapshot': stamp, 'source_uuid': uuid, 'identity_verified': True,
            'authorizes_state_transition': False, 'authorizes_prune': False}


def protected_union(source_state, receiver_state):
    """Fail closed on invalid state or same-name/different-UUID snapshots."""
    source = _state.protected(source_state)
    receiver = _state.protected(receiver_state)
    for stamp in source.keys() & receiver.keys():
        if source[stamp] != receiver[stamp]:
            raise StateError('cross-host protection UUID disagreement')
    return dict(sorted((source | receiver).items()))
