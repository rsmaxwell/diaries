#!/usr/bin/python3
"""0040 Increment 3G: guarded agreed-parent bootstrap candidate.

Production CLI is PLAN ONLY. No state writes, pins, scheduler changes or deletion.
The injected commit primitive is for disposable regression fixtures only, and
must not be exposed as an operational CLI before sender/pruner integration.
"""
import argparse
import importlib.util
import json
from pathlib import Path

STAMP = '20261030-030033Z'
UUID = 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'


def state_module():
    path = Path(__file__).with_name('btrfs-agreed-parent-state.py')
    spec = importlib.util.spec_from_file_location('agreed_parent_bootstrap_state', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_candidate(*, source, receiver, receipt, source_pins, receiver_prune_disabled):
    """Validate collected trusted evidence. Caller must collect it under locks."""
    s = state_module()
    candidate = s.snapshot({'timestamp': STAMP, 'uuid': UUID})
    if not all(isinstance(item, dict) for item in (source, receiver, receipt, source_pins)):
        raise s.StateError('missing identity or pin evidence')
    if source.get('uuid') != UUID or source.get('readonly') is not True:
        raise s.StateError('source identity or read-only mismatch')
    if receiver.get('received_uuid') != UUID or receiver.get('readonly') is not True:
        raise s.StateError('receiver identity or read-only mismatch')
    if (receipt.get('schema') != 1 or receipt.get('snapshot') != STAMP or
        receipt.get('source_uuid') != UUID or receipt.get('received_uuid') != UUID or
        receipt.get('read_only_verified') is not True or
        receipt.get('source_send_exit') != 0 or receipt.get('receiver_receive_exit') != 0):
        raise s.StateError('receiver receipt mismatch')
    if (source_pins.get('protected', {}).get(STAMP) != UUID or
        source_pins.get('prune_protected', {}).get(STAMP) != UUID):
        raise s.StateError('missing source-side replication protection')
    if receiver_prune_disabled is not True:
        raise s.StateError('receiver pruning must remain disabled')
    return candidate


def disposable_commit(path, candidate, *, lock_asserted, protection_frozen):
    """Fixture-only primitive: never invoke against production state paths.

    Repeated identical states are accepted; conflicting or corrupt state fails.
    Stable external locking and schedule isolation are preconditions, not managed
    by this primitive. Production deployment requires a separate reviewed tool.
    """
    s = state_module()
    if lock_asserted is not True or protection_frozen is not True:
        raise s.StateError('external lock and scheduling freeze required')
    if path.exists() or path.is_symlink():
        existing = s.load(path)
        wanted = s.initial(candidate)
        if existing != wanted:
            raise s.StateError('existing state differs from proposed parent')
        return 'unchanged'
    s.save(path, s.initial(candidate))
    return 'created'


def main():
    parser = argparse.ArgumentParser(description='Read-only agreed-parent bootstrap plan')
    parser.add_argument('--plan', action='store_true', required=True)
    args = parser.parse_args()
    if args.plan:
        print(json.dumps({'mode': 'plan-only', 'candidate': {'timestamp': STAMP, 'uuid': UUID},
                          'authorizes_state_write': False, 'authorizes_prune': False,
                          'requires': ['locked live evidence', 'sender and receiver schedule isolation',
                                       'both-endpoint protection and state migration review']}, sort_keys=True))


if __name__ == '__main__':
    main()
