#!/usr/bin/python3
import importlib.util, json, pathlib, unittest
p=pathlib.Path(__file__).resolve().parents[1]/'files'/'btrfs-agreed-parent-observation-bridge.py'
spec=importlib.util.spec_from_file_location('bridge',p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
a={'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
s={'schema':1,'established':a,'pending':None,'previous':None}
def reply(state=s, **kwargs):
    d={'schema':1,'host':'backup','state':state,'verified':[a], 'authorizes_transition':False,'authorizes_prune':False}
    d.update(kwargs); return json.dumps(d)
class Tests(unittest.TestCase):
    def test_matches(self): self.assertEqual(m.inspect(s,reply(),ssh_exit=0)['comparison'],'matched')
    def test_diverged(self):
        other=dict(s,pending={'timestamp':'20261031-030000Z','uuid':'11111111-1111-1111-1111-111111111111'})
        self.assertEqual(m.inspect(other,reply(),ssh_exit=0)['comparison'],'diverged')
    def test_receiver_pending_without_receipt_diverges_safely(self):
        b={'timestamp':'20261030-170009Z','uuid':'a9b78fb9-4da6-cf4f-b242-13909f574193'}
        pending=dict(s,pending=b)
        result=m.inspect(s,reply(state=pending),ssh_exit=0)
        self.assertEqual(result['comparison'],'diverged')
        self.assertEqual(result['receiver']['pending'],b)
        self.assertFalse(result['authorizes_transition'])
    def test_exit_failure(self):
        with self.assertRaises(m.ObservationError): m.inspect(s,reply(),ssh_exit=255)
    def test_false_bool_exit(self):
        with self.assertRaises(m.ObservationError): m.inspect(s,reply(),ssh_exit=False)
    def test_malformed(self):
        with self.assertRaises(m.ObservationError): m.inspect(s,'{',ssh_exit=0)
    def test_wrong_host(self):
        with self.assertRaises(m.ObservationError): m.inspect(s,reply(host='mars'),ssh_exit=0)
    def test_authority(self):
        with self.assertRaises(m.ObservationError): m.inspect(s,reply(authorizes_prune=True),ssh_exit=0)
    def test_missing_evidence(self):
        with self.assertRaises(m.ObservationError): m.inspect(s,reply(verified=[]),ssh_exit=0)
    def test_unexpected_fields(self):
        with self.assertRaises(m.ObservationError): m.inspect(s,reply(extra=True),ssh_exit=0)
    def test_invalid_source(self):
        with self.assertRaises(Exception): m.inspect(dict(s,established=None),reply(),ssh_exit=0)
if __name__=='__main__': unittest.main(verbosity=2)
