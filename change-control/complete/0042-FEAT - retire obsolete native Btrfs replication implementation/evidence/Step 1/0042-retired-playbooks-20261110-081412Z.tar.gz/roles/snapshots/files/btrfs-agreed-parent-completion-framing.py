#!/usr/bin/python3
"""0040 Step 12.3 Integration 04M: dormant bounded control-frame contract.

Frames are for a DEDICATED control channel belonging to the SAME authenticated
transfer session. Never put these bytes into raw `btrfs receive` stdin. This
module cannot authenticate the channel, verify Btrfs streams, persist receipts,
or execute a transfer. A future session owner must enforce those properties.
"""
import json
import secrets
import struct

MAX_CONTROL = 4096

class FrameRefused(RuntimeError):
    pass


def encode(message):
    if type(message) is not dict:
        raise FrameRefused('control message must be an object')
    payload = json.dumps(message, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if not 0 < len(payload) <= MAX_CONTROL:
        raise FrameRefused('control message exceeds bound')
    return struct.pack('!I', len(payload)) + payload


def decode(frame):
    if type(frame) is not bytes or len(frame) < 4:
        raise FrameRefused('invalid control frame')
    length = struct.unpack('!I', frame[:4])[0]
    if not 0 < length <= MAX_CONTROL or len(frame) != length + 4:
        raise FrameRefused('truncated, oversized or trailing control frame')
    try:
        value = json.loads(frame[4:].decode('utf-8'), object_pairs_hook=_unique_fields,
                           parse_constant=lambda _: (_ for _ in ()).throw(ValueError('invalid number')))
    except (ValueError, UnicodeError, TypeError) as exc:
        raise FrameRefused('invalid control JSON') from exc
    if type(value) is not dict:
        raise FrameRefused('control frame must contain an object')
    return value


def _unique_fields(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate control field')
        value[key] = item
    return value


class CompletionSession:
    """In-memory single-use challenge. Not an authentication or lock primitive."""

    def __init__(self, parent, candidate, protocol, *, authenticated_channel=False):
        if authenticated_channel is not True:
            raise FrameRefused('authenticated channel ownership required')
        protocol.identity(parent)
        protocol.identity(candidate)
        if candidate['timestamp'] <= parent['timestamp']:
            raise FrameRefused('invalid transaction order')
        self.parent = dict(parent)
        self.candidate = dict(candidate)
        self.protocol = protocol
        self._challenge = protocol.challenge(parent, candidate, secrets.token_hex(32))
        self._consumed = False

    def challenge_frame(self):
        if self._consumed:
            raise FrameRefused('challenge already consumed')
        return encode(self._challenge)

    def complete(self, frame, *, receiver_locks_held=False, authenticated_channel=False):
        # Consume before validation: failed or uncertain response cannot be replayed.
        if self._consumed:
            raise FrameRefused('completion already attempted')
        self._consumed = True
        if receiver_locks_held is not True or authenticated_channel is not True:
            raise FrameRefused('receiver locks and authenticated channel required')
        reply = decode(frame)
        result = self.protocol.validate_reply(
            self._challenge, reply, authenticated_session_bound=True,
            receiver_locks_held=True)
        return {'schema': 1, 'status': 'completion-control-validated',
                'parent': dict(self.parent), 'candidate': dict(self.candidate),
                'sender_exit_verified_by_control': True,
                'receipt_written': False, 'transfer_executed': False,
                'authorizes_promote': False, 'authorizes_prune': False,
                'authorizes_release': False}
