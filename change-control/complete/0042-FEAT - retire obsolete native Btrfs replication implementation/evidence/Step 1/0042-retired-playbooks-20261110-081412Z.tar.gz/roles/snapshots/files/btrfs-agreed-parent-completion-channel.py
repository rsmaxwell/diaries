#!/usr/bin/python3
"""0040 Step 12.3 / 04N: dormant authenticated-channel *transport contract*.

The caller must supply an ALREADY authenticated, exclusively owned and bounded
control-channel connection that is bound to the exact data-transfer session.
This module cannot establish SSH identity, bind independent SSH connections,
start Btrfs processes, or commit a receipt. A callable is NOT proof of identity.
"""
import struct

MAX_CONTROL = 4096

class ChannelRefused(RuntimeError):
    pass


def exact_read(read, count):
    """Read exactly count bytes; fail closed on EOF/invalid data."""
    if type(count) is not int or not 0 <= count <= MAX_CONTROL:
        raise ChannelRefused('invalid read bound')
    output = bytearray()
    while len(output) < count:
        block = read(count - len(output))
        if type(block) is not bytes or not block or len(block) > count-len(output):
            raise ChannelRefused('short or invalid control read')
        output.extend(block)
    return bytes(output)


def read_frame(read):
    """Four-byte length then at most 4096 bytes; no unbounded allocations."""
    prefix = exact_read(read, 4)
    size = struct.unpack('!I', prefix)[0]
    if size < 1 or size > MAX_CONTROL:
        raise ChannelRefused('invalid control frame size')
    return prefix + exact_read(read, size)


def write_frame(write, frame):
    """Write complete pre-encoded bounded frame. No silent short writes."""
    if type(frame) is not bytes or len(frame) < 5 or len(frame) > MAX_CONTROL+4:
        raise ChannelRefused('invalid outbound frame')
    size = struct.unpack('!I', frame[:4])[0]
    if size != len(frame)-4:
        raise ChannelRefused('invalid outbound frame length')
    offset = 0
    while offset < len(frame):
        n = write(frame[offset:])
        if type(n) is not int or n <= 0 or n > len(frame)-offset:
            raise ChannelRefused('short or invalid control write')
        offset += n


def perform_completion(session, channel, *, parent, candidate, session_id,
                       authenticated_peer=False, exclusive_channel=False,
                       same_transfer_session=False, receiver_locks_held=False,
                       deadline_enforced=False, binary_stream_finished=False):
    """One challenge/reply exchange on a separate control channel.

    channel exposes read(n), write(bytes), transfer_session_id; the outer
    coordinator is responsible for trusted peer authentication, EOF/timeout,
    independent data process exit checks, lock ownership, and receipt commit.
    No default success assumptions; never retry an uncertain session.
    """
    if not all(v is True for v in (authenticated_peer, exclusive_channel,
            same_transfer_session, receiver_locks_held, deadline_enforced,
            binary_stream_finished)):
        raise ChannelRefused('missing externally verified transfer safety conditions')
    if type(session_id) is not str or not session_id or getattr(channel,'transfer_session_id',None) != session_id:
        raise ChannelRefused('control/data session binding mismatch')
    if session.parent != parent or session.candidate != candidate:
        raise ChannelRefused('different A/B transaction')
    if not callable(getattr(channel,'read',None)) or not callable(getattr(channel,'write',None)):
        raise ChannelRefused('invalid channel')
    try:
        write_frame(channel.write, session.challenge_frame())
        response = read_frame(channel.read)
        result = session.complete(response, receiver_locks_held=True, authenticated_channel=True)
    except Exception as exc:
        # Session owner must discard connection and reconcile receiver state.
        raise ChannelRefused('completion exchange failed; inspect, do not retry') from exc
    return dict(result, control_session_id=session_id, receipt_written=False, transfer_executed=False)
