#!/usr/bin/python3
"""0040 Step 12.3 Integration 04K: dormant two-sided receipt commit contract.

A receiver cannot attest the sender process exit code merely from a completed
Btrfs receive. No production CLI, no filesystem writes, and no transfer action.
A future protocol needs a bounded authenticated completion message under the
same transaction locks before committing the final receipt.
"""
import re

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')


class CommitRefused(RuntimeError):
    pass


def identity(value):
    if (type(value) is not dict or set(value) != {'timestamp', 'uuid'} or
            type(value['timestamp']) is not str or not STAMP.fullmatch(value['timestamp']) or
            type(value['uuid']) is not str or not UUID.fullmatch(value['uuid'])):
        raise CommitRefused('invalid snapshot identity')
    return value


def validate_completion(parent, candidate, receiver_evidence, sender_completion, *,
                        manager_lock_held=False, writer_lock_held=False,
                        source_session_authenticated=False):
    """Validate evidence without persisting a receipt or granting mutation authority.

    The caller must obtain sender_completion from the authenticated live sender
    session *after* its process exits. A caller-supplied boolean is not proof of
    session ownership; the eventual service must enforce that boundary itself.
    """
    identity(parent)
    identity(candidate)
    if candidate['timestamp'] <= parent['timestamp']:
        raise CommitRefused('invalid incremental ordering')
    if (manager_lock_held is not True or writer_lock_held is not True or
            source_session_authenticated is not True):
        raise CommitRefused('receiver locks and authenticated source session required')
    if (type(receiver_evidence) is not dict or set(receiver_evidence) != {
            'parent', 'candidate', 'receiver_receive_exit', 'readonly_verified',
            'received_uuid', 'incremental_parent_verified', 'state_unchanged'} or
            receiver_evidence['parent'] != parent or
            receiver_evidence['candidate'] != candidate or
            type(receiver_evidence['receiver_receive_exit']) is not int or
            receiver_evidence['receiver_receive_exit'] != 0 or
            receiver_evidence['readonly_verified'] is not True or
            receiver_evidence['received_uuid'] != candidate['uuid'] or
            receiver_evidence['incremental_parent_verified'] is not True or
            receiver_evidence['state_unchanged'] is not True):
        raise CommitRefused('incomplete receiver evidence')
    if (type(sender_completion) is not dict or set(sender_completion) != {
            'transaction_id', 'parent', 'candidate', 'source_send_exit',
            'authenticated', 'stream_finished'} or
            sender_completion['transaction_id'] != candidate['timestamp'] or
            sender_completion['parent'] != parent or
            sender_completion['candidate'] != candidate or
            type(sender_completion['source_send_exit']) is not int or
            sender_completion['source_send_exit'] != 0 or
            sender_completion['authenticated'] is not True or
            sender_completion['stream_finished'] is not True):
        raise CommitRefused('missing verified sender completion')
    return {'schema': 1, 'status': 'receipt-commit-evidence-validated',
            'parent': dict(parent), 'candidate': dict(candidate),
            'source_send_exit': 0, 'receiver_receive_exit': 0,
            'receipt_written': False, 'state_changed': False,
            'authorizes_transfer': False, 'authorizes_promote': False,
            'authorizes_prune': False, 'authorizes_release': False}
