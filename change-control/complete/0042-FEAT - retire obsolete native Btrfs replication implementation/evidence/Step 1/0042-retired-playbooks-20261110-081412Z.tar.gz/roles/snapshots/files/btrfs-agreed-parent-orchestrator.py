#!/usr/bin/python3
"""0040 3H.4b: dormant sender RPC decision/confirmation adapter.

No SSH command construction, no local state writes, no Btrfs operations. The caller
must provide independently observed states/evidence while holding appropriate locks.
An uncertain RPC never triggers an implicit retry or a state transition.
"""
import importlib.util
import json
from pathlib import Path


def load(name):
    path = Path(__file__).with_name('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('agreed_0040_3h4b_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

coordinator = load('coordinator')
rpc = load('rpc')


class UncertainTransition(RuntimeError):
    """Receiver may have committed; the caller must perform an independent read."""


def receiver_request(operation, transaction_id, before, candidate):
    """Build a request compatible with the fixed receiver endpoint, never a shell command."""
    if operation not in ('get-state', 'prepare', 'promote'):
        raise ValueError('operation is not supported by receiver endpoint')
    rpc.require(isinstance(transaction_id, str) and bool(rpc.STAMP.fullmatch(transaction_id)),
                'invalid transaction ID')
    if before is not None:
        rpc.state(before)
    if operation == 'get-state':
        if candidate is not None:
            raise ValueError('get-state candidate must be null')
    else:
        if before is None:
            raise ValueError('mutation must specify expected state')
        rpc.identity(candidate)
        if candidate['timestamp'] != transaction_id:
            raise ValueError('candidate transaction mismatch')
    return json.dumps({'schema': 1, 'operation': operation,
                       'transaction_id': transaction_id,
                       'expected_before': before, 'candidate': candidate},
                      sort_keys=True, separators=(',', ':'))


def expected_receiver_after(operation, before, candidate):
    """Compute exact receiver postcondition from validated precondition."""
    rpc.state(before)
    if operation == 'prepare':
        if before['pending'] is not None or before['previous'] is not None:
            raise ValueError('transition already in progress')
        return {'schema': 1, 'established': before['established'],
                'pending': candidate, 'previous': None}
    if operation == 'promote':
        if before['pending'] != candidate or before['previous'] is not None:
            raise ValueError('candidate is not pending')
        return {'schema': 1, 'established': candidate, 'pending': None,
                'previous': before['established']}
    raise ValueError('unsupported mutation')


def confirm_mutation(operation, transaction_id, before, candidate, *, command, run):
    """Check SSH exit code AND exact durable JSON acknowledgement.

    ``command`` is a caller-constructed fixed argv. The caller is responsible for
    delivering receiver_request() to its stdin; this adapter never constructs a
    privileged command or performs an automatic retry.
    """
    expected = expected_receiver_after(operation, before, candidate)
    receiver_request(operation, transaction_id, before, candidate)
    try:
        response = rpc.request(command, operation=operation, transaction_id=transaction_id,
                               expected_state=expected, run=run)
    except rpc.ProtocolError as exc:
        raise UncertainTransition('receiver outcome uncertain: use read-only get-state') from exc
    return response['state']


def validate_recovery_reply(stdout, *, transaction_id, returncode=0):
    """Validate an unpredicted get-state response; never infer mutation success alone."""
    if type(returncode) is not int or returncode != 0:
        raise UncertainTransition('get-state did not complete')
    if type(stdout) is not str or not 0 < len(stdout) <= 65536:
        raise UncertainTransition('missing/oversized get-state reply')
    try:
        result = json.loads(stdout)
        if type(result) is not dict or set(result) != {'schema', 'operation', 'transaction_id', 'status', 'state'}:
            raise ValueError('unexpected fields')
        if (type(result['schema']) is not int or result['schema'] != 1 or
                result['operation'] != 'get-state' or result['transaction_id'] != transaction_id or
                result['status'] != 'success'):
            raise ValueError('stale or invalid recovery acknowledgement')
        rpc.state(result['state'])
    except (ValueError, TypeError, KeyError, rpc.ProtocolError) as exc:
        raise UncertainTransition('invalid receiver recovery reply') from exc
    return result['state']


def classify_recovery(*, operation, before, candidate, observed_receiver):
    """Describe observed receiver result; never perform a retry or release a pin."""
    rpc.state(observed_receiver)
    after = expected_receiver_after(operation, before, candidate)
    if observed_receiver == after:
        return 'receiver-committed-verified'
    if observed_receiver == before:
        return 'receiver-not-committed-reinspect-before-retry'
    raise UncertainTransition('receiver diverged: operator reconciliation required')


def next_action(source, receiver, candidate, *, source_candidate_verified, receiver_has_candidate):
    """Relay the deterministic decision; evidence flags are NOT trust assertions."""
    return coordinator.decision(source, receiver, candidate,
                                source_candidate_verified=source_candidate_verified,
                                receiver_has_candidate=receiver_has_candidate)
