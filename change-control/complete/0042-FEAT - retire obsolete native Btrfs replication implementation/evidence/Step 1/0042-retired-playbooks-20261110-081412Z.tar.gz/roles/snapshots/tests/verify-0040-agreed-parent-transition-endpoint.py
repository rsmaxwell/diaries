#!/usr/bin/python3
"""3H.3 dormant endpoint regression tests; no live receiver access."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

BASE = Path(__file__).resolve().parent
if not (BASE / 'btrfs-agreed-parent-transition-endpoint.py').exists():
    BASE = Path(__file__).resolve().parents[1] / 'files'
spec = importlib.util.spec_from_file_location('endpoint_3h3', BASE / 'btrfs-agreed-parent-transition-endpoint.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
A = {'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp':'20261031-030015Z','uuid':'3a2cc82d-a9ab-964f-af85-f073dd45f0a4'}
STATE = {'schema':1,'established':A,'pending':None,'previous':None}

def raw(op='get-state', expected=None, candidate=None):
    return json.dumps({'schema':1,'operation':op,'transaction_id':B['timestamp'],
                       'expected_before':expected,'candidate':candidate})

class Tests(unittest.TestCase):
    def test_recovery_get_state_without_expected(self):
        req = mod.parse_request(raw())
        self.assertIsNone(req['expected_before'])
        stub = Mock(); stub.transition.return_value={'state':STATE}
        self.assertEqual(mod.dispatch(req,core=stub,verifier=lambda *a:None)['state'],STATE)
        self.assertIsNone(stub.transition.call_args.kwargs['expected_before'])
    def test_prepare(self):
        self.assertEqual(mod.parse_request(raw('prepare',STATE,B))['candidate'],B)
    def test_promote(self):
        self.assertEqual(mod.parse_request(raw('promote',STATE,B))['operation'],'promote')
    def test_acknowledge_forbidden(self):
        with self.assertRaises(ValueError): mod.parse_request(raw('acknowledge-previous',STATE))
    def test_extra_fields_forbidden(self):
        value=json.loads(raw()); value['path']='/etc/passwd'
        with self.assertRaises(ValueError): mod.parse_request(json.dumps(value))
    def test_candidate_mismatch(self):
        with self.assertRaises(ValueError): mod.parse_request(raw('prepare',STATE,A))
    def test_invalid_state(self):
        with self.assertRaises(Exception): mod.parse_request(raw('prepare',{},B))
    def test_oversize(self):
        with self.assertRaises(ValueError): mod.parse_request(' ' * 65537)
    def test_non_json(self):
        with self.assertRaises(ValueError): mod.parse_request('not json')
    def test_receipt_failure(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); receipts=root/'state'; receipts.mkdir(); snaps=root/'snaps'; snaps.mkdir()
            observer=Mock(); observer.inspect_snapshot.return_value={'flags':'readonly','received_uuid':A['uuid']}
            with self.assertRaises(ValueError):
                mod.verify_snapshot(A,receipts,snaps,observer=observer)
    def test_mismatched_receipt(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); receipts=root/'state'; receipts.mkdir(); snaps=root/'snaps'; snaps.mkdir()
            (receipts/(A['timestamp']+'.json')).write_text(json.dumps({'schema':1,'snapshot':A['timestamp']}))
            observer=Mock(); observer.inspect_snapshot.return_value={'flags':'readonly','received_uuid':A['uuid']}
            with self.assertRaises(ValueError):
                mod.verify_snapshot(A,receipts,snaps,observer=observer)

if __name__=='__main__': unittest.main(verbosity=2)
