#!/usr/bin/python3
"""Offline 3H.4b RPC acknowledgement and interruption regressions."""
import importlib.util
import json
from pathlib import Path
import subprocess
import unittest

BASE = Path(__file__).resolve().parents[1] / 'files'

def mod(name):
    spec = importlib.util.spec_from_file_location('test_' + name, BASE / ('btrfs-agreed-parent-' + name + '.py'))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

m = mod('orchestrator')
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp': '20261031-030015Z', 'uuid': '11111111-2222-3333-4444-555555555555'}
T = B['timestamp']
S = {'schema': 1, 'established': A, 'pending': None, 'previous': None}
P = dict(S, pending=B)
Q = dict(S, established=B, previous=A)

def reply(op, s= P, tid=T):
    return json.dumps({'schema': 1, 'operation': op, 'transaction_id': tid, 'status': 'success', 'state': s})

class Tests(unittest.TestCase):
    def test_request_shape(self):
        self.assertEqual(json.loads(m.receiver_request('prepare', T, S, B))['candidate'], B)
    def test_no_previous_ack(self):
        with self.assertRaises(ValueError): m.receiver_request('acknowledge-previous', T, S, None)
    def test_get_state_without_expected(self):
        self.assertIsNone(json.loads(m.receiver_request('get-state', T, None, None))['expected_before'])
    def test_expected_prepare(self):
        self.assertEqual(m.expected_receiver_after('prepare', S, B), P)
    def test_expected_promote(self):
        self.assertEqual(m.expected_receiver_after('promote', P, B), Q)
    def test_confirm_success(self):
        result = m.confirm_mutation('prepare', T, S, B, command=['ssh', 'fixed'],
                 run=lambda *a, **kw: subprocess.CompletedProcess([], 0, reply('prepare')))
        self.assertEqual(result, P)
    def test_nonzero_with_valid_json(self):
        with self.assertRaises(m.UncertainTransition):
            m.confirm_mutation('prepare', T, S, B, command=['ssh', 'fixed'],
               run=lambda *a, **kw: subprocess.CompletedProcess([], 4, reply('prepare')))
    def test_wrong_json(self):
        with self.assertRaises(m.UncertainTransition):
            m.confirm_mutation('prepare', T, S, B, command=['ssh', 'fixed'],
               run=lambda *a, **kw: subprocess.CompletedProcess([], 0, reply('prepare', Q)))
    def test_timeout_never_retries(self):
        calls = []
        def fail(*args, **kwargs):
            calls.append(1)
            raise subprocess.TimeoutExpired('ssh', 3)
        with self.assertRaises(m.UncertainTransition):
            m.confirm_mutation('prepare', T, S, B, command=['ssh', 'fixed'], run=fail)
        self.assertEqual(len(calls), 1)
    def test_get_state_reply(self):
        self.assertEqual(m.validate_recovery_reply(reply('get-state', P), transaction_id=T), P)
    def test_stale_recovery_reply(self):
        with self.assertRaises(m.UncertainTransition):
            m.validate_recovery_reply(reply('get-state', P, '20261029-030003Z'), transaction_id=T)
    def test_nonzero_recovery(self):
        with self.assertRaises(m.UncertainTransition):
            m.validate_recovery_reply(reply('get-state', P), transaction_id=T, returncode=255)
    def test_reconciliation_committed(self):
        self.assertEqual(m.classify_recovery(operation='prepare', before=S, candidate=B, observed_receiver=P), 'receiver-committed-verified')
    def test_reconciliation_not_committed(self):
        self.assertEqual(m.classify_recovery(operation='prepare', before=S, candidate=B, observed_receiver=S), 'receiver-not-committed-reinspect-before-retry')
    def test_reconciliation_diverged(self):
        with self.assertRaises(m.UncertainTransition):
            m.classify_recovery(operation='prepare', before=S, candidate=B, observed_receiver=Q)

if __name__ == '__main__':
    unittest.main(verbosity=2)
