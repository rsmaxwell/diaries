#!/usr/bin/python3
"""0040-FEAT 3H.3: DORMANT receiver transition RPC endpoint candidate.

NOT installed, NOT sudo-authorised. Fixed paths and three explicitly allowed
operations. JSON request on stdin; exactly one JSON success on stdout. Errors
on stderr with exit 1. Does not implement acknowledgement or pruning.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
STATE_DIR = Path('/@data/mars-received/.replication-state')
SNAPSHOT_DIR = Path('/@data/mars-received/@data')
STATE_PATH = STATE_DIR / '.agreed-parent.json'
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER_LOCK = STATE_DIR / 'writer.lock'
RECEIVER_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'
SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
ALLOWED = {'get-state', 'prepare', 'promote'}


def load_module(name):
    path = BASE / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('agreed_3h3_' + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parse_request(raw):
    if not isinstance(raw, str) or not 0 < len(raw.encode('utf-8')) <= 65536:
        raise ValueError('missing/oversized request')
    data = json.loads(raw)
    if type(data) is not dict or set(data) != {'schema', 'operation', 'transaction_id', 'expected_before', 'candidate'}:
        raise ValueError('invalid request fields')
    if type(data['schema']) is not int or data['schema'] != 1 or data['operation'] not in ALLOWED:
        raise ValueError('invalid operation/schema')
    if type(data['transaction_id']) is not str or not STAMP.fullmatch(data['transaction_id']):
        raise ValueError('invalid transaction identity')
    if data['operation'] == 'get-state':
        if data['candidate'] is not None:
            raise ValueError('get-state cannot specify candidate')
        if data['expected_before'] is not None:
            load_module('state').validate(data['expected_before'])
    else:
        load_module('state').validate(data['expected_before'])
        load_module('state').snapshot(data['candidate'])
        if data['candidate']['timestamp'] != data['transaction_id']:
            raise ValueError('candidate/transaction mismatch')
    return data


def verify_snapshot(snapshot, receipt_dir, snapshot_dir, *, observer=None):
    """Called only while transition core holds manager+writer locks."""
    observer = observer or load_module('endpoint')
    observer.validate_filesystem()
    stamp, uuid = snapshot['timestamp'], snapshot['uuid']
    observed = observer.inspect_snapshot(stamp)
    path = receipt_dir / (stamp + '.json')
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
        raise ValueError('missing/unsafe receipt')
    receipt = json.loads(path.read_text(encoding='utf-8'))
    if (type(receipt) is not dict or receipt.get('schema') != 1 or
            receipt.get('snapshot') != stamp or receipt.get('source_uuid') != uuid or
            receipt.get('received_uuid') != uuid or
            receipt.get('destination') != str(snapshot_dir / stamp) or
            receipt.get('source_filesystem_uuid') != SOURCE_FS or
            receipt.get('receiver_filesystem_uuid') != RECEIVER_FS or
            receipt.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
            receipt.get('read_only_verified') is not True or
            type(receipt.get('source_send_exit')) is not int or receipt['source_send_exit'] != 0 or
            type(receipt.get('receiver_receive_exit')) is not int or receipt['receiver_receive_exit'] != 0 or
            observed.get('flags') != 'readonly' or observed.get('received_uuid') != uuid):
        raise ValueError('receiver evidence mismatch')


def dispatch(request, *, core=None, verifier=None):
    if core is None:
        core = load_module('transition')
    return core.transition(operation=request['operation'], transaction_id=request['transaction_id'],
                           expected_before=request['expected_before'], candidate=request['candidate'],
                           state_path=STATE_PATH, receipt_dir=STATE_DIR, snapshot_dir=SNAPSHOT_DIR,
                           manager_lock=MANAGER_LOCK, writer_lock=WRITER_LOCK,
                           verify=verifier or verify_snapshot)


def main():
    if sys.argv != [sys.argv[0], '--request']:
        raise ValueError('only fixed --request command allowed')
    if os.geteuid() != 0:
        raise ValueError('root required')
    # One bounded JSON request. Never accept paths, shell commands or arbitrary operation flags.
    raw = sys.stdin.buffer.read(65537)
    if len(raw) > 65536:
        raise ValueError('oversized request')
    request = parse_request(raw.decode('utf-8'))
    response = dispatch(request)
    print(json.dumps(response, sort_keys=True, separators=(',', ':')))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, RuntimeError, OSError, UnicodeError, subprocess.TimeoutExpired) as exc:
        print('receiver transition refused: ' + str(exc), file=sys.stderr)
        sys.exit(1)
