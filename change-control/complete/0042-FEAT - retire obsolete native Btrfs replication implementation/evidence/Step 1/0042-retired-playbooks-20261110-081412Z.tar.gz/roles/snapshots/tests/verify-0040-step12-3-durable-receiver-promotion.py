#!/usr/bin/python3
"""Offline regression for dormant durable receiver promotion."""
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve()
FILES = HERE.parent.parent / 'files'

def load(name):
    p = FILES / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), p)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

promotion = load('durable-promotion')
state = load('state')
A = {'timestamp': '20261030-010000Z', 'uuid': '11111111-1111-1111-1111-111111111111'}
B = {'timestamp': '20261031-010000Z', 'uuid': '22222222-2222-2222-2222-222222222222'}
BEFORE = state.prepare(state.initial(A), B)
AFTER = state.promote(BEFORE)

class Tests(unittest.TestCase):
    def test_durable_promotion(self):
        def core(**kw):
            self.assertEqual(kw['operation'], 'promote')
            self.assertEqual(kw['expected_before'], BEFORE)
            return {'schema': 1, 'status': 'success', 'operation': 'promote',
                    'transaction_id': B['timestamp'], 'state': AFTER}
        result = promotion.promote_receiver_fixed(BEFORE, B, transition=core,
                               state_module=state, transition_kwargs={})
        self.assertTrue(result['previous_retained'])
        self.assertFalse(result['authorizes_release'])

    def test_recovery_after_lost_ack(self):
        for observed, status in [(BEFORE, 'receiver-still-pending'),
                                 (AFTER, 'receiver-promoted-durable')]:
            def core(**kw):
                self.assertEqual(kw['operation'], 'get-state')
                return {'schema': 1, 'operation': 'get-state', 'status': 'success',
                        'transaction_id': B['timestamp'], 'state': observed}
            self.assertEqual(promotion.reconcile_receiver_fixed(BEFORE, B,
                transition=core, state_module=state, transition_kwargs={})['status'], status)

    def test_divergence_fail_closed(self):
        wrong = state.initial(A)
        with self.assertRaises(promotion.PromotionRefused):
            promotion.reconcile_receiver_fixed(BEFORE, B, transition=lambda **kw: {
                'schema': 1, 'operation': 'get-state', 'status': 'success',
                'transaction_id': B['timestamp'], 'state': wrong},
                state_module=state, transition_kwargs={})

    def test_malformed_reply_fail_closed(self):
        with self.assertRaises(promotion.PromotionRefused):
            promotion.promote_receiver_fixed(BEFORE, B, transition=lambda **kw: {},
                state_module=state, transition_kwargs={})

    def test_reject_unprepared(self):
        with self.assertRaises(promotion.PromotionRefused):
            promotion.promote_receiver_fixed(state.initial(A), B, transition=lambda **kw: None,
                state_module=state, transition_kwargs={})

    def test_does_not_retry_on_exception(self):
        count = [0]
        def failed(**kw):
            count[0] += 1
            raise ConnectionError('lost acknowledgement')
        with self.assertRaises(ConnectionError):
            promotion.promote_receiver_fixed(BEFORE, B, transition=failed,
                state_module=state, transition_kwargs={})
        self.assertEqual(count[0], 1)

if __name__ == '__main__':
    unittest.main()
