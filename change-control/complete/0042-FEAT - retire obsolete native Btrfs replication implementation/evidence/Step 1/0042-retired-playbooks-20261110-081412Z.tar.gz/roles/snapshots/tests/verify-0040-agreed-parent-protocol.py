#!/usr/bin/python3
"""Disposable persisted-endpoint protocol regressions; zero SSH/Btrfs operations."""
import importlib.util
import tempfile
import unittest
from pathlib import Path

FILES = Path(__file__).resolve().parents[1] / "files"
def load(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), FILES / name)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

state = load('btrfs-agreed-parent-state.py')
protocol = load('btrfs-agreed-parent-protocol.py')
A = {'timestamp': '20261030-120000Z', 'uuid': '11111111-1111-1111-1111-111111111111'}
B = {'timestamp': '20261030-130000Z', 'uuid': '22222222-2222-2222-2222-222222222222'}
C = {'timestamp': '20261030-140000Z', 'uuid': '33333333-3333-3333-3333-333333333333'}

class Regression(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.src, self.dst = root / 'source.json', root / 'receiver.json'
        state.save(self.src, state.initial(A))
        state.save(self.dst, state.initial(A))

    def prepare_pair(self):
        for p in (self.src, self.dst):
            protocol.prepare_endpoint(p, B, established_verified=True, candidate_pinned=True)

    def promote_pair(self):
        self.prepare_pair()
        for p in (self.dst, self.src):
            protocol.promote_endpoint(p, receipt_verified=True, peer_pending_verified=True)

    def test_complete_transition(self):
        self.promote_pair()
        self.assertEqual(protocol.verify_both_promoted(self.src, self.dst)['established'], B)
        for p in (self.src, self.dst):
            protocol.clear_previous_endpoint(p, both_promoted_verified=True)
        self.assertTrue(protocol.plan(self.src, self.dst)['synchronised'])
        self.assertEqual(protocol.plan(self.src, self.dst)['protected_union'], [B['timestamp']])

    def test_interruption_after_only_one_prepare(self):
        protocol.prepare_endpoint(self.src, B, established_verified=True, candidate_pinned=True)
        view = protocol.plan(self.src, self.dst)
        self.assertFalse(view['synchronised'])
        self.assertEqual(view['protected_union'], [A['timestamp'], B['timestamp']])
        with self.assertRaises(protocol.StateError):
            protocol.verify_both_promoted(self.src, self.dst)

    def test_interruption_after_receiver_promotes(self):
        self.prepare_pair()
        protocol.promote_endpoint(self.dst, receipt_verified=True, peer_pending_verified=True)
        with self.assertRaises(protocol.StateError):
            protocol.verify_both_promoted(self.src, self.dst)
        self.assertEqual(protocol.plan(self.src, self.dst)['protected_union'],
                         [A['timestamp'], B['timestamp']])

    def test_confirmation_mandatory(self):
        with self.assertRaises(protocol.StateError):
            protocol.prepare_endpoint(self.src, B, established_verified=False, candidate_pinned=True)
        self.prepare_pair()
        with self.assertRaises(protocol.StateError):
            protocol.promote_endpoint(self.src, receipt_verified=False, peer_pending_verified=True)
        with self.assertRaises(protocol.StateError):
            protocol.clear_previous_endpoint(self.src, both_promoted_verified=False)

    def test_mismatched_promotions_refused(self):
        self.promote_pair()
        state.save(self.dst, state.initial(C))
        with self.assertRaises(protocol.StateError):
            protocol.verify_both_promoted(self.src, self.dst)

    def test_missing_or_corrupt_state_blocks(self):
        self.dst.unlink()
        with self.assertRaises(protocol.StateError):
            protocol.plan(self.src, self.dst)
        self.dst.write_text('{oops')
        with self.assertRaises(protocol.StateError):
            protocol.plan(self.src, self.dst)

    def test_no_overlapping_or_backward_transition(self):
        with self.assertRaises(protocol.StateError):
            protocol.prepare_endpoint(self.src, A, established_verified=True, candidate_pinned=True)
        protocol.prepare_endpoint(self.src, B, established_verified=True, candidate_pinned=True)
        with self.assertRaises(protocol.StateError):
            protocol.prepare_endpoint(self.src, C, established_verified=True, candidate_pinned=True)

if __name__ == '__main__':
    unittest.main(verbosity=2)
