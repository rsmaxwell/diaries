#!/usr/bin/python3
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SRC = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-bootstrap.py'
spec = importlib.util.spec_from_file_location('bootstrap_0040', SRC)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def evidence():
    u, t = mod.UUID, mod.STAMP
    return dict(source={'uuid': u, 'readonly': True}, receiver={'received_uuid': u, 'readonly': True},
                receipt={'schema': 1, 'snapshot': t, 'source_uuid': u, 'received_uuid': u,
                         'read_only_verified': True, 'source_send_exit': 0, 'receiver_receive_exit': 0},
                source_pins={'protected': {t: u}, 'prune_protected': {t: u}}, receiver_prune_disabled=True)


class BootstrapRegression(unittest.TestCase):
    def test_verified_evidence(self):
        self.assertEqual(mod.validate_candidate(**evidence())['uuid'], mod.UUID)

    def test_wrong_receiver_rejected(self):
        e = evidence(); e['receiver']['received_uuid'] = 'wrong'
        with self.assertRaises(RuntimeError): mod.validate_candidate(**e)

    def test_missing_pin_rejected(self):
        e = evidence(); e['source_pins']['prune_protected'] = {}
        with self.assertRaises(RuntimeError): mod.validate_candidate(**e)

    def test_prune_gate_rejected(self):
        e = evidence(); e['receiver_prune_disabled'] = False
        with self.assertRaises(RuntimeError): mod.validate_candidate(**e)

    def test_idempotent_disposable(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / '.agreed-parent.json'
            c = mod.validate_candidate(**evidence())
            self.assertEqual(mod.disposable_commit(p, c, lock_asserted=True, protection_frozen=True), 'created')
            self.assertEqual(mod.disposable_commit(p, c, lock_asserted=True, protection_frozen=True), 'unchanged')

    def test_freeze_required(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / '.agreed-parent.json'
            with self.assertRaises(RuntimeError):
                mod.disposable_commit(p, mod.validate_candidate(**evidence()), lock_asserted=True, protection_frozen=False)
            self.assertFalse(p.exists())

    def test_conflict_and_corruption_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / '.agreed-parent.json'
            p.write_text('invalid json')
            with self.assertRaises(RuntimeError):
                mod.disposable_commit(p, mod.validate_candidate(**evidence()), lock_asserted=True, protection_frozen=True)
            self.assertEqual(p.read_text(), 'invalid json')

    def test_cli_read_only(self):
        result = subprocess.run([sys.executable, str(SRC), '--plan'], capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        self.assertFalse(data['authorizes_state_write'])
        self.assertFalse(data['authorizes_prune'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
