#!/usr/bin/python3
"""0040 Step 12.3: dormant durable receiver promotion/reconciliation.

NO CLI, SSH route, sudoers permission, scheduling or parent release.
Only call after independently verifying the completed B transfer. This module
never treats a lost acknowledgement as evidence that promotion failed.
"""


class PromotionRefused(RuntimeError):
    pass


def _request(before, candidate):
    if type(before) is not dict or type(candidate) is not dict:
        raise PromotionRefused('invalid promotion input')
    if before.get('pending') != candidate or before.get('previous') is not None:
        raise PromotionRefused('candidate not exclusively pending')
    if before.get('established') is None:
        raise PromotionRefused('missing established parent')
    if candidate['timestamp'] <= before['established']['timestamp']:
        raise PromotionRefused('candidate is not newer')
    return {'operation': 'promote', 'transaction_id': candidate['timestamp'],
            'expected_before': before, 'candidate': candidate}


def promoted_state(before, candidate, *, state_module):
    state_module.validate(before)
    state_module.snapshot(candidate)
    _request(before, candidate)
    return state_module.promote(before)


def promote_receiver_fixed(before, candidate, *, transition, state_module, transition_kwargs):
    """Transition under core locks, durable readback and receipt verification.

    `transition` is the existing transition.transition API, with trusted fixed
    receiver paths/verify/lock supplied by its privileged caller. No default
    runtime entry is provided. No retry on an exception or uncertain SSH result.
    """
    expected = promoted_state(before, candidate, state_module=state_module)
    if type(transition_kwargs) is not dict:
        raise PromotionRefused('missing trusted transition configuration')
    result = transition(**_request(before, candidate), **transition_kwargs)
    if (type(result) is not dict or result.get('schema') != 1 or
            result.get('status') != 'success' or result.get('operation') != 'promote' or
            result.get('transaction_id') != candidate['timestamp'] or
            result.get('state') != expected):
        raise PromotionRefused('receiver promotion durable postcondition not confirmed')
    return {'schema': 1, 'status': 'receiver-promoted-durable',
            'parent': before['established'], 'candidate': candidate,
            'state': expected, 'previous_retained': True,
            'authorizes_release': False, 'authorizes_prune': False}


def reconcile_receiver_fixed(before, candidate, *, transition, state_module, transition_kwargs):
    """Read only, after lost acknowledgement. Never retry the write.

    Returns pending, promoted or refused. Caller must compare both peers before
    advancing on mars. Refusal leaves A+B protected and demands investigation.
    """
    expected = promoted_state(before, candidate, state_module=state_module)
    response = transition(operation='get-state', transaction_id=candidate['timestamp'],
                          expected_before=None, candidate=None, **transition_kwargs)
    if (type(response) is not dict or response.get('schema') != 1 or
            response.get('operation') != 'get-state' or response.get('status') != 'success' or
            response.get('transaction_id') != candidate['timestamp']):
        raise PromotionRefused('untrusted receiver state readback')
    observed = response.get('state')
    state_module.validate(observed)
    if observed == expected:
        status = 'receiver-promoted-durable'
    elif observed == before:
        status = 'receiver-still-pending'
    else:
        raise PromotionRefused('receiver state diverged; manual reconciliation required')
    return {'schema': 1, 'status': status, 'state': observed,
            'previous_retained': observed == expected,
            'authorizes_release': False, 'authorizes_prune': False}
