#!/usr/bin/python3
"""Regression for the 04S dormant receiver lock integration."""
from contextlib import contextmanager
import importlib.util
from pathlib import Path
import unittest

p = Path(__file__).parents[1] / 'files/btrfs-agreed-parent-locked-session-review.py'
spec = importlib.util.spec_from_file_location('review04s', p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp': '20261030-170009Z', 'uuid': 'a9b78fb9-4da6-cf4f-b242-13909f574193'}
S = {'schema': 1, 'established': A, 'pending': B, 'previous': None}

class Fake:
    def __init__(self):
        self.events = []
        self.fail = None
        self.session = None
    def deps(self):
        f = self
        class Receiver:
            @staticmethod
            def _lock(stack, path):
                label = 'manager' if 'manager' in str(path) else 'writer'
                @contextmanager
                def acquire():
                    f.events.append('enter-' + label)
                    try: yield
                    finally: f.events.append('leave-' + label)
                stack.enter_context(acquire())
        class Endpoint:
            @staticmethod
            def validate_filesystem():
                f.events.append('fs')
        class State:
            @staticmethod
            def snapshot(item):
                if item not in (A, B): raise RuntimeError('unknown identity')
            @staticmethod
            def load(path):
                f.events.append('state')
                return S
        class Absence:
            @staticmethod
            def verify(a, b, current, **kwargs):
                f.events.append('absence')
                if f.fail == 'absence': raise RuntimeError('artifact exists')
                return {'destination_absent': True, 'receipt_absent': True}
        class Boundary:
            @staticmethod
            def verify_before_receive(*args, **kwargs):
                f.events.append('boundary')
                if f.fail == 'boundary': raise RuntimeError('boundary refusal')
                assert kwargs['manager_lock_held'] and kwargs['writer_lock_held']
        class Session:
            def __init__(self, *args, **kwargs):
                f.events.append('session')
                self.phase = 'registering'
                f.session = self
            def close(self):
                f.events.append('close')
                self.phase = 'closed'
        class Binding: ReceiverSession = Session
        return dict(receiver=Receiver, endpoint=Endpoint, state=State,
                    absence=Absence, boundary=Boundary, binding=Binding)

class Tests(unittest.TestCase):
    def test_success_and_order(self):
        f=Fake(); result=m.review(A,B,deps=f.deps())
        self.assertEqual(result['status'], 'receiver-locked-session-review')
        self.assertEqual(result['channels_registered'], [])
        self.assertFalse(result['authorizes_transfer'])
        self.assertEqual(f.events, ['enter-manager','enter-writer','fs','state',
                                    'absence','boundary','session','close','leave-writer','leave-manager'])
        self.assertEqual(f.session.phase, 'closed')
    def test_absence_failure_frees_locks(self):
        f=Fake();f.fail='absence'
        with self.assertRaisesRegex(RuntimeError,'artifact'):m.review(A,B,deps=f.deps())
        self.assertEqual(f.events[-2:],['leave-writer','leave-manager'])
        self.assertNotIn('session',f.events)
    def test_boundary_failure_frees_locks(self):
        f=Fake();f.fail='boundary'
        with self.assertRaisesRegex(RuntimeError,'boundary'):m.review(A,B,deps=f.deps())
        self.assertEqual(f.events[-2:],['leave-writer','leave-manager'])
    def test_wrong_order(self):
        f=Fake()
        with self.assertRaises(RuntimeError):m.review(B,A,deps=f.deps())
        self.assertFalse(f.events)
    def test_no_ssh_or_receive(self):
        src=p.read_text()
        self.assertNotIn('subprocess',src)
        self.assertNotIn('socket.',src)
        self.assertNotIn('session.register(',src)
        self.assertNotIn('btrfs receive',src.lower().replace('no btrfs receive', ''))
    def test_cli_review_only(self):
        src=p.read_text()
        self.assertIn("required=True)",src)
        self.assertNotIn('execute-transfer',src)
    def test_no_session_token_export(self):
        f=Fake(); r=m.review(A,B,deps=f.deps())
        self.assertNotIn('token',str(r))
    def test_missing_absence_evidence(self):
        f=Fake(); d=f.deps()
        class Bad:
            @staticmethod
            def verify(*args, **kwargs): return {'destination_absent': True, 'receipt_absent': False}
        d['absence']=Bad
        with self.assertRaisesRegex(RuntimeError,'absence'): m.review(A,B,deps=d)
        self.assertEqual(f.events[-2:],['leave-writer','leave-manager'])

if __name__ == '__main__': unittest.main(verbosity=2)
