#!/usr/bin/python3
"""Disposable tests: no host writes, no systemctl or Btrfs calls."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest import TestCase, main, mock

SCRIPT = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-initialise.py'
spec = importlib.util.spec_from_file_location('init0040', SCRIPT)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class GuardTests(TestCase):
    def test_source_identity(self):
        m.parse_subvolume(' UUID: '+m.UUID+'\n Flags: readonly\n', 'source')

    def test_receiver_identity(self):
        m.parse_subvolume(' Received UUID: '+m.UUID+'\n Flags: readonly\n', 'receiver')

    def test_wrong_uuid(self):
        with self.assertRaises(RuntimeError):
            m.parse_subvolume(' UUID: wrong\n Flags: readonly\n', 'source')

    def test_not_readonly(self):
        with self.assertRaises(RuntimeError):
            m.parse_subvolume(' UUID: '+m.UUID+'\n Flags: -\n', 'source')

    def test_running_service_refused(self):
        with self.assertRaises(RuntimeError):
            m.check_quiescence('source', active={'push.service': 'active'})

    def test_inactive_services(self):
        m.check_quiescence('source', active={'push.service': 'inactive', 'prune.timer': 'inactive'})

    def test_plan_cli_requires_endpoint(self):
        result = subprocess.run([sys.executable, str(SCRIPT), '--plan'], capture_output=True)
        self.assertNotEqual(result.returncode, 0)

    def test_source_requires_peer(self):
        with mock.patch.object(m.os, 'geteuid', return_value=0):
            with self.assertRaisesRegex(RuntimeError, 'receiver must'):
                m.initialise('source', apply=True)

    def test_non_root_write_refused(self):
        with mock.patch.object(m.os, 'geteuid', return_value=1000):
            with self.assertRaisesRegex(RuntimeError, 'root required'):
                m.initialise('receiver', apply=True)

    def test_source_protection_missing_pin(self):
        with mock.patch.object(m.Path, 'is_dir', return_value=True), mock.patch.object(m.Path, 'is_symlink', return_value=False):
            with self.assertRaisesRegex(RuntimeError, 'source protection'):
                m.check_evidence('source', show='UUID: '+m.UUID+'\nFlags: readonly',
                                 protection={'schema': 1, 'protected': {m.STAMP: m.UUID}})

    def test_receiver_pruning_refused(self):
        with mock.patch.object(m.Path, 'is_dir', return_value=True), mock.patch.object(m.Path, 'is_symlink', return_value=False):
            with self.assertRaisesRegex(RuntimeError, 'receiver pruning'):
                m.check_evidence('receiver', show='Received UUID: '+m.UUID+'\nFlags: readonly',
                                 config={'mode': 'receiver', 'receiver_prune_enabled': True})

    def test_receiver_bad_receipt(self):
        with mock.patch.object(m.Path, 'is_dir', return_value=True), mock.patch.object(m.Path, 'is_symlink', return_value=False):
            with self.assertRaisesRegex(RuntimeError, 'receipt'):
                m.check_evidence('receiver', show='Received UUID: '+m.UUID+'\nFlags: readonly',
                                 config={'mode': 'receiver', 'receiver_prune_enabled': False}, receipt={'schema': 1})

    def test_state_file_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / '.agreed-parent.json'
            s = m.state_module()
            s.save(p, s.initial({'timestamp': m.STAMP, 'uuid': m.UUID}))
            self.assertEqual(p.stat().st_mode & 0o777, 0o600)
            self.assertEqual(s.load(p)['established']['uuid'], m.UUID)


if __name__ == '__main__':
    main(verbosity=2)
