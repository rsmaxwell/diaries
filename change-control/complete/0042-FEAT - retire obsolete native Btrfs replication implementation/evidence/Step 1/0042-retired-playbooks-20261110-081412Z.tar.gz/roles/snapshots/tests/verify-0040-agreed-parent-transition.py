#!/usr/bin/python3
"""3H.2 non-production contract regressions (no Btrfs or SSH)."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-transition.py'
if not MODULE.exists():
    MODULE = Path(__file__).with_name('btrfs-agreed-parent-transition.py')
spec = importlib.util.spec_from_file_location('transition_3h2', MODULE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp': '20261031-030015Z', 'uuid': '3a2cc82d-a9ab-964f-af85-f073dd45f0a4'}


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        base = Path(self.tmp.name)
        self.receipts = base / 'state'; self.receipts.mkdir()
        self.snaps = base / 'snapshots'; self.snaps.mkdir()
        self.manager = base / 'manager.lock'; self.manager.touch()
        self.writer = self.receipts / 'writer.lock'; self.writer.touch()
        self.path = self.receipts / '.agreed-parent.json'
        self.current = mod.state.initial(A)
        self.checked = []
        self.writes = []

    def verify(self, snap, receipt_dir, snapshot_dir):
        self.checked.append(snap)

    def save(self, path, data, *, require_root):
        self.assertTrue(require_root)
        self.current = data
        self.writes.append(data)

    def load(self, path, *, require_root):
        self.assertTrue(require_root)
        return self.current

    def call(self, operation, expected, candidate=None, transaction_id=B['timestamp'], verify=None):
        with patch.object(mod.state, 'load', self.load), patch.object(mod.state, 'save', self.save):
            return mod.transition(operation=operation, transaction_id=transaction_id,
                                  expected_before=expected, candidate=candidate,
                                  state_path=self.path, receipt_dir=self.receipts,
                                  snapshot_dir=self.snaps, manager_lock=self.manager,
                                  writer_lock=self.writer, verify=self.verify if verify is None else verify,
                                  lock=lambda stack, path: None)

    def test_get_state(self):
        result = self.call('get-state', self.current)
        self.assertEqual(result['state'], self.current)
        self.assertFalse(self.writes)

    def test_prepare_and_idempotence(self):
        before = self.current
        result = self.call('prepare', before, B)
        self.assertEqual(result['state']['pending'], B)
        self.assertEqual(len(self.writes), 1)
        self.call('prepare', before, B)
        self.assertEqual(len(self.writes), 1)
        self.assertEqual({v['timestamp'] for v in self.checked}, {A['timestamp']})

    def test_prepare_allows_unreceived_candidate_but_promote_requires_receipt(self):
        def verifier(snap, *args):
            if snap == B:
                raise RuntimeError('B not received yet')
        before = self.current
        prepared = self.call('prepare', before, B, verify=verifier)['state']
        self.assertEqual(prepared['pending'], B)
        with self.assertRaises(RuntimeError):
            self.call('promote', prepared, B, verify=verifier)
        self.assertEqual(len(self.writes), 1)

    def test_promote_and_acknowledge(self):
        before = self.current
        prepared = self.call('prepare', before, B)['state']
        promoted = self.call('promote', prepared, B)['state']
        self.assertEqual(promoted['established'], B)
        self.assertEqual(promoted['previous'], A)
        self.assertEqual(promoted['pending'], None)
        self.call('promote', prepared, B)
        self.assertEqual(len(self.writes), 2)
        acknowledged = self.call('acknowledge-previous', promoted)['state']
        self.assertIsNone(acknowledged['previous'])

    def test_stale_request_rejected(self):
        self.call('prepare', self.current, B)
        with self.assertRaises(mod.state.StateError):
            self.call('get-state', mod.state.initial(B))

    def test_candidate_mismatch_rejected(self):
        with self.assertRaises(mod.state.StateError):
            self.call('prepare', self.current, dict(B, timestamp='20261101-030015Z'))

    def test_evidence_failure_prevents_write(self):
        def fail(*args): raise RuntimeError('bad receipt')
        with self.assertRaises(RuntimeError):
            self.call('prepare', self.current, B, verify=fail)
        self.assertFalse(self.writes)

    def test_pending_deletion_prevents_write(self):
        (self.receipts / '.receiver-prune-pending.json').touch()
        with self.assertRaises(mod.state.StateError):
            self.call('prepare', self.current, B)
        self.assertFalse(self.writes)

    def test_durable_readback_failure(self):
        with patch.object(mod.state, 'load', side_effect=[self.current, self.current]), patch.object(mod.state, 'save', self.save):
            with self.assertRaises(mod.state.StateError):
                mod.transition(operation='prepare', transaction_id=B['timestamp'], expected_before=self.current,
                    candidate=B, state_path=self.path, receipt_dir=self.receipts,
                    snapshot_dir=self.snaps, manager_lock=self.manager, writer_lock=self.writer,
                    verify=self.verify, lock=lambda stack, path: None)

    def test_acknowledge_requires_previous(self):
        with self.assertRaises(mod.state.StateError):
            self.call('acknowledge-previous', self.current)

    def test_no_implicit_ssh(self):
        self.assertNotIn('subprocess', mod.__dict__)

if __name__ == '__main__':
    unittest.main(verbosity=2)
