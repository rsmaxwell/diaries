#!/usr/bin/python3
"""3D source-only integration regressions; mock Btrfs, never call live systems."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

base = Path(__file__).resolve().parents[1] / 'files'
spec = importlib.util.spec_from_file_location('agreed_3d', base/'btrfs-agreed-parent-endpoint.py')
endpoint = importlib.util.module_from_spec(spec)
spec.loader.exec_module(endpoint)
STAMP = '20261030-130000Z'
UUID = '01234567-89ab-cdef-0123-456789abcdef'

class Regression(unittest.TestCase):
    def runner(self, argv, **kwargs):
        if argv[1:3] == ['filesystem', 'show']:
            return SimpleNamespace(returncode=0, stdout='uuid: '+endpoint.RECEIVER_FS+'\n')
        return SimpleNamespace(returncode=0, stdout='UUID: another\nFlags: readonly\nReceived UUID: '+UUID+'\n')

    def test_filesystem_valid(self):
        endpoint.validate_filesystem(runner=self.runner)

    def test_filesystem_mismatch(self):
        with self.assertRaises(RuntimeError):
            endpoint.validate_filesystem(runner=lambda *a,**k: SimpleNamespace(returncode=0,stdout='uuid: wrong'))

    def test_failure_rejected(self):
        with self.assertRaises(RuntimeError):
            endpoint.validate_filesystem(runner=lambda *a,**k: SimpleNamespace(returncode=1,stdout=''))

    def test_subvolume_identity(self):
        with patch.object(endpoint, 'SNAPSHOT_DIR', Path('/tmp/nonexistent-0040-3d')):
            with self.assertRaises(RuntimeError): endpoint.inspect_snapshot(STAMP, runner=self.runner)

    def test_traversal_rejected(self):
        with self.assertRaises(RuntimeError): endpoint.inspect_snapshot('../bad', runner=self.runner)

    def test_observation_has_no_writes(self):
        class Receiver:
            def observe(self, **kw):
                self.kw = kw
                return {'authorizes_transition':False,'authorizes_prune':False}
        receiver = Receiver()
        result = endpoint.observe(runner=self.runner, receiver_module=receiver)
        self.assertFalse(result['authorizes_prune'])
        self.assertEqual(receiver.kw['state_path'], endpoint.STATE_PATH)
        self.assertEqual(receiver.kw['writer_lock'], endpoint.WRITER_LOCK)
        self.assertEqual(receiver.kw['source_fs'], endpoint.SOURCE_FS)

    def test_oversized_response(self):
        with self.assertRaises(RuntimeError):
            endpoint.btrfs_run(['btrfs','filesystem','show','/'], runner=lambda *a,**k: SimpleNamespace(returncode=0,stdout='x'*70000))

if __name__ == '__main__': unittest.main(verbosity=2)
