#!/usr/bin/python3
"""Disposable Increment 3B read-only transport contract regressions."""
import importlib.util
import json
from pathlib import Path
import subprocess
import unittest

path = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-ssh.py'
spec = importlib.util.spec_from_file_location('agreed_parent_ssh', path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
UUID = '01234567-89ab-cdef-0123-456789abcdef'

def fixture(host='mars'):
    return {'schema': 1, 'host': host, 'snapshot': '20261030-130000Z',
            'source_uuid': UUID, 'read_only': True, 'receipt_verified': True}

class Regression(unittest.TestCase):
    def test_valid_pair_read_only(self):
        result = mod.compare(fixture(), fixture('backup'))
        self.assertTrue(result['matched'])
        self.assertFalse(result['authorizes_transition'])
        self.assertFalse(result['authorizes_prune'])

    def test_wrong_identity_rejected(self):
        peer = fixture('backup'); peer['source_uuid'] = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
        with self.assertRaises(mod.ObservationError): mod.compare(fixture(), peer)

    def test_missing_receipt_rejected(self):
        peer = fixture('backup'); peer['receipt_verified'] = False
        with self.assertRaises(mod.ObservationError): mod.compare(fixture(), peer)

    def test_extra_fields_rejected(self):
        record = fixture(); record['prune_approved'] = True
        with self.assertRaises(mod.ObservationError): mod.validate_observation(record)

    def test_bounded_ssh_success(self):
        def runner(argv, **kw):
            self.assertEqual(argv, ['ssh', 'backup', 'readonly-endpoint'])
            self.assertLessEqual(kw['timeout'], 60)
            return subprocess.CompletedProcess(argv, 0, json.dumps(fixture('backup')), '')
        self.assertFalse(mod.collect(['ssh', 'backup', 'readonly-endpoint'], runner=runner)['authorizes_transition'])

    def test_timeout_rejected(self):
        def runner(argv, **kw): raise subprocess.TimeoutExpired(argv, kw['timeout'])
        with self.assertRaises(mod.ObservationError): mod.collect(['ssh', 'backup'], runner=runner)

    def test_nonzero_rejected(self):
        def runner(argv, **kw): return subprocess.CompletedProcess(argv, 255, '', 'ssh failure')
        with self.assertRaises(mod.ObservationError): mod.collect(['ssh', 'backup'], runner=runner)

    def test_malformed_json_rejected(self):
        def runner(argv, **kw): return subprocess.CompletedProcess(argv, 0, '{', '')
        with self.assertRaises(mod.ObservationError): mod.collect(['ssh', 'backup'], runner=runner)

if __name__ == '__main__':
    unittest.main(verbosity=2)
