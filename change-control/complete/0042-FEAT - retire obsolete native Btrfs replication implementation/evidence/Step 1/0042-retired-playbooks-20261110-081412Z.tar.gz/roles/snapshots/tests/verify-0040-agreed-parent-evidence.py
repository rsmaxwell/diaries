#!/usr/bin/python3
import copy
import importlib.util
import pathlib
import unittest

FILE = pathlib.Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-evidence.py'
spec = importlib.util.spec_from_file_location('evidence_0040', FILE)
e = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)
UUID = '11111111-1111-1111-1111-111111111111'
OTHER = '22222222-2222-2222-2222-222222222222'
STAMP = '20261030-130000Z'
IDENTITY = {'timestamp': STAMP, 'uuid': UUID}
SOURCE = {'uuid': UUID, 'flags': 'readonly', 'parent_uuid': OTHER, 'received_uuid': '-'}
RECEIVER = {'uuid': OTHER, 'flags': 'readonly', 'received_uuid': UUID}
RECEIPT = {'schema': 1, 'snapshot': STAMP, 'source_uuid': UUID, 'received_uuid': UUID,
           'destination': '/received/' + STAMP, 'source_filesystem_uuid': 'source-fs',
           'receiver_filesystem_uuid': 'receiver-fs', 'transport': 'btrfs-incremental',
           'read_only_verified': True, 'source_send_exit': 0, 'receiver_receive_exit': 0}


def check(source=SOURCE, receiver=RECEIVER, receipt=RECEIPT):
    return e.verify_snapshot_pair(IDENTITY, source, receiver, receipt,
        source_parent_uuid=OTHER, destination='/received/' + STAMP,
        source_fs='source-fs', receiver_fs='receiver-fs')


class EvidenceRegression(unittest.TestCase):
    def test_valid_read_only(self):
        self.assertFalse(check()['authorizes_state_transition'])
        self.assertFalse(check()['authorizes_prune'])

    def test_source_mutation_or_lineage_fails(self):
        for key, value in [('uuid', OTHER), ('flags', 'readwrite'), ('parent_uuid', UUID), ('received_uuid', UUID)]:
            with self.subTest(key=key):
                x = dict(SOURCE, **{key: value})
                with self.assertRaises(e.StateError): check(source=x)

    def test_receiver_identity_fails(self):
        for key, value in [('received_uuid', OTHER), ('flags', 'readwrite'), ('uuid', None)]:
            with self.subTest(key=key):
                with self.assertRaises(e.StateError): check(receiver=dict(RECEIVER, **{key: value}))

    def test_receipt_tampering_fails(self):
        for key, value in [('snapshot', '20261029-130000Z'), ('destination', '/other'),
                           ('source_uuid', OTHER), ('received_uuid', OTHER),
                           ('source_filesystem_uuid', 'wrong'), ('receiver_filesystem_uuid', 'wrong'),
                           ('read_only_verified', 1), ('source_send_exit', False),
                           ('receiver_receive_exit', 1), ('transport', 'unknown'), ('schema', True)]:
            with self.subTest(key=key):
                with self.assertRaises(e.StateError): check(receipt=dict(RECEIPT, **{key: value}))

    def test_missing_evidence_fails(self):
        for item in (None, [], 'bad'):
            with self.assertRaises(e.StateError): check(receipt=item)

    def test_union_rejects_conflicting_uuid(self):
        a = e._state.initial(IDENTITY)
        b = e._state.initial({'timestamp': STAMP, 'uuid': OTHER})
        with self.assertRaises(e.StateError): e.protected_union(a, b)

    def test_union_covers_pending_and_previous(self):
        a = e._state.initial(IDENTITY)
        b = e._state.prepare(a, {'timestamp': '20261030-140000Z', 'uuid': OTHER})
        promoted = e._state.promote(b)
        result = e.protected_union(a, promoted)
        self.assertEqual(set(result), {STAMP, '20261030-140000Z'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
