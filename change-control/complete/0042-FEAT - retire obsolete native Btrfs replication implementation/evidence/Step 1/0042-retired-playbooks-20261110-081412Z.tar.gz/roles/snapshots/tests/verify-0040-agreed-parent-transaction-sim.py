#!/usr/bin/python3
"""Simulated 0040 3H.4e durability / interruption boundaries."""
import importlib.util
from pathlib import Path
import unittest

FILE = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-transaction-sim.py'
spec = importlib.util.spec_from_file_location('agreed_3h4e_sim', FILE)
sim = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sim)
A = {'timestamp': '20261030-030033Z', 'uuid': 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B = {'timestamp': '20261031-030015Z', 'uuid': '00000000-0000-0000-0000-000000000001'}
STEPS = ('prepare-receiver', 'prepare-source', 'replicate-candidate', 'promote-receiver', 'promote-source')


class Tests(unittest.TestCase):
    def test_happy_path(self):
        s = sim.Simulation(A, B)
        left, right = s.finish()
        self.assertEqual(left, right)
        self.assertEqual(left['established'], B)
        self.assertEqual(left['previous'], A)
        self.assertIsNone(left['pending'])
        self.assertEqual(s.transfer_count, 1)
        self.assertEqual(s.choose(), 'await-cross-endpoint-acknowledgement')

    def test_each_lost_ack_reconciles_from_durable_state(self):
        for boundary in STEPS:
            with self.subTest(boundary=boundary):
                s = sim.Simulation(A, B)
                while s.choose() != boundary:
                    s.step()
                with self.assertRaises(sim.Interrupted):
                    s.step(interrupt_after=boundary)
                # No assumed rollback and no blind retry of the lost command.
                # The next action is computed from independently observed states.
                observed = s.choose()
                self.assertNotEqual(observed, boundary)
                left, right = s.finish()
                self.assertEqual(left, right)
                self.assertEqual(left['previous'], A)
                self.assertEqual(s.transfer_count, 1)

    def test_mismatched_receiver_state_stops(self):
        s = sim.Simulation(A, B)
        s.receiver['established'] = dict(B)
        with self.assertRaises(sim.coordinator.CoordinationError):
            s.choose()

    def test_source_ahead_stops(self):
        s = sim.Simulation(A, B)
        s.source['pending'] = dict(B)
        with self.assertRaises(sim.coordinator.CoordinationError):
            s.choose()

    def test_receiver_receipt_not_assumed(self):
        s = sim.Simulation(A, B)
        s.step(); s.step()
        self.assertEqual(s.choose(), 'replicate-candidate')
        self.assertFalse(s.receiver_has_candidate)
        self.assertEqual(s.transfer_count, 0)

    def test_previous_never_released(self):
        s = sim.Simulation(A, B)
        s.finish()
        self.assertEqual(s.step(), 'await-cross-endpoint-acknowledgement')
        self.assertEqual(s.source['previous'], A)
        self.assertEqual(s.receiver['previous'], A)

    def test_invalid_candidate_rejected(self):
        with self.assertRaises(ValueError):
            sim.Simulation(A, A)

    def test_does_not_expose_io(self):
        self.assertFalse(hasattr(sim, 'run_ssh'))
        self.assertFalse(hasattr(sim, 'write_state'))
        self.assertFalse(hasattr(sim, 'release_previous'))


if __name__ == '__main__':
    unittest.main(verbosity=2)
