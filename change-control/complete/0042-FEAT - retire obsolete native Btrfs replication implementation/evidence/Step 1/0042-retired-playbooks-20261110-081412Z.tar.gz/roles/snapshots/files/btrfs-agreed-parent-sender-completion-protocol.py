#!/usr/bin/python3
"""0040 Step 12.3 Integration 04L: PURE sender-completion handshake contract.

No network, locks, secrets, stream, state writes or receipt creation. The future
receiver transaction must generate a fresh unpredictable nonce, bind it to the
same authenticated live SSH stream/session, and keep both receiver locks until
completion evidence and receipt are committed. A JSON boolean is not proof of
authentication. Do not expose this module as a remote execution endpoint.
"""
import hmac
import re

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
NONCE = re.compile(r'[0-9a-f]{64}\Z')

class CompletionRefused(RuntimeError):
    pass


def identity(value):
    if (type(value) is not dict or set(value) != {'timestamp', 'uuid'} or
            type(value['timestamp']) is not str or not STAMP.fullmatch(value['timestamp']) or
            type(value['uuid']) is not str or not UUID.fullmatch(value['uuid'])):
        raise CompletionRefused('invalid snapshot identity')
    return value


def challenge(parent, candidate, nonce):
    identity(parent); identity(candidate)
    if candidate['timestamp'] <= parent['timestamp']:
        raise CompletionRefused('invalid parent/candidate order')
    if type(nonce) is not str or not NONCE.fullmatch(nonce):
        raise CompletionRefused('invalid receiver-provided nonce')
    return {'schema': 1, 'operation': 'sender-completion-challenge',
            'transaction_id': candidate['timestamp'], 'parent': dict(parent),
            'candidate': dict(candidate), 'nonce': nonce}


def completion_request(expected_challenge, *, exit_status, stream_finished):
    """Build structured sender report; no claim it is authenticated."""
    validate_challenge_shape(expected_challenge)
    if type(exit_status) is not int or type(stream_finished) is not bool:
        raise CompletionRefused('invalid sender process result')
    return {'schema': 1, 'operation': 'sender-completion',
            'transaction_id': expected_challenge['transaction_id'],
            'parent': dict(expected_challenge['parent']),
            'candidate': dict(expected_challenge['candidate']),
            'nonce': expected_challenge['nonce'],
            'source_send_exit': exit_status, 'stream_finished': stream_finished}


def validate_challenge_shape(value):
    if (type(value) is not dict or set(value) != {
            'schema', 'operation', 'transaction_id', 'parent', 'candidate', 'nonce'} or
            type(value['schema']) is not int or value['schema'] != 1 or
            value['operation'] != 'sender-completion-challenge'):
        raise CompletionRefused('invalid challenge envelope')
    identity(value['parent']); identity(value['candidate'])
    if value['transaction_id'] != value['candidate']['timestamp'] or (
            type(value['nonce']) is not str or not NONCE.fullmatch(value['nonce'])):
        raise CompletionRefused('invalid challenge transaction')


def validate_reply(expected_challenge, reply, *, authenticated_session_bound=False,
                   receiver_locks_held=False):
    """Check a response only after caller enforces session and lock provenance.

    Caller MUST prove nonce was freshly created for this one pending receive,
    supplied over the SAME authenticated session, and never accepted before.
    This pure function cannot verify such provenance or prevent replay by itself.
    """
    validate_challenge_shape(expected_challenge)
    if authenticated_session_bound is not True or receiver_locks_held is not True:
        raise CompletionRefused('session binding and receiver locks required')
    if (type(reply) is not dict or set(reply) != {
            'schema', 'operation', 'transaction_id', 'parent', 'candidate',
            'nonce', 'source_send_exit', 'stream_finished'} or
            type(reply['schema']) is not int or reply['schema'] != 1 or
            reply['operation'] != 'sender-completion' or
            reply['transaction_id'] != expected_challenge['transaction_id'] or
            reply['parent'] != expected_challenge['parent'] or
            reply['candidate'] != expected_challenge['candidate'] or
            type(reply['nonce']) is not str or
            not hmac.compare_digest(reply['nonce'], expected_challenge['nonce']) or
            type(reply['source_send_exit']) is not int or
            reply['source_send_exit'] != 0 or reply['stream_finished'] is not True):
        raise CompletionRefused('sender completion missing, failed, or mismatched')
    return {'schema': 1, 'status': 'sender-completion-validated',
            'parent': dict(expected_challenge['parent']),
            'candidate': dict(expected_challenge['candidate']),
            'source_send_exit': 0, 'receipt_written': False,
            'authorizes_promote': False, 'authorizes_prune': False,
            'authorizes_release': False}
