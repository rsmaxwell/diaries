#!/usr/bin/python3
"""04N bounded channel tests; mock authentication assertions are NOT live evidence."""
import importlib.util
import struct
import unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]/'files/btrfs-agreed-parent-completion-channel.py'
s=importlib.util.spec_from_file_location('channel04n',P); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
class Channel:
    def __init__(self, payload=b'', session_id='session-1', chunk=2):
        self.data=payload; self.transfer_session_id=session_id; self.output=bytearray(); self.chunk=chunk
    def read(self,n):
        part=self.data[:min(n,self.chunk)]; self.data=self.data[len(part):]; return part
    def write(self,data):
        size=min(self.chunk,len(data)); self.output.extend(data[:size]); return size
class Session:
    parent={'timestamp':'A','uuid':'a'}
    candidate={'timestamp':'B','uuid':'b'}
    def __init__(self): self.completed=0
    def challenge_frame(self): return struct.pack('!I',3)+b'hey'
    def complete(self,response,**kwargs):
        if response != struct.pack('!I',2)+b'ok': raise ValueError('wrong reply')
        self.completed+=1
        return {'status':'complete'}
GOOD=dict(parent=Session.parent,candidate=Session.candidate,session_id='session-1',authenticated_peer=True,exclusive_channel=True,same_transfer_session=True,receiver_locks_held=True,deadline_enforced=True,binary_stream_finished=True)
class Tests(unittest.TestCase):
    def test_partial_reads(self):
        c=Channel(struct.pack('!I',2)+b'ok'); self.assertEqual(m.read_frame(c.read),struct.pack('!I',2)+b'ok')
    def test_empty_read_refused(self):
        with self.assertRaises(m.ChannelRefused):m.read_frame(Channel().read)
    def test_oversize_refused(self):
        with self.assertRaises(m.ChannelRefused):m.read_frame(Channel(struct.pack('!I',4097)).read)
    def test_zero_length_refused(self):
        with self.assertRaises(m.ChannelRefused):m.read_frame(Channel(struct.pack('!I',0)).read)
    def test_partial_writes(self):
        c=Channel(); m.write_frame(c.write,struct.pack('!I',3)+b'hey'); self.assertEqual(bytes(c.output),struct.pack('!I',3)+b'hey')
    def test_bad_write_refused(self):
        with self.assertRaises(m.ChannelRefused):m.write_frame(lambda d:0,struct.pack('!I',3)+b'hey')
    def test_wrong_length_refused(self):
        with self.assertRaises(m.ChannelRefused):m.write_frame(lambda d:len(d),struct.pack('!I',3)+b'ab')
    def test_success_mock(self):
        c=Channel(struct.pack('!I',2)+b'ok'); r=m.perform_completion(Session(),c,**GOOD); self.assertEqual(r['status'],'complete'); self.assertFalse(r['receipt_written'])
    def test_missing_verified_condition(self):
        for key in ('authenticated_peer','exclusive_channel','same_transfer_session','receiver_locks_held','deadline_enforced','binary_stream_finished'):
            with self.subTest(key=key), self.assertRaises(m.ChannelRefused):m.perform_completion(Session(),Channel(),**dict(GOOD,**{key:False}))
    def test_wrong_session_id(self):
        with self.assertRaises(m.ChannelRefused):m.perform_completion(Session(),Channel(session_id='other'),**GOOD)
    def test_wrong_transaction(self):
        with self.assertRaises(m.ChannelRefused):m.perform_completion(Session(),Channel(),**dict(GOOD,parent={'timestamp':'X','uuid':'x'}))
    def test_invalid_reply_does_not_succeed(self):
        s=Session(); c=Channel(struct.pack('!I',2)+b'no')
        with self.assertRaises(m.ChannelRefused):m.perform_completion(s,c,**GOOD)
        self.assertEqual(s.completed,0)
    def test_truncated_reply(self):
        with self.assertRaises(m.ChannelRefused):m.perform_completion(Session(),Channel(struct.pack('!I',20)+b'x'),**GOOD)
    def test_no_runtime_cli_or_subprocess(self):
        source=P.read_text(); self.assertNotIn('subprocess',source); self.assertNotIn('if __name__',source)
if __name__=='__main__':unittest.main(verbosity=2)
