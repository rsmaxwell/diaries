#!/usr/bin/python3
import importlib.util
from pathlib import Path
import unittest
p = Path(__file__).resolve().parents[1] / 'files/btrfs-agreed-parent-sender-completion-protocol.py'
spec = importlib.util.spec_from_file_location('completion04l', p)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
A={'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B={'timestamp':'20261030-170009Z','uuid':'a9b78fb9-4da6-cf4f-b242-13909f574193'}
N='a'*64
class Tests(unittest.TestCase):
    def setUp(self):
        self.c=m.challenge(A,B,N)
        self.r=m.completion_request(self.c,exit_status=0,stream_finished=True)
    def verify(self, r=None, **kw):
        return m.validate_reply(self.c, self.r if r is None else r,
          authenticated_session_bound=kw.get('auth',True),receiver_locks_held=kw.get('locks',True))
    def test_success(self): self.assertEqual(self.verify()['receipt_written'],False)
    def test_no_session(self):
        with self.assertRaises(m.CompletionRefused): self.verify(auth=False)
    def test_no_locks(self):
        with self.assertRaises(m.CompletionRefused): self.verify(locks=False)
    def test_failed_sender(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, source_send_exit=1))
    def test_bool_exit(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, source_send_exit=False))
    def test_unfinished_stream(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, stream_finished=False))
    def test_wrong_nonce(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, nonce='b'*64))
    def test_wrong_parent(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, parent=B))
    def test_wrong_candidate(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, candidate=A))
    def test_other_transaction(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, transaction_id=A['timestamp']))
    def test_extra_fields(self):
        with self.assertRaises(m.CompletionRefused): self.verify(dict(self.r, authenticated=True))
    def test_bad_challenge(self):
        with self.assertRaises(m.CompletionRefused): m.challenge(A,B,'invalid')
    def test_no_io_or_cli(self):
        self.assertFalse(hasattr(m,'main'))
        self.assertFalse(hasattr(m,'write_receipt'))
if __name__=='__main__': unittest.main(verbosity=2)
