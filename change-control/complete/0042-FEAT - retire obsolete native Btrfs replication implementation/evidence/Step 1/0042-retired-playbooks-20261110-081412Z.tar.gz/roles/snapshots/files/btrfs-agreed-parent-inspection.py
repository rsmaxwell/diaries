#!/usr/bin/python3
"""0040 3H.4f: dormant, read-only sender/receiver state comparison.

No production entrypoint invokes this module. No SSH or state writes happen unless
an explicit caller supplies a transport callback. A future privileged adapter must
own and validate the live source lock and receiver SSH identity separately.
"""
import importlib.util
import json
from pathlib import Path


def load_module(suffix):
    path = Path(__file__).with_name('btrfs-agreed-parent-' + suffix + '.py')
    spec = importlib.util.spec_from_file_location('agreed_3h4f_' + suffix.replace('-', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def inspect(*, local_state, receiver_reply, transaction_id, receiver_exit_code=0):
    """Compare verified receiver get-state reply with validated local durable state.

    local_state: the value loaded under source locks by a trusted caller.
    receiver_reply: captured stdout of a fixed, independently authenticated SSH
                    get-state command; no command is executed here.
    """
    state = load_module('state')
    rpc = load_module('rpc')
    state.validate(local_state)
    if type(receiver_exit_code) is not int or receiver_exit_code != 0:
        raise rpc.ProtocolError('receiver SSH failed; outcome unknown')
    if type(receiver_reply) is not str or not 0 < len(receiver_reply) <= 65536:
        raise rpc.ProtocolError('empty/oversized receiver observation')
    try:
        payload = json.loads(receiver_reply)
    except (TypeError, ValueError) as exc:
        raise rpc.ProtocolError('invalid receiver observation JSON') from exc
    if type(payload) is not dict or type(payload.get('state')) is not dict:
        raise rpc.ProtocolError('missing receiver state')
    # Validates the whole response envelope and the claimed state, not just JSON.
    rpc.validate_response(receiver_reply, operation='get-state',
                          transaction_id=transaction_id, expected_state=payload['state'])
    receiver_state = payload['state']
    if receiver_state != local_state:
        return {'schema': 1, 'status': 'diverged', 'source': local_state,
                'receiver': receiver_state, 'authorizes_transition': False,
                'authorizes_prune': False}
    return {'schema': 1, 'status': 'matched', 'source': local_state,
            'receiver': receiver_state, 'authorizes_transition': False,
            'authorizes_prune': False}
