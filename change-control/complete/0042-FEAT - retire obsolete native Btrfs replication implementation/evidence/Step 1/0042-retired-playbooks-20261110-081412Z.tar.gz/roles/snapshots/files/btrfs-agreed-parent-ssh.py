#!/usr/bin/python3
"""0040 Increment 3B: bounded READ-ONLY SSH observation adapter.

Not deployed, not a remote command endpoint, not transition authority. The caller
must provide an audited, allowlisted read-only remote command and arrange endpoint
locks separately. Never feed returned observations directly to a destructive action.
"""
import json
import subprocess

class ObservationError(RuntimeError):
    pass


def collect(command, *, timeout=20, runner=subprocess.run):
    """Run a fixed argv command; reject incomplete, oversized or untrusted output."""
    if not isinstance(command, (tuple, list)) or not command or any(
        not isinstance(part, str) or not part or '\x00' in part for part in command
    ):
        raise ObservationError('invalid fixed command')
    if type(timeout) not in (int, float) or not 0 < timeout <= 60:
        raise ObservationError('invalid timeout')
    try:
        result = runner(list(command), capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ObservationError('remote observation unavailable') from exc
    if result.returncode != 0:
        raise ObservationError('remote observation failed')
    output = result.stdout
    if not isinstance(output, str) or len(output.encode('utf-8')) > 65536:
        raise ObservationError('invalid observation length')
    try:
        record = json.loads(output)
    except (ValueError, TypeError) as exc:
        raise ObservationError('invalid JSON observation') from exc
    return validate_observation(record)


def validate_observation(value):
    """Validate an inert observation envelope; never grant transition authority."""
    if not isinstance(value, dict) or set(value) != {'schema', 'host', 'snapshot', 'source_uuid', 'read_only', 'receipt_verified'}:
        raise ObservationError('unexpected observation fields')
    if type(value['schema']) is not int or value['schema'] != 1:
        raise ObservationError('unexpected schema')
    if value['host'] not in ('mars', 'backup'):
        raise ObservationError('unexpected host')
    import re
    if not isinstance(value['snapshot'], str) or not re.fullmatch(r'[0-9]{8}-[0-9]{6}Z', value['snapshot']):
        raise ObservationError('invalid snapshot')
    if not isinstance(value['source_uuid'], str) or not re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', value['source_uuid']):
        raise ObservationError('invalid UUID')
    if type(value['read_only']) is not bool or type(value['receipt_verified']) is not bool:
        raise ObservationError('invalid evidence flags')
    return dict(value, authorizes_transition=False, authorizes_prune=False)


def compare(source, receiver):
    """Read-only matching check; stale observations are never sufficient authority."""
    a, b = validate_observation({k: v for k, v in source.items() if k not in ('authorizes_transition', 'authorizes_prune')}), validate_observation({k: v for k, v in receiver.items() if k not in ('authorizes_transition', 'authorizes_prune')})
    if (a['host'] != 'mars' or b['host'] != 'backup' or
            a['snapshot'] != b['snapshot'] or a['source_uuid'] != b['source_uuid'] or
            not a['read_only'] or not b['read_only'] or not b['receipt_verified']):
        raise ObservationError('peer observation disagrees')
    return {'snapshot': a['snapshot'], 'source_uuid': a['source_uuid'], 'matched': True,
            'authorizes_transition': False, 'authorizes_prune': False}
