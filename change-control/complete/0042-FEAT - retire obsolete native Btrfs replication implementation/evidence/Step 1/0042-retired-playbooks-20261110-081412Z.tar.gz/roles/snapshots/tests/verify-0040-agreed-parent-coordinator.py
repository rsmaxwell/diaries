#!/usr/bin/python3
import importlib.util
from pathlib import Path
import unittest
P = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-agreed-parent-coordinator.py'
spec = importlib.util.spec_from_file_location('coord', P)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
A={'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B={'timestamp':'20261031-030015Z','uuid':'a901ddd2-66c7-0b42-b26c-ab6886273b7a'}
C={'timestamp':'20261101-030015Z','uuid':'b901ddd2-66c7-0b42-b26c-ab6886273b7a'}
def st(est=A,pending=None,previous=None): return {'schema':1,'established':est,'pending':pending,'previous':previous}
def action(s,r,**kw): return c.decision(s,r,B,source_candidate_verified=True,**kw)['next']
class Tests(unittest.TestCase):
    def test_start(self): self.assertEqual(action(st(),st()),'prepare-receiver')
    def test_receiver_prepared(self): self.assertEqual(action(st(),st(pending=B)),'prepare-source')
    def test_replication_needed(self): self.assertEqual(action(st(pending=B),st(pending=B)),'replicate-candidate')
    def test_receiver_acceptance(self): self.assertEqual(action(st(pending=B),st(pending=B),receiver_has_candidate=True),'promote-receiver')
    def test_receiver_promoted(self): self.assertEqual(action(st(pending=B),st(est=B,previous=A),receiver_has_candidate=True),'promote-source')
    def test_both_promoted(self): self.assertEqual(action(st(est=B,previous=A),st(est=B,previous=A)),'await-cross-endpoint-acknowledgement')
    def test_no_release(self):
        for s,r in [(st(),st()),(st(pending=B),st(pending=B)),(st(est=B,previous=A),st(est=B,previous=A))]:
            self.assertFalse(c.decision(s,r,B,source_candidate_verified=True)['safe_to_release_previous'])
    def test_source_ahead_fails(self):
        with self.assertRaises(c.CoordinationError): action(st(pending=B),st())
    def test_wrong_pending_fails(self):
        with self.assertRaises(c.CoordinationError): action(st(pending=C),st(pending=B))
    def test_mismatched_established_fails(self):
        with self.assertRaises(c.CoordinationError): action(st(),st(est=C))
    def test_unknown_candidate_fails(self):
        with self.assertRaises(c.CoordinationError): c.decision(st(),st(),B)
    def test_receiver_proof_required_for_source_promotion(self):
        with self.assertRaises(c.CoordinationError): action(st(pending=B),st(est=B,previous=A))
    def test_stale_candidate_fails(self):
        with self.assertRaises(c.CoordinationError): c.decision(st(),st(),A,source_candidate_verified=True)
    def test_invalid_flag_fails(self):
        with self.assertRaises(c.CoordinationError): action(st(),st(),receiver_has_candidate='true')
if __name__ == '__main__': unittest.main(verbosity=2)
