#!/usr/bin/python3
"""0040 3H.4c: DORMANT source-side state transition primitive, no CLI.

The invoking coordinator must already hold the source .native-push.lock.
The operation acquires only the snapshot-manager lock, preserving lock order.
Peer evidence and source Btrfs checks are supplied by trusted callbacks;
no SSH is invoked here. No previous-parent acknowledgement is available.
"""
from contextlib import ExitStack
import importlib.util
from pathlib import Path
import re


def _state_module():
    path = Path(__file__).with_name('btrfs-agreed-parent-state.py')
    spec = importlib.util.spec_from_file_location('agreed_parent_3h4c_state', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


state = _state_module()
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')


def transition(*, operation, transaction_id, expected_before, candidate,
               state_path, manager_lock, push_lock_held, acquire_manager,
               verify_source, verify_peer, require_root=True):
    """Persist an exact local postcondition and return it after read-back.

    `push_lock_held` is a trusted in-process invariant supplied by the coordinator,
    NEVER an RPC/user option. `verify_peer(op, candidate, before, after)` must
    check independently validated durable receiver evidence, not a boolean claim.
    Caller must not release its source push lock until this function returns.
    """
    if operation not in ('get-state', 'prepare', 'promote'):
        raise state.StateError('unsupported source operation')
    if not isinstance(transaction_id, str) or not STAMP.fullmatch(transaction_id):
        raise state.StateError('invalid transaction identity')
    if push_lock_held is not True:
        raise state.StateError('source push lock not held')
    if not all(callable(fn) for fn in (acquire_manager, verify_source, verify_peer)):
        raise state.StateError('trusted verifier/manager lock required')
    if not all(isinstance(p, Path) and p.is_absolute() for p in (state_path, manager_lock)):
        raise state.StateError('absolute source paths required')
    if state_path.name != '.agreed-parent.json' or state_path.parent.is_symlink():
        raise state.StateError('unsafe source state path')
    if expected_before is not None:
        state.validate(expected_before)
    if operation == 'get-state':
        if candidate is not None:
            raise state.StateError('unexpected candidate')
    else:
        if expected_before is None:
            raise state.StateError('expected state required')
        state.snapshot(candidate)
        if candidate['timestamp'] != transaction_id:
            raise state.StateError('candidate/transaction mismatch')
    with ExitStack() as stack:
        # Push lock belongs to caller; acquiring it again can deadlock.
        acquire_manager(stack, manager_lock)
        before = state.load(state_path, require_root=require_root)
        if operation == 'get-state':
            if expected_before is not None and before != expected_before:
                raise state.StateError('unexpected persisted source state')
            after = before
        elif operation == 'prepare':
            after = state.prepare(expected_before, candidate)
        else:
            if expected_before['pending'] != candidate:
                raise state.StateError('pending candidate mismatch')
            after = state.promote(expected_before)
        if operation != 'get-state' and before not in (expected_before, after):
            raise state.StateError('stale/conflicting source state')
        # Verify all existing on-disk parents before committing. During prepare
        # candidate B may not exist at the receiver, but must exist on source.
        for stamp, uuid in state.protected(after).items():
            verify_source({'timestamp': stamp, 'uuid': uuid})
        # Receiver proof is mandatory for any source mutation. Implementations
        # must validate receiver SSH status, JSON transaction and postcondition.
        verify_peer(operation, candidate, before, after)
        if before != after:
            state.save(state_path, after, require_root=require_root)
        persisted = state.load(state_path, require_root=require_root)
        if persisted != after:
            raise state.StateError('source durable read-back mismatch')
        return {'schema': 1, 'operation': operation, 'transaction_id': transaction_id,
                'status': 'success', 'state': persisted, 'authorizes_prune': False}
