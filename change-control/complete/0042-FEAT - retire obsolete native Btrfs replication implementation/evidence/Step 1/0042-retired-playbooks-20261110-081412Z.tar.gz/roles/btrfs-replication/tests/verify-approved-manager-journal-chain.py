#!/usr/bin/env python3
"""0040: real approval adapter + real manager journal, isolated fixtures.

Requires root to create and validate a genuinely root-owned 0600 approval.
Socketpair carries the real two-challenge protocol; kernel Btrfs actions and
inventory are substituted. Does not grant or use production deletion authority.
"""
import importlib.util
import json
import os
import socket
import sys
import tempfile
import threading
import uuid
from contextlib import ExitStack
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    sys.modules[name] = obj
    spec.loader.exec_module(obj)
    return obj

sender = load(ROOT / 'files/btrfs-native-push.py', 'approved_chain_sender')
receiver = load(ROOT / 'files/btrfs-native-push-receiver.py', 'approved_chain_receiver')
manager = load(ROOT.parent / 'snapshots/files/btrfs-snapshot-manager.py', 'approved_chain_manager')

STAMPS = ('20261020-010000Z', '20261021-010000Z', '20261022-010000Z')
CANDIDATE, PARENT, NEWEST = STAMPS

class Peer:
    def __init__(self, incoming, outgoing, thread, errors):
        self.stdout, self.stdin = incoming, outgoing
        self.thread, self.errors = thread, errors
    def wait(self, timeout=None):
        self.thread.join(timeout)
        if self.thread.is_alive():
            raise RuntimeError('fixture worker did not exit')
        return 1 if self.errors else 0

def scenario(interrupt):
    with tempfile.TemporaryDirectory(prefix='0040-approved-manager-journal-') as td:
        root = Path(td)
        received = root / 'received'; received.mkdir()
        state = root / 'state'; state.mkdir()
        consumed = state / 'consumed'; consumed.mkdir()
        manager_lock = root / 'manager.lock'; manager_lock.touch()
        writer_lock = state / 'writer.lock'; writer_lock.touch()
        uuids = {name: str(uuid.uuid4()) for name in STAMPS}
        for name in STAMPS:
            (received/name).mkdir()
            (state/(name+'.json')).write_text(json.dumps({
                'schema': 1, 'snapshot': name, 'source_uuid': uuids[name],
                'received_uuid': uuids[name], 'destination': str(received/name),
                'read_only_verified': True}))
        approval = root / 'approval.json'
        approval.write_text(json.dumps({
            'schema': 1, 'operation': 'receiver-prune-one', 'candidate': CANDIDATE,
            'protected_parent': PARENT, 'protected_parent_uuid': uuids[PARENT],
            'expires_at_utc': (datetime.now(timezone.utc)+timedelta(minutes=15)).strftime('%Y-%m-%dT%H:%M:%SZ'),
            'reason': 'Isolated source-manager journal integration regression'}))
        approval.chmod(0o600)
        config = manager.Config(snapshot_root=root, lock_path=manager_lock,
            writer_lock_path=writer_lock,
            sources=(manager.SnapshotSource('mars', None, received),),
            retention=manager.RetentionPolicy(0, 0, 0, 0, 0, 0),
            verification=manager.VerificationPolicy(False, '', '', '', None),
            checkpoint_holds_required=True, mode='receiver',
            receiver_state_dir=state, receiver_prune_enabled=False)
        entries = [(name, datetime.strptime(name, manager.TIMESTAMP_FORMAT).replace(tzinfo=timezone.utc), received/name)
                   for name in reversed(STAMPS)]
        # Real manager journal and receipts, substituted Btrfs kernel inventory/actions.
        kernel_patches = [
            patch.object(manager, 'receiver_inventory', return_value=entries),
            patch.object(manager, 'retention_keep_set', return_value=set()),
            patch.object(manager, 'receiver_verified_checkpoint_holds', return_value={PARENT}),
            patch.object(manager, 'validate_prune_candidate', return_value=None),
            patch.object(manager, 'native_prune_subvolume_id', return_value=12345),
            patch.object(manager, 'run', side_effect=lambda cmd, **kwargs: type('BtrfsOutput', (), {'stdout': ('Received UUID: '+uuids[CANDIDATE]+'\n') if 'show' in cmd else 'ro=true\n'})()),
        ]
        challenges = []
        def source_pin(role, stamp):
            assert role == 'protect-prune-source' and stamp == PARENT
            challenges.append(stamp)
            return {'source_uuid': uuids[PARENT]}
        def plan(stamp, parent_uuid):
            assert stamp == PARENT and parent_uuid == uuids[PARENT]
            return {'snapshot': PARENT, 'source_uuid': parent_uuid,
                    'authorizes_prune': False, 'deletion_executed': False,
                    'candidates': [CANDIDATE]}
        def delete(path):
            assert path == received/CANDIDATE
            assert (state/'.receiver-prune-pending.json').is_file(), 'journal must precede Btrfs deletion'
            if interrupt:
                raise RuntimeError('injected interruption after durable manager journal')
            path.rmdir()
        a, b = socket.socketpair()
        source_in = a.makefile('r', encoding='utf-8')
        source_out = a.makefile('w', encoding='utf-8', buffering=1)
        target_in = b.makefile('r', encoding='utf-8')
        target_out = b.makefile('w', encoding='utf-8', buffering=1)
        errors = []
        def worker():
            try:
                receiver.run_approved_manager_bound_transaction(
                    PARENT, uuids[PARENT], CANDIDATE,
                    manager=manager, config=config,
                    incoming=target_in, outgoing=target_out, planner=plan,
                    delete_subvolume=delete,
                    approval_path=approval, consumed_dir=consumed)
            except Exception as exc:
                errors.append(exc)
            finally:
                target_out.close(); target_in.close(); b.close()
        with ExitStack() as stack:
            for item in kernel_patches:
                stack.enter_context(item)
            thread = threading.Thread(target=worker, daemon=True)
            thread.start()
            peer = Peer(source_in, source_out, thread, errors)
            try:
                if interrupt:
                    try:
                        sender.answer_transaction_challenges(peer, PARENT, uuids[PARENT], CANDIDATE,
                            protect_pin=source_pin)
                    except (OSError, RuntimeError, EOFError, ValueError):
                        pass
                    else:
                        raise AssertionError('interrupted deletion was accepted')
                else:
                    result = sender.answer_transaction_challenges(peer, PARENT, uuids[PARENT], CANDIDATE,
                        protect_pin=source_pin)
                    assert result['journal_transaction_completed'] is True
            finally:
                source_out.close(); source_in.close(); a.close()
                thread.join(4)
            assert not thread.is_alive()
            assert len(challenges) == 2, challenges
            assert len(list(consumed.glob('*.json'))) == 1
            assert (received/PARENT).is_dir() and (received/NEWEST).is_dir()
            assert (state/(PARENT+'.json')).exists() and (state/(NEWEST+'.json')).exists()
            pending = state/'.receiver-prune-pending.json'
            receipt = state/(CANDIDATE+'.json')
            if interrupt:
                assert pending.is_file() and receipt.is_file() and (received/CANDIDATE).is_dir()
                assert manager.receiver_recovery_plan(config)['state'] == 'BEFORE_DELETE'
                print('PASS: interrupted approved two-challenge transaction preserves journal, receipt and reservation')
            else:
                assert not pending.exists() and not receipt.exists() and not (received/CANDIDATE).exists()
                assert manager.receiver_recovery_plan(config)['state'] == 'CLEAN'
                print('PASS: approved two-challenge transaction resolves real manager journal and receipt')

if os.geteuid() != 0:
    print('SKIP: root is required for root-owned approval; use sudo for positive acceptance')
else:
    scenario(False)
    scenario(True)
    print('LIMIT: Btrfs kernel actions and authenticated cross-host process are not exercised')
