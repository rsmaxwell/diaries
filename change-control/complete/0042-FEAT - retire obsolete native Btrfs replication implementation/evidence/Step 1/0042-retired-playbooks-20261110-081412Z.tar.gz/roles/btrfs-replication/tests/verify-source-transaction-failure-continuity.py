#!/usr/bin/env python3
"""Disposable source-lock/timeout regression; no network, sudo or Btrfs operations.

The child emits no protocol response and deliberately blocks. Test observes the
actual flock from a separate process, and a durable fixture pin after timeout.
"""
import importlib.util
import fcntl
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time

source = Path(__file__).resolve().parents[1] / 'files/btrfs-native-push.py'
spec = importlib.util.spec_from_file_location('btrfs_native_push_failure_test', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

stamp = '20261024-030038Z'
parent_uuid = '22e0ca45-0f49-c745-85b0-af6b6cfb915c'
candidate = '20261012-100003Z'
with tempfile.TemporaryDirectory(prefix='0040-sender-continuity-') as temp:
    root = Path(temp)
    lock = root / 'push.lock'
    lock.touch(mode=0o600)
    pin = root / 'source-pin.json'
    pin.write_text(json.dumps({'snapshot': stamp, 'uuid': parent_uuid}))
    outcome = []

    def runner():
        try:
            module.run_private_transaction_process(
                [sys.executable, '-c', 'import time; time.sleep(30)'],
                stamp, parent_uuid, candidate, source_lock=lock,
                protect_pin=lambda *_: (_ for _ in ()).throw(AssertionError('Unexpected pin renewal')),
                transaction_timeout=0.35, abort_timeout=0.2)
        except RuntimeError as exc:
            outcome.append(str(exc))
        except Exception as exc:
            outcome.append(type(exc).__name__ + ': ' + str(exc))

    worker = threading.Thread(target=runner)
    worker.start()
    held = False
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline and worker.is_alive():
        with lock.open('r+') as f:
            try:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
                fcntl.flock(f, fcntl.LOCK_UN)
            except BlockingIOError:
                held = True
                break
        time.sleep(0.005)
    assert held, 'Sender never obtained exclusive lock'
    worker.join(timeout=5)
    assert not worker.is_alive(), 'Timeout left sender worker blocked'
    assert len(outcome) == 1 and 'deadline exceeded' in outcome[0].lower(), outcome
    assert json.loads(pin.read_text()) == {'snapshot': stamp, 'uuid': parent_uuid}, 'Source pin changed'
    with lock.open('r+') as f:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(f, fcntl.LOCK_UN)
    print('PASS: timeout retained durable fixture pin; source lock held then released after child reaping')
