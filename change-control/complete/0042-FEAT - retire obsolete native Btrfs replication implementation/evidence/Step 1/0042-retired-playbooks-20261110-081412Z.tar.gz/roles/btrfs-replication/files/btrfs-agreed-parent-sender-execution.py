#!/usr/bin/env python3
"""0040 Step 12.3: internal two-phase sender integration, no production CLI.

The source lock/pin verifier and receiver receipt reader must be supplied from
trusted installed code. A live sender cannot use this until those are connected
and full recovery/promotion gates are accepted.
"""

class ExecutionRefused(RuntimeError):
    pass


def execute_provisional_then_receipt(parent, candidate, *, transaction,
                                     fixed_commands, binary_transport,
                                     sender_handoff, session_proof,
                                     read_sender_key, pinned_parent_verified,
                                     verify_final_receipt,
                                     timeout_seconds=1800):
    """One receive, one nonce query and one authenticated receipt finalisation.

    Transport exit evidence is captured in the closure immediately after the
    actual subprocess adapter returns. The finalisation callback cannot invent
    process results. This function deliberately has no promotion authority.
    """
    if (type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 7200 or
            not callable(pinned_parent_verified) or
            not callable(verify_final_receipt) or not callable(read_sender_key) or
            any(module is None for module in (transaction, fixed_commands,
                                              binary_transport, sender_handoff,
                                              session_proof))):
        raise ExecutionRefused('missing trusted sender execution dependencies')
    observed = []

    def transfer(a, b):
        if observed:
            raise ExecutionRefused('transfer must execute exactly once')
        send_cmd, ssh_cmd = fixed_commands.receive_commands(a, b)
        result = binary_transport.run_binary_send_ssh(
            send_cmd, ssh_cmd, timeout_seconds=timeout_seconds)
        # Do not admit bools as process exits. The transaction also checks this.
        if (type(result) is not dict or
                set(result) != {'source_send_exit', 'ssh_exit'} or
                any(type(x) is not int or x != 0 for x in result.values())):
            raise ExecutionRefused('sender/SSH exit evidence not proven')
        observed.append(result.copy())
        return result

    def finalise(a, b):
        if len(observed) != 1:
            raise ExecutionRefused('finalisation without observed transport exit')
        return sender_handoff.sender_handoff(
            a, b, exits=observed[0], commands=fixed_commands,
            proof_module=session_proof, key=read_sender_key())

    return transaction.send_then_finalize(
        parent, candidate, pinned_parent_verified=pinned_parent_verified,
        receive_transfer=transfer, finalise_authenticated=finalise,
        verify_final_receipt=verify_final_receipt)

# Source-side integration: retain both source locks across the entire provisional
# transfer and receipt finalisation. This is deliberately internal, not a CLI.
SOURCE_STATE = '/media/usb/@snapshots/.agreed-parent.json'
SOURCE_PUSH_LOCK = '/media/usb/@snapshots/.native-push.lock'
SOURCE_MANAGER_LOCK = '/run/lock/btrfs-snapshot-manager.lock'


def execute_with_verified_source(parent, candidate, *, source_observer,
                                 state_module, evidence_module, execution):
    """Require canonical pinned A/pending B and their real Btrfs identities.

    `execution` is the existing two-phase sender implementation, invoked under
    both source locks. No source state writes, pin release or parent promotion.
    The injected dependencies are for offline regression only; an eventual
    privileged runtime entry must load fixed installed modules.
    """
    from contextlib import ExitStack
    from pathlib import Path

    if not callable(getattr(source_observer, 'lock', None)):
        raise ExecutionRefused('missing source lock implementation')
    if not callable(execution):
        raise ExecutionRefused('missing two-phase execution')
    state_path = Path(SOURCE_STATE)
    with ExitStack() as stack:
        source_observer.lock(stack, Path(SOURCE_PUSH_LOCK))
        source_observer.lock(stack, Path(SOURCE_MANAGER_LOCK))
        current = state_module.load(state_path, require_root=True)
        state_module.validate(current)
        if (current.get('established') != parent or
                current.get('pending') != candidate or
                current.get('previous') is not None):
            raise ExecutionRefused('source A/B differs from prepared agreed-parent state')
        for snapshot in (parent, candidate):
            result = evidence_module.verify_source(snapshot)
            if result != dict(snapshot, verified=True):
                raise ExecutionRefused('source Btrfs identity verification failed')
        # This verified result is produced locally, under the same locks.
        def pinned(a, b):
            return a == parent and b == candidate
        result = execution(parent, candidate, pinned_parent_verified=pinned)
        if (type(result) is not dict or
                result.get('authorizes_prune') is not False or
                result.get('authorizes_transition') is not False or
                result.get('authorizes_release') is not False):
            raise ExecutionRefused('unsafe two-phase execution result')
        return result

# Step 12.3: fixed runtime dependency composition.  This is intentionally
# internal: no main(), and no permission to change the protected parent.
from pathlib import Path as _Path
import importlib.util as _importlib_util

_RUNTIME_LIB = _Path('/usr/local/libexec')
_RUNTIME_NAMES = {
    'source_observer': 'btrfs-agreed-parent-source-observer.py',
    'state_module': 'btrfs-agreed-parent-state.py',
    'evidence_module': 'btrfs-agreed-parent-source-evidence.py',
    'transaction': 'btrfs-agreed-parent-sender-transaction.py',
    'fixed_commands': 'btrfs-agreed-parent-fixed-commands.py',
    'binary_transport': 'btrfs-agreed-parent-stream-adapter.py',
    'sender_handoff': 'btrfs-agreed-parent-sender-proof-handoff.py',
    'session_proof': 'btrfs-agreed-parent-session-proof.py',
    'receipt_readback': 'btrfs-agreed-parent-receipt-readback.py',
}


def _load_fixed_runtime_modules(*, directory=_RUNTIME_LIB):
    """Only load the nine approved, root-owned runtime modules.

    The directory override exists exclusively for disposable source tests; it
    cannot be passed through a public entry point (there is none).
    """
    import os
    import stat
    if os.geteuid() != 0:
        raise ExecutionRefused('trusted sender runtime requires root')
    directory = _Path(directory)
    if not directory.is_dir() or directory.is_symlink():
        raise ExecutionRefused('unsafe trusted module directory')
    modules = {}
    for key, name in _RUNTIME_NAMES.items():
        path = directory / name
        info = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or
                info.st_mode & 0o022 or info.st_nlink != 1 or path.is_symlink()):
            raise ExecutionRefused('unsafe trusted sender module: ' + name)
        spec = _importlib_util.spec_from_file_location('sender_0040_' + key, path)
        if spec is None or spec.loader is None:
            raise ExecutionRefused('sender module cannot be loaded')
        obj = _importlib_util.module_from_spec(spec)
        spec.loader.exec_module(obj)
        modules[key] = obj
    return modules


def execute_installed_source_internal(parent, candidate, *, modules=None):
    """Bind canonical source evidence to the real sender integration.

    This is not a production entry point.  A later cutover must provide safe
    receipt readback, privilege-controlled SSH execution and recovery policy.
    """
    if modules is None:
        modules = _load_fixed_runtime_modules()
    if type(modules) is not dict or set(modules) != set(_RUNTIME_NAMES):
        raise ExecutionRefused('incomplete trusted sender runtime')
    if any(modules[name] is None for name in _RUNTIME_NAMES):
        raise ExecutionRefused('missing trusted runtime dependency')

    receipt_reader = modules['receipt_readback']
    handoff = modules['sender_handoff']
    if (not callable(getattr(receipt_reader, 'verify_receipt_over_ssh', None)) or
            not callable(getattr(handoff, 'read_sender_key', None))):
        raise ExecutionRefused('trusted receipt or sender key interface missing')

    def run_verified(a, b, *, pinned_parent_verified):
        def verify_final_receipt(x, y):
            return receipt_reader.verify_receipt_over_ssh(
                x, y, commands=modules['fixed_commands'])

        return execute_provisional_then_receipt(
            a, b, transaction=modules['transaction'],
            fixed_commands=modules['fixed_commands'],
            binary_transport=modules['binary_transport'],
            sender_handoff=handoff, session_proof=modules['session_proof'],
            read_sender_key=handoff.read_sender_key,
            pinned_parent_verified=pinned_parent_verified,
            verify_final_receipt=verify_final_receipt)

    return execute_with_verified_source(
        parent, candidate, source_observer=modules['source_observer'],
        state_module=modules['state_module'],
        evidence_module=modules['evidence_module'], execution=run_verified)
