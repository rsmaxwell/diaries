#!/usr/bin/env python3
"""Bounded Step 12.3 sender workflow driver; dependency-injected, not a CLI.

A trusted runtime must own source locks, supply authenticated independent
observations, and bind actions to fixed verified commands. Never catches a
transaction failure to infer a successful receipt. Incomplete receive is
rejected by the coordinator pending fenced receiver reconciliation.
"""

class DriverRefused(RuntimeError):
    pass


def drive(*, coordinator, policy, observe, operate, locks_held=False,
          max_actions=6):
    """Drive at most max_actions verified transitions, halting on idle/no progress.

    A new observation is required for each step. Action `select-next-candidate`
    ends this invocation (a candidate must be explicitly selected by the
    trusted provider before a later invocation). No arbitrary retry loop.
    """
    if locks_held is not True:
        raise DriverRefused('canonical sender locks required')
    if type(max_actions) is not int or not 1 <= max_actions <= 16:
        raise DriverRefused('invalid action budget')
    if not all(callable(x) for x in (observe, operate)):
        raise DriverRefused('trusted callbacks required')
    history = []
    for _ in range(max_actions):
        result = coordinator.choose_once(policy=policy, observe=observe,
                                         operation=operate,
                                         canonical_locks_held=True)
        if type(result) is not dict or result.get('status') != 'one-step-verified':
            raise DriverRefused('invalid coordinator result')
        action, following = result['action'], result['next_action']
        history.append(action)
        if action == 'select-next-candidate':
            return {'status': 'awaiting-candidate-selection', 'actions': history,
                    'authorizes_prune': False, 'authorizes_release': False}
        if following == 'select-next-candidate':
            return {'status': 'cycle-ready', 'actions': history,
                    'authorizes_prune': False, 'authorizes_release': False}
        # No progress proves that a callback may have lied about completion;
        # a transient outage must NOT be silently treated as success.
        if following == action:
            raise DriverRefused('no verified durable progress after action: ' + action)
    raise DriverRefused('bounded workflow exhausted without synchronized idle state')
