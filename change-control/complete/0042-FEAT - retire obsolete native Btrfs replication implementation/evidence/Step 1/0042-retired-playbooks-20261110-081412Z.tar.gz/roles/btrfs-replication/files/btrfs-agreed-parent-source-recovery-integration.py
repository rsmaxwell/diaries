#!/usr/bin/python3
"""0040 3H.5t: DORMANT source prepare / receiver-pending recovery bridge.

No CLI or transport. Invoking code must own source push lock, provide a fresh
receiver observation under the source transition's manager lock, and verify
source Btrfs identities. The live sender does not import this module.
"""
from pathlib import Path
import importlib.util

class Refused(RuntimeError):
    pass

def load(path):
    spec = importlib.util.spec_from_file_location('step5t_' + path.stem.replace('-', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def prepare_source(*, source_before, candidate, state_path, manager_lock,
                   push_lock_held, acquire_manager, verify_source, read_receiver,
                   transition=None, recovery=None):
    """Prepare source only after fresh confirmed receiver pending=B.

    Caller MUST own push lock, not reacquire it. Source transition acquires
    manager lock and calls verify_peer before any durable source write. The
    read_receiver callback MUST query authenticated get-state on every call,
    without cached output. No retry is performed after uncertain failure.
    """
    if push_lock_held is not True or not all(callable(x) for x in
             (acquire_manager, verify_source, read_receiver)):
        raise Refused('source push lock and independent verifiers required')
    if not isinstance(state_path, Path) or not isinstance(manager_lock, Path):
        raise Refused('Path arguments required')
    if transition is None or recovery is None:
        raise Refused('trusted source transition and recovery modules required')
    state = transition.state
    state.validate(source_before)
    state.snapshot(candidate)
    if source_before['pending'] is not None or source_before['previous'] is not None:
        raise Refused('source already in transition')
    calls = 0
    def verify_peer(operation, observed_candidate, before, after):
        nonlocal calls
        calls += 1
        if calls != 1 or operation != 'prepare' or before != source_before or observed_candidate != candidate:
            raise Refused('unexpected source transition or repeated receiver observation')
        if after != state.prepare(source_before, candidate):
            raise Refused('unexpected source postcondition')
        # This runs inside transition's manager lock before its state.save.
        response = read_receiver(candidate['timestamp'])
        checked_candidate = verify_source(candidate)
        checked_parent = verify_source(source_before['established'])
        outcome = recovery.decide(before, response, candidate, checked_candidate,
                                  checked_parent, validate=state.validate)
        if outcome.get('status') != 'receiver-prepared-source-unprepared' or any(
                value is not False for key, value in outcome.items() if key.startswith('authorizes_')):
            raise Refused('receiver recovery decision refused')
    try:
        result = transition.transition(
            operation='prepare', transaction_id=candidate['timestamp'],
            expected_before=source_before, candidate=candidate,
            state_path=state_path, manager_lock=manager_lock,
            push_lock_held=True, acquire_manager=acquire_manager,
            verify_source=verify_source, verify_peer=verify_peer)
    except Exception as exc:
        raise Refused('source prepare unconfirmed; inspect both durable states, do not retry') from exc
    if calls != 1 or result.get('status') != 'success' or result.get('state') != state.prepare(source_before, candidate):
        raise Refused('source durable preparation not confirmed; inspect both endpoints')
    return {'schema': 1, 'status': 'source-prepared-verified',
            'source': result['state'], 'receiver_reads': calls,
            'authorizes_transfer': False, 'authorizes_promote': False,
            'authorizes_prune': False, 'authorizes_release': False}
