# 0040-FEAT Step 3 — Internal gateway delegation

This source-only package introduces a private bridge in the restricted root-entry module. It verifies fixed root configuration, receiver-only/pruning-disabled mode and lock topology, and delegates to the existing `run_approved_manager_bound_transaction` adapter. The manager owns journal semantics. The bridge carries original live protocol streams and callback without starting another SSH process.

**Not deployed, not authorised:** The public CLI still supports only `--verify-boundary`; there is no privileged socket/SSH gateway, no production source-held controller invoking the bridge, no callback authority, and no sudoers change. The tests use disposable mocks and perform no Btrfs operation. This is source-level integration evidence, NOT acceptance of a real deletion.

Remaining acceptance: explicitly designed privileged process/session lifetime, protected source lock and pin continuity on real SSH interruptions, dedicated disposable receiver with real Btrfs deletion/receipt/journal recovery, controlled Ansible check/diff and deployment only after approval. Keep `receiver_prune_enabled: false` and existing holds intact.
