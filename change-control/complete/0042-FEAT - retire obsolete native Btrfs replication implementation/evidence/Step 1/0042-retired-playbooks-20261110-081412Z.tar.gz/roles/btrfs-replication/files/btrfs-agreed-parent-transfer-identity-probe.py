#!/usr/bin/python3
"""0040 12.3/04P: bounded read-only identity probe for two SSH transports.

No Btrfs invocation, receiver endpoint, lock assertion, transfer or state write.
Two SSH probes do NOT establish cryptographic cross-channel session binding.
"""
import argparse
import json
import subprocess
import sys

SSH = ('/usr/sbin/runuser', '-u', 'richard', '--', 'ssh',
       '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1')
COMMAND = (*SSH, 'id', '-un')

class ProbeRefused(RuntimeError):
    pass

def probe(*, run=subprocess.run, timeout=25):
    if type(timeout) is not int or timeout < 16 or timeout > 60:
        raise ProbeRefused('invalid bounded deadline')
    results=[]
    for channel in ('data', 'control'):
        try:
            p=run(list(COMMAND), capture_output=True, text=True, timeout=timeout,
                  check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ProbeRefused(channel+' SSH identity probe failed or timed out') from exc
        if (type(p.returncode) is not int or p.returncode != 0 or
                p.stdout != 'richard\n' or type(p.stderr) is not str or
                len(p.stderr) > 8192):
            raise ProbeRefused(channel+' SSH authentication or remote identity refused')
        results.append({'channel':channel,'remote_account':'richard','ssh_identity_verified':True})
    return {'schema':1, 'status':'read-only-ssh-identity-probe',
            'channels':results, 'transfer_executed':False,
            'cross_channel_binding_verified':False,
            'receiver_locks_verified':False, 'authorizes_transfer':False,
            'authorizes_promote':False,'authorizes_prune':False,
            'authorizes_release':False}

def main():
    parser=argparse.ArgumentParser(description='0040 04P read-only SSH identity probe')
    parser.add_argument('--review-only', action='store_true', required=True)
    parser.parse_args()
    print(json.dumps(probe(),sort_keys=True))

if __name__=='__main__':
    try: main()
    except ProbeRefused as exc:
        print('04P probe refused: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
