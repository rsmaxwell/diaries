#!/usr/bin/env python3
"""0040 Step 3: disposable authenticated mars->backup SSH peer gate.

Execute on mars via python3 - piped from mango. No Btrfs or production state touched.
SSH is deliberately fixed to an already configured operator account/port; no caller
supplied command, destination, approval or deletion capability.
"""
import fcntl
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import tempfile
import time

TARGET = 'richard@10.254.22.1'
PORT = '39263'
import shlex
REMOTE_PY = ('import json,sys; '
             'v=json.loads(sys.stdin.readline()); '
             'print(json.dumps({"nonce":v["nonce"],"kind":"0040-test"}),flush=True)')
REMOTE = 'python3 -u -c ' + shlex.quote(REMOTE_PY)
SSH = ['ssh', '-T', '-p', PORT, '-o', 'BatchMode=yes',
       '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=10',
       '-o', 'ConnectionAttempts=1', '-o', 'ClearAllForwardings=yes',
       '-o', 'RequestTTY=no', TARGET, REMOTE]


def main():
    if os.geteuid() == 0:
        raise RuntimeError('Run as unprivileged operator on mars')
    with tempfile.TemporaryDirectory(prefix='0040-ssh-gate-') as d:
        path = Path(d)
        with (path / 'source.lock').open('w+') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            pin = path / 'pin.json'
            nonce = secrets.token_hex(20)
            pin.write_text(json.dumps({'kind': 'disposable-pin', 'nonce': nonce}) + '\n')
            process = subprocess.Popen(SSH, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, text=True, start_new_session=True)
            try:
                out, err = process.communicate(json.dumps({'nonce': nonce}) + '\n', timeout=25)
                if process.returncode:
                    raise RuntimeError(f'SSH failed rc={process.returncode}: {err[-400:]}')
                values = json.loads(out.strip())
                if values != {'nonce': nonce, 'kind': '0040-test'}:
                    raise RuntimeError('Authenticated SSH response mismatch')
                if json.loads(pin.read_text())['nonce'] != nonce:
                    raise RuntimeError('Source disposable pin changed')
                print('PASS: authenticated mars-to-backup SSH challenge matches source-held disposable pin')
                print('PASS: SSH peer exited successfully while source fixture lock remained held')
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
    print('LIMIT: disposable pin only; does not prove receiver manager approval, remote PID reaping or deletion')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        sys.exit(1)
