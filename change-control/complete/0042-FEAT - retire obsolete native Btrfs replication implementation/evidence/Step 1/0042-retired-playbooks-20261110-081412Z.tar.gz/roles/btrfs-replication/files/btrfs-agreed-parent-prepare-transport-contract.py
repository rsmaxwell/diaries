#!/usr/bin/python3
"""0040 3H.5k: dormant fixed receiver prepare transport contract.

Pure message construction / postcondition and recovery validation; NO SSH,
subprocess, lock acquisition, mutation, retry or production command entrypoint.
Only a separately reviewed privileged coordinator may supply real observations.
"""
import json
import re

STAMP = re.compile(r"^[0-9]{8}-[0-9]{6}Z$")
UUID = re.compile(r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
MAX_REPLY = 65536

class ContractError(RuntimeError):
    pass

def require(condition, message):
    if not condition:
        raise ContractError(message)

def identity(value):
    require(type(value) is dict and set(value) == {'timestamp', 'uuid'}, 'invalid identity fields')
    require(type(value['timestamp']) is str and STAMP.fullmatch(value['timestamp']) is not None, 'invalid timestamp')
    require(type(value['uuid']) is str and UUID.fullmatch(value['uuid']) is not None, 'invalid UUID')
    return value

def state(value):
    require(type(value) is dict and set(value) == {'schema','established','pending','previous'}, 'invalid state fields')
    require(type(value['schema']) is int and value['schema'] == 1, 'invalid state schema')
    require(value['established'] is not None, 'missing established parent')
    stamps=[]
    for key in ('established','pending','previous'):
        if value[key] is not None:
            identity(value[key]); stamps.append(value[key]['timestamp'])
    require(len(stamps) == len(set(stamps)), 'duplicate parent timestamp')
    require(value['pending'] is None or value['previous'] is None, 'overlapping transitions')
    return value

def prepare_request(source_state, receiver_state, candidate):
    state(source_state); state(receiver_state); identity(candidate)
    require(source_state == receiver_state, 'source and receiver disagree')
    require(source_state['pending'] is None and source_state['previous'] is None, 'unfinished transition')
    require(candidate['timestamp'] > source_state['established']['timestamp'], 'candidate not newer')
    return {'schema':1,'operation':'prepare','transaction_id':candidate['timestamp'],
            'expected_before':receiver_state,'candidate':candidate}

def expected_after(request):
    require(type(request) is dict and set(request) == {'schema','operation','transaction_id','expected_before','candidate'}, 'invalid request fields')
    require(type(request['schema']) is int and request['schema'] == 1 and request['operation'] == 'prepare', 'invalid operation')
    state(request['expected_before']); identity(request['candidate'])
    require(request['transaction_id'] == request['candidate']['timestamp'], 'transaction mismatch')
    return dict(request['expected_before'], pending=request['candidate'])

def reply_state(raw, *, operation, transaction_id, exit_status):
    require(type(exit_status) is int and exit_status == 0, 'SSH result uncertain')
    require(type(raw) is str and 0 < len(raw.encode('utf-8')) <= MAX_REPLY, 'invalid reply length')
    try:
        data=json.loads(raw)
    except (ValueError,TypeError) as exc:
        raise ContractError('malformed JSON') from exc
    require(type(data) is dict and set(data) == {'schema','operation','transaction_id','status','state'}, 'invalid reply fields')
    require(type(data['schema']) is int and data['schema'] == 1 and data['operation'] == operation and data['transaction_id'] == transaction_id and data['status'] == 'success', 'stale or unsuccessful reply')
    return state(data['state'])

def reconcile(request, *, prepare_exit, prepare_stdout, recover_exit=None, recover_stdout=None):
    """Classify a supplied result, never execute or repeat a prepare.

    Recovery evidence must be a separately obtained authenticated get-state reply;
    the caller is responsible for lock ownership and freshness.
    """
    before=state(request['expected_before']); after=state(expected_after(request))
    tid=request['transaction_id']
    try:
        observed=reply_state(prepare_stdout, operation='prepare',transaction_id=tid,exit_status=prepare_exit)
        require(observed == after, 'prepare postcondition mismatch')
        status='receiver-prepared-verified'
    except (ContractError, TypeError):
        require(recover_stdout is not None, 'uncertain prepare requires fresh get-state')
        observed=reply_state(recover_stdout,operation='get-state',transaction_id=tid,exit_status=recover_exit)
        require(observed == after, 'prepare not confirmed; no retry')
        status='receiver-prepared-recovered'
    return {'schema':1,'status':status,'receiver':observed,'authorizes_source_prepare':False,
            'authorizes_transfer':False,'authorizes_promote':False,'authorizes_prune':False,
            'authorizes_release':False}
