#!/usr/bin/env python3
"""Non-destructive receiver approval/replay preflight regression."""
import datetime
import importlib.util
import json
import os
from pathlib import Path
import tempfile

MODULE = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-native-push-receiver.py'
spec = importlib.util.spec_from_file_location('native_receiver', MODULE)
receiver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(receiver)
STAMP = '20261022-030026Z'
PARENT = '20261024-030038Z'
UUID = '22e0ca45-0f49-c745-85b0-af6b6cfb915c'
CLOCK = datetime.datetime(2026, 10, 24, 7, tzinfo=datetime.timezone.utc)


def rejected(callback):
    try:
        callback()
    except (RuntimeError, OSError, ValueError, TypeError):
        return
    raise AssertionError('unsafe approval unexpectedly accepted')


with tempfile.TemporaryDirectory() as folder:
    root = Path(folder)
    approval = root / 'approval.json'
    consumed_dir = root / 'consumed'
    consumed_dir.mkdir()
    data = {'schema': 1, 'operation': 'receiver-prune-one',
            'candidate': STAMP, 'protected_parent': PARENT,
            'protected_parent_uuid': UUID, 'reason': 'Disposable test only',
            'expires_at_utc': '2026-10-24T07:30:00Z'}
    approval.write_text(json.dumps(data))
    approval.chmod(0o600)
    # Non-root users cannot create a genuine root-owned test file. Test the
    # positive case only when invoked as root; never weaken the production check.
    def check(**kw):
        return receiver.validate_receiver_prune_approval(
            approval, candidate=STAMP, parent_stamp=PARENT, parent_uuid=UUID,
            consumed_dir=consumed_dir, now=CLOCK, **kw)
    if os.geteuid() == 0:
        result = check()
        assert result['authorizes_deletion'] is False
        consumed = consumed_dir / (result['approval_sha256'] + '.json')
        consumed.write_text('{}')  # Disposable replay fixture, not production consumption.
        rejected(check)
        consumed.unlink()
    else:
        rejected(check)
    rejected(lambda: receiver.validate_receiver_prune_approval(
        approval, candidate='20261025-030038Z', parent_stamp=PARENT,
        parent_uuid=UUID, consumed_dir=consumed_dir, now=CLOCK))
    approval.chmod(0o644)
    rejected(check)
    approval.chmod(0o600)
    link = root / 'link.json'
    link.symlink_to(approval)
    rejected(lambda: receiver.validate_receiver_prune_approval(
        link, candidate=STAMP, parent_stamp=PARENT,
        parent_uuid=UUID, consumed_dir=consumed_dir, now=CLOCK))
    rejected(lambda: receiver.validate_receiver_prune_approval(
        approval, candidate=STAMP, parent_stamp=PARENT,
        parent_uuid=UUID, consumed_dir=root / 'missing', now=CLOCK))
    data['expires_at_utc'] = '2026-10-24T06:59:59Z'
    approval.write_text(json.dumps(data))
    rejected(check)
print('PASS: receiver approval preflight rejects unsafe identity, permissions, expiry and replay; no deletion')
