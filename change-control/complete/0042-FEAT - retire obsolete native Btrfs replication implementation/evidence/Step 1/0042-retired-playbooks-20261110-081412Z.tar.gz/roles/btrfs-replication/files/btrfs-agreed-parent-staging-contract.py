#!/usr/bin/env python3
"""0040 Step 12.3: internal transaction-specific Btrfs staging contract.

No CLI, filesystem mutations, deletion, or authority to publish.  This is a
strict common contract for the upcoming receive/publish/reconcile integration.
Callers must still hold both canonical receiver locks and independently prove
ownership, process termination, Btrfs identity and receipt absence.
"""
from pathlib import Path
import re

ROOT = Path('/@data/mars-received')
STAGING_ROOT = ROOT / '@data'
FINAL_ROOT = ROOT / '@data'
STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
NONCE = re.compile(r'[0-9a-f]{64}\Z')

class StagingRefused(RuntimeError):
    pass


def paths(candidate_stamp, transaction_nonce):
    """Derive fixed receiver paths; never accept an arbitrary path from RPC."""
    if type(candidate_stamp) is not str or not STAMP.fullmatch(candidate_stamp):
        raise StagingRefused('invalid candidate snapshot identity')
    if type(transaction_nonce) is not str or not NONCE.fullmatch(transaction_nonce):
        raise StagingRefused('invalid transaction nonce')
    transaction_dir = STAGING_ROOT
    return {
        'staging_parent': transaction_dir,
        'staged_subvolume': transaction_dir / ('.receive-' + transaction_nonce),
        'published_subvolume': FINAL_ROOT / candidate_stamp,
    }


def verify_journal_binding(journal, candidate, *, locks_held=False):
    """Validate that a reserved journal addresses exactly one staging tree.

    This does NOT establish that a staged Btrfs subvolume belongs to the
    journal; safe publication/deletion needs independently captured inode,
    subvolume ID, Btrfs UUID, ownership and lifecycle evidence.
    """
    if locks_held is not True:
        raise StagingRefused('both receiver locks required')
    if type(journal) is not dict or journal.get('status') != 'receiving':
        raise StagingRefused('missing active provisional journal')
    if type(candidate) is not dict or set(candidate) != {'timestamp', 'uuid'}:
        raise StagingRefused('invalid candidate identity')
    if journal.get('candidate') != candidate:
        raise StagingRefused('journal candidate mismatch')
    return paths(candidate['timestamp'], journal.get('nonce'))
