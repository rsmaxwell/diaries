# 0040-FEAT Step 3 — production integration gate (OPEN)

## Evidence already accepted
- Deployment and Ansible second-run idempotency on mars and backup.
- Twenty verified received snapshots, no receiver inventory errors, clean recovery state, protected checkpoint holds.
- Eight-script disposable coordination suite passed on mango as normal user and root (root runs the positive approved transaction case).
- Real mars-to-backup SSH interruption fixture passed, with an explicit limitation that it does not prove remote PID reaping or production pin/journal continuity.
- Playbooks source through commit `024e740` was reported clean and pushed; do not treat this note as live inspection of that commit.

## Safety gaps observed in source review
1. The unprivileged receiver's public `main()` takes the receiver writer lock before command dispatch. Its *internal* approved manager-bound adapter acquires manager lock then writer lock. Directly dispatching to that adapter under the existing outer lock would invert/reacquire lock ordering; design an exclusive, manager-first entry path without nesting the old lock.
2. Receiver approval validation requires root-owned, mode-0600 approval files. The receiver entry point runs unprivileged. Define a separate constrained privileged approval reader or audited root-side verification boundary; do not weaken approval permissions or simply run all receiver operations as root.
3. The endpoint code implements `delete-receiver`, but the deployed sudoers template does **not** authorise it. Do not expose this role until the cross-host lease and recovery acceptance test succeeds.
4. `receiver_prune_enabled` is `false` in both receiver templates. Preserve the default-off configuration and 03:30 UTC source-initiated timer.
5. One-time approval reservation must be durably tied to the receiver pending journal; interrupted sessions must preserve both for manual reconciliation. No automated recovery or unpinning after uncertain outcomes.

## Required next change (consolidated)
- Implement a narrowly-scoped explicit operator entry point, not a timer, with a one-snapshot approval and a separate receiver-side privilege boundary.
- Maintain a source-held lock and durable parent pin throughout live SSH session and until the receiver's outcome is known; preserve the pin when uncertain.
- Receiver lock order: manager then writer, held throughout approval verification, reservation, fresh challenges, journal, Btrfs operation and receipt reconciliation.
- Require two fresh source-pin challenges, verified source/received UUID identities, valid retention candidate and independent immutable checkpoint holds.
- Make receiver delete narrowly authorised for the exact journaled candidate only after an approved disposable Btrfs rehearsal; never expose general Btrfs commands.
- Provide an explicit, reviewed operator recovery runbook for BEFORE_DELETE, AFTER_DELETE_RECEIPT_PRESENT, AFTER_RECEIPT_REMOVAL, and inconsistent/corrupt states. Recovery is not automatic.

## Acceptance sequence
1. Implement and review source changes and maintain default-off / no-deletion privilege boundary.
2. Run source regressions and the static boundary test; examine any intentional changes to the static test before accepting them.
3. Execute one isolated Btrfs filesystem/subvolume end-to-end destructive *disposable-only* rehearsal with interrupted SSH, positive successful deletion, failed deletion, rejected held candidate and replay protection.
4. Review Ansible `--check --diff`, explicitly record the exact changes and rollback plans.
5. Deploy only after explicit operator approval and verify successful backup push, intact recovery holds, idempotency and no unintended changes.

Step 3 remains OPEN. No production receiver snapshot deletion has been authorised.
