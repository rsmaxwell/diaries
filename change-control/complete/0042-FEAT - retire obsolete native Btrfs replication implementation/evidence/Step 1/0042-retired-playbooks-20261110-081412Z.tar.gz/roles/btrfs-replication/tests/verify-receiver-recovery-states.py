#!/usr/bin/env python3
"""0040 Step 3: disposable, non-destructive receiver recovery classification tests.

Loads the deployed manager source by repository-relative path; Btrfs commands are
mocked, and all files exist only in a temporary directory. No real receive,
prune, repair, snapshot mutation, or production state is accessed.
"""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

MANAGER = Path(__file__).resolve().parents[2] / 'snapshots/files/btrfs-snapshot-manager.py'
STAMP = '20261022-030026Z'
UUID = '571d59ec-5110-4944-b4e1-78b3372675d2'


def load_manager():
    spec = importlib.util.spec_from_file_location('btrfs_snapshot_manager_recovery_test', MANAGER)
    module = importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def fixture(root, *, snapshot=True, receipt=True, journal=True):
    snapshots = root / 'snapshots'
    state = root / 'state'
    snapshots.mkdir()
    state.mkdir()
    target = snapshots / STAMP
    receipt_path = state / (STAMP + '.json')
    if snapshot:
        target.mkdir()
    if receipt:
        receipt_path.write_text(json.dumps({
            'schema': 1, 'snapshot': STAMP, 'destination': str(target),
            'source_uuid': UUID, 'received_uuid': UUID, 'read_only_verified': True,
        }))
    if journal:
        (state / '.receiver-prune-pending.json').write_text(json.dumps({
            'schema': 1, 'snapshot': STAMP, 'destination': str(target),
            'receipt': str(receipt_path), 'source_uuid': UUID,
        }))
    config = SimpleNamespace(mode='receiver', receiver_state_dir=state,
        writer_lock_path=state / 'writer.lock', sources=(SimpleNamespace(
            name='@data', snapshot_directory=snapshots),), snapshot_root=snapshots)
    return config, target, receipt_path, state / '.receiver-prune-pending.json'


def fingerprint(root):
    return sorted((str(p.relative_to(root)), 'dir' if p.is_dir() else hashlib.sha256(p.read_bytes()).hexdigest())
        for p in root.rglob('*'))


def check_case(manager, name, expected=None, modify=None, error=False):
    with tempfile.TemporaryDirectory(prefix='0040-recovery-') as tmp:
        root = Path(tmp)
        options = {'snapshot': True, 'receipt': True, 'journal': True}
        if name == 'after_delete_receipt':
            options['snapshot'] = False
        elif name == 'after_receipt_removal':
            options['snapshot'] = options['receipt'] = False
        elif name == 'inconsistent':
            options['receipt'] = False
        elif name == 'clean':
            options['journal'] = False
        config, target, receipt_path, journal = fixture(root, **options)
        if modify:
            modify(config, target, receipt_path, journal)
        before = fingerprint(root)
        def fake_run(command, *, check=True):
            if command[:3] == ['btrfs', 'subvolume', 'show']:
                assert Path(command[3]) == target
                return subprocess.CompletedProcess(command, 0, 'Received UUID: ' + UUID + '\n', '')
            if command[:4] == ['btrfs', 'property', 'get', '-ts']:
                assert Path(command[4]) == target
                return subprocess.CompletedProcess(command, 0, 'ro=true\n', '')
            raise AssertionError('Unexpected Btrfs invocation: ' + str(command))
        with patch.object(manager, 'run', side_effect=fake_run):
            with contextlib.redirect_stdout(io.StringIO()):
                if error:
                    try:
                        manager.receiver_recovery_plan(config)
                    except (manager.SnapshotError, OSError, ValueError, TypeError):
                        pass
                    else:
                        raise AssertionError(name + ' must fail closed')
                else:
                    result = manager.receiver_recovery_plan(config)
                    assert result['state'] == expected, (name, result)
                    assert result['authorizes_repair'] is False
        assert fingerprint(root) == before, name + ': changed disposable recovery state'
        print('PASS:', name, 'no repair/deletion; fixture unchanged')


def corrupt_journal(config, target, receipt, journal):
    journal.write_text('{bad-json')


def wrong_uuid(config, target, receipt, journal):
    value = json.loads(receipt.read_text())
    value['received_uuid'] = '00000000-0000-0000-0000-000000000000'
    receipt.write_text(json.dumps(value))


def wrong_path(config, target, receipt, journal):
    value = json.loads(journal.read_text())
    value['destination'] = '/outside/managed/tree'
    journal.write_text(json.dumps(value))


def journal_symlink(config, target, receipt, journal):
    journal.unlink()
    journal.symlink_to(receipt)


def main():
    manager = load_manager()
    for name, expected in (
        ('before_delete', 'BEFORE_DELETE'),
        ('after_delete_receipt', 'AFTER_DELETE_RECEIPT_PRESENT'),
        ('after_receipt_removal', 'AFTER_RECEIPT_REMOVAL'),
        ('inconsistent', 'INCONSISTENT'),
        ('clean', 'CLEAN'),
    ):
        check_case(manager, name, expected=expected)
    for name, modify in (
        ('corrupt_journal', corrupt_journal),
        ('receipt_uuid_mismatch', wrong_uuid),
        ('journal_path_mismatch', wrong_path),
        ('journal_symlink', journal_symlink),
    ):
        check_case(manager, name, modify=modify, error=True)
    print('PASS: receiver recovery classifications and fail-closed checks; no Btrfs changes')


if __name__ == '__main__':
    main()
