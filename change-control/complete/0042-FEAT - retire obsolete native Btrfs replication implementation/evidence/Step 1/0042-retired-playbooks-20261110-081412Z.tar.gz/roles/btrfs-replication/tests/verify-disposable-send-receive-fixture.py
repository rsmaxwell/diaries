#!/usr/bin/env python3
"""0040 Step 3: isolated, disposable Btrfs send/receive identity fixture.

--plan does not create/modify/delete anything. --execute is explicitly destructive
ONLY under a fresh /@data/.0040-send-receive-<random> namespace on backup.
No production receiver manager, receipts, checkpoint holds, or sudoers touched.
On failure the complete fixture is preserved for inspection.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

PARENT = Path('/@data')
PREFIX = '.0040-send-receive-'
ACK = 'CREATE-DELETE-ONLY-0040-SEND-RECEIVE'

def run(*args):
    result = subprocess.run(args, text=True, capture_output=True, check=True)
    return result.stdout

def uuid_of(path, field):
    result = run('btrfs', 'subvolume', 'show', str(path))
    match = re.search(r'^\s*' + re.escape(field) + r':\s*(\S+)', result, re.M)
    if not match or match.group(1) in ('-', 'none'):
        raise RuntimeError(f'Missing {field} for {path}')
    return match.group(1)

def preflight():
    if not PARENT.is_dir() or PARENT.is_symlink():
        raise RuntimeError('Unsafe /@data parent')
    mount = run('findmnt', '-n', '-o', 'FSTYPE', '--target', str(PARENT)).strip()
    if mount != 'btrfs':
        raise RuntimeError('Disposable parent is not Btrfs')
    if not Path('/usr/bin/btrfs').exists():
        raise RuntimeError('Btrfs command unavailable')
    return {'parent': str(PARENT), 'fstype': mount}

def transfer(snapshot, dest, parent_snapshot=None):
    # Explicitly separate sender/receiver process exit results; no shell pipeline.
    command = ['btrfs', 'send']
    if parent_snapshot is not None:
        command += ['-p', str(parent_snapshot)]
    command += [str(snapshot)]
    sender = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        receiver = subprocess.run(['btrfs', 'receive', str(dest)], stdin=sender.stdout,
                                  stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    finally:
        sender.stdout.close()
    sender_stderr = sender.communicate()[1]
    if sender.returncode != 0 or receiver.returncode != 0:
        raise RuntimeError('Disposable transfer failed: sender=%s receiver=%s; %s %s' % (
            sender.returncode, receiver.returncode,
            sender_stderr.decode(errors='replace')[-500:],
            receiver.stderr.decode(errors='replace')[-500:]))

def execute():
    if os.geteuid() != 0:
        raise PermissionError('root required for disposable Btrfs operations')
    namespace = PARENT / (PREFIX + uuid.uuid4().hex)
    if namespace.exists() or namespace.is_symlink():
        raise RuntimeError('Disposable namespace collision')
    # Explicit root, no caller-selectable target paths.
    run('btrfs', 'subvolume', 'create', str(namespace))
    print('FIXTURE: ' + str(namespace), flush=True)
    source = namespace / 'source'
    origin = namespace / 'origin'
    incoming = namespace / 'incoming'
    origin.mkdir()
    incoming.mkdir()
    try:
        run('btrfs', 'subvolume', 'create', str(source))
        (source / 'small-payload.txt').write_text('0040 fixture base\n')
        parent_snapshot = origin / '20261024-000001Z'
        run('btrfs', 'subvolume', 'snapshot', '-r', str(source), str(parent_snapshot))
        (source / 'small-payload.txt').write_text('0040 fixture increment\n')
        child_snapshot = origin / '20261024-000002Z'
        run('btrfs', 'subvolume', 'snapshot', '-r', str(source), str(child_snapshot))
        transfer(parent_snapshot, incoming)
        transfer(child_snapshot, incoming, parent_snapshot)
        for name in (parent_snapshot.name, child_snapshot.name):
            expected = uuid_of(origin / name, 'UUID')
            received = uuid_of(incoming / name, 'Received UUID')
            if received != expected:
                raise RuntimeError('Btrfs received UUID mismatch for ' + name)
        if (incoming / child_snapshot.name / 'small-payload.txt').read_text() != '0040 fixture increment\n':
            raise RuntimeError('Incremental received content mismatch')
        print('PASS: real disposable full + incremental Btrfs send/receive, received UUIDs match', flush=True)
        # Cleanup only the exact paths constructed above; never glob or recurse.
        for target in (incoming / child_snapshot.name, incoming / parent_snapshot.name,
                       child_snapshot, parent_snapshot, source, namespace):
            if target == namespace:
                incoming.rmdir()
                origin.rmdir()
            if not target.is_relative_to(namespace):
                raise RuntimeError('Unsafe deletion path')
            run('btrfs', 'subvolume', 'delete', str(target))
        if namespace.exists():
            raise RuntimeError('Namespace remains following delete')
        print('PASS: disposable namespace absent; no production files modified', flush=True)
    except Exception:
        print('FAIL: fixture preserved for review at ' + str(namespace), file=sys.stderr)
        raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--plan', action='store_true')
    group.add_argument('--execute', action='store_true')
    parser.add_argument('--accept-disposable-delete', default='')
    args = parser.parse_args()
    baseline = preflight()
    if args.plan:
        if args.accept_disposable_delete:
            parser.error('Acknowledgement forbidden in plan mode')
        print('PASS: read-only send/receive preflight ' + json.dumps(baseline, sort_keys=True))
        print('PLAN: one fresh disposable namespace under /@data; full + incremental receive; verify received UUID and tiny payload; delete exact disposable subvolumes')
        print('LIMIT: does not test source-held SSH, approval reservation, manager journal or receipt deletion')
        return
    if args.accept_disposable_delete != ACK:
        parser.error('Explicit acknowledgement required: ' + ACK)
    execute()

if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, PermissionError, OSError, subprocess.CalledProcessError) as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
