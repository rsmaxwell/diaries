#!/usr/bin/env python3
"""0040 Step 12.3: dormant sender-side A->B promotion coordinator.

No CLI, SSH invocation, scheduler, state-path selection or privilege grant.
The privileged caller must hold the source transaction locks across this call
and supply fixed, independently authenticated receiver adapters.
This module does not release/prune A. All uncertainty fails closed.
"""

class PromotionRefused(RuntimeError):
    pass


def _valid_state(state, parent, candidate, *, promoted):
    if type(state) is not dict or set(state) != {'schema', 'established', 'pending', 'previous'} or state['schema'] != 1:
        return False
    if promoted:
        return state['established'] == candidate and state['pending'] is None and state['previous'] == parent
    return state['established'] == parent and state['pending'] == candidate and state['previous'] is None


def coordinate_after_receipt(parent, candidate, *, verify_source_prepared,
                             verify_receiver_receipt, promote_receiver,
                             read_receiver_promoted, promote_source,
                             read_source_state):
    """Advance receiver first, then source, requiring independent readbacks.

    Each supplied adapter MUST be a trusted fixed implementation. The two
    promote adapters are idempotent (receiver promotion is already so in
    receiver-entry); the caller must NOT automatically retry on uncertainty.
    Before calling, source and receiver Btrfs identities must be established
    by the corresponding trusted verification components.
    """
    adapters = (verify_source_prepared, verify_receiver_receipt,
                promote_receiver, read_receiver_promoted, promote_source,
                read_source_state)
    if not all(callable(x) for x in adapters):
        raise PromotionRefused('missing trusted promotion adapters')
    if (type(parent) is not dict or type(candidate) is not dict or
            set(parent) != {'timestamp', 'uuid'} or set(candidate) != {'timestamp', 'uuid'} or
            any(type(v) is not str or not v for obj in (parent, candidate) for v in obj.values()) or
            parent['timestamp'] >= candidate['timestamp']):
        raise PromotionRefused('invalid A/B identities')
    if verify_source_prepared(parent, candidate) is not True:
        raise PromotionRefused('source A pinned and B pending not verified')
    if verify_receiver_receipt(parent, candidate) is not True:
        raise PromotionRefused('authenticated receiver final receipt unverified')
    # An acknowledgement alone NEVER authorises a source state write.
    promote_receiver(parent, candidate)
    receiver = read_receiver_promoted(parent, candidate)
    if not _valid_state(receiver, parent, candidate, promoted=True):
        raise PromotionRefused('receiver B durable readback unverified; retain source A')
    # Source promotion must be journaled/durable inside a trusted fixed adapter.
    # Never infer success from a callback return value.
    promote_source(parent, candidate)
    source = read_source_state(parent, candidate)
    if not _valid_state(source, parent, candidate, promoted=True):
        raise PromotionRefused('source B durable readback unverified; retain A')
    return {'schema': 1, 'status': 'both-promoted-previous-pinned',
            'parent': parent, 'candidate': candidate,
            'receiver_state': receiver, 'source_state': source,
            'authorizes_release': False, 'authorizes_prune': False}
