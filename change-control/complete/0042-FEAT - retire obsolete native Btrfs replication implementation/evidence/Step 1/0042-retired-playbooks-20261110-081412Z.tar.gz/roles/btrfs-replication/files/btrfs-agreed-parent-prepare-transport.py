#!/usr/bin/python3
"""0040 Stage B1: fixed receiver prepare transport, dormant until a reviewed lock-owning caller.

One authenticated SSH invocation; never retry or infer success from failure.
Caller must establish/hold source push and manager locks, independently validate
source Btrfs identity and expected receiver state, then reconcile uncertain output.
No CLI, release, pruning, promotion or snapshot deletion entrypoint.
"""
import json
import subprocess
import importlib.util
from pathlib import Path

BASE = Path(__file__).resolve().parent
SSH = ('/usr/sbin/runuser', '-u', 'richard', '--', 'ssh',
       '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1',
       'sudo', '-n', '/usr/local/libexec/btrfs-agreed-parent-prepare-endpoint.py', '--request')

class PrepareUncertain(RuntimeError):
    """A request may already have persisted on receiver. Observe; never blindly retry."""


def contract_module():
    p = BASE / 'btrfs-agreed-parent-prepare-transport-contract.py'
    spec = importlib.util.spec_from_file_location('stageb1_contract', p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def invoke(request, *, locks_held=False, source_verified=False,
           run=subprocess.run, contract=None):
    """Send exactly once, return (exit_code, stdout) for external reconciliation.

    An ambiguous failure always raises PrepareUncertain; the caller must obtain
    fresh authenticated get-state and check exact expected-after before advancing.
    The trusted booleans may only come from internal lock/evidence ownership;
    do not expose this function directly as a privileged CLI.
    """
    if locks_held is not True or source_verified is not True:
        raise ValueError('source locks and evidence are mandatory')
    c = contract or contract_module()
    if type(request) is not dict or set(request) != {
        'schema', 'operation', 'transaction_id', 'expected_before', 'candidate'
    }:
        raise ValueError('invalid request fields')
    expected = c.prepare_request(request['expected_before'], request['expected_before'], request['candidate'])
    if expected != request:
        raise ValueError('invalid prepare request')
    raw = json.dumps(request, separators=(',', ':'), sort_keys=True)
    if len(raw.encode('utf-8')) > 65536:
        raise ValueError('oversized request')
    try:
        result = run(list(SSH), input=raw, capture_output=True,
                     text=True, timeout=90, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise PrepareUncertain('receiver prepare outcome uncertain; authenticated get-state required') from exc
    if type(result.returncode) is not int or result.returncode != 0:
        raise PrepareUncertain('receiver prepare exit uncertain; authenticated get-state required')
    if type(result.stdout) is not str or not 0 < len(result.stdout.encode('utf-8')) <= 65536:
        raise PrepareUncertain('receiver prepare reply missing/oversized; get-state required')
    try:
        observed = c.reply_state(result.stdout, operation='prepare',
                                 transaction_id=request['transaction_id'],
                                 exit_status=result.returncode)
        if observed != c.expected_after(request):
            raise ValueError('unexpected receiver postcondition')
    except (ValueError, RuntimeError, KeyError, TypeError) as exc:
        raise PrepareUncertain('receiver prepare reply uncertain; get-state required') from exc
    return {'schema': 1, 'status': 'receiver-prepared-verified',
            'receiver': observed, 'prepare_attempts': 1,
            'authorizes_source_prepare': False, 'authorizes_transfer': False,
            'authorizes_promote': False, 'authorizes_prune': False,
            'authorizes_release': False}
