#!/usr/bin/python3
"""0040 Step 12.3/04U: dormant local registration socket boundary.

Socket lifetime and kernel peer verification only. NO SSH proof, no registration,
no Btrfs I/O. The caller must own the actual receiver locks. Do not enable a
public listener or treat local peer UID as proof of authenticated SSH identity.
"""
from contextlib import contextmanager
import importlib.util
import os
from pathlib import Path
import socket
import stat
import sys

class RegistrationRefused(RuntimeError):
    pass

def load_peer(path=None):
    path = Path(path) if path else Path(__file__).with_name('btrfs-agreed-parent-local-peer.py')
    spec = importlib.util.spec_from_file_location('04u_local_peer', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

@contextmanager
def temporary_listener(path, *, directory, locks_held=False, owner_uid=0, mode=0o600):
    """Create a single locked-transaction listener; refuse unsafe/stale paths.

    The caller creates an exclusively owned private directory beforehand.
    Never unlink a pre-existing socket or other object; require manual review.
    """
    p, root = Path(path), Path(directory)
    if locks_held is not True:
        raise RegistrationRefused('receiver locks not held')
    if not p.is_absolute() or p.parent != root or p.name in ('', '.', '..'):
        raise RegistrationRefused('socket outside exact private directory')
    if type(owner_uid) is not int or owner_uid < 0 or mode != 0o600:
        raise RegistrationRefused('unsafe ownership or socket mode')
    try:
        root_st = root.lstat()
    except OSError as exc:
        raise RegistrationRefused('private directory missing') from exc
    if (not stat.S_ISDIR(root_st.st_mode) or root_st.st_uid != owner_uid or
            stat.S_IMODE(root_st.st_mode) != 0o700 or root.is_symlink()):
        raise RegistrationRefused('private directory must be owned and 0700')
    if p.exists() or p.is_symlink():
        raise RegistrationRefused('existing socket path requires investigation')
    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    created = False
    try:
        listener.bind(str(p))
        created = True
        os.chmod(p, mode)
        listener.listen(2)
        listener.settimeout(2)
        yield listener
    finally:
        listener.close()
        if created:
            st = p.lstat() if p.exists() or p.is_symlink() else None
            if st and stat.S_ISSOCK(st.st_mode) and st.st_uid == os.geteuid():
                p.unlink()

def review_one_connection(listener, *, expected_uid, peer_module=None, timeout=2):
    """Verify one local process and close; never read instructions or register."""
    if type(timeout) not in (int, float) or not 0 < timeout <= 30:
        raise RegistrationRefused('invalid accept deadline')
    if not isinstance(listener, socket.socket) or listener.family != socket.AF_UNIX:
        raise RegistrationRefused('Unix socket listener required')
    listener.settimeout(timeout)
    try:
        connection, _ = listener.accept()
    except (OSError, socket.timeout) as exc:
        raise RegistrationRefused('registration review accept failed') from exc
    try:
        peer = (peer_module or load_peer()).verify_local_peer(connection, expected_uid=expected_uid)
        return {'schema': 1, 'status': 'local-peer-review',
                'peer_uid': peer.uid, 'peer_pid_observed': True,
                'ssh_identity_verified': False, 'channels_registered': [],
                'transfer_executed': False, 'authorizes_transfer': False}
    finally:
        connection.close()
