#!/usr/bin/env python3
"""Consolidated 0040-FEAT Step 3, non-destructive source regression driver.

Executes the accepted independent regression scripts in a fixed order plus the
new sender protocol-interruption fixture. No Ansible or Btrfs operations are
initiated by this driver. Run normally, then with sudo to exercise root-only
positive approval cases; each child uses disposable fixtures.
"""
from pathlib import Path
import subprocess
import sys

TESTS = (
    'verify-prune-approval-contract.py',
    'verify-receiver-prune-approval.py',
    'verify-receiver-approval-consumption.py',
    'verify-receiver-approved-lock-binding.py',
    'verify-source-transaction-failure-continuity.py',
    'verify-source-protocol-interruption.py',
    'verify-receiver-recovery-states.py',
    'verify-approved-two-challenge-integration.py',
)

base = Path(__file__).resolve().parent
for filename in TESTS:
    target = base / filename
    if not target.is_file():
        raise SystemExit(f'FAIL: required Step 3 regression missing: {target}')
    print(f'=== {filename} ===', flush=True)
    subprocess.run([sys.executable, str(target)], check=True)
print(f'PASS: all {len(TESTS)} Step 3 non-destructive regression scripts', flush=True)
