#!/usr/bin/env python3
"""0040 Step 12.3 fixed sender-side SSH command construction.

Internal only.  No CLI, no receipt authority, no snapshot mutations.  These
commands must only be used after the source pin and receiver preparation have
been independently verified.  The receiver executable is installed. All commands remain fixed-argv and
require source-side transaction orchestration.
"""
import re

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
SOURCE_ENDPOINT = '/usr/local/libexec/btrfs-native-endpoint'
RECEIVER_PRIVILEGE = ('sudo', '-n')
RECEIVER_ENTRY = '/usr/local/bin/btrfs-agreed-parent-receiver'
SSH = ('ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=15', '-T', '-p', '39263', 'richard@10.254.22.1')


class CommandRefused(ValueError):
    pass


def _stamp(obj):
    if type(obj) is not dict or set(obj) != {'timestamp', 'uuid'}:
        raise CommandRefused('invalid identity shape')
    stamp, uuid = obj['timestamp'], obj['uuid']
    if (type(stamp) is not str or not STAMP.fullmatch(stamp) or
        type(uuid) is not str or not re.fullmatch(
            r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', uuid)):
        raise CommandRefused('invalid snapshot identity')
    return stamp


def receive_commands(parent, candidate):
    """Return exact argv for direct incremental send and SSH binary receive.

    No shell interpolation or command overrides; SSH has no pty allocation.
    Returned args are not executable until receiver is installed and enabled.
    """
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b:
        raise CommandRefused('nonincreasing snapshot timestamps')
    return (
        ['sudo', '-n', SOURCE_ENDPOINT, '--role', 'incremental-source',
         '--snapshot', b, '--parent', a],
        [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--receive', '--parent', a, '--parent-uuid', parent['uuid'],
         '--candidate', b, '--candidate-uuid', candidate['uuid']],
    )


def finalise_command(parent, candidate):
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b:
        raise CommandRefused('nonincreasing snapshot timestamps')
    return [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--finalise', '--parent', a, '--parent-uuid', parent['uuid'],
            '--candidate', b, '--candidate-uuid', candidate['uuid']]


def session_command(parent, candidate):
    """Fixed authenticated read-only query for receiver-owned session nonce."""
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b:
        raise CommandRefused('nonincreasing snapshot timestamps')
    return [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--session', '--parent', a, '--parent-uuid', parent['uuid'],
            '--candidate', b, '--candidate-uuid', candidate['uuid']]


def receipt_command(parent, candidate):
    """Canonical read-only receipt query, over the established SSH identity."""
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b:
        raise CommandRefused('nonincreasing snapshot timestamps')
    return [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--receipt', '--parent', a,
            '--parent-uuid', parent['uuid'], '--candidate', b,
            '--candidate-uuid', candidate['uuid']]


def promote_command(parent, candidate):
    """Receiver-first durable promotion, preserving previous parent A."""
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b:
        raise CommandRefused('nonincreasing snapshot timestamps')
    return [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--promote',
            '--parent', a, '--parent-uuid', parent['uuid'],
            '--candidate', b, '--candidate-uuid', candidate['uuid']]


def promoted_readback_command(parent, candidate):
    """Independent receiver promoted-state readback over fixed SSH."""
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b:
        raise CommandRefused('nonincreasing snapshot timestamps')
    return [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--promoted-readback',
            '--parent', a, '--parent-uuid', parent['uuid'],
            '--candidate', b, '--candidate-uuid', candidate['uuid']]

def acknowledge_previous_command(parent, candidate):
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b: raise CommandRefused('nonincreasing identities')
    return [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--acknowledge-previous',
            '--parent', a, '--parent-uuid', parent['uuid'],
            '--candidate', b, '--candidate-uuid', candidate['uuid']]

def previous_readback_command(parent, candidate):
    a, b = _stamp(parent), _stamp(candidate)
    if a >= b: raise CommandRefused('nonincreasing identities')
    return [*SSH, *RECEIVER_PRIVILEGE, RECEIVER_ENTRY, '--previous-readback',
            '--parent', a, '--parent-uuid', parent['uuid'],
            '--candidate', b, '--candidate-uuid', candidate['uuid']]
