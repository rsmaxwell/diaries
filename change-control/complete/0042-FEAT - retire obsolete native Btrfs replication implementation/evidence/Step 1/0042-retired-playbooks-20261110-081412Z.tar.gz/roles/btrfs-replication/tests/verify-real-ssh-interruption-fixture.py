#!/usr/bin/env python3
"""0040 Step 3: isolated real-SSH transport/lock/pin interruption rehearsal.

Run on mars as richard. No Btrfs, sudo, production locks or approvals.
No writes on backup; the remote process has a bounded lifetime.
"""
import fcntl
import os
from pathlib import Path
import subprocess
import tempfile
import time
import uuid

SSH = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "-p", "39263", "richard@10.254.22.1"]


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def main():
    marker = "diaries0040-" + uuid.uuid4().hex
    with tempfile.TemporaryDirectory(prefix="0040-crosshost-") as scratch:
        base = Path(scratch)
        pin = base / "durable-pin.json"
        lock_path = base / "source.lock"
        pin.write_text('{"protected":true,"fixture":true}\n', encoding="utf-8")
        initial = pin.read_bytes()
        lock_path.touch(mode=0o600)
        with lock_path.open("r+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            # A remote read-only process with a unique marker and bounded lifetime.
            # It intentionally performs no file access or Btrfs operations.
            remote = ("exec python3 -c 'import sys,time; "
                      "print(sys.argv[1],flush=True); time.sleep(12)' " + marker)
            proc = subprocess.Popen(SSH + [remote], stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    text=True, start_new_session=True)
            try:
                line = proc.stdout.readline().strip()
                require(line == marker, "remote session did not prove startup")
                print("PASS: actual mars-to-backup SSH process established", flush=True)
                # Ensure a second process cannot acquire the source lock while active.
                fd = os.open(lock_path, os.O_RDWR)
                try:
                    try:
                        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError:
                        print("PASS: source fixture lock excluded competing acquisition", flush=True)
                    else:
                        raise RuntimeError("source fixture lock not exclusive")
                finally:
                    os.close(fd)
                proc.terminate()
                try:
                    proc.communicate(timeout=4)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.communicate(timeout=4)
                require(proc.returncode != 0, "interrupted transport falsely reported success")
                require(pin.read_bytes() == initial, "fixture source pin changed")
                print("PASS: interrupted SSH nonzero; local process reaped; fixture pin preserved", flush=True)
            finally:
                if proc.poll() is None:
                    proc.kill()
                    proc.communicate(timeout=4)
        # Process group cleanup on the remote side may lag an SSH disconnect.
        # Do NOT infer remote reaping from the local SSH exit code.
        # Wait for the bounded 12s remote process lifetime before claiming quiescence.
        time.sleep(13)
        # A fresh SSH round trip confirms the transport is still operational.
        check = subprocess.run(SSH + ["true"], capture_output=True, text=True, timeout=20)
        require(check.returncode == 0, "post-interruption SSH connectivity failed")
        require(pin.read_bytes() == initial, "fixture pin changed after interruption")
        print("PASS: post-interruption SSH connectivity; bounded remote fixture lifetime elapsed", flush=True)
        print("LIMIT: does not prove remote PID reaping, production source-pin continuity, or journal recovery", flush=True)


if __name__ == "__main__":
    main()
