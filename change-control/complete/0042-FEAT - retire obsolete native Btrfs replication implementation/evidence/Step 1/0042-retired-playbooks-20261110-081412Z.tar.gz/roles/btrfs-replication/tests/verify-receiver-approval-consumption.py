#!/usr/bin/env python3
"""Disposable one-time approval-marker test; does not access Btrfs or production state."""
import concurrent.futures
import datetime
import importlib.util
import json
import os
from pathlib import Path
import tempfile

SRC = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-native-push-receiver.py'
spec = importlib.util.spec_from_file_location('native_receiver', SRC)
receiver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(receiver)
STAMP = '20261022-030026Z'
PARENT = '20261024-030038Z'
UUID = '22e0ca45-0f49-c745-85b0-af6b6cfb915c'
CLOCK = datetime.datetime(2026, 10, 24, 7, tzinfo=datetime.timezone.utc)


def reject(call):
    try:
        call()
    except (RuntimeError, OSError, ValueError, TypeError):
        return
    raise AssertionError('unsafe replay/identity was accepted')


with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    approval = root / 'approval.json'
    consumed = root / 'consumed'
    consumed.mkdir(mode=0o700)
    approval.write_text(json.dumps({
        'schema': 1, 'operation': 'receiver-prune-one', 'candidate': STAMP,
        'protected_parent': PARENT, 'protected_parent_uuid': UUID,
        'expires_at_utc': '2026-10-24T07:30:00Z', 'reason': 'Disposable test'}))
    approval.chmod(0o600)
    if os.geteuid() == 0:
        validated = receiver.validate_receiver_prune_approval(
            approval, candidate=STAMP, parent_stamp=PARENT,
            parent_uuid=UUID, consumed_dir=consumed, now=CLOCK)
    else:
        # Non-root may test the internal marker's atomicity without weakening
        # the production validator's strict root-ownership requirement.
        reject(lambda: receiver.validate_receiver_prune_approval(
            approval, candidate=STAMP, parent_stamp=PARENT,
            parent_uuid=UUID, consumed_dir=consumed, now=CLOCK))
        validated = {'approval_sha256': 'a' * 64, 'candidate': STAMP,
                     'protected_parent': PARENT, 'protected_parent_uuid': UUID,
                     'authorizes_deletion': False}
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(receiver.reserve_receiver_prune_approval,
                               consumed, validated) for _ in range(8)]
        outcomes = []
        for result in futures:
            try:
                outcomes.append(result.result())
            except RuntimeError as exc:
                assert 'already consumed' in str(exc)
        assert len(outcomes) == 1, outcomes
    marker = outcomes[0]
    assert marker.stat().st_mode & 0o777 == 0o600
    payload = json.loads(marker.read_text())
    assert payload['state'] == 'reserved-not-authorised'
    assert payload['candidate'] == STAMP
    reject(lambda: receiver.reserve_receiver_prune_approval(consumed, validated))
    if os.geteuid() == 0:
        reject(lambda: receiver.validate_receiver_prune_approval(
            approval, candidate=STAMP, parent_stamp=PARENT,
            parent_uuid=UUID, consumed_dir=consumed, now=CLOCK))
    # Simulated interruption: marker is deliberately retained, not rolled back.
    assert marker.is_file()
    reject(lambda: receiver.reserve_receiver_prune_approval(
        consumed, {**validated, 'approval_sha256': '../unsafe'}))
    reject(lambda: receiver.reserve_receiver_prune_approval(
        root / 'missing', validated))
    assert not (root / 'unsafe').exists()
print('PASS: one-time durable marker, 8 competing attempts, replay and interruption fail closed; no deletion')
