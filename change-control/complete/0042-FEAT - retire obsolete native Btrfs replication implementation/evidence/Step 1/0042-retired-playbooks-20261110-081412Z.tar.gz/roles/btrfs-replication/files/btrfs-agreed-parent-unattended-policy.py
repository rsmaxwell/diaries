#!/usr/bin/env python3
"""0040 Step 12.3: side-effect-free scheduled recovery decision contract.

This module deliberately does not delete partial receives or invoke SSH.
The caller must obtain durable, authenticated receiver evidence while holding
its transaction locks. Unknown evidence is a hard refusal, never a retry.
"""

class RecoveryRefused(RuntimeError):
    pass


def _valid(state):
    if type(state) is not dict or set(state) != {'schema', 'established', 'pending', 'previous'} or state['schema'] != 1:
        raise RecoveryRefused('invalid durable state')
    for key in ('established', 'pending', 'previous'):
        ident = state[key]
        if ident is not None and (type(ident) is not dict or set(ident) != {'timestamp', 'uuid'} or
                                  not all(type(v) is str and v for v in ident.values())):
            raise RecoveryRefused('invalid snapshot identity')
    if state['established'] is None:
        raise RecoveryRefused('missing established parent')
    if state['pending'] is not None and state['previous'] is not None:
        raise RecoveryRefused('pending and previous both populated')
    return state


def next_action(source, receiver, *, committed=None, destination=None, candidate=None):
    """Decide one safe action from independently authenticated durable evidence.

    committed: True/False/None (unknown); destination: 'absent', 'readonly-matching',
    'incomplete', or None. Caller must not infer these from SSH exit alone.
    A refusal is an integrity stop, not a transient retry.
    """
    s, r = _valid(source), _valid(receiver)
    b, p, a = s['established'], s['pending'], s['previous']
    if a is not None:
        if s == r or r == {'schema': 1, 'established': b, 'pending': None, 'previous': None}:
            if committed is True:
                return 'acknowledge-previous'
            raise RecoveryRefused('previous parent present without verified committed receipt')
        raise RecoveryRefused('unreconciled previous parent on receiver')
    if p is not None:
        if r == s:
            if committed is True and destination == 'readonly-matching':
                return 'resume-committed'
            if committed is False and destination == 'absent':
                return 'execute-prepared'
            if committed is False and destination == 'incomplete':
                return 'reconcile-incomplete-receive'  # requires transaction-owned cleanup contract
            raise RecoveryRefused('prepared transfer evidence uncertain')
        if r == {'schema': 1, 'established': p, 'pending': None, 'previous': b}:
            if committed is True and destination == 'readonly-matching':
                return 'resume-committed'
            raise RecoveryRefused('receiver promoted without verified committed receipt')
        raise RecoveryRefused('receiver/source preparation mismatch')
    if s != r:
        raise RecoveryRefused('idle source/receiver disagreement')
    if candidate is None:
        return 'select-next-candidate'
    if type(candidate) is not dict or set(candidate) != {'timestamp', 'uuid'} or not all(type(v) is str and v for v in candidate.values()):
        raise RecoveryRefused('invalid next candidate identity')
    if candidate['timestamp'] <= b['timestamp'] or candidate == b:
        raise RecoveryRefused('next candidate is not newer than established parent')
    return 'prepare-next-candidate'
