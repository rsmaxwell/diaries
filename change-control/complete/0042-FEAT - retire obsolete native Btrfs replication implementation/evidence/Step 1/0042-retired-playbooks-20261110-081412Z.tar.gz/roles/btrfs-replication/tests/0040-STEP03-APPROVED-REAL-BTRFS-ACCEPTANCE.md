# 0040 Step 3: approved real-Btrfs transaction in a disposable receiver namespace

This is a bounded integration rehearsal, **not** the final cross-host acceptance.
It combines the installed `run_approved_manager_bound_transaction`, real manager
`receiver_delete_one_locked`, real Btrfs send/receive and deletion, a root-owned
single-use approval, two distinct nonce challenges and a disposable source pin.

`--plan` is read-only. `--execute` requires an explicit acknowledgement and uses a
fresh `@data/.0040-approved-manager-transaction-*` namespace on `backup`.
Production `/@data/mars-received` receipts and holds, production manager locks,
production approval state and sudoers are not accessed or modified.

**If execution fails, do not rerun or delete the preserved fixture.** Collect
its exact `FIXTURE` path and full output for recovery review.

The challenge peer is a local socket on backup. This **does not** test the live
`mars` → `backup` authenticated source holder, remote child reaping or the final
privileged production executor. Those remain explicit acceptance gates.
