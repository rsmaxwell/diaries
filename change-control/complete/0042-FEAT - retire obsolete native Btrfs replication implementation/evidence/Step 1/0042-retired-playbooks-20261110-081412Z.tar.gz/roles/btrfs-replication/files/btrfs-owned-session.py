#!/usr/bin/env python3
"""Private, undeployed 0040 disposable peer-process ownership primitive.

Not a deletion authorisation or production SSH executor. Caller must enforce
source lock/pin and independently verify peer identity before any transaction.
"""
import os
import select
import signal
import subprocess
import time


class BoundedLineReader:
    """Read one complete UTF-8 protocol line within a monotonic deadline."""
    def __init__(self, fd, timeout=5.0, max_bytes=4096):
        if not 0 < timeout <= 60 or not 0 < max_bytes <= 4096:
            raise ValueError('Unsafe bounded protocol settings')
        self.fd, self.timeout, self.max_bytes = fd, timeout, max_bytes

    def readline(self, size=-1):
        limit = min(self.max_bytes, size) if size > 0 else self.max_bytes
        end = time.monotonic() + self.timeout
        buf = bytearray()
        while len(buf) < limit:
            remaining = end - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Source peer response timed out')
            ready, _, _ = select.select([self.fd], [], [], remaining)
            if not ready:
                raise TimeoutError('Source peer response timed out')
            part = os.read(self.fd, 1)
            if not part:
                raise EOFError('Source peer disconnected')
            buf.extend(part)
            if part == b'\n':
                return buf.decode('utf-8', errors='strict')
        raise ValueError('Source peer protocol line too long')


class LineWriter:
    def __init__(self, fd):
        self.fd = fd

    def write(self, value):
        data = value.encode('utf-8', errors='strict')
        if len(data) > 4096:
            raise ValueError('Source peer output too large')
        self.fd.write(data)
        self.fd.flush()
        return len(value)

    def flush(self):
        self.fd.flush()


def run_owned_disposable_peer(argv, transaction, *, line_timeout=5.0):
    """Own an *explicit test peer* for an internal transaction, reaping on all paths.

    This helper has no CLI entry point, no SSH trust assertion, no Btrfs callback,
    and cannot itself authorise deletion. A future trusted caller must be reviewed.
    """
    if (not isinstance(argv, (tuple, list)) or not argv or
            not all(isinstance(item, str) and item for item in argv) or
            not callable(transaction)):
        raise ValueError('Explicit peer argv and transaction required')
    child = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, start_new_session=True)
    try:
        result = transaction(BoundedLineReader(child.stdout.fileno(), line_timeout),
                             LineWriter(child.stdin))
        # Completion is never trusted while the peer is still alive or has failed.
        child.stdin.close()
        try:
            rc = child.wait(timeout=line_timeout)
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError('Source peer did not finish') from exc
        if rc != 0:
            raise RuntimeError(f'Source peer failed (exit={rc})')
        return result
    finally:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        for stream in (child.stdin, child.stdout):
            if stream and not stream.closed:
                stream.close()


def run_owned_gateway_transaction(argv, gateway, gateway_kwargs, *, line_timeout=5.0):
    """PRIVATE integration: keep one owned peer alive across a gateway transaction.

    This is not an SSH authentication check or deletion authorisation. The caller
    must validate endpoint identity, source lock/pin and privileged callback.
    """
    if not callable(gateway) or not isinstance(gateway_kwargs, dict):
        raise ValueError('Explicit gateway and keyword arguments required')
    reserved = {'incoming', 'outgoing'}
    if reserved.intersection(gateway_kwargs):
        raise ValueError('Gateway streams are exclusively owned by the peer')

    def invoke(incoming, outgoing):
        return gateway(incoming=incoming, outgoing=outgoing, **gateway_kwargs)

    return run_owned_disposable_peer(argv, invoke, line_timeout=line_timeout)
