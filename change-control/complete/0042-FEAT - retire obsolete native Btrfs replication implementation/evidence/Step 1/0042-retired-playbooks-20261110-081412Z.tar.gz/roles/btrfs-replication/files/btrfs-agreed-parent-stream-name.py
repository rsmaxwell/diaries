#!/usr/bin/env python3
"""Internal bounded first-command Btrfs send-stream name transformer.

Only the first SUBVOL/SNAPSHOT PATH TLV changes. The remaining stream bytes
are forwarded byte-for-byte in bounded chunks, without spool files.
This module does not authenticate the sender or authorise publication.
"""
import re
import struct

MAGIC = b'btrfs-stream\x00'
HEADER = struct.Struct('<IHI')
ATTRIBUTE = struct.Struct('<HH')
POLYNOMIAL = 0x82F63B78
STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
NONCE = re.compile(r'[0-9a-f]{64}\Z')
MAX_FIRST_COMMAND = 65536
CHUNK = 1024 * 1024

class Refused(RuntimeError):
    pass

def private_name(nonce):
    if type(nonce) is not str or NONCE.fullmatch(nonce) is None:
        raise Refused('invalid private receive nonce')
    return '.receive-' + nonce

def crc32c(data):
    value = 0
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (POLYNOMIAL if value & 1 else 0)
    return value & 0xffffffff

def _exact(source, length):
    data = bytearray()
    while len(data) < length:
        chunk = source.read(length - len(data))
        if not chunk:
            raise Refused('truncated initial Btrfs stream command')
        data.extend(chunk)
    return bytes(data)

def rewrite_first(source, stamp, nonce):
    """Read <=64KiB, check framing/checksum, return replacement first command.

    No data is passed to btrfs receive before this validation succeeds.
    The caller must forward the rest of source verbatim with forward_rest().
    """
    if type(stamp) is not str or STAMP.fullmatch(stamp) is None:
        raise Refused('invalid original Btrfs subvolume name')
    private = private_name(nonce).encode('ascii')
    prefix = _exact(source, len(MAGIC) + 4)
    if prefix[:len(MAGIC)] != MAGIC or struct.unpack('<I', prefix[len(MAGIC):])[0] not in (1, 2):
        raise Refused('unsupported Btrfs stream header')
    raw_header = _exact(source, HEADER.size)
    size, command, checksum = HEADER.unpack(raw_header)
    if command not in (1, 2) or size > MAX_FIRST_COMMAND:
        raise Refused('unexpected first Btrfs stream command')
    payload = _exact(source, size)
    if crc32c(HEADER.pack(size, command, 0) + payload) != checksum:
        raise Refused('invalid first Btrfs command checksum')
    offset = 0
    seen = False
    updated = bytearray()
    while offset < len(payload):
        if offset + ATTRIBUTE.size > len(payload):
            raise Refused('truncated Btrfs stream TLV')
        tag, n = ATTRIBUTE.unpack_from(payload, offset)
        offset += ATTRIBUTE.size
        if offset + n > len(payload):
            raise Refused('invalid Btrfs stream TLV size')
        value = payload[offset:offset+n]
        offset += n
        if tag == 15:
            if seen or value != stamp.encode('ascii'):
                raise Refused('unexpected or duplicate Btrfs stream path')
            seen = True
            value = private
        updated.extend(ATTRIBUTE.pack(tag, len(value)))
        updated.extend(value)
    if not seen or len(updated) > MAX_FIRST_COMMAND:
        raise Refused('missing Btrfs stream path or oversized rewrite')
    new_length = len(updated)
    new_checksum = crc32c(HEADER.pack(new_length, command, 0) + updated)
    return prefix + HEADER.pack(new_length, command, new_checksum) + updated

def forward_rest(source, output):
    """Forward without buffering the rest of potentially multi-terabyte stream."""
    while True:
        chunk = source.read(CHUNK)
        if not chunk:
            break
        output.write(chunk)
