#!/usr/bin/python3
"""0040 Step 12.3 Integration 04A: read-only prepared A->B transfer review.

No send, receive, state mutation, promotion, pruning or release. This is NOT
transfer authorisation. The transfer coordinator must repeat checks under locks.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/usr/local/libexec')
PUSH = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
STATE = Path('/media/usb/@snapshots/.agreed-parent.json')
AUTH = ('authorizes_prepare','authorizes_promote','authorizes_transfer','authorizes_prune','authorizes_release')

def load(name):
    path = ROOT / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('review_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def verify_prepared(source, reply, target, verified_parent, verified_target, validate):
    validate(source)
    if type(reply) is not dict or set(reply) != {'schema','receiver',*AUTH} or type(reply['schema']) is not int or reply['schema'] != 1:
        raise RuntimeError('invalid authenticated receiver observation')
    if any(reply[key] is not False for key in AUTH):
        raise RuntimeError('receiver unexpectedly claimed mutation authority')
    receiver = reply['receiver']
    validate(receiver)
    if source != receiver:
        raise RuntimeError('prepared source and receiver disagree')
    if source['previous'] is not None or source['pending'] is None:
        raise RuntimeError('both endpoints must be in prepared A/B state')
    parent = source['established']
    candidate = source['pending']
    if candidate != target or candidate['timestamp'] <= parent['timestamp']:
        raise RuntimeError('requested candidate is not the pending B')
    if verified_parent != dict(parent, verified=True) or verified_target != dict(candidate, verified=True):
        raise RuntimeError('Btrfs source identity/read-only validation failed')
    return {'schema':1, 'status':'prepared-transfer-review', 'mode':'incremental',
            'parent':parent, 'candidate':candidate, 'source':source, 'receiver':receiver,
            'state_changed':False, 'transfer_executed':False, 'release_executed':False,
            'authorizes_transfer':False, 'authorizes_promote':False,
            'authorizes_prune':False, 'authorizes_release':False}

def review(timestamp, *, deps=None):
    d = deps if deps is not None else {name:load(name) for name in (
        'locked-get-state','state','source-evidence','transfer-plan','get-state-transport')}
    with ExitStack() as stack:
        d['locked-get-state'].acquire(stack, PUSH)
        d['locked-get-state'].acquire(stack, MANAGER)
        source = d['state'].load(STATE, require_root=True)
        d['state'].validate(source)
        if source['pending'] is None or source['previous'] is not None:
            raise RuntimeError('source is not prepared for transfer')
        target = d['transfer-plan'].target_identity(timestamp)
        parent = d['source-evidence'].verify_source(source['established'])
        candidate = d['source-evidence'].verify_source(target)
        reply = d['get-state-transport'].get_state(timestamp, source_lock_held=True)
        return verify_prepared(source, reply, target, parent, candidate, d['state'].validate)

def main():
    parser=argparse.ArgumentParser(description='Read-only prepared A->B transfer review, no transfer')
    parser.add_argument('--target', required=True)
    parser.add_argument('--review-only', action='store_true', required=True)
    args=parser.parse_args()
    if os.geteuid()!=0: raise RuntimeError('root required')
    print(json.dumps(review(args.target), sort_keys=True))

if __name__=='__main__':
    try: main()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        print('prepared-transfer review refused: '+str(exc), file=sys.stderr)
        raise SystemExit(1)
