#!/usr/bin/python3
"""0040 Step 12.3 / 04T: dormant Unix-domain peer credential verifier.

This module verifies a local AF_UNIX SOCK_STREAM peer using Linux SO_PEERCRED.
It deliberately DOES NOT authenticate an SSH connection, create listeners,
construct the 04Q TransportProof, register transfer channels or authorize IO.
Only a future privileged process may associate a verified local peer with a
trusted, independently authenticated SSH command/session.
"""
import os
import socket
import struct
from dataclasses import dataclass


class LocalPeerRefused(RuntimeError):
    pass


@dataclass(frozen=True)
class LocalPeer:
    pid: int
    uid: int
    gid: int


def verify_local_peer(connection, *, expected_uid, expected_gid=None):
    """Verify kernel-reported credentials, not data supplied by the peer."""
    if type(expected_uid) is not int or expected_uid < 0:
        raise LocalPeerRefused('expected uid required')
    if expected_gid is not None and (type(expected_gid) is not int or expected_gid < 0):
        raise LocalPeerRefused('invalid expected gid')
    if not isinstance(connection, socket.socket):
        raise LocalPeerRefused('kernel-backed socket required')
    if connection.family != socket.AF_UNIX or connection.type & socket.SOCK_STREAM != socket.SOCK_STREAM:
        raise LocalPeerRefused('Unix stream socket required')
    if not hasattr(socket, 'SO_PEERCRED'):
        raise LocalPeerRefused('SO_PEERCRED unavailable')
    try:
        raw = connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize('3i'))
        if len(raw) != struct.calcsize('3i'):
            raise LocalPeerRefused('invalid kernel credential size')
        pid, uid, gid = struct.unpack('3i', raw)
    except OSError as exc:
        raise LocalPeerRefused('cannot read kernel peer credentials') from exc
    if pid <= 0 or uid != expected_uid or (expected_gid is not None and gid != expected_gid):
        raise LocalPeerRefused('unexpected local peer identity')
    return LocalPeer(pid=pid, uid=uid, gid=gid)


def review_current_process_peer():
    """Offline diagnostic only: socketpair proves kernel peer credential support."""
    left, right = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        return verify_local_peer(left, expected_uid=os.geteuid(), expected_gid=os.getegid())
    finally:
        left.close()
        right.close()
