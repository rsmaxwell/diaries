#!/usr/bin/python3
"""0040 3H.5j: locked, read-only preflight for receiver prepare.

This executable NEVER sends a prepare request and NEVER modifies state. The
output is a proposed request, not authorisation to execute it. The operation
must be integrated separately with a privileged receiver endpoint.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/usr/local/libexec')
STATE_PATH = Path('/media/usb/@snapshots/.agreed-parent.json')
PUSH_LOCK = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')


def load(name):
    path = ROOT / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('preflight_' + name.replace('-', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def evaluate(source, receiver, candidate, verified, *, validate):
    """Pure decision; verified is a locally produced identity, not an authority flag."""
    validate(source)
    validate(receiver)
    if source != receiver or source['pending'] is not None or source['previous'] is not None:
        raise RuntimeError('endpoints not at the same quiescent agreed parent')
    if not isinstance(candidate, dict) or set(candidate) != {'timestamp', 'uuid'}:
        raise RuntimeError('invalid candidate')
    if verified != dict(candidate, verified=True):
        raise RuntimeError('candidate not independently verified')
    if candidate['timestamp'] <= source['established']['timestamp']:
        raise RuntimeError('candidate does not follow established parent')
    request = {'schema': 1, 'operation': 'prepare', 'transaction_id': candidate['timestamp'],
               'expected_before': receiver, 'candidate': candidate}
    return {'schema': 1, 'status': 'ready-for-independent-review', 'request': request,
            'authorizes_prepare': False, 'authorizes_source_prepare': False,
            'authorizes_transfer': False, 'authorizes_promote': False,
            'authorizes_prune': False, 'authorizes_release': False}


def inspect(timestamp, *, modules=None):
    """Acquire both real source locks, inspect local Btrfs, query receiver only."""
    locked, state, evidence, transport = modules or (
        load('locked-get-state'), load('state'), load('source-evidence'), load('get-state-transport'))
    with ExitStack() as stack:
        locked.acquire(stack, PUSH_LOCK)
        locked.acquire(stack, MANAGER_LOCK)
        source = state.load(STATE_PATH, require_root=True)
        state.validate(source)
        if source['pending'] is not None or source['previous'] is not None:
            raise RuntimeError('source transition in progress')
        # The candidate identity must come from Btrfs, not user JSON.
        target_module = load('transfer-plan')
        candidate = target_module.target_identity(timestamp)
        verified = evidence.verify_source(candidate)
        reply = transport.get_state(timestamp, source_lock_held=True)
        for field in ('authorizes_prepare', 'authorizes_promote', 'authorizes_transfer',
                      'authorizes_prune', 'authorizes_release'):
            if reply.get(field) is not False:
                raise RuntimeError('receiver observation claimed authority')
        return evaluate(source, reply['receiver'], candidate, verified, validate=state.validate)


def main():
    parser = argparse.ArgumentParser(description='Read-only receiver-prepare preflight')
    parser.add_argument('--target', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(inspect(args.target), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError) as exc:
        print('receiver prepare preflight refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
