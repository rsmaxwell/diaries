#!/usr/bin/env python3
"""Read-only regression for the 0040 Step 3 production deletion boundary.

This deliberately does not exercise or authorise deletion. Run on the Playbooks
source tree before and after each change to the proposed production entry point.
"""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = ROOT / 'files'
TEMPLATES = ROOT / 'templates'


def check(condition, message):
    if not condition:
        raise AssertionError(message)
    print('PASS: ' + message)


def parsed(name):
    return ast.parse((FILES / name).read_text(encoding='utf-8'))


def function(tree, name):
    return next(node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name)


receiver = parsed('btrfs-native-push-receiver.py')
manager = parsed('btrfs-native-endpoint.py')
receiver_main = function(receiver, 'main')
receiver_main_text = ast.unparse(receiver_main)
check('run_approved_manager_bound_transaction' not in receiver_main_text,
      'receiver public main does not invoke internal approved deletion')
check('run_manager_bound_transaction' not in receiver_main_text,
      'receiver public main does not invoke internal manager transaction')
check('run_approved_manager_bound_transaction' in {n.name for n in receiver.body if isinstance(n, ast.FunctionDef)},
      'approved transaction exists only as internal adapter')
check("LOCK.open('r+')" in receiver_main_text,
      'receiver public main owns writer lock; nesting manager-first locks is not approved')
endpoint_main = ast.unparse(function(manager, 'main'))
check("'delete-receiver'" in endpoint_main,
      'privileged endpoint implements journal-constrained delete-receiver')
sudoers = (TEMPLATES / 'btrfs-native-sudoers.j2').read_text(encoding='utf-8')
check('btrfs_native_enable_receiver_delete_endpoint | default(false) | bool' in sudoers and
      "btrfs_native_endpoint_role == 'receiver'" in sudoers and
      '--role delete-receiver --snapshot *' in sudoers,
      'receiver deletion sudoers requires explicit receiver-only default-off opt-in')
for name in ('btrfs-receiver-manager.json.j2', 'btrfs-receiver-retention.json.j2'):
    config = (TEMPLATES / name).read_text(encoding='utf-8')
    check('"receiver_prune_enabled": false' in config,
          name + ' keeps production pruning disabled')
print('PASS: fail-closed production privilege boundary (read-only source check)')
