# 0040 Step 3 — Controlled endpoint exposure (not pruning authorisation)

- Commit baseline: `d01a80b`.
- Changes sudoers template **only** behind `btrfs_native_enable_receiver_delete_endpoint | default(false) | bool`, constrained to `btrfs_native_endpoint_role == receiver`.
- This is a privileged **deletion primitive** requiring an existing matching pending transaction journal and Btrfs UUID/receipt checks; it does **not** establish a source-held authenticated approval, reserve a single-use token, or create a journal. It is NOT a completed approved pruning workflow.
- Production `receiver_prune_enabled` remains `false`. Historical holds and datasets must not be altered to test exposure.
- Review with Ansible `--check --diff` before explicitly opting in for the receiver; validate exact sudoers diff and source regression. Do not enable as a long-term unattended bypass.
- Rollback: omit or set `btrfs_native_enable_receiver_delete_endpoint: false` in the corresponding host override and reapply the existing role; verify sudoers no longer permits `delete-receiver`.
- Approval and cross-host end-to-end deletion remain OUTSTANDING.
