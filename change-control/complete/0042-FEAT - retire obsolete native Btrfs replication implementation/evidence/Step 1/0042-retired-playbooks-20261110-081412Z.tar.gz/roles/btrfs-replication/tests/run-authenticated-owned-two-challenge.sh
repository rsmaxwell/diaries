#!/usr/bin/env bash
# Run in mango terminal, transmit the current accepted source without installing it on mars.
set -euo pipefail
cd /home/richard/playbooks
python3 - <<'PY2' | ssh mars 'python3 -'
import base64, pathlib
root=pathlib.Path('roles/btrfs-replication')
helper=(root/'files/btrfs-owned-session.py').read_bytes()
test=(root/'tests/verify-authenticated-owned-two-challenge.py').read_bytes()
# The remote interpreter consumes the program on stdin, so embed helper as a
# literal base64 line in a temporary in-memory composite program instead.
encoded=base64.b64encode(helper).decode()
program=test.decode().replace('sys.stdin.readline().strip(),validate=True', repr(encoded)+',validate=True')
print(program)
PY2
