#!/usr/bin/python3
"""0040 Step 12.3 / 04O: dormant A/B SSH execution identity and session lifecycle.

Only validates/plans. No subprocess invocation, receive, receipt, SSH connection,
or authorization. A session ID does not authenticate independent SSH channels.
"""
import re
import secrets

class SessionRefused(RuntimeError):
    pass

SSH = ('/usr/sbin/runuser','-u','richard','--','ssh',
       '-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
       '-o','ConnectTimeout=15','-p','39263','richard@10.254.22.1')


def identity(item):
    if (type(item) is not dict or set(item) != {'timestamp','uuid'} or
        type(item['timestamp']) is not str or
        re.fullmatch(r'[0-9]{8}-[0-9]{6}Z', item['timestamp']) is None or
        type(item['uuid']) is not str or
        re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', item['uuid']) is None):
        raise SessionRefused('invalid exact snapshot identity')
    return dict(item)


def argv_pair(parent, candidate, *, data_endpoint, control_endpoint):
    """Construct equal SSH identity prefixes for independently reviewed remote CLIs.

    Exact remote allowlisting is mandatory here; arbitrary commands are refused.
    This only plans two commands, not proof of SSH authentication/session binding.
    """
    a=identity(parent); b=identity(candidate)
    if a['timestamp'] >= b['timestamp']:
        raise SessionRefused('invalid snapshot order')
    approved = {
        'data': '/usr/local/libexec/btrfs-agreed-parent-receive-data-session.py',
        'control': '/usr/local/libexec/btrfs-agreed-parent-receive-control-session.py',
    }
    if data_endpoint != approved['data'] or control_endpoint != approved['control']:
        raise SessionRefused('remote endpoints not approved or not yet implemented')
    args=('--parent',a['timestamp'],'--parent-uuid',a['uuid'],
          '--candidate',b['timestamp'],'--candidate-uuid',b['uuid'])
    return {'data': (*SSH,'sudo','-n',data_endpoint,*args),
            'control': (*SSH,'sudo','-n',control_endpoint,*args)}


class Lifecycle:
    """Single-use coordination record. Inputs are independent attestations.

    No Boolean attestation is inferred from command construction. The caller
    must obtain authenticated transport and lock evidence from real runtime.
    """
    def __init__(self,parent,candidate,*,token=None):
        self.parent=identity(parent);self.candidate=identity(candidate)
        if self.parent['timestamp'] >= self.candidate['timestamp']:
            raise SessionRefused('invalid order')
        self.token=secrets.token_hex(32) if token is None else token
        if type(self.token) is not str or re.fullmatch('[0-9a-f]{64}',self.token) is None:
            raise SessionRefused('invalid session token')
        self.phase='created'

    def start(self,*,source_lock=False,receiver_locks=False,data_authenticated=False,
              control_authenticated=False,peer_binding_verified=False,deadline_active=False):
        if self.phase!='created':
            self.phase='failed';raise SessionRefused('session not single use')
        if not all(v is True for v in (source_lock,receiver_locks,data_authenticated,
                     control_authenticated,peer_binding_verified,deadline_active)):
            self.phase='failed';raise SessionRefused('missing external session proof')
        self.phase='active'

    def complete(self,*,sender_rc=None,receiver_rc=None,stream_verified=False,
                 challenge_consumed=False,receiver_locks=False,receipt_committed=False):
        if self.phase!='active':
            self.phase='failed';raise SessionRefused('session not active')
        if (type(sender_rc) is not int or sender_rc != 0 or
            type(receiver_rc) is not int or receiver_rc != 0 or
            any(v is not True for v in (stream_verified,challenge_consumed,
                                     receiver_locks,receipt_committed))):
            self.phase='failed';raise SessionRefused('incomplete or failed transfer evidence')
        self.phase='completed'
        return {'schema':1,'status':'session-evidence-complete',
                'parent':dict(self.parent),'candidate':dict(self.candidate),
                'session_token':self.token,'authorizes_promote':False,
                'authorizes_prune':False,'authorizes_release':False}

    def fail(self):
        self.phase='failed'
