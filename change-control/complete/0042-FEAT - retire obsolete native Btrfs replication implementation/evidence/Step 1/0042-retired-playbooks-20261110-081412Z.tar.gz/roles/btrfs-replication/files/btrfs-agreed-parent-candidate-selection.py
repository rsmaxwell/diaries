#!/usr/bin/env python3
"""Read-only, conservative eligible-candidate discovery on the source host.

The preparation checkpoint, not this selector, authorises the actual transaction.
"""
import re
import subprocess
from pathlib import Path

STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
UUID = re.compile(r'^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$')
ROOT = Path('/media/usb/@snapshots/@data')

class CandidateRefused(RuntimeError):
    pass


def select_candidate(parent, *, root=ROOT, show=None):
    """Return newest readonly snapshot newer than parent, or None if none exists.

    Fail closed on a malformed or non-subvolume timestamp entry. Never follow
    symlinks. Caller must serialize selection and preparation under source locks.
    """
    if not isinstance(parent, str) or not STAMP.fullmatch(parent):
        raise CandidateRefused('invalid established parent timestamp')
    if show is None:
        def show(path):
            result = subprocess.run(['btrfs', 'subvolume', 'show', str(path)],
                                    capture_output=True, text=True, check=False)
            if result.returncode:
                raise CandidateRefused('Btrfs identity inspection failed')
            return result.stdout
    if not root.is_dir() or root.is_symlink():
        raise CandidateRefused('snapshot root unavailable or unsafe')
    candidates = []
    for path in root.iterdir():
        name = path.name
        if not STAMP.fullmatch(name) or name <= parent:
            continue
        if path.is_symlink() or not path.is_dir():
            raise CandidateRefused('unsafe candidate entry: ' + name)
        output = show(path)
        fields = {}
        for line in output.splitlines():
            if ':' in line:
                key, value = line.split(':', 1)
                fields[key.strip()] = value.strip()
        if (fields.get('Name') != name or
                not UUID.fullmatch(fields.get('UUID', '')) or
                fields.get('Flags') != 'readonly' or
                fields.get('Received UUID') != '-'):
            raise CandidateRefused('invalid local snapshot identity: ' + name)
        candidates.append({'timestamp': name, 'uuid': fields['UUID']})
    return max(candidates, key=lambda item: item['timestamp']) if candidates else None
