#!/usr/bin/env python3
"""0040 Step 12.3: durable, fail-closed receiver provisional transfer reservation.

Not wired to live Btrfs receive. Never removes or finalises a journal.
Caller MUST hold manager then writer locks while reserving, before receiving B.
"""
import json
import os
from pathlib import Path
import re
import stat
import secrets

NAME = '.agreed-parent-transfer-pending.json'
STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
BOOT_ID_PATH = Path('/proc/sys/kernel/random/boot_id')

def local_boot_id(reader=None):
    raw = BOOT_ID_PATH.read_text() if reader is None else reader()
    if type(raw) is not str or not UUID.fullmatch(raw.strip()):
        raise Refused('invalid receiver boot identity')
    return raw.strip()

def assess_previous_boot(journal, *, current_boot_id=None):
    """Evidence only: proves a former boot cannot retain Linux tasks.

    Does not prove destination ownership or authorise deletion/retransmission.
    """
    if type(journal) is not dict or journal.get('scope_binding') != 'reserved-not-termination-evidence':
        raise Refused('missing scoped journal identity')
    recorded = journal.get('receiver_boot_id')
    if type(recorded) is not str or not UUID.fullmatch(recorded):
        raise Refused('missing or invalid recorded boot identity')
    current = local_boot_id() if current_boot_id is None else current_boot_id
    if type(current) is not str or not UUID.fullmatch(current):
        raise Refused('invalid current receiver boot identity')
    return {'schema': 1, 'recorded_boot_id': recorded, 'current_boot_id': current,
            'old_boot_terminated': recorded != current,
            'classification': 'previous-boot' if recorded != current else 'same-boot',
            'cleanup_authorized': False, 'retransmit_authorized': False,
            'destination_ownership_proven': False}


class Refused(RuntimeError):
    pass

def reserve(state_dir, parent, candidate, *, manager_lock_held=False, writer_lock_held=False, scoped=False, boot_id_reader=None):
    if manager_lock_held is not True or writer_lock_held is not True:
        raise Refused('both receiver locks required')
    if type(parent) is not dict or type(candidate) is not dict:
        raise Refused('invalid A/B identities')
    for item in (parent, candidate):
        if set(item) != {'timestamp', 'uuid'} or type(item['timestamp']) is not str or type(item['uuid']) is not str or not STAMP.fullmatch(item['timestamp']) or not UUID.fullmatch(item['uuid']):
            raise Refused('invalid A/B identity')
    if parent['timestamp'] >= candidate['timestamp']:
        raise Refused('non-incremental candidate')
    directory = Path(state_dir)
    if not directory.is_absolute() or directory.is_symlink() or not directory.is_dir():
        raise Refused('unsafe state directory')
    path = directory / NAME
    # Existing journal (even malformed or symlink) is a hard stop. Never repair automatically.
    if path.exists() or path.is_symlink():
        raise Refused('pending transfer already exists')
    nonce = secrets.token_hex(32)
    if type(scoped) is not bool:
        raise Refused('invalid scoped reservation mode')
    data = {'schema': 1, 'status': 'receiving', 'parent': parent, 'candidate': candidate,
            'nonce': nonce}
    if scoped:
        # Scope name is unique per reservation; the journal is durable before launch.
        data['scope_unit'] = 'btrfs-agreed-receive-' + candidate['timestamp'] + '-' + nonce[:16] + '.scope'
        data['scope_binding'] = 'reserved-not-termination-evidence'
        data['receiver_boot_id'] = local_boot_id(boot_id_reader)
    payload = (json.dumps(data, sort_keys=True) + '\n').encode('utf-8')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as output:
            output.write(payload)
            output.flush()
            os.fsync(output.fileno())
        dirfd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(dirfd)
        finally: os.close(dirfd)
    except BaseException:
        # Deliberately retain any created journal on failure: recovery is manual.
        raise
    return path


def bind_staging(path, candidate, nonce, identity, *, manager_lock_held=False,
                 writer_lock_held=False):
    """Durably bind one reserved directory before streaming; never repair/rebind.

    Recovery of an unbound journal remains manual and no stream may start.
    The caller must retain both canonical locks throughout reservation/binding.
    """
    if manager_lock_held is not True or writer_lock_held is not True:
        raise Refused('receiver locks required')
    path = Path(path)
    if path.name != NAME or path.is_symlink() or not path.is_file():
        raise Refused('noncanonical journal')
    with path.open('r') as source:
        journal = json.load(source)
    if (type(journal) is not dict or journal.get('status') != 'receiving' or
            journal.get('nonce') != nonce or journal.get('candidate') != candidate or
            'staging' in journal):
        raise Refused('journal already bound or changed')
    if (type(identity) is not dict or
            type(identity.get('directory_dev')) is not int or
            type(identity.get('directory_ino')) is not int or
            identity['directory_dev'] < 0 or identity['directory_ino'] <= 0):
        raise Refused('invalid filesystem identity')
    journal['staging'] = {'directory_dev': identity['directory_dev'],
                          'directory_ino': identity['directory_ino']}
    payload = (json.dumps(journal, sort_keys=True) + '\n').encode()
    tmp = path.with_name(path.name + '.binding-' + nonce)
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as sink:
            sink.write(payload)
            sink.flush()
            os.fsync(sink.fileno())
        # Validate original identity again immediately before replacement.
        with path.open('r') as original:
            if json.load(original) != {k: v for k, v in journal.items() if k != 'staging'}:
                raise Refused('journal changed before staging binding')
        os.replace(tmp, path)
        dfd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except BaseException:
        # A leftover temporary binding is an incident, not retry permission.
        raise
    return path


def record_publication_witness(path, parent, candidate, nonce, witness, *,
                               manager_lock_held=False, writer_lock_held=False):
    """Persist received-subvolume identity before no-overwrite publication.

    A crash leaves a distinguishable pre-publication intent. Never repair or
    remove a journal automatically; a witnessed-but-unpublished stage still
    needs independent readback and explicit reconciliation.
    """
    if manager_lock_held is not True or writer_lock_held is not True:
        raise Refused('both receiver locks required')
    path = Path(path)
    if path.name != NAME or path.is_symlink() or not path.is_file():
        raise Refused('noncanonical provisional journal')
    metadata = path.lstat()
    if metadata.st_uid != 0 or stat.S_IMODE(metadata.st_mode) != 0o600:
        raise Refused('unsafe provisional journal')
    with path.open() as stream:
        existing = json.load(stream)
    if (type(existing) is not dict or existing.get('schema') != 1 or
            existing.get('status') != 'receiving' or
            existing.get('parent') != parent or existing.get('candidate') != candidate or
            existing.get('nonce') != nonce or
            set(existing) != {'schema', 'status', 'parent', 'candidate', 'nonce',
                              'scope_unit', 'scope_binding', 'receiver_boot_id', 'staging'} or
            type(existing['staging']) is not dict or
            set(existing['staging']) != {'directory_dev', 'directory_ino'}):
        raise Refused('staged journal changed or already witnessed')
    if (type(witness) is not dict or set(witness) != {'subvolume_uuid', 'received_uuid'} or
            type(witness['subvolume_uuid']) is not str or
            type(witness['received_uuid']) is not str or
            not UUID.fullmatch(witness['subvolume_uuid']) or
            witness['received_uuid'] != candidate['uuid']):
        raise Refused('unsafe publication witness')
    updated = dict(existing, publication_witness=dict(witness))
    tmp = path.with_name(path.name + '.witness-' + nonce)
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as sink:
            sink.write((json.dumps(updated, sort_keys=True) + '\n').encode())
            sink.flush()
            os.fsync(sink.fileno())
        with path.open() as stream:
            if json.load(stream) != existing:
                raise Refused('provisional journal changed before witness persistence')
        os.replace(tmp, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    except BaseException:
        # Never clean uncertain temporary evidence automatically.
        raise
    return path
