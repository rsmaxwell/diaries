#!/usr/bin/env python3
"""Disposable lock/approval binding regression; never touches production Btrfs."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

source = Path(__file__).resolve().parents[1] / 'files/btrfs-native-push-receiver.py'
spec = importlib.util.spec_from_file_location('native_receiver_approval_binding', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

STAMP = '20261024-030038Z'
CANDIDATE = '20261012-100003Z'
UUID = '22e0ca45-0f49-c745-85b0-af6b6cfb915c'

def reject(action):
    try:
        action()
    except (RuntimeError, ValueError, OSError):
        return
    raise AssertionError('Expected refusal')

with tempfile.TemporaryDirectory(prefix='0040-receiver-approval-') as td:
    root = Path(td)
    state = root / 'state'; state.mkdir()
    consumed = state / 'consumed'; consumed.mkdir()
    manager_lock = root / 'manager.lock'; manager_lock.touch()
    writer_lock = state / 'writer.lock'; writer_lock.touch()
    approval = root / 'approval.json'
    approval.write_text(json.dumps({
        'schema': 1, 'operation': 'receiver-prune-one',
        'candidate': CANDIDATE, 'protected_parent': STAMP,
        'protected_parent_uuid': UUID,
        'expires_at_utc': (datetime.now(timezone.utc) + timedelta(minutes=25)).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'reason': 'Disposable test fixture only',
    }))
    approval.chmod(0o600)
    config = SimpleNamespace(mode='receiver', receiver_prune_enabled=False,
        receiver_state_dir=state, writer_lock_path=writer_lock, lock_path=manager_lock)
    calls = []
    def interrupted(*args, **kwargs):
        calls.append('session')
        raise RuntimeError('simulated SSH disconnection before deletion journal')
    def invoke(**overrides):
        kw = dict(manager=object(), config=config, incoming=None, outgoing=None,
                  planner=None, delete_subvolume=lambda path: (_ for _ in ()).throw(
                      AssertionError('Unexpected Btrfs delete')),
                  approval_path=approval, consumed_dir=consumed,
                  transaction_runner=interrupted)
        kw.update(overrides)
        return module.run_approved_manager_bound_transaction(STAMP, UUID, CANDIDATE, **kw)
    # fail closed without root-owned approval; no reservation or transaction
    if os.geteuid() != 0:
        reject(invoke)
        assert not calls and not list(consumed.iterdir())
        print('PASS: unprivileged approval rejected; no reservation or deletion')
    else:
        reject(invoke)
        markers = list(consumed.glob('*.json'))
        assert len(markers) == 1 and calls == ['session']
        assert json.loads(markers[0].read_text())['state'] == 'reserved-not-authorised'
        reject(invoke)  # exact same approval is now consumed
        assert calls == ['session']
        # An existing recovery journal blocks even a distinct approval.
        (state / '.receiver-prune-pending.json').write_text('{}')
        reject(invoke)
        assert len(list(consumed.glob('*.json'))) == 1
        print('PASS: lock-held reservation persists interruption; replay and journal reject; no deletion')
