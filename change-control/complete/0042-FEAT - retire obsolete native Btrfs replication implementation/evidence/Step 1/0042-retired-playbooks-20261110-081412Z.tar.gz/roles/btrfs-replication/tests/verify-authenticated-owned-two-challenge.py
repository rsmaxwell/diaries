#!/usr/bin/env python3
"""0040 isolated authenticated SSH + owned gateway, two challenges and abort.

Runs unprivileged on mars, streamed from mango. No production locks/receipts
or snapshot operations. The remote command is fixed and non-destructive.
"""
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import secrets
import shlex
import sys
import tempfile

PORT = '39263'
HOST = 'richard@10.254.22.1'
# Remote interpreter implements only a two-challenge echo. It never invokes sudo.
REMOTE_CODE = '''import json,sys
for i in range(2):
    line = sys.stdin.readline()
    if not line: sys.exit(9)
    req = json.loads(line)
    if req.get('kind') != '0040-test-challenge' or req.get('sequence') != i:
        sys.exit(8)
    print(json.dumps({'kind':'0040-test-response','sequence':i,
                      'nonce':req['nonce']}),flush=True)
'''
SSH = ['ssh','-T','-p',PORT,'-o','BatchMode=yes',
       '-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=10',
       '-o','ConnectionAttempts=1','-o','ClearAllForwardings=yes',
       '-o','RequestTTY=no',HOST,'python3 -u -c '+shlex.quote(REMOTE_CODE)]

def load_owned():
    # The archived operational helper is streamed via a second payload from
    # mango. No stale copy of it is installed on mars.
    import base64
    payload = base64.b64decode(sys.stdin.readline().strip(),validate=True).decode('utf-8')
    if not payload.startswith('#!/usr/bin/env python3'):
        raise RuntimeError('Invalid owned helper payload')
    import types
    mod = types.ModuleType('owned_peer')
    exec(compile(payload,'btrfs-owned-session.py','exec'),mod.__dict__)
    return mod

def main():
    if os.geteuid() == 0:
        raise RuntimeError('Unprivileged mars execution required')
    owned = load_owned()
    with tempfile.TemporaryDirectory(prefix='0040-auth-owned-') as directory:
        root = Path(directory)
        with (root/'source.lock').open('w+') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            pin = root/'pin.json'
            token = secrets.token_hex(24)
            pin.write_text(json.dumps({'fixture_token':token}))
            def challenge(*, incoming, outgoing, expected):
                nonces = set()
                for sequence in range(2):
                    assert json.loads(pin.read_text())['fixture_token'] == expected
                    nonce = secrets.token_hex(32)
                    assert nonce not in nonces
                    nonces.add(nonce)
                    outgoing.write(json.dumps({'kind':'0040-test-challenge',
                                     'sequence':sequence,'nonce':nonce})+'\n')
                    outgoing.flush()
                    response = json.loads(incoming.readline(4096))
                    if response != {'kind':'0040-test-response',
                                     'sequence':sequence,'nonce':nonce}:
                        raise RuntimeError('Wrong authenticated challenge response')
                return 'challenged'
            result = owned.run_owned_gateway_transaction(SSH,challenge,
                          {'expected':token},line_timeout=15)
            assert result == 'challenged'
            assert json.loads(pin.read_text())['fixture_token']==token
            print('PASS: two fresh challenges over one authenticated owned SSH session')
            print('PASS: source fixture lock and durable pin survived entire exchange')
            try:
                def interrupt(*,incoming,outgoing):
                    outgoing.write(json.dumps({'kind':'0040-test-challenge',
                                       'sequence':0,'nonce':secrets.token_hex(32)})+'\n')
                    outgoing.flush()
                    assert incoming.readline(4096)
                    raise RuntimeError('deliberate interruption')
                owned.run_owned_gateway_transaction(SSH,interrupt,{},line_timeout=15)
            except RuntimeError as exc:
                assert str(exc) == 'deliberate interruption',str(exc)
            else:
                raise AssertionError('interrupted exchange reported success')
            assert json.loads(pin.read_text())['fixture_token']==token
            print('PASS: interrupted authenticated session fails closed; fixture pin remains')
            print('LIMIT: does not prove remote PID reaping or production lock/journal/deletion')

if __name__ == '__main__':
    try: main()
    except Exception as exc:
        print(f'FAIL: {type(exc).__name__}: {exc}',file=sys.stderr)
        raise
