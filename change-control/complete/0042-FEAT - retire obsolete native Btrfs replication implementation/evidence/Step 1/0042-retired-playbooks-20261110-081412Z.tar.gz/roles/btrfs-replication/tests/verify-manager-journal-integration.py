#!/usr/bin/env python3
"""0040 Stage 2: test real receiver journal/receipt transaction with isolated paths.

Only Btrfs inventory and subvolume kernel operations are substituted; the real
receiver_delete_one_locked and durable journal functions are executed unchanged.
No production config, Btrfs snapshots, SSH, or approvals are accessed.
"""
import importlib.util
import json
from pathlib import Path
import tempfile
from datetime import datetime, timezone
from unittest.mock import patch
import uuid

MANAGER = Path(__file__).resolve().parents[2] / 'snapshots/files/btrfs-snapshot-manager.py'
spec = importlib.util.spec_from_file_location('step03_receiver_manager', MANAGER)
manager = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = manager
spec.loader.exec_module(manager)

CANDIDATE = '20261020-010000Z'
PARENT = '20261021-010000Z'
NEWEST = '20261022-010000Z'
STAMPS = (CANDIDATE, PARENT, NEWEST)

def scenario(interrupt):
    with tempfile.TemporaryDirectory(prefix='0040-journal-') as tmp:
        root = Path(tmp)
        received = root / 'received'
        state = root / 'state'
        received.mkdir(); state.mkdir()
        (state / 'writer.lock').touch()
        uuids = {stamp: str(uuid.uuid4()) for stamp in STAMPS}
        for stamp in STAMPS:
            (received / stamp).mkdir()
            receipt = {'schema':1,'snapshot':stamp,'source_uuid':uuids[stamp],
                       'received_uuid':uuids[stamp], 'destination':str(received / stamp),
                       'read_only_verified':True}
            (state / (stamp + '.json')).write_text(json.dumps(receipt))
        config = manager.Config(
            snapshot_root=root, lock_path=root/'manager.lock',
            writer_lock_path=state/'writer.lock',
            sources=(manager.SnapshotSource('mars',None,received),),
            retention=manager.RetentionPolicy(0,0,0,0,0,0),
            verification=manager.VerificationPolicy(False,'','','',None),
            checkpoint_holds_required=True,
            mode='receiver',receiver_state_dir=state,receiver_prune_enabled=False)
        entries = [(stamp,datetime.strptime(stamp,manager.TIMESTAMP_FORMAT).replace(tzinfo=timezone.utc),received/stamp)
                   for stamp in reversed(STAMPS)]
        invoked=[]
        def verify():
            invoked.append('pin')
        def delete(path):
            assert path == received/CANDIDATE
            assert (state/'.receiver-prune-pending.json').is_file(), 'journal must precede deletion'
            invoked.append('delete')
            if interrupt:
                raise RuntimeError('injected interruption after durable journal')
            path.rmdir()
        patches = [
            patch.object(manager,'receiver_inventory',return_value=entries),
            patch.object(manager,'retention_keep_set',return_value=set()),
            patch.object(manager,'receiver_verified_checkpoint_holds',return_value={PARENT}),
            patch.object(manager,'validate_prune_candidate',return_value=None),
            patch.object(manager,'native_prune_subvolume_id',return_value=12345),
            patch.object(manager,'run',side_effect=lambda cmd, **kwargs: type('R',(),{'stdout':('Received UUID: '+uuids[CANDIDATE]+'\n') if 'show' in cmd else 'ro=true\n'})()),
        ]
        from contextlib import ExitStack
        with ExitStack() as stack:
            for p in patches: stack.enter_context(p)
            if interrupt:
                try:
                    manager.receiver_delete_one_locked(config,CANDIDATE,
                        protected_stamp=PARENT,expected_parent_uuid=uuids[PARENT],
                        verify_source_pin=verify, delete_subvolume=delete)
                except RuntimeError as exc:
                    assert str(exc).startswith('injected interruption')
                else: raise AssertionError('interruption unexpectedly accepted')
                assert (state/'.receiver-prune-pending.json').is_file()
                assert (state/(CANDIDATE+'.json')).is_file()
                assert (received/CANDIDATE).exists()
                assert manager.receiver_recovery_plan(config)['state']=='BEFORE_DELETE'
                try:
                    manager.receiver_delete_one_locked(config,CANDIDATE,
                        protected_stamp=PARENT,expected_parent_uuid=uuids[PARENT],
                        verify_source_pin=verify,delete_subvolume=delete)
                except manager.SnapshotError as exc:
                    assert 'pending transaction' in str(exc)
                else: raise AssertionError('pending journal allowed replay')
                print('PASS: interrupted deletion leaves journal and receipt; recovery operator-gated and replay rejected')
            else:
                manager.receiver_delete_one_locked(config,CANDIDATE,
                    protected_stamp=PARENT,expected_parent_uuid=uuids[PARENT],
                    verify_source_pin=verify,delete_subvolume=delete)
                assert not (state/'.receiver-prune-pending.json').exists()
                assert not (state/(CANDIDATE+'.json')).exists()
                assert not (received/CANDIDATE).exists()
                assert manager.receiver_recovery_plan(config)['state']=='CLEAN'
                print('PASS: isolated manager journal written before deletion, receipt removed and journal CLEAN')
        assert invoked == ['pin','delete']
        for stamp in (PARENT,NEWEST):
            assert (received/stamp).is_dir() and (state/(stamp+'.json')).is_file()
        print('PASS: protected parent and newest receipt/snapshot remain intact')

scenario(False)
scenario(True)
print('LIMIT: Btrfs operations, live source lock, SSH channel, approval reservation and production authority NOT exercised')
