#!/usr/bin/python3
"""0040 3H.5d: dormant receiver prepare/uncertain-outcome adapter.

No SSH, Btrfs, source-state writes, or retry. The caller must supply trusted
locked source/receiver observations and an authenticated fixed-endpoint transport.
This adapter never authorises local source preparation or release.
"""
import importlib.util
import json
from pathlib import Path


def load_orchestrator():
    path = Path(__file__).resolve().parents[2] / 'snapshots/files/btrfs-agreed-parent-orchestrator.py'
    spec = importlib.util.spec_from_file_location('agreed_prepare_orchestrator', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class PrepareUncertain(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise ValueError(message)


def prepare(*, source, receiver, candidate, source_verified, invoke, recover,
            orchestrator=None):
    """One conditional receiver prepare attempt; on ambiguity perform ONE read.

    invoke(request_json) -> (ssh_exit:int, stdout:str), using caller's fixed
    authenticated endpoint. recover(request_json) -> (ssh_exit:int, stdout:str)
    for a fresh get-state; NOT an automatic repeat of prepare.
    A returned 'prepared' result means receiver durable state only: source
    preparation still requires independent privileged execution/verification.
    """
    o = orchestrator or load_orchestrator()
    require(callable(invoke) and callable(recover), 'missing transport adapters')
    require(source_verified is True, 'source identity not verified')
    action = o.next_action(source, receiver, candidate,
                           source_candidate_verified=True, receiver_has_candidate=False)
    require(action == {'next': 'prepare-receiver', 'safe_to_release_previous': False},
            'receiver preparation is not the next allowed action')
    tid = candidate['timestamp']
    payload = o.receiver_request('prepare', tid, receiver, candidate)
    expected = o.expected_receiver_after('prepare', receiver, candidate)
    try:
        code, stdout = invoke(payload)
        require(type(code) is int and code == 0, 'uncertain SSH status')
        confirmed = o.rpc.validate_response(stdout, operation='prepare',
                                            transaction_id=tid, expected_state=expected)['state']
        return result('receiver-prepared-verified', confirmed)
    except (Exception,) as original:
        # Never blindly repeat prepare. Even a nonzero response could follow a commit.
        query = o.receiver_request('get-state', tid, None, None)
        try:
            code, stdout = recover(query)
            observed = o.validate_recovery_reply(stdout, transaction_id=tid, returncode=code)
            outcome = o.classify_recovery(operation='prepare', before=receiver,
                                          candidate=candidate, observed_receiver=observed)
        except Exception as recovery_error:
            raise PrepareUncertain('receiver prepare uncertain; independent operator reconciliation required') from recovery_error
        if outcome == 'receiver-committed-verified':
            return result('receiver-prepared-recovered', observed)
        raise PrepareUncertain('receiver prepare not confirmed; do not automatically retry') from original


def result(status, receiver_state):
    return {'schema': 1, 'status': status, 'receiver': receiver_state,
            'authorizes_source_prepare': False, 'authorizes_transfer': False,
            'authorizes_promote': False, 'authorizes_release': False}
