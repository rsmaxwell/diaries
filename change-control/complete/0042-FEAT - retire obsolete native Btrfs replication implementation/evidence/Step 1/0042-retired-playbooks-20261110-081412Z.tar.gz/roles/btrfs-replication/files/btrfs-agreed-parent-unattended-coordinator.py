#!/usr/bin/env python3
"""0040 Step 12.3: fail-closed orchestration of one unattended recovery action.

Pure dependency-injected engine, NOT a production entrypoint. A trusted outer
runner must obtain the canonical sender locks, independently authenticate the
receiver evidence, enforce receive exclusion, and run the exact fixed commands.
No automatic partial-destination deletion, stream retry, or scheduler cutover.
"""

class UnattendedRefused(RuntimeError):
    pass

ACTIONS = frozenset({'select-next-candidate', 'prepare-next-candidate',
                     'execute-prepared', 'resume-committed',
                     'acknowledge-previous', 'reconcile-incomplete-receive'})


def choose_once(*, policy, observe, operation, canonical_locks_held=False):
    """Perform at most one safe action and require independently refreshed state.

    observe() supplies source/receiver, committed, destination and candidate
    from a trusted, independently verified evidence provider. It must not
    derive receipt validity from the local source state or SSH exit code.
    operation(action, evidence) invokes a trusted implementation, not shell
    strings. No operation is allowed to return unverifiable success.
    """
    if canonical_locks_held is not True:
        raise UnattendedRefused('canonical source transaction locks required')
    if not callable(observe) or not callable(operation):
        raise UnattendedRefused('trusted observation and operation callbacks required')
    before = observe()
    if type(before) is not dict or set(before) != {
            'source', 'receiver', 'committed', 'destination', 'candidate'}:
        raise UnattendedRefused('incomplete independent evidence')
    action = policy.next_action(before['source'], before['receiver'],
                                committed=before['committed'],
                                destination=before['destination'],
                                candidate=before['candidate'])
    if action not in ACTIONS:
        raise UnattendedRefused('unknown policy action')
    if action == 'reconcile-incomplete-receive':
        # Ownership and process-group fencing are NOT proven by a journal alone.
        raise UnattendedRefused('incomplete receive requires separately verified fenced reconciler')
    outcome = operation(action, before)
    if type(outcome) is not dict or outcome.get('completed') is not True or set(outcome) != {'completed'}:
        raise UnattendedRefused('operation completion not independently established')
    after = observe()
    if type(after) is not dict or set(after) != set(before):
        raise UnattendedRefused('post-operation independent evidence missing')
    # Post-observation must itself pass the fail-closed policy validation.  Do
    # not insist on a specific next action: a crash-safe operation can be a
    # validated no-op after an earlier remote commit.
    following = policy.next_action(after['source'], after['receiver'],
                                   committed=after['committed'],
                                   destination=after['destination'],
                                   candidate=after['candidate'])
    if following not in ACTIONS:
        raise UnattendedRefused('unknown follow-up action')
    return {'status': 'one-step-verified', 'action': action,
            'next_action': following, 'authorizes_release': False,
            'authorizes_prune': False}
