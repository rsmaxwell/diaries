#!/usr/bin/env python3
"""Source-only tests for fixed receiver gateway routing. Never connects SSH."""
import importlib.util
from pathlib import Path
from unittest import mock
import sys
p = Path(__file__).resolve().parents[1] / 'files/btrfs-native-push.py'
spec = importlib.util.spec_from_file_location('stageb_sender', p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
parent = '20261029-030003Z'
candidate = '20261020-030026Z'
uuid = '11111111-1111-1111-1111-111111111111'
command = m.build_receiver_prune_command(parent, uuid, candidate)
assert command == m.SSH + ['sudo', '-n', '/usr/local/sbin/btrfs-receiver-prune', '--transaction', '--protected-parent', parent, '--parent-uuid', uuid, '--candidate', candidate]
for bad in (parent, '20261030-030003Z', '../../etc/passwd'):
    try: m.build_receiver_prune_command(parent, uuid, bad)
    except RuntimeError: pass
    else: raise AssertionError('unsafe candidate accepted')
called=[]
with mock.patch.object(m, 'run_unattended_prune_one', side_effect=lambda c, **kw: called.append((c,kw)) or {'kind':'transaction-completed'}), \
     mock.patch.object(m, 'LOCK') as lock, mock.patch.object(m.os, 'geteuid', return_value=1000), \
     mock.patch.object(sys, 'argv', ['sender', '--unattended-prune-one', candidate]):
    lock.is_file.return_value = False  # CLI must NOT enter normal push lock
    m.main()
assert len(called)==1 and called[0][0]==candidate
assert called[0][1]['build_command'] is m.build_receiver_prune_command
lock.open.assert_not_called()
print('PASS: fixed SSH gateway routing, protected boundary and single-lock CLI dispatch')
