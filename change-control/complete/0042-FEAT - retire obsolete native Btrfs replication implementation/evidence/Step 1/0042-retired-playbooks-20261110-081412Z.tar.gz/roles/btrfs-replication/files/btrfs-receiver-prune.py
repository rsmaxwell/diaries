#!/usr/bin/env python3
"""0040-FEAT Step 12.3: privileged receiver pruning transaction gateway.

The gateway supports a non-destructive boundary check and an explicitly
requested, source-held receiver pruning transaction.

Transactions require a verified common parent, two live source-pin
challenges, receiver retention and checkpoint validation, manager/writer
locking, and journal-backed deletion completion.

Only eligible receiver snapshots may be deleted. Source snapshots on
mars are never deletion targets.

Dedicated replication service accounts and privilege separation are
deferred to 0041-FEAT.
"""
import argparse
import os
from pathlib import Path
import stat
import sys
import subprocess

# Fixed privileged configuration, never a caller-selected repository/path.
CONFIG = Path('/etc/btrfs-snapshot-manager.json')


def verify_root_and_config(config=CONFIG):
    if os.geteuid() != 0:
        raise PermissionError('root-only boundary: privileged execution required')
    if not config.is_absolute() or config.is_symlink() or not config.is_file():
        raise RuntimeError('Unsafe privileged configuration path')
    info = config.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != 0 or info.st_mode & 0o022:
        raise RuntimeError('Unsafe privileged configuration owner/mode')
    import json
    data = json.loads(config.read_text(encoding='utf-8'))
    if data.get('mode') != 'receiver' or data.get('receiver_prune_enabled') is not False:
        raise RuntimeError('Receiver mode required; automatic pruning must remain disabled')
    return data



def run_internal_approved_transaction(*, receiver_module, manager, receiver_config,
                                      incoming, outgoing, planner, delete_subvolume,
                                      stamp, uuid, candidate, approval_path, consumed_dir,
                                      approved_adapter=None):
    """Private bridge to the existing manager-first approved transaction.

    NOT exported by the CLI. The caller must supply a live source-held channel
    and a separately reviewed privileged deletion callback. No such caller or
    callback is installed or authorised by this change. This function has no
    fallback deletion implementation and never handles ordinary SSH commands.
    """
    # Verify the production-root boundary before invoking *any* provided code.
    boundary = verify_root_and_config()
    if (getattr(receiver_config, 'mode', None) != 'receiver' or
            getattr(receiver_config, 'receiver_prune_enabled', None) is not False):
        raise RuntimeError('Receiver transaction config must remain fail-closed')
    # Refuse disconnected manager/config instances before acquiring locks.
    if (getattr(receiver_config, 'receiver_state_dir', None) is None or
            getattr(receiver_config, 'writer_lock_path', None) !=
            receiver_config.receiver_state_dir / 'writer.lock' or
            getattr(receiver_config, 'lock_path', None) ==
            receiver_config.writer_lock_path):
        raise RuntimeError('Unsafe receiver transaction lock configuration')
    if not (hasattr(incoming, 'readline') and hasattr(outgoing, 'write')):
        raise RuntimeError('Live two-challenge stream required')
    if approved_adapter is None:
        approved_adapter = receiver_module.run_approved_manager_bound_transaction
    if not callable(approved_adapter) or not callable(planner) or not callable(delete_subvolume):
        raise RuntimeError('Missing reviewed transaction dependencies')
    # The adapter itself holds manager lock THEN receiver writer lock throughout,
    # reserves approval once, and delegates journal/recovery to the manager.
    # Never catch uncertain transaction errors here or report success on failure.
    result = approved_adapter(
        stamp, uuid, candidate, manager=manager, config=receiver_config,
        incoming=incoming, outgoing=outgoing, planner=planner,
        delete_subvolume=delete_subvolume,
        approval_path=approval_path, consumed_dir=consumed_dir)
    if not isinstance(result, dict) or result.get('production_authorized') is not False:
        raise RuntimeError('Internal transaction returned unexpected authority result')
    return result


def run_receiver_prune_transaction(*, receiver_module, manager, receiver_config,
                                   incoming, outgoing, stamp, uuid, candidate,
                                   approval_path, consumed_dir, endpoint='/usr/local/libexec/btrfs-native-endpoint',
                                   run_command=subprocess.run, approved_adapter=None):
    """Connect the existing manager transaction to the fixed Btrfs delete endpoint.

    This is internal wiring only; no CLI or Ansible deployment invokes it yet.
    Both manager and writer locks are acquired by the approved transaction.
    """
    root = receiver_module.ROOT
    if root != Path('/@data/mars-received/@data'):
        raise RuntimeError('Unexpected receiver repository')
    if not isinstance(candidate, str) or not receiver_module.STAMP.fullmatch(candidate):
        raise RuntimeError('Invalid receiver prune candidate')

    def delete_subvolume(path):
        if not isinstance(path, Path) or path != root / candidate:
            raise RuntimeError('Manager supplied unexpected deletion path')
        run_command([endpoint, '--role', 'delete-receiver', '--snapshot', candidate], check=True)

    # The receiver transaction emits challenges on the explicitly supplied
    # outgoing stream. The manager may print diagnostic inventory on stdout;
    # move those diagnostics to stderr to preserve the SSH wire protocol.
    from contextlib import redirect_stdout
    with redirect_stdout(sys.stderr):
        return run_internal_approved_transaction(
            receiver_module=receiver_module, manager=manager,
            receiver_config=receiver_config, incoming=incoming, outgoing=outgoing,
            planner=receiver_module.protected_retention_plan,
            delete_subvolume=delete_subvolume, stamp=stamp, uuid=uuid,
            candidate=candidate, approval_path=approval_path, consumed_dir=consumed_dir,
            approved_adapter=approved_adapter)


def run_unattended_receiver_transaction(*, receiver_module, manager, receiver_config,
                                        incoming, outgoing, stamp, uuid, candidate,
                                        endpoint='/usr/local/libexec/btrfs-native-endpoint',
                                        run_command=subprocess.run, transaction_adapter=None):
    """Source-held, retention-authorised receiver transaction; no approval file.

    INTERNAL ONLY in this increment. The operational CLI is deliberately left
    unchanged until regressions, disposable Btrfs, and Ansible review pass.
    The receiver adapter owns manager + writer locks, source-pin challenges,
    retention revalidation, and the manager's deletion journal.
    """
    verify_root_and_config()
    if (getattr(receiver_config, 'mode', None) != 'receiver' or
            getattr(receiver_config, 'receiver_prune_enabled', None) is not False or
            getattr(receiver_config, 'receiver_state_dir', None) is None or
            getattr(receiver_config, 'writer_lock_path', None) !=
            receiver_config.receiver_state_dir / 'writer.lock' or
            getattr(receiver_config, 'lock_path', None) == receiver_config.writer_lock_path):
        raise RuntimeError('Invalid receiver configuration or lock topology')
    if not (hasattr(incoming, 'readline') and hasattr(outgoing, 'write')):
        raise RuntimeError('Live source-held challenge streams required')
    root = receiver_module.ROOT
    if root != Path('/@data/mars-received/@data'):
        raise RuntimeError('Unexpected receiver repository')
    if (not isinstance(candidate, str) or not receiver_module.STAMP.fullmatch(candidate)
            or not isinstance(stamp, str) or not receiver_module.STAMP.fullmatch(stamp)
            or candidate >= stamp):
        raise RuntimeError('Candidate must be older than protected parent')

    def delete_subvolume(path):
        if not isinstance(path, Path) or path != root / candidate:
            raise RuntimeError('Manager supplied unexpected deletion path')
        run_command([endpoint, '--role', 'delete-receiver', '--snapshot', candidate],
                    check=True)

    adapter = transaction_adapter or receiver_module.run_manager_bound_transaction
    if not callable(adapter):
        raise RuntimeError('Missing receiver transaction adapter')
    from contextlib import redirect_stdout
    with redirect_stdout(sys.stderr):
        result = adapter(stamp, uuid, candidate, manager=manager, config=receiver_config,
                         incoming=incoming, outgoing=outgoing,
                         planner=receiver_module.protected_retention_plan,
                         delete_subvolume=delete_subvolume)
    if (not isinstance(result, dict) or
            result.get('kind') != 'transaction-completed' or
            result.get('snapshot') != candidate or
            result.get('protected_parent') != stamp or
            result.get('protected_parent_uuid') != uuid or
            result.get('journal_transaction_completed') is not True):
        raise RuntimeError('Invalid receiver completion result')
    return result

def load_installed_module(name, path):
    """Load one already-installed Python utility without replacing its CLI."""
    import importlib.util
    from importlib.machinery import SourceFileLoader
    loader = SourceFileLoader(name, str(path))
    spec = importlib.util.spec_from_loader(name, loader)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    loader.exec_module(module)
    return module


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument('--verify-boundary', action='store_true')
    selection.add_argument('--transaction', action='store_true',
                           help='Run one source-held, retention-authorised prune transaction')
    parser.add_argument('--protected-parent')
    parser.add_argument('--parent-uuid')
    parser.add_argument('--candidate')
    args = parser.parse_args(argv)
    verify_root_and_config()
    if args.verify_boundary:
        if any((args.protected_parent, args.parent_uuid, args.candidate)):
            parser.error('Boundary check accepts no transaction arguments')
        print('PASS: privileged receiver boundary checked; no deletion permitted')
        return

    if not all((args.protected_parent, args.parent_uuid, args.candidate)):
        parser.error('Transaction requires parent, UUID and candidate')
    # Import only after verifying the command and root receiver configuration.
    manager = load_installed_module('btrfs_receiver_prune_manager',
                                    Path('/usr/local/sbin/btrfs-snapshot-manager'))
    receiver = load_installed_module('btrfs_receiver_prune_protocol',
                                     Path('/usr/local/bin/btrfs-native-push-receiver'))
    config = manager.load_config(CONFIG)
    # All challenge/response messages must use the original SSH streams.
    run_unattended_receiver_transaction(
        receiver_module=receiver, manager=manager, receiver_config=config,
        incoming=sys.stdin, outgoing=sys.stdout,
        stamp=args.protected_parent, uuid=args.parent_uuid, candidate=args.candidate)


if __name__ == '__main__':
    try:
        main()
    except (PermissionError, RuntimeError, ValueError, OSError) as exc:
        print('DENIED: ' + str(exc), file=sys.stderr)
        sys.exit(1)
