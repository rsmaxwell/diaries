#!/usr/bin/env python3
"""0040 Step 12.3: internal sender nonce/proof/finalise handoff.

Must only be called AFTER the binary transport has returned verified independent
send/SSH exits. There is no CLI, transfer, key generation or transition here.
"""
import json
import os
import stat
import re
import subprocess
from pathlib import Path

KEY = Path('/etc/diaries/btrfs-agreed-parent-sender-proof.key')
MAX_RESPONSE = 8192

class HandoffRefused(RuntimeError):
    pass


def read_sender_key(path=KEY):
    """Read one fixed, root-owned secret through a verified no-follow descriptor.

    The fstat and read operate on the same inode, avoiding a path re-open
    between verification and use. Caller must already be root.
    """
    if Path(path) != KEY:
        raise HandoffRefused('unexpected sender key location')
    if os.geteuid() != 0:
        raise HandoffRefused('sender key requires privileged caller')
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC
    if hasattr(os, 'O_NONBLOCK'):
        flags |= os.O_NONBLOCK  # Never hang while opening an unexpected FIFO.
    try:
        fd = os.open(KEY, flags)
    except OSError as exc:
        raise HandoffRefused('sender key cannot be securely opened') from exc
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or
                info.st_nlink != 1 or (info.st_mode & 0o777) != 0o600):
            raise HandoffRefused('unsafe sender key ownership, links or mode')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            key = stream.read(33)
        if len(key) != 32 or any(char not in b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-' for char in key):
            raise HandoffRefused('sender key must be exactly 32 approved ASCII bytes')
        return key
    finally:
        os.close(fd)


def _parse_response(raw, *, status, parent, candidate):
    if type(raw) is not bytes or len(raw) > MAX_RESPONSE:
        raise HandoffRefused('unsafe SSH response length')
    try:
        obj = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeError) as exc:
        raise HandoffRefused('invalid receiver response') from exc
    if (type(obj) is not dict or obj.get('schema') != 1 or
        obj.get('status') != status or obj.get('parent') != parent or
        obj.get('candidate') != candidate):
        raise HandoffRefused('receiver response identity/status mismatch')
    return obj


def sender_handoff(parent, candidate, *, exits, commands, proof_module, key,
                   runner=subprocess.run, timeout_seconds=30):
    """Observe authenticated receiver nonce then submit MAC through fixed SSH.

    The caller must pass *actual observed* process results, not a remote claim.
    Completion is receipt-only and leaves source pin and parent unchanged.
    """
    if (type(exits) is not dict or set(exits) != {'source_send_exit', 'ssh_exit'} or
        any(type(v) is not int or v != 0 for v in exits.values())):
        raise HandoffRefused('binary sender/SSH exits not verified')
    if type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 120:
        raise HandoffRefused('invalid SSH deadline')
    if type(key) is not bytes or len(key) != 32:
        raise HandoffRefused('missing authenticated sender key')
    # The fixed command builder validates identities and canonical SSH target.
    session_command = commands.session_command(parent, candidate)
    finalise_command = commands.finalise_command(parent, candidate)
    try:
        session = runner(session_command, input=b'', stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, timeout=timeout_seconds, check=False)
    except Exception as exc:
        raise HandoffRefused('receiver session query uncertain') from exc
    if type(session.returncode) is not int or session.returncode != 0:
        raise HandoffRefused('receiver session query failed')
    response = _parse_response(session.stdout, status='receiver-session-provisional',
                               parent=parent, candidate=candidate)
    nonce = response.get('nonce')
    if type(nonce) is not str or re.fullmatch(r'[0-9a-f]{64}', nonce) is None:
        raise HandoffRefused('missing or invalid receiver nonce')
    proof = proof_module.create_proof(parent, candidate, nonce, key=key,
                                     send_exit=0, ssh_exit=0, receiver_exit=0)
    payload = json.dumps(proof, separators=(',', ':'), sort_keys=True).encode('ascii')
    try:
        finished = runner(finalise_command, input=payload, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=timeout_seconds, check=False)
    except Exception as exc:
        raise HandoffRefused('receiver finalisation uncertain; reconcile manually') from exc
    if type(finished.returncode) is not int or finished.returncode != 0:
        raise HandoffRefused('receiver finalisation failed; reconcile manually')
    ack = _parse_response(finished.stdout,
                          status='receiver-receipt-committed-promotion-pending',
                          parent=parent, candidate=candidate)
    if (ack.get('receipt_committed') is not True or ack.get('state_changed') is not False or
        ack.get('authorizes_prune') is not False or ack.get('authorizes_release') is not False):
        raise HandoffRefused('unsafe receiver receipt acknowledgement')
    return ack
