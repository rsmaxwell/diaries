#!/usr/bin/env python3
"""0040 Step 12.3: internal lock-owning receiver receipt finalisation.

This is deliberately NOT a CLI. The trusted sender completion verifier is a
required explicit injected dependency; a remotely asserted success flag does
not provide sender proof. No parent promotion, journal deletion, or pruning.
"""
from contextlib import ExitStack
import fcntl
import os
from pathlib import Path
import stat

MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER = Path('/@data/mars-received/.replication-state/writer.lock')
STATE = Path('/@data/mars-received/.replication-state')

class TransactionRefused(RuntimeError):
    pass


def _lock(stack, path):
    if path.is_symlink():
        raise TransactionRefused('symlinked receiver lock')
    descriptor = os.open(path, os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
    stack.callback(os.close, descriptor)
    metadata = os.fstat(descriptor)
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
        raise TransactionRefused('unsafe receiver lock')
    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return descriptor


def finalize_transaction(parent, candidate, *, finalisation, storage,
                         verify_sender_completion, inspect_received,
                         receipt_fields, lock_paths=(MANAGER, WRITER),
                         state_dir=STATE, staged_receive=None,
                         staging_storage=None, provisional_journal=None,
                         staged_module_loader=None):
    """Acquire the canonical locks and delegate the one receipt-only commit.

    A verifier provided from remote request data is forbidden by the caller's
    trust boundary. There is no default verifier and no CLI to inject one.
    """
    if tuple(map(Path, lock_paths)) != (MANAGER, WRITER) or Path(state_dir) != STATE:
        raise TransactionRefused('noncanonical receiver finalisation paths')
    if not callable(verify_sender_completion) or not callable(inspect_received):
        raise TransactionRefused('trusted sender proof and Btrfs inspector required')
    if finalisation is None or storage is None:
        raise TransactionRefused('trusted finalisation modules required')
    with ExitStack() as stack:
        _lock(stack, MANAGER)
        _lock(stack, WRITER)
        journal = storage.read_journal(STATE)
        if type(journal) is dict and 'staging' in journal:
            if callable(staged_module_loader):
                staging_storage = staged_module_loader('staging-storage')
                provisional_journal = staged_module_loader('provisional-journal')
            if (staged_receive is None or staging_storage is None or
                    provisional_journal is None or
                    not callable(getattr(staged_receive, 'inspect_staged_received', None)) or
                    not callable(getattr(staging_storage, 'publish', None)) or
                    not callable(getattr(staging_storage, 'published_absent', None)) or
                    not callable(getattr(provisional_journal, 'record_publication_witness', None))):
                raise TransactionRefused('trusted staged finalisation modules required')
            nonce = journal.get('nonce')
            binding = journal.get('staging')
            if type(nonce) is not str or type(binding) is not dict:
                raise TransactionRefused('invalid staging journal')
            return finalisation.finalize_staged_locked(
                parent, candidate,
                read_state=lambda: storage.read_state(STATE),
                read_journal=lambda: storage.read_journal(STATE),
                verify_source_completion=verify_sender_completion,
                inspect_staged=lambda b, n: staged_receive.inspect_staged_received(b, n, state_dir=STATE),
                record_publication_witness=lambda j, witness:
                    provisional_journal.record_publication_witness(
                        STATE / provisional_journal.NAME, parent, candidate, nonce,
                        witness, manager_lock_held=True, writer_lock_held=True),
                publish_staged=lambda b, j: staging_storage.publish(
                    b['timestamp'], nonce,
                    directory_dev=binding['directory_dev'],
                    directory_ino=binding['directory_ino'], locks_held=True,
                    verified_receive=True, sender_authenticated=True,
                    btrfs_identity_verified=True),
                inspect_published=inspect_received,
                published_absent=lambda stamp: staging_storage.published_absent(
                    stamp, locks_held=True),
                receipt_absent=lambda stamp: storage.receipt_absent(stamp, STATE),
                commit_receipt=lambda stamp, receipt: storage.commit_receipt(
                    stamp, receipt, directory=STATE, locks_held=True),
                receipt_fields=receipt_fields,
                manager_lock_held=True, writer_lock_held=True)
        return finalisation.finalize_locked(
            parent, candidate,
            read_state=lambda: storage.read_state(STATE),
            read_journal=lambda: storage.read_journal(STATE),
            verify_source_completion=verify_sender_completion,
            inspect_received=inspect_received,
            receipt_absent=lambda stamp: storage.receipt_absent(stamp, STATE),
            commit_receipt=lambda stamp, receipt: storage.commit_receipt(
                stamp, receipt, directory=STATE, locks_held=True),
            receipt_fields=receipt_fields,
            manager_lock_held=True, writer_lock_held=True)


def finalize_authenticated_transaction(parent, candidate, *, evidence, key,
                                       proof_module, finalisation, storage,
                                       inspect_received, receipt_fields,
                                       staged_receive=None, staging_storage=None,
                                       provisional_journal=None, staged_module_loader=None):
    """Compose authenticated sender evidence with lock-held finalisation.

    The proof is untrusted request data. Verification happens inside the
    finalisation core after it reads the receiver-owned journal under both
    locks; the remote request cannot choose the expected session nonce.
    The key must come from a trusted local configuration, never the request.
    This is an internal boundary, not a public finalisation command.
    """
    if type(evidence) is not dict or type(key) is not bytes or len(key) < 32:
        raise TransactionRefused('invalid sender evidence or missing trusted key')
    if not callable(getattr(proof_module, 'verify_proof', None)):
        raise TransactionRefused('missing trusted session proof verifier')

    def verify_locked(a, b, nonce):
        return proof_module.verify_proof(evidence, a, b, nonce, key=key)

    return finalize_transaction(
        parent, candidate, finalisation=finalisation, storage=storage,
        verify_sender_completion=verify_locked,
        inspect_received=inspect_received, receipt_fields=receipt_fields,
        staged_receive=staged_receive, staging_storage=staging_storage,
        provisional_journal=provisional_journal,
        staged_module_loader=staged_module_loader)
