#!/usr/bin/python3
"""0040 Step 12.3: privileged agreed-parent receiver entry.

Fixed receiver CLI: journal-first receive, authenticated finalisation, durable
receiver-first promotion and independent readback. Never authorises pruning or
releasing the previous parent.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
import stat
from pathlib import Path
import sys

LIB = Path('/usr/local/libexec')
STATE = Path('/@data/mars-received/.replication-state')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER = STATE / 'writer.lock'


def module(name, directory=LIB):
    path = directory / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('review_entry_' + name.replace('-', '_'), path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def review(parent, candidate, *, dependencies=None, locks=(MANAGER, WRITER)):
    """Read actual A/B and destination under the same canonical receiver locks."""
    if tuple(map(Path, locks)) != (MANAGER, WRITER):
        raise RuntimeError('noncanonical receiver locks')
    d = dependencies if dependencies is not None else {
        x: module(x) for x in ('receiver', 'endpoint', 'state', 'transfer-absence', 'receive-boundary')
    }
    d['state'].snapshot(parent)
    d['state'].snapshot(candidate)
    with ExitStack() as stack:
        d['receiver']._lock(stack, MANAGER)
        d['receiver']._lock(stack, WRITER)
        d['endpoint'].validate_filesystem()
        state = d['state'].load(STATE / '.agreed-parent.json')
        evidence = d['transfer-absence'].verify(parent, candidate, state, state=d['state'])
        if evidence.get('destination_absent') is not True or evidence.get('receipt_absent') is not True or evidence.get('state_changed') is not False:
            raise RuntimeError('incomplete receiver absence proof')
        d['receive-boundary'].verify_before_receive(
            state, parent, candidate, {
                'snapshot_absent': True, 'receipt_absent': True,
                'partial_artifacts_absent': True, 'prune_journal_absent': True,
            }, manager_lock_held=True, writer_lock_held=True)
        return {'schema': 1, 'status': 'agreed-parent-receiver-entry-review',
                'parent': parent, 'candidate': candidate, 'state': state,
                'receiver_locks_held_during_review': True,
                'destination_absent': True, 'receipt_absent': True,
                'stream_accepted': False, 'journal_created': False,
                'receipt_committed': False, 'state_changed': False,
                'authorizes_transfer': False, 'authorizes_transition': False,
                'authorizes_prune': False, 'authorizes_release': False}


# 0040 Step 12.3: internal consolidation seam (NO production CLI route).
# Exactly one lock owner: the tested journal-first transaction in the current
# receiver implementation. Never call this inside review(), which owns locks.
# The legacy implementation is a transitional dependency; its existing --accept
# CLI is NOT the agreed-parent receive interface and must be retired separately.
def receive_candidate_internal(parent, candidate, *, input_stream, dependencies=None):
    """Delegate to the journal-first transaction without exposing execution.

    dependencies is strictly an internal test seam, not CLI or RPC input.
    Actual production execution remains disabled pending privilege and SSH
    boundary review, stream-process lifetime audit, and receiver migration.
    """
    if input_stream is None or not hasattr(input_stream, 'read'):
        raise RuntimeError('binary stream required')
    if dependencies is None:
        # Deliberate fail-closed default: no runtime caller can opt in yet.
        raise RuntimeError('agreed-parent receiver execution not enabled')
    if type(dependencies) is not dict or set(dependencies) != {'integrated_receive'}:
        raise RuntimeError('invalid internal receiver dependencies')
    integrated = dependencies['integrated_receive']
    if not callable(integrated):
        raise RuntimeError('invalid internal receiver adapter')
    result = integrated(parent, candidate, input_stream=input_stream)
    if not (type(result) is dict and result.get('status') == 'receiver-provisional-only'
            and result.get('receipt_committed') is False
            and result.get('transfer_finalized') is False
            and result.get('authorizes_transition') is False
            and result.get('authorizes_prune') is False
            and result.get('authorizes_release') is False):
        raise RuntimeError('receiver returned unsafe provisional result')
    return result



def verify_established_parent_locked(stamp, source_uuid, *, endpoint, attestation):
    """Verify parent A from receiver-owned receipt and Btrfs metadata.

    Called only from the receive core's lock-held preflight; this function
    does not claim to acquire locks or to validate a client-supplied receipt.
    """
    import re
    if (type(stamp) is not str or re.fullmatch(r'[0-9]{8}-[0-9]{6}Z', stamp) is None or
            type(source_uuid) is not str or
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', source_uuid) is None):
        raise RuntimeError('invalid parent identity')
    receipt = attestation.strict_receipt(STATE / (stamp + '.json'), stamp)
    observed = endpoint.inspect_snapshot(stamp)
    expected_path = str(Path('/@data/mars-received/@data') / stamp)
    if (type(receipt) is not dict or receipt.get('schema') != 1 or
            receipt.get('snapshot') != stamp or receipt.get('source_uuid') != source_uuid or
            receipt.get('received_uuid') != source_uuid or receipt.get('destination') != expected_path or
            receipt.get('source_filesystem_uuid') != attestation.SOURCE_FS or
            receipt.get('receiver_filesystem_uuid') != attestation.RECEIVER_FS or
            receipt.get('read_only_verified') is not True or
            receipt.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
            type(receipt.get('source_send_exit')) is not int or receipt['source_send_exit'] != 0 or
            type(receipt.get('receiver_receive_exit')) is not int or receipt['receiver_receive_exit'] != 0 or
            type(observed) is not dict or observed.get('flags') != 'readonly' or
            observed.get('received_uuid') != source_uuid):
        raise RuntimeError('established parent receipt or Btrfs identity refused')
    return {'receiver_verified_under_lock': True, 'snapshot': stamp,
            'source_uuid': source_uuid}


def receive_from_migrated_core_internal(parent, candidate, *, input_stream, dependencies=None, scoped=False, staged=False):
    """One internal delegation to the migrated core; not callable from CLI.

    Only the core acquires both locks; never call inside review(). The
    injected dependency map is for offline tests, not a production enable flag.
    """
    if input_stream is None or not hasattr(input_stream, 'read'):
        raise RuntimeError('binary stream required')
    if dependencies is None:
        raise RuntimeError('agreed-parent receiver execution not enabled')
    if type(scoped) is not bool or type(staged) is not bool or (staged and not scoped):
        raise RuntimeError('invalid scoped/staged receive selection')
    required = {'core', 'state', 'absence', 'endpoint', 'journal', 'attestation',
                'manager_lock', 'writer_lock', 'state_dir', 'runner', 'inspect_received'}
    if scoped:
        required = required | {'scope-observer'}
    if staged:
        required = required | {'staging-storage'}
    if type(dependencies) is not dict or set(dependencies) != required:
        raise RuntimeError('invalid internal migrated core dependencies')
    if scoped and not callable(getattr(dependencies['scope-observer'], 'inspect_scope_lifecycle', None)):
        raise RuntimeError('trusted scope observer missing')
    if staged and (not callable(getattr(dependencies['staging-storage'], 'reserve', None)) or
                   not callable(getattr(dependencies['journal'], 'bind_staging', None))):
        raise RuntimeError('trusted staging reservation and journal binding required')
    d = dependencies
    core = d['core']
    if not callable(getattr(core, 'receive_prepared_candidate_integrated', None)):
        raise RuntimeError('missing migrated receive core')
    def trusted_parent(stamp, source_uuid):
        return verify_established_parent_locked(stamp, source_uuid,
                                                endpoint=d['endpoint'], attestation=d['attestation'])
    result = core.receive_prepared_candidate_integrated(
        parent, candidate, input_stream=input_stream,
        state_module=d['state'], absence_module=d['absence'],
        endpoint_module=d['endpoint'], journal_module=d['journal'],
        manager_lock=d['manager_lock'], writer_lock=d['writer_lock'],
        state_dir=d['state_dir'], verify_parent=trusted_parent,
        runner=None if scoped else d['runner'], inspect_received=d['inspect_received'],
        **({'scoped': True, 'scope_query': d['scope-observer'].inspect_scope_lifecycle, 'scope_lifecycle': True} if scoped else {}),
        **({'staged': True, 'staging_storage': d['staging-storage']} if staged else {}))
    if not (type(result) is dict and result.get('status') == 'receiver-provisional-only' and
            result.get('receipt_committed') is False and
            result.get('transfer_finalized') is False and
            result.get('authorizes_transition') is False and
            result.get('authorizes_prune') is False and
            result.get('authorizes_release') is False):
        raise RuntimeError('migrated core returned unsafe provisional result')
    return result



def receive_fixed(parent, candidate, *, input_stream, loader=module, scoped=False, staged=False):
    """Root-only fixed-module receive: journal-first; NO receipt/finalisation.

    Only the installed module set is selected.  Remote input consists solely
    of exact A/B identities and the binary stdin stream.  The core owns both
    locks from preflight through process termination; its subprocess inherits
    both descriptors so coordinator death does not release exclusion early.
    """
    if os.geteuid() != 0:
        raise RuntimeError('root required for agreed-parent receiving')
    if input_stream is None or not hasattr(input_stream, 'read'):
        raise RuntimeError('binary receive stream required')
    if type(scoped) is not bool or type(staged) is not bool or (staged and not scoped):
        raise RuntimeError('invalid scoped/staged receive mode')
    names = ('receive-core', 'state', 'transfer-absence', 'endpoint',
             'provisional-journal', 'transfer-attestation')
    d = {name: loader(name) for name in names}
    if scoped:
        d['scope-observer'] = loader('scope-observer')
    if staged:
        d['staging-storage'] = loader('staging-storage')
    return receive_from_migrated_core_internal(
        parent, candidate, input_stream=input_stream,
        dependencies={
            'core': d['receive-core'], 'state': d['state'],
            'absence': d['transfer-absence'], 'endpoint': d['endpoint'],
            'journal': d['provisional-journal'],
            'attestation': d['transfer-attestation'],
            'manager_lock': MANAGER, 'writer_lock': WRITER,
            'state_dir': STATE, 'runner': __import__('subprocess').run,
            'inspect_received': d['receive-core'].inspect,
            **({'scope-observer': d['scope-observer']} if scoped else {}),
            **({'staging-storage': d['staging-storage']} if staged else {}),
        }, scoped=scoped, staged=staged)




# Never take key location, material, or sender exit codes from SSH arguments.
PROOF_KEY = Path('/etc/diaries/btrfs-agreed-parent-sender-proof.key')
MAX_PROOF_BYTES = 4096


def read_protected_key(path=PROOF_KEY):
    """Read a fixed root-owned key, refusing links and permissive access."""
    if Path(path) != PROOF_KEY:
        raise RuntimeError('noncanonical sender-proof key')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or
                info.st_nlink != 1 or info.st_mode & 0o077 or
                info.st_size < 32 or info.st_size > 4096):
            raise RuntimeError('unsafe sender-proof key')
        key = os.read(fd, 4097)
        if len(key) < 32 or len(key) > 4096:
            raise RuntimeError('invalid sender-proof key')
        return key
    finally:
        os.close(fd)


def read_completion_proof(stream):
    """Read bounded JSON only on the separate finalisation SSH connection."""
    if stream is None or not hasattr(stream, 'read'):
        raise RuntimeError('sender completion proof required')
    raw = stream.read(MAX_PROOF_BYTES + 1)
    if type(raw) is not bytes or not raw or len(raw) > MAX_PROOF_BYTES:
        raise RuntimeError('missing or oversized sender completion proof')
    proof = json.loads(raw.decode('utf-8'))
    if type(proof) is not dict or set(proof) != {'payload', 'mac'}:
        raise RuntimeError('invalid sender completion proof')
    return proof


def finalise_fixed(parent, candidate, *, input_stream=None, loader=module,
                   key_reader=read_protected_key):
    """Authenticate a session-bound sender proof under both receiver locks.

    A completed receive is NOT a promotion. A remote assertion is only
    authenticated evidence; the sender must derive it from actual process waits.
    No key or exit code is accepted as a command argument.
    """
    if os.geteuid() != 0:
        raise RuntimeError('root required for agreed-parent finalisation')
    import re
    stamp = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
    uuid = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
    for obj in (parent, candidate):
        if (type(obj) is not dict or set(obj) != {'timestamp', 'uuid'} or
                type(obj['timestamp']) is not str or not stamp.fullmatch(obj['timestamp']) or
                type(obj['uuid']) is not str or not uuid.fullmatch(obj['uuid'])):
            raise RuntimeError('invalid finalisation identity')
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid finalisation order')
    evidence = read_completion_proof(input_stream)
    key = key_reader()
    modules = {name: loader(name) for name in
               ('finalisation-transaction', 'finalisation-core',
                'finalisation-storage', 'session-proof', 'receive-core')}
    # The receiver constructs its own receipt fields; the authenticated proof
    # itself does not become an authority to invent filesystem metadata.
    receipt_fields = {
        'schema': 1, 'snapshot': candidate['timestamp'],
        'destination': str(Path('/@data/mars-received/@data') / candidate['timestamp']),
        'source_uuid': candidate['uuid'], 'received_uuid': candidate['uuid'],
        'parent_snapshot': parent['timestamp'],
        'parent_source_uuid': parent['uuid'],
        'transport': 'btrfs-incremental', 'read_only_verified': True,
        'source_send_exit': 0, 'receiver_receive_exit': 0,
    }
    result = modules['finalisation-transaction'].finalize_authenticated_transaction(
        parent, candidate, evidence=evidence, key=key,
        proof_module=modules['session-proof'],
        finalisation=modules['finalisation-core'],
        storage=modules['finalisation-storage'],
        inspect_received=modules['receive-core'].inspect,
        receipt_fields=receipt_fields,
        staged_receive=modules['receive-core'],
        staged_module_loader=loader)
    if not (type(result) is dict and
            result.get('status') == 'receiver-receipt-committed-promotion-pending' and
            result.get('receipt_committed') is True and
            result.get('authorizes_transition') is False and
            result.get('authorizes_prune') is False and
            result.get('authorizes_release') is False):
        raise RuntimeError('unsafe finalisation result; reconciliation required')
    return result


def session_fixed(parent, candidate, *, loader=module):
    """Read receiver-owned provisional session under BOTH locks, without mutation.

    The return value is a nonce, NOT sender completion proof or approval to
    finalise. Only the authenticated existing SSH account may request it.
    An existing or malformed journal must never be repaired or replaced here.
    """
    import re
    if os.geteuid() != 0:
        raise RuntimeError('root required for agreed-parent session inspection')
    stamp = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
    uuid = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
    for obj in (parent, candidate):
        if (type(obj) is not dict or set(obj) != {'timestamp', 'uuid'} or
                type(obj['timestamp']) is not str or not stamp.fullmatch(obj['timestamp']) or
                type(obj['uuid']) is not str or not uuid.fullmatch(obj['uuid'])):
            raise RuntimeError('invalid agreed-parent session identity')
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid agreed-parent session ordering')
    receiver = loader('receiver')
    storage = loader('finalisation-storage')
    with ExitStack() as stack:
        receiver._lock(stack, MANAGER)
        receiver._lock(stack, WRITER)
        state = storage.read_state(STATE)
        journal = storage.read_journal(STATE)
        if (type(state) is not dict or set(state) != {'schema', 'established', 'pending', 'previous'} or
                type(state['schema']) is not int or state['schema'] != 1 or
                state['established'] != parent or state['pending'] != candidate or
                state['previous'] is not None):
            raise RuntimeError('agreed-parent session state mismatch')
        # Use the exact same strict journal contract as receipt finalisation.
        # A scoped journal is not a termination or cleanup attestation.
        loader('finalisation-core').validate_provisional_journal(journal, parent, candidate)
        return {'schema': 1, 'status': 'receiver-session-provisional',
                'parent': parent, 'candidate': candidate, 'nonce': journal['nonce'],
                'receipt_committed': False, 'authorizes_transition': False,
                'authorizes_prune': False, 'authorizes_release': False}


def _receipt_locked(parent, candidate, *, storage, receive_core):
    """Validate an existing committed receipt; caller owns both receiver locks.

    Never invoke this helper without the canonical manager and writer locks.
    """
    state = storage.read_state(STATE)
    if (type(state) is not dict or not ((state.get('established') == parent and
                  state.get('pending') == candidate and state.get('previous') is None) or
                 (state.get('established') == candidate and
                  state.get('pending') is None and state.get('previous') == parent))):
        raise RuntimeError('receiver state does not match final receipt request')
    # Reuse descriptor-safe receipt reader; never trust a symlink or partial file.
    receipt = storage._safe_read(STATE / (candidate['timestamp'] + '.json'))
    if (type(receipt) is not dict or receipt.get('schema') != 1 or
            receipt.get('snapshot') != candidate['timestamp'] or
            receipt.get('destination') != str(Path('/@data/mars-received/@data') / candidate['timestamp']) or
            receipt.get('source_uuid') != candidate['uuid'] or
            receipt.get('received_uuid') != candidate['uuid'] or
            receipt.get('parent_snapshot') != parent['timestamp'] or
            receipt.get('parent_source_uuid') != parent['uuid'] or
            receipt.get('read_only_verified') is not True or
            type(receipt.get('source_send_exit')) is not int or
            receipt['source_send_exit'] != 0 or
            type(receipt.get('receiver_receive_exit')) is not int or
            receipt['receiver_receive_exit'] != 0):
        raise RuntimeError('receiver final receipt identity refused')
    observed = receive_core.inspect(candidate['timestamp'])
    if (type(observed) is not dict or
            observed.get('received_uuid') != candidate['uuid'] or
            observed.get('flags') != 'readonly'):
        raise RuntimeError('receiver Btrfs evidence differs from final receipt')
    return {'schema': 1, 'status': 'receiver-final-receipt-verified',
            'parent': parent, 'candidate': candidate, 'receipt': receipt,
            'receipt_committed': True, 'authorizes_transition': False,
            'authorizes_prune': False, 'authorizes_release': False}


def receipt_fixed(parent, candidate, *, loader=module):
    """Read an independently verified final receipt under both receiver locks."""
    import re
    if os.geteuid() != 0:
        raise RuntimeError('root required for receiver receipt readback')
    stamp = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
    uuid = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
    for identity in (parent, candidate):
        if (type(identity) is not dict or set(identity) != {'timestamp', 'uuid'} or
                type(identity['timestamp']) is not str or not stamp.fullmatch(identity['timestamp']) or
                type(identity['uuid']) is not str or not uuid.fullmatch(identity['uuid'])):
            raise RuntimeError('invalid receipt identity')
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid receipt ordering')
    receiver = loader('receiver')
    storage = loader('finalisation-storage')
    receive_core = loader('receive-core')
    with ExitStack() as stack:
        receiver._lock(stack, MANAGER)
        receiver._lock(stack, WRITER)
        return _receipt_locked(parent, candidate, storage=storage, receive_core=receive_core)


def promote_receiver_fixed(parent, candidate, *, loader=module):
    """Durably promote B on receiver, retaining A as previous (internal only).

    No public CLI: deployed entry can expose this only after sender/receiver
    recovery and deployment contracts are accepted. Never releases A.
    """
    if os.geteuid() != 0:
        raise RuntimeError('root required for receiver promotion')
    receiver = loader('receiver')
    storage = loader('finalisation-storage')
    receive_core = loader('receive-core')
    state_module = loader('state')
    state_path = STATE / '.agreed-parent.json'
    with ExitStack() as stack:
        receiver._lock(stack, MANAGER)
        receiver._lock(stack, WRITER)
        current = state_module.load(state_path, require_root=True)
        state_module.snapshot(parent)
        state_module.snapshot(candidate)
        if parent['timestamp'] >= candidate['timestamp']:
            raise RuntimeError('invalid promotion ordering')
        promoted = (current['established'] == candidate and
                    current['previous'] == parent and current['pending'] is None)
        prepared = (current['established'] == parent and
                    current['pending'] == candidate and current['previous'] is None)
        if not (prepared or promoted):
            raise RuntimeError('receiver state does not match promotion/recovery')
        # Committed receipt and on-disk Btrfs identity are required on *every*
        # invocation, including a retry after a lost promotion acknowledgement.
        proof = _receipt_locked(parent, candidate, storage=storage,
                                receive_core=receive_core)
        if proof.get('receipt_committed') is not True:
            raise RuntimeError('receiver receipt not committed')
        if prepared:
            new_state = state_module.promote(current)
            state_module.save(state_path, new_state, require_root=True)
            observed = state_module.load(state_path, require_root=True)
            if observed != new_state:
                raise RuntimeError('receiver promotion durability check failed')
        else:
            observed = current
        return {'schema': 1, 'status': 'receiver-promoted-previous-pinned',
                'parent': parent, 'candidate': candidate, 'state': observed,
                'receipt_committed': True, 'authorizes_prune': False,
                'authorizes_release': False}

def inspect_incomplete_fixed(parent, candidate, *, loader=module):
    """Read-only incident evidence from receiver-owned canonical paths.

    No external fencing or ownership assertions are accepted. Locks are held
    from state/journal acquisition through the resulting inspection decision.
    """
    if os.geteuid() != 0:
        raise RuntimeError('root required for receiver incident inspection')
    receiver = loader('receiver')
    storage = loader('finalisation-storage')
    inspection = loader('incomplete-inspection')
    state_module = loader('state')
    state_module.snapshot(parent)
    state_module.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid inspection ordering')
    with ExitStack() as stack:
        receiver._lock(stack, MANAGER)
        receiver._lock(stack, WRITER)
        return inspection.inspect_locked_under_existing_locks(
            parent, candidate, storage=storage, state_dir=STATE,
            destination_root=Path('/@data/mars-received/@data'))


def inspect_incomplete_btrfs_fixed(parent, candidate, *, loader=module):
    """Inspect exact receiver transaction and Btrfs destination under both locks.

    This is diagnosis, NOT proof of process fencing or journal ownership.
    Do not convert this report into deletion or retransmission authority.
    """
    if os.geteuid() != 0:
        raise RuntimeError('root required for receiver incident inspection')
    receiver = loader('receiver')
    storage = loader('finalisation-storage')
    inspection = loader('incomplete-inspection')
    state_module = loader('state')
    state_module.snapshot(parent)
    state_module.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid inspection ordering')
    with ExitStack() as stack:
        receiver._lock(stack, MANAGER)
        receiver._lock(stack, WRITER)
        transaction = inspection.inspect_locked_under_existing_locks(
            parent, candidate, storage=storage, state_dir=STATE,
            destination_root=Path('/@data/mars-received/@data'))
        destination = inspection.inspect_btrfs_destination(candidate)
        if destination['status'] == 'absent' and transaction['destination_present']:
            raise RuntimeError('destination changed during inspection')
        if destination['status'] != 'absent' and not transaction['destination_present']:
            raise RuntimeError('destination appeared during inspection')
        return {'schema': 1, 'status': 'incomplete-receive-btrfs-diagnostic',
                'transaction': transaction, 'destination': destination,
                'stream_terminated_independently_proven': False,
                'journal_ownership_proven': False,
                'cleanup_authorized': False, 'retransmit_authorized': False,
                'prune_authorized': False, 'release_authorized': False}



def inspect_previous_boot_fixed(parent, candidate, *, loader=module, boot_id_reader=None):
    """Privileged locked previous-boot recovery assessment; never mutate.

    A reboot fences processes of the prior boot only; Btrfs metadata alone
    cannot establish nonce ownership of an incomplete destination.
    """
    if os.geteuid() != 0:
        raise RuntimeError('root required for receiver recovery assessment')
    receiver = loader('receiver')
    storage = loader('finalisation-storage')
    inspection = loader('incomplete-inspection')
    reconciler = loader('incomplete-reconciler')
    state_module = loader('state')
    state_module.snapshot(parent)
    state_module.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid recovery identity ordering')
    if boot_id_reader is None:
        boot_id_reader = lambda: Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    with ExitStack() as stack:
        receiver._lock(stack, MANAGER)
        receiver._lock(stack, WRITER)
        current = storage.read_state(STATE)
        journal = storage.read_journal(STATE)
        if (type(current) is not dict or current.get('schema') != 1 or
            current.get('established') != parent or current.get('pending') != candidate or
            current.get('previous') is not None):
            raise RuntimeError('receiver pending state mismatch')
        if storage.receipt_absent(candidate['timestamp'], STATE) is not True:
            raise RuntimeError('committed or uncertain receipt')
        reconciler.validate_journal(journal, parent, candidate)
        fencing = reconciler.fence_previous_boot(journal, boot_id_reader=boot_id_reader)
        destination = inspection.inspect_btrfs_destination(candidate)
        if destination.get('status') not in ('absent', 'btrfs-subvolume-observed'):
            raise RuntimeError('unrecognised Btrfs destination status')
        return {'schema': 1, 'status': 'receiver-previous-boot-recovery-assessment',
                'parent': parent, 'candidate': candidate, 'fencing': fencing,
                'destination': destination, 'receipt_absent': True,
                'stream_terminated_independently_proven': True,
                'journal_ownership_proven': False, 'cleanup_authorized': False,
                'retransmit_authorized': False, 'prune_authorized': False,
                'release_authorized': False}



def assess_staged_recovery_fixed(parent, candidate, *, loader=module, boot_id_reader=None):
    """Receiver-owned read-only private-stage assessment under canonical locks."""
    if os.geteuid() != 0:
        raise RuntimeError('root required for staged recovery assessment')
    receiver = loader('receiver')
    storage = loader('finalisation-storage')
    reconciler = loader('incomplete-reconciler')
    recovery = loader('staged-recovery')
    state_module = loader('state')
    state_module.snapshot(parent)
    state_module.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid staged recovery identity order')
    if boot_id_reader is None:
        boot_id_reader = lambda: Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    with ExitStack() as stack:
        receiver._lock(stack, MANAGER)
        receiver._lock(stack, WRITER)
        state = storage.read_state(STATE)
        journal = storage.read_journal(STATE)
        if reconciler.validate_journal(journal, parent, candidate) != 'staged':
            raise RuntimeError('only nonce-bound staged journal supported')
        fence = reconciler.fence_previous_boot(journal, boot_id_reader=boot_id_reader)
        return recovery.assess(parent, candidate, journal, state=state,
                               receipt_absent=storage.receipt_absent(candidate['timestamp'], STATE),
                               previous_boot_fence=fence, locks_held=True)

def main():
    parser = argparse.ArgumentParser(description='Agreed-parent receiver: review or provisional receive')
    for name in ('parent', 'parent-uuid', 'candidate', 'candidate-uuid'):
        parser.add_argument('--' + name, required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--review-only', action='store_true')
    mode.add_argument('--receive', action='store_true')
    mode.add_argument('--receive-scoped', action='store_true',
                      help='Opt-in journal-bound systemd scoped receive (no cleanup or retry)')
    mode.add_argument('--receive-staged-scoped', action='store_true',
                      help='Opt-in staged scoped receive; provisional result only (no publication or retry)')
    mode.add_argument('--finalise', action='store_true')
    mode.add_argument('--session', action='store_true')
    mode.add_argument('--receipt', action='store_true')
    mode.add_argument('--promote', action='store_true')
    mode.add_argument('--promoted-readback', action='store_true')
    mode.add_argument('--acknowledge-previous', action='store_true')
    mode.add_argument('--previous-readback', action='store_true')
    mode.add_argument('--inspect-incomplete', action='store_true')
    mode.add_argument('--inspect-incomplete-btrfs', action='store_true')
    mode.add_argument('--assess-staged-recovery', action='store_true',
                      help='Read-only previous-boot private-stage classification; no deletion/retry')
    mode.add_argument('--assess-previous-boot', action='store_true',
                      help='Read-only previous-boot fencing and Btrfs evidence; no cleanup')
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    parent = {'timestamp': args.parent, 'uuid': args.parent_uuid}
    candidate = {'timestamp': args.candidate, 'uuid': args.candidate_uuid}
    if args.assess_staged_recovery:
        result = assess_staged_recovery_fixed(parent, candidate)
    elif args.assess_previous_boot:
        result = inspect_previous_boot_fixed(parent, candidate)
    elif args.inspect_incomplete_btrfs:
        result = inspect_incomplete_btrfs_fixed(parent, candidate)
    elif args.inspect_incomplete:
        result = inspect_incomplete_fixed(parent, candidate)
    elif args.acknowledge_previous:
        result = module('previous-ack').acknowledge(parent, candidate)
    elif args.previous_readback:
        result = module('previous-ack').readback(parent, candidate)
    elif args.promote:
        result = module('receiver-promotion-binding').promote_verified_receiver(parent, candidate)
    elif args.promoted_readback:
        result = module('receiver-promoted-readback').read_promoted_state(parent, candidate)
    elif args.receipt:
        result = receipt_fixed(parent, candidate)
    elif args.session:
        result = session_fixed(parent, candidate)
    elif args.finalise:
        result = finalise_fixed(parent, candidate, input_stream=sys.stdin.buffer)
    elif args.receive or args.receive_scoped or args.receive_staged_scoped:
        # Never put protocol chatter on stdin: SSH stdin is binary Btrfs data.
        result = receive_fixed(parent, candidate, input_stream=sys.stdin.buffer,
                               scoped=(args.receive_scoped or args.receive_staged_scoped),
                               staged=args.receive_staged_scoped)
    else:
        result = review(parent, candidate)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, TypeError, OSError, KeyError) as exc:
        print('agreed-parent receiver refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
