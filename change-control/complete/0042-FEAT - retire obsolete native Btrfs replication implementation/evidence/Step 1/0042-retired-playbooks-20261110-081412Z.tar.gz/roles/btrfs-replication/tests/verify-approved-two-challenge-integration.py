#!/usr/bin/env python3
"""0040 Step 3: disposable end-to-end INTERNAL challenge/approval/journal integration.

Uses in-process socket streams and injected transaction callbacks. No SSH, sudo,
Btrfs operations, production paths, receipts or snapshot deletion. Root is required
only for the positive root-owned approval fixture; non-root execution is a skip.
"""
import importlib.util
import json
import os
from pathlib import Path
import socket
import tempfile
import threading
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

FILES = Path(__file__).resolve().parents[1] / 'files'
def load(filename, name):
    spec = importlib.util.spec_from_file_location(name, FILES / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

sender = load('btrfs-native-push.py', 'step03_sender')
receiver = load('btrfs-native-push-receiver.py', 'step03_receiver')
PARENT = '20261024-030038Z'
CANDIDATE = '20261012-100003Z'
UUID = '22e0ca45-0f49-c745-85b0-af6b6cfb915c'

if os.geteuid() != 0:
    print('SKIP: positive approval fixture requires root; run this regression with sudo')
    raise SystemExit(0)

class TestProcess:
    def __init__(self, output, input_, thread, outcome):
        self.stdout, self.stdin = output, input_
        self.thread, self.outcome = thread, outcome
    def wait(self, timeout=None):
        self.thread.join(timeout)
        if self.thread.is_alive():
            raise RuntimeError('Disposable receiver thread did not terminate')
        return 0 if not self.outcome else 1

def execute(interrupt):
    with tempfile.TemporaryDirectory(prefix='0040-approved-two-challenge-') as td:
        root = Path(td)
        state = root / 'state'; state.mkdir()
        consumed = state / 'consumed'; consumed.mkdir()
        manager_lock = root / 'manager.lock'; manager_lock.touch()
        writer_lock = state / 'writer.lock'; writer_lock.touch()
        approval = root / 'approval.json'
        approval.write_text(json.dumps({
            'schema': 1, 'operation': 'receiver-prune-one',
            'candidate': CANDIDATE, 'protected_parent': PARENT,
            'protected_parent_uuid': UUID,
            'expires_at_utc': (datetime.now(timezone.utc) + timedelta(minutes=20)).strftime('%Y-%m-%dT%H:%M:%SZ'),
            'reason': 'Disposable integration regression only',
        }))
        approval.chmod(0o600)
        config = SimpleNamespace(mode='receiver', receiver_prune_enabled=False,
            receiver_state_dir=state, writer_lock_path=writer_lock, lock_path=manager_lock)
        pin_calls = []
        def protect_pin(role, stamp):
            assert role == 'protect-prune-source' and stamp == PARENT
            pin_calls.append(stamp)
            return {'source_uuid': UUID}
        def planner(stamp, uuid):
            assert stamp == PARENT and uuid == UUID
            return {'snapshot': PARENT, 'source_uuid': UUID, 'authorizes_prune': False,
                    'deletion_executed': False, 'candidates': [CANDIDATE]}
        class Manager:
            def receiver_delete_one_locked(self, config_, target, *, protected_stamp,
                                           expected_parent_uuid, verify_source_pin,
                                           delete_subvolume):
                assert target == CANDIDATE and protected_stamp == PARENT
                assert expected_parent_uuid == UUID
                verify_source_pin()  # second fresh challenge, after retention recheck
                (state / '.receiver-prune-pending.json').write_text('{"disposable":true}')
                if interrupt:
                    raise RuntimeError('Simulated interruption after durable journal')
                (state / '.receiver-prune-pending.json').unlink()  # mock completion; NOT real manager
        a, b = socket.socketpair()
        sender_in = a.makefile('r', encoding='utf-8')
        sender_out = a.makefile('w', encoding='utf-8', buffering=1)
        receiver_in = b.makefile('r', encoding='utf-8')
        receiver_out = b.makefile('w', encoding='utf-8', buffering=1)
        outcome = []
        def worker():
            try:
                receiver.run_approved_manager_bound_transaction(
                    PARENT, UUID, CANDIDATE, manager=Manager(), config=config,
                    incoming=receiver_in, outgoing=receiver_out, planner=planner,
                    delete_subvolume=lambda _: (_ for _ in ()).throw(
                        AssertionError('Real deletion callback must never be invoked')),
                    approval_path=approval, consumed_dir=consumed)
            except Exception as exc:
                outcome.append(exc)
            finally:
                receiver_out.close(); receiver_in.close(); b.close()
        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        proc = TestProcess(sender_in, sender_out, thread, outcome)
        try:
            if interrupt:
                try:
                    sender.answer_transaction_challenges(proc, PARENT, UUID, CANDIDATE,
                                                         protect_pin=protect_pin)
                except (RuntimeError, EOFError, ValueError, OSError):
                    pass
                else:
                    raise AssertionError('Interrupted transaction was accepted')
            else:
                result = sender.answer_transaction_challenges(proc, PARENT, UUID, CANDIDATE,
                                                              protect_pin=protect_pin)
                assert result['journal_transaction_completed'] is True
            assert len(pin_calls) == 2, pin_calls
            assert len(list(consumed.glob('*.json'))) == 1
            assert (state / '.receiver-prune-pending.json').exists() == interrupt
            print('PASS: ' + ('journal retained on interrupted two-challenge exchange' if interrupt
                              else 'two fresh challenges and journal-backed mock completion'))
        finally:
            sender_out.close(); sender_in.close(); a.close()
            thread.join(3)
            assert not thread.is_alive(), 'Receiver thread leaked'

execute(False)
execute(True)
print('PASS: internal two-challenge approval integration; no real deletion')
