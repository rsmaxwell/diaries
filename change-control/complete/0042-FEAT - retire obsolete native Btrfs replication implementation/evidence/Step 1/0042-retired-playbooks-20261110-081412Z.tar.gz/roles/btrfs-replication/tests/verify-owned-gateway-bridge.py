#!/usr/bin/env python3
"""0040 source-only integration: owned process and internal gateway callback."""
import importlib.util
from pathlib import Path
import sys

MODULE = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-owned-session.py'
spec = importlib.util.spec_from_file_location('owned_peer', MODULE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

peer = ['-u', '-c', '''import sys,json
request=json.loads(sys.stdin.readline())
print(json.dumps({'echo':request['nonce']}),flush=True)
''']

def good_gateway(*, incoming, outgoing, expected):
    outgoing.write('{"nonce":"hello"}\n')
    outgoing.flush()
    assert incoming.readline() == '{"echo": "hello"}\n'
    return expected

assert mod.run_owned_gateway_transaction([sys.executable, *peer], good_gateway, {'expected': 42}) == 42
print('PASS: owned process streams bound to gateway; child exits successfully')

try:
    mod.run_owned_gateway_transaction([sys.executable, *peer], good_gateway, {'expected': 42, 'incoming': None})
except ValueError:
    print('PASS: caller cannot substitute an unowned input stream')
else:
    raise AssertionError('Caller-controlled stream accepted')

def broken_gateway(*, incoming, outgoing):
    raise RuntimeError('interrupted transaction')

try:
    mod.run_owned_gateway_transaction([sys.executable, '-u', '-c', 'import time;time.sleep(30)'], broken_gateway, {})
except RuntimeError as exc:
    assert str(exc) == 'interrupted transaction'
    print('PASS: gateway exception propagates; owned child terminated and reaped')
else:
    raise AssertionError('Unexpected success')

try:
    mod.run_owned_gateway_transaction([sys.executable, '-u', '-c', 'import time;time.sleep(30)'],
                                      lambda *, incoming, outgoing: incoming.readline(), {}, line_timeout=0.1)
except TimeoutError:
    print('PASS: stalled gateway response fails closed and child reaped')
else:
    raise AssertionError('Unexpected success')

print('LIMIT: no trusted SSH endpoint, source lock/pin, Btrfs or production deletion')
