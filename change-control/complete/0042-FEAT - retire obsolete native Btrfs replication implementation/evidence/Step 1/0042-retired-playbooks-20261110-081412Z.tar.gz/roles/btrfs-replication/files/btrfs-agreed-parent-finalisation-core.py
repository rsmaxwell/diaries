#!/usr/bin/env python3
"""0040 Step 12.3: INTERNAL, fail-closed receiver finalisation transaction.

No CLI, SSH endpoint, pin promotion or prune authority. This composes trusted
lock-held readers/writers; adapters MUST be selected by fixed installed code,
never by remote caller. The source-success assertion is not itself evidence:
its authenticated binding and independent sender exit verification remain an
external prerequisite, deliberately required by this interface.
"""
import re
import uuid

NONCE = re.compile(r'[0-9a-f]{64}\Z')

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')

class FinalisationRefused(RuntimeError):
    pass


def identity(item):
    if (type(item) is not dict or set(item) != {'timestamp', 'uuid'} or
            type(item['timestamp']) is not str or not STAMP.fullmatch(item['timestamp']) or
            type(item['uuid']) is not str or not UUID.fullmatch(item['uuid'])):
        raise FinalisationRefused('invalid A/B identity')
    return item


def validate_provisional_journal(journal, parent, candidate):
    """Accept only the legacy or boot-bound scoped reservation schema.

    Scope reservation is not termination or cleanup evidence. Finalisation
    still requires independently authenticated source/receiver completion.
    """
    legacy = {'schema', 'status', 'parent', 'candidate', 'nonce'}
    scoped = legacy | {'scope_unit', 'scope_binding', 'receiver_boot_id'}
    staged = scoped | {'staging'}
    witnessed = staged | {'publication_witness'}
    if (type(journal) is not dict or set(journal) not in (legacy, scoped, staged, witnessed) or
            type(journal.get('schema')) is not int or journal['schema'] != 1 or
            journal.get('status') != 'receiving' or
            journal.get('parent') != parent or journal.get('candidate') != candidate or
            type(journal.get('nonce')) is not str or
            NONCE.fullmatch(journal['nonce']) is None):
        raise FinalisationRefused('provisional journal mismatch')
    if set(journal) in (scoped, staged, witnessed):
        expected = ('btrfs-agreed-receive-' + candidate['timestamp'] + '-' +
                    journal['nonce'][:16] + '.scope')
        if (journal['scope_unit'] != expected or
                journal['scope_binding'] != 'reserved-not-termination-evidence' or
                type(journal['receiver_boot_id']) is not str):
            raise FinalisationRefused('invalid scoped journal binding')
        try:
            boot = uuid.UUID(journal['receiver_boot_id'])
        except (ValueError, AttributeError) as exc:
            raise FinalisationRefused('invalid scoped journal boot ID') from exc
        if str(boot) != journal['receiver_boot_id'] or boot.version != 4:
            raise FinalisationRefused('invalid scoped journal boot ID')
    if set(journal) in (staged, witnessed):
        binding = journal['staging']
        if (type(binding) is not dict or
                set(binding) != {'directory_dev', 'directory_ino'} or
                any(type(binding[key]) is not int for key in binding) or
                binding['directory_dev'] < 0 or binding['directory_ino'] <= 0):
            raise FinalisationRefused('invalid staged filesystem binding')
    if set(journal) == witnessed:
        witness = journal['publication_witness']
        if (type(witness) is not dict or
                set(witness) != {'subvolume_uuid', 'received_uuid'} or
                type(witness['subvolume_uuid']) is not str or
                not UUID.fullmatch(witness['subvolume_uuid']) or
                witness['received_uuid'] != candidate['uuid']):
            raise FinalisationRefused('invalid publication witness')
    return journal


def finalize_locked(parent, candidate, *, read_state, read_journal,
                    verify_source_completion, inspect_received, receipt_absent,
                    commit_receipt, receipt_fields, manager_lock_held=False,
                    writer_lock_held=False):
    """Write a B receipt only after strict reconciliation under BOTH locks.

    No journal deletion: unresolved or completed provisional journal is retained
    until a separately reviewed promotion/recovery protocol has been accepted.
    An uncertain commit is never retried automatically.
    """
    identity(parent); identity(candidate)
    if not parent['timestamp'] < candidate['timestamp']:
        raise FinalisationRefused('invalid incremental ordering')
    if manager_lock_held is not True or writer_lock_held is not True:
        raise FinalisationRefused('receiver locks not held')
    callbacks = (read_state, read_journal, verify_source_completion,
                 inspect_received, receipt_absent, commit_receipt)
    if not all(callable(fn) for fn in callbacks):
        raise FinalisationRefused('missing trusted finalisation adapters')
    state = read_state()
    if (type(state) is not dict or set(state) != {'schema', 'established', 'pending', 'previous'} or
            type(state['schema']) is not int or state['schema'] != 1 or
            state['established'] != parent or state['pending'] != candidate or state['previous'] is not None):
        raise FinalisationRefused('agreed-parent state changed')
    journal = read_journal()
    validate_provisional_journal(journal, parent, candidate)
    if 'staging' in journal:
        raise FinalisationRefused('staged transaction requires staged publication finaliser')
    # This trusted callback MUST establish authenticated session binding and
    # independently observed source-send AND SSH exit == 0; never a wire flag.
    proof = verify_source_completion(parent, candidate, journal['nonce'])
    if proof != {'authenticated_session': True, 'source_send_exit': 0,
                 'ssh_exit': 0, 'receiver_receive_exit': 0,
                 'parent': parent, 'candidate': candidate}:
        raise FinalisationRefused('authenticated sender completion unproven')
    observed = inspect_received(candidate['timestamp'])
    if (type(observed) is not dict or observed.get('flags') != 'readonly' or
            observed.get('received_uuid') != candidate['uuid'] or
            type(observed.get('uuid')) is not str or not observed['uuid']):
        raise FinalisationRefused('received B identity unverified')
    if receipt_absent(candidate['timestamp']) is not True:
        raise FinalisationRefused('receipt exists or absence uncertain')
    if (type(receipt_fields) is not dict or
            receipt_fields.get('snapshot') != candidate['timestamp'] or
            receipt_fields.get('source_uuid') != candidate['uuid'] or
            receipt_fields.get('received_uuid') != candidate['uuid'] or
            receipt_fields.get('parent_snapshot') != parent['timestamp'] or
            receipt_fields.get('parent_source_uuid') != parent['uuid'] or
            receipt_fields.get('transport') != 'btrfs-incremental' or
            receipt_fields.get('read_only_verified') is not True or
            type(receipt_fields.get('source_send_exit')) is not int or
            receipt_fields['source_send_exit'] != 0 or
            type(receipt_fields.get('receiver_receive_exit')) is not int or
            receipt_fields['receiver_receive_exit'] != 0):
        raise FinalisationRefused('unsafe receipt contents')
    try:
        commit_receipt(candidate['timestamp'], receipt_fields)
    except Exception as exc:
        raise FinalisationRefused('uncertain receipt commit; manual reconciliation') from exc
    return {'schema': 1, 'status': 'receiver-receipt-committed-promotion-pending',
            'parent': parent, 'candidate': candidate, 'journal_retained': True,
            'receipt_committed': True, 'state_changed': False,
            'authorizes_transition': False, 'authorizes_prune': False,
            'authorizes_release': False}


def finalize_staged_locked(parent, candidate, *, read_state, read_journal,
                           verify_source_completion, inspect_staged,
                           record_publication_witness, publish_staged,
                           inspect_published, receipt_absent, commit_receipt,
                           receipt_fields, published_absent=None, manager_lock_held=False,
                           writer_lock_held=False):
    """Authenticated staged publication + receipt commit under receiver locks.

    The journal witness is durable BEFORE the atomic no-overwrite rename.
    If the process crashes after publication, rerunning with the same verified
    witness may roll forward, but must never delete or overwrite the snapshot.
    Callbacks are trusted receiver-local operations, NOT externally selectable
    RPC options. Missing/ambiguous evidence always fails closed.
    """
    identity(parent); identity(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise FinalisationRefused('invalid parent/candidate order')
    if manager_lock_held is not True or writer_lock_held is not True:
        raise FinalisationRefused('both receiver locks required')
    functions = (read_state, read_journal, verify_source_completion, inspect_staged,
                 record_publication_witness, publish_staged, inspect_published,
                 receipt_absent, commit_receipt)
    if not all(callable(fn) for fn in functions):
        raise FinalisationRefused('trusted staged finalisation adapters required')
    state = read_state()
    if (type(state) is not dict or set(state) !=
            {'schema', 'established', 'pending', 'previous'} or
            state.get('schema') != 1 or state.get('established') != parent or
            state.get('pending') != candidate or state.get('previous') is not None):
        raise FinalisationRefused('agreed-parent state changed')
    journal = validate_provisional_journal(read_journal(), parent, candidate)
    if 'staging' not in journal:
        raise FinalisationRefused('transaction is not staged')
    if verify_source_completion(parent, candidate, journal['nonce']) != {
            'authenticated_session': True, 'source_send_exit': 0,
            'ssh_exit': 0, 'receiver_receive_exit': 0,
            'parent': parent, 'candidate': candidate}:
        raise FinalisationRefused('authenticated sender completion unproven')
    if receipt_absent(candidate['timestamp']) is not True:
        raise FinalisationRefused('receipt exists or absence uncertain')
    if (type(receipt_fields) is not dict or
            receipt_fields.get('snapshot') != candidate['timestamp'] or
            receipt_fields.get('source_uuid') != candidate['uuid'] or
            receipt_fields.get('received_uuid') != candidate['uuid'] or
            receipt_fields.get('parent_snapshot') != parent['timestamp'] or
            receipt_fields.get('parent_source_uuid') != parent['uuid'] or
            receipt_fields.get('transport') != 'btrfs-incremental' or
            receipt_fields.get('read_only_verified') is not True or
            type(receipt_fields.get('source_send_exit')) is not int or
            receipt_fields['source_send_exit'] != 0 or
            type(receipt_fields.get('receiver_receive_exit')) is not int or
            receipt_fields['receiver_receive_exit'] != 0):
        raise FinalisationRefused('unsafe receipt contents')
    witness = journal.get('publication_witness')
    if witness is None:
        # A staged Btrfs inspection is proof of the received subvolume UUID,
        # but not permission to publish without the authenticated sender proof.
        stage = inspect_staged(candidate, journal['nonce'])
        if (type(stage) is not dict or
                stage.get('status') != 'staged-received-verified' or
                stage.get('candidate') != candidate or
                stage.get('receipt_committed') is not False or
                stage.get('publication_authorized') is not False or
                stage.get('cleanup_authorized') is not False or
                type(stage.get('subvolume_uuid')) is not str or
                not UUID.fullmatch(stage['subvolume_uuid'])):
            raise FinalisationRefused('unverified staged Btrfs identity')
        witness = {'subvolume_uuid': stage['subvolume_uuid'],
                   'received_uuid': candidate['uuid']}
        # Must atomically fsync the journal and parent BEFORE publication.
        record_publication_witness(journal, witness)
        updated = validate_provisional_journal(read_journal(), parent, candidate)
        if updated.get('publication_witness') != witness or updated.get('staging') != journal['staging']:
            raise FinalisationRefused('publication witness not durably read back')
        publication = publish_staged(candidate, updated)
        if (type(publication) is not dict or
                publication.get('status') != 'published-awaiting-receipt' or
                publication.get('receipt_committed') is not False or
                publication.get('cleanup_authorized') is not False):
            raise FinalisationRefused('publication uncertain; preserve journal')
    else:
        # The witness was fsynced before the no-overwrite rename. A crash may
        # therefore leave either an intact staged candidate or a published one.
        # Only the trusted receiver-local absence reader may decide which path
        # applies. An ambiguous result must never trigger a rename or deletion.
        if not callable(published_absent):
            raise FinalisationRefused('trusted published-absence check required')
        absent = published_absent(candidate['timestamp'])
        if type(absent) is not bool:
            raise FinalisationRefused('published absence uncertain')
        if absent:
            stage = inspect_staged(candidate, journal['nonce'])
            if (type(stage) is not dict or
                    stage.get('status') != 'staged-received-verified' or
                    stage.get('candidate') != candidate or
                    stage.get('subvolume_uuid') != witness['subvolume_uuid'] or
                    stage.get('receipt_committed') is not False or
                    stage.get('publication_authorized') is not False or
                    stage.get('cleanup_authorized') is not False or
                    witness['received_uuid'] != candidate['uuid']):
                raise FinalisationRefused('witnessed staged identity mismatch')
            # Record is already durable; do not rewrite or rebind the witness.
            publication = publish_staged(candidate, journal)
            if (type(publication) is not dict or
                    publication.get('status') != 'published-awaiting-receipt' or
                    publication.get('receipt_committed') is not False or
                    publication.get('cleanup_authorized') is not False):
                raise FinalisationRefused('publication uncertain; preserve journal')
        # Otherwise the final path exists. Independently inspect and compare
        # its exact Btrfs identity with the persisted witness below.
    published = inspect_published(candidate['timestamp'])
    if (type(published) is not dict or
            published.get('flags') != 'readonly' or
            published.get('received_uuid') != candidate['uuid'] or
            published.get('uuid') != witness['subvolume_uuid']):
        raise FinalisationRefused('published Btrfs identity mismatch; preserve journal')
    if receipt_absent(candidate['timestamp']) is not True:
        raise FinalisationRefused('receipt appeared during publication')
    try:
        commit_receipt(candidate['timestamp'], receipt_fields)
    except Exception as exc:
        raise FinalisationRefused('uncertain staged receipt commit; reconcile') from exc
    return {'schema': 1, 'status': 'receiver-receipt-committed-promotion-pending',
            'parent': parent, 'candidate': candidate, 'journal_retained': True,
            'receipt_committed': True, 'state_changed': False,
            'authorizes_transition': False, 'authorizes_prune': False,
            'authorizes_release': False, 'cleanup_authorized': False}
