#!/usr/bin/python3
"""0040 Step 12.3 Integration 04B: dormant exact-parent transfer transport contract.

Pure validation/building only. This file does not execute send, receive, SSH,
state mutation, promotion, retention or source-release commands.
"""
import re

STAMP = re.compile(r"[0-9]{8}-[0-9]{6}Z\Z")
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z")
RECEIVER = '/usr/local/bin/btrfs-native-push-receiver'
SOURCE_ENDPOINT = '/usr/local/libexec/btrfs-native-endpoint'
SSH = ('ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1')

class Refused(RuntimeError):
    pass

def identity(item):
    if type(item) is not dict or set(item) != {'timestamp', 'uuid'}:
        raise Refused('invalid snapshot identity fields')
    stamp, uuid = item['timestamp'], item['uuid']
    if type(stamp) is not str or not STAMP.fullmatch(stamp):
        raise Refused('invalid timestamp')
    if type(uuid) is not str or not UUID.fullmatch(uuid):
        raise Refused('invalid snapshot UUID')
    return stamp, uuid

def exact_incremental_commands(parent, candidate):
    """Construct the *only* supported A->B transfer commands; never execute.

    Caller must independently hold source push lock and verify locked source and
    authenticated receiver prepared states before invoking these commands.
    """
    a, au = identity(parent)
    b, bu = identity(candidate)
    if b <= a or b == a:
        raise Refused('candidate must be newer than parent')
    common = ('--snapshot', b, '--source-uuid', bu,
              '--parent', a, '--parent-uuid', au)
    return {'parent': {'timestamp': a, 'uuid': au},
            'candidate': {'timestamp': b, 'uuid': bu},
            'receiver_plan': (RECEIVER, *common),
            'sender': ('sudo', '-n', SOURCE_ENDPOINT, '--role',
                       'incremental-source', '--snapshot', b, '--parent', a),
            'receiver_accept': (*SSH, RECEIVER, *common, '--accept'),
            'authorizes_transfer': False,
            'authorizes_prune': False,
            'authorizes_release': False}

def validate_receiver_plan(plan, parent, candidate):
    """Fail closed on the existing receiver's pre-stream validation response."""
    commands = exact_incremental_commands(parent, candidate)
    p, c = commands['parent'], commands['candidate']
    expected = {'snapshot': c['timestamp'], 'source_uuid': c['uuid'],
                'parent': p['timestamp'], 'parent_uuid': p['uuid'],
                'action': 'incremental'}
    if type(plan) is not dict or plan != expected:
        raise Refused('receiver plan does not match exact prepared identities')
    return True

def validate_receipt(receipt, parent, candidate):
    """Check identity fields only; caller must also verify receipt safety and
    receiver Btrfs readonly/received UUID under receiver locks.

    Passing this pure validation is never transfer or promotion authority.
    """
    commands = exact_incremental_commands(parent, candidate)
    p, c = commands['parent'], commands['candidate']
    if type(receipt) is not dict or not all((
        receipt.get('schema') == 1,
        receipt.get('transport') == 'btrfs-incremental',
        receipt.get('snapshot') == c['timestamp'],
        receipt.get('source_uuid') == c['uuid'],
        receipt.get('received_uuid') == c['uuid'],
        receipt.get('parent_snapshot') == p['timestamp'],
        receipt.get('parent_source_uuid') == p['uuid'],
        receipt.get('read_only_verified') is True,
        type(receipt.get('source_send_exit')) is int and receipt['source_send_exit'] == 0,
        type(receipt.get('receiver_receive_exit')) is int and receipt['receiver_receive_exit'] == 0,
    )):
        raise Refused('receipt identity/status mismatch')
    return True
