#!/usr/bin/env python3
"""0040 Step 12.3: internal binary Btrfs send -> SSH transport.

There is no production CLI, receiver finalisation or parent transition here.
Never treat an uncertain cleanup as successful transfer evidence.
"""
import os
import signal
import subprocess
import time


class StreamUncertain(RuntimeError):
    pass


def _group_alive(pid):
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return False
    return True


def _stop_group(proc, *, grace=2.0, clock=time.monotonic):
    """Bounded cleanup of a session; fail closed if descendants persist.

    Waiting for the leader is NOT equivalent to proving its group has gone.
    A remaining group requires operator reconciliation, not a receipt.
    """
    if proc is None:
        return
    pid = proc.pid
    if not _group_alive(pid):
        if proc.poll() is None:
            proc.wait(timeout=grace)
        return
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(pid, sig)
        except ProcessLookupError:
            pass
        end = clock() + grace
        while clock() < end:
            try:
                proc.wait(timeout=min(0.05, max(0.001, end-clock())))
            except subprocess.TimeoutExpired:
                pass
            if not _group_alive(pid):
                return
            time.sleep(0.01)
    raise StreamUncertain('receive transport process group not gone; retain parent protection')


def run_binary_send_ssh(send_command, ssh_command, *, timeout_seconds=1800,
                        popen=subprocess.Popen, clock=time.monotonic):
    """Stream directly, observe BOTH local exits, and reject unresolved workers.

    Commands must be built by trusted installed code. No shell, no remote
    acknowledgement accepted as process evidence, no output logging of binary
    data. Receiver must separately verify the provisional journal.
    """
    if (not isinstance(send_command, (tuple, list)) or
        not isinstance(ssh_command, (tuple, list)) or
        not send_command or not ssh_command or
        any(type(x) is not str or not x for x in [*send_command, *ssh_command]) or
        type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 7200):
        raise StreamUncertain('invalid trusted command or deadline')
    sender = receiver = None
    deadline = clock() + timeout_seconds
    result = None
    failure = None
    try:
        sender = popen(list(send_command), stdout=subprocess.PIPE,
                       stderr=subprocess.DEVNULL, start_new_session=True)
        receiver = popen(list(ssh_command), stdin=sender.stdout,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        sender.stdout.close()
        sender_rc = sender.wait(timeout=max(0.001, deadline - clock()))
        receiver_rc = receiver.wait(timeout=max(0.001, deadline - clock()))
        if _group_alive(sender.pid) or _group_alive(receiver.pid):
            raise StreamUncertain('surviving transport process group')
        result = {'source_send_exit': sender_rc, 'ssh_exit': receiver_rc}
    except BaseException as exc:
        failure = exc
    # Cleanup is mandatory even for timeout/interrupt. Never mask an unsafe
    # cleanup outcome with earlier successful process exit codes.
    for proc in (receiver, sender):
        try:
            _stop_group(proc, clock=clock)
        except BaseException as exc:
            failure = exc
    if failure is not None:
        raise StreamUncertain('binary stream or cleanup uncertain; retain source pin') from failure
    return result
