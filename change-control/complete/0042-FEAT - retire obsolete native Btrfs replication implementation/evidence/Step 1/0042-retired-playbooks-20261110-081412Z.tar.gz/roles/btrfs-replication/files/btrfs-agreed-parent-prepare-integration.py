#!/usr/bin/python3
"""0040 3H.5l: dormant receiver preparation coordinator/contract integration.

The caller supplies independently verified locked observations and injected
transports. No locks, SSH, filesystem writes, or CLI exist in this module.
A verified result NEVER authorises source state advancement or transfer.
"""
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def load(name):
    path = BASE / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('agreed_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class IntegrationRefused(RuntimeError):
    pass


def coordinate(*, source_state, receiver_state, candidate, source_verified,
               invoke_prepare, read_receiver, contract=None, coordinator=None):
    """Issue at most one prepare and one recovery get-state under caller-held locks.

    The transport callbacks MUST be supplied by a future reviewed caller that
    owns both source locks and authenticates the remote receiver. They return
    (integer_exit_code, stdout). This dormant component cannot establish those
    properties, so its result grants NO mutation authority.
    """
    c = contract or load('prepare-transport-contract')
    p = coordinator or load('receiver-prepare')
    if source_verified is not True or not callable(invoke_prepare) or not callable(read_receiver):
        raise IntegrationRefused('missing independently verified source or transport')
    try:
        request = c.prepare_request(source_state, receiver_state, candidate)
        if c.expected_after(request) != dict(receiver_state, pending=candidate):
            raise IntegrationRefused('invalid expected durable postcondition')
    except (ValueError, RuntimeError, TypeError, KeyError) as exc:
        raise IntegrationRefused('prepare precondition refused') from exc

    calls = {'prepare': 0, 'recover': 0}

    def invoke(payload):
        calls['prepare'] += 1
        if calls['prepare'] != 1 or not isinstance(payload, str) or json.loads(payload) != request:
            raise IntegrationRefused('unexpected or repeated prepare payload')
        return invoke_prepare(payload)

    def recover(payload):
        calls['recover'] += 1
        if calls['recover'] != 1 or not isinstance(payload, str) or json.loads(payload) != {
            'schema': 1, 'operation': 'get-state',
            'transaction_id': request['transaction_id'],
            'expected_before': None, 'candidate': None
        }:
            raise IntegrationRefused('unexpected or repeated recovery request')
        return read_receiver(payload)

    try:
        outcome = p.prepare(source=source_state, receiver=receiver_state,
                            candidate=candidate, source_verified=True,
                            invoke=invoke, recover=recover)
        if (type(outcome) is not dict or
                outcome.get('status') not in ('receiver-prepared-verified', 'receiver-prepared-recovered') or
                outcome.get('receiver') != c.expected_after(request) or
                calls['prepare'] != 1 or calls['recover'] > 1):
            raise IntegrationRefused('unverified receiver postcondition')
        # The contract independently checks the successful result's exact schema.
        # A recovery reply has already been strictly checked by the coordinator.
        for key in ('authorizes_source_prepare', 'authorizes_transfer',
                    'authorizes_promote', 'authorizes_release'):
            if outcome.get(key) is not False:
                raise IntegrationRefused('unexpected state-changing authority')
        return {'schema': 1, 'status': outcome['status'], 'receiver': outcome['receiver'],
                'prepare_attempts': calls['prepare'], 'recovery_reads': calls['recover'],
                'authorizes_source_prepare': False, 'authorizes_transfer': False,
                'authorizes_promote': False, 'authorizes_prune': False,
                'authorizes_release': False}
    except Exception as exc:
        raise IntegrationRefused('receiver prepare not independently confirmed; do not retry') from exc
