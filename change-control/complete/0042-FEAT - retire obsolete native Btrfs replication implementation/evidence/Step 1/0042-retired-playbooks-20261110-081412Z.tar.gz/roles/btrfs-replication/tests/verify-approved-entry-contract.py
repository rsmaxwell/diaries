#!/usr/bin/env python3
"""Fail-closed regression for an undeployed privileged boundary (no Btrfs)."""
import importlib.util
import pathlib
import tempfile
import json
import os
from unittest import mock

HERE = pathlib.Path(__file__).resolve().parent
MODULE = HERE.parent / 'files' / 'btrfs-receiver-prune.py'
spec = importlib.util.spec_from_file_location('approved_boundary', MODULE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# Preserve the actual UID before mocking the shared os module.
actual_euid = os.geteuid()

with tempfile.TemporaryDirectory() as tmp:
    root = pathlib.Path(tmp)
    config = root / 'receiver.json'
    config.write_text(json.dumps({'mode':'receiver','receiver_prune_enabled':False}))
    config.chmod(0o600)
    with mock.patch.object(module.os, 'geteuid', return_value=1000):
        try:
            module.verify_root_and_config(config)
        except PermissionError:
            pass
        else:
            raise AssertionError('Unprivileged boundary was accepted')
    with mock.patch.object(module.os, 'geteuid', return_value=0):
        # Invalid mode and pruning configurations always fail, even when root.
        for value in ({'mode':'sender','receiver_prune_enabled':False},
                      {'mode':'receiver','receiver_prune_enabled':True}):
            config.write_text(json.dumps(value))
            try:
                module.verify_root_and_config(config)
            except RuntimeError:
                pass
            else:
                raise AssertionError('Unsafe config accepted')
        config.write_text(json.dumps({'mode':'receiver','receiver_prune_enabled':False}))
        if actual_euid == 0:
            assert module.verify_root_and_config(config)['mode'] == 'receiver'
        else:
            # Root file ownership cannot be faked: default fail-closed.
            try:
                module.verify_root_and_config(config)
            except RuntimeError:
                pass
            else:
                raise AssertionError('Non-root config ownership accepted')
        link = root / 'symlink.json'
        link.symlink_to(config)
        try:
            module.verify_root_and_config(link)
        except RuntimeError:
            pass
        else:
            raise AssertionError('Symlink accepted')

src = MODULE.read_text()
main = src.split('def main(argv=None):', 1)[1]
assert "selection.add_argument('--verify-boundary'" in main
assert "selection.add_argument('--transaction'" in main
assert 'run_unattended_receiver_transaction(' in main
assert 'run_receiver_prune_transaction(' not in main
assert 'run_internal_approved_transaction(' not in main
print('PASS: root-only receiver configuration and explicit transaction dispatch')
