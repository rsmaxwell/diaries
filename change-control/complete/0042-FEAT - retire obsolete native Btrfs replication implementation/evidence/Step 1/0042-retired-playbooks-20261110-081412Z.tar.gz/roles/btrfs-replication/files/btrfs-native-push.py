#!/usr/bin/env python3
"""0034 source-initiated Btrfs push. Manual snapshot selection or Step 11.4 --latest scheduling."""

# MODULE GUIDE: Source-initiated native Btrfs snapshot replication controller.  Runs on mars and
# drives a constrained receiver over outbound SSH to backup. Chooses a source snapshot and
# verified common parent, protects the parent against local pruning, and coordinates safe native
# send/receive. Private Step 3 challenge helpers exercise cross-host deletion coordination but
# are NOT a public deletion command or proof that production receiver pruning is enabled.  A
# source lock serializes this controller; pin state protects incremental ancestry; receiver
# receipts identify accepted snapshots. Failure/timeouts must preserve protection rather than
# guess that a remote operation finished.  This is the btrfs-replication role implementation,
# including Step 3 work.

import argparse
from contextvars import ContextVar
import fcntl
import json
import os
import signal
import time
from pathlib import Path
import re
import subprocess
import threading
import sys

# STAMP: Canonical UTC snapshot timestamp pattern; filters names before treating them as managed
# snapshots.
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
# ENDPOINT: Restricted remote/privileged transport and endpoint; not general command forwarding.
ENDPOINT = '/usr/local/libexec/btrfs-native-endpoint'
# REMOTE: Restricted remote/privileged transport and endpoint; not general command forwarding.
REMOTE = '/usr/local/bin/btrfs-native-push-receiver'
# SSH: Restricted remote/privileged transport and endpoint; not general command forwarding.
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1']
# LOCK: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
LOCK = Path('/media/usb/@snapshots/.native-push.lock')
# SOURCE_PARENT: Pinned filesystem or replication ancestry identity; mismatches must fail
# closed.
SOURCE_PARENT = 'fc4585b5-1649-b94c-bcb6-a9253c9cf080'

# Restrict every preparation subprocess to the remaining shared deadline.
_PREPARE_DEADLINE = ContextVar('btrfs_prepare_deadline', default=None)

def preparation_subprocess_timeout():
    deadline = _PREPARE_DEADLINE.get()
    if deadline is None:
        return 20
    remaining = deadline - time.monotonic()
    require(remaining > 0, 'Preparation deadline exceeded; source pin retained')
    return min(20, remaining)



# FUNCTION require: Check a security or consistency precondition; reject immediately rather than
# continuing with unsafe state. Inputs: value, message.
def require(value, message):
    if not value:
        raise RuntimeError(message)



# FUNCTION local: Call a specific privileged source endpoint role and decode its structured
# result. Inputs: role, snapshot, expected.
def local(role, snapshot, expected=None):
    args = ['sudo', '-n', ENDPOINT, '--role', role, '--snapshot', snapshot]
    if expected:
        args += ['--expected-uuid', expected]
    return json.loads(subprocess.run(args, capture_output=True, text=True, check=True, timeout=preparation_subprocess_timeout()).stdout)



# FUNCTION local_sources: Ask the source endpoint for managed snapshots rather than trusting
# arbitrary directory names.
def local_sources():
    result = subprocess.run(
        ['sudo', '-n', ENDPOINT, '--role', 'list-source'],
        capture_output=True, text=True, check=True, timeout=preparation_subprocess_timeout(),
    )
    values = json.loads(result.stdout)
    require(isinstance(values, list), 'Invalid local source list')
    return values



# FUNCTION remote: Invoke the constrained remote receiver over the configured outbound SSH
# transport.
def remote(*args):
    return subprocess.run(SSH + [REMOTE] + list(args), capture_output=True, text=True, check=True, timeout=preparation_subprocess_timeout()).stdout



# FUNCTION receiver_values: Parse a receiver response and enforce mandatory typed
# identity/receipt fields.
def receiver_values():
    values = json.loads(remote('--list'))
    require(isinstance(values, list), 'Invalid receiver parent list')
    return values



# FUNCTION choose_latest_source: Select the most recent validated source snapshot for unattended
# invocation.
def choose_latest_source():
    values = local_sources()
    candidates = [item for item in values if isinstance(item, dict) and STAMP.fullmatch(str(item.get('snapshot', '')))]
    require(candidates, 'No valid local source snapshots are available')
    latest = max(candidates, key=lambda item: item['snapshot'])
    require(re.fullmatch(r'[0-9a-f-]{36}', str(latest.get('uuid', ''))), 'Latest source has invalid UUID')
    return latest['snapshot'], latest['uuid']



# FUNCTION choose_parent: Select the best common ancestor whose source UUID agrees with a
# received receipt. Inputs: stamp, values.
def choose_parent(stamp, values=None):
    values = receiver_values() if values is None else values
    require(isinstance(values, list), 'Invalid receiver parent list')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for candidate in sorted(values, key=lambda item: item['snapshot'], reverse=True):
        previous = candidate['snapshot']
        if not STAMP.fullmatch(previous) or previous >= stamp:
            continue
        try:
            info = local('inspect-source', previous)
        except (subprocess.CalledProcessError, OSError, ValueError):
            continue
        if (info.get('flags') == 'readonly' and info.get('parent_uuid') == SOURCE_PARENT and
                info.get('received_uuid') in (None, '-') and info.get('uuid') == candidate['source_uuid']):
            return previous, info['uuid']
    return None, None




# FUNCTION inspect_common_parent: Independently verify the selected parent on both sides before
# an incremental transfer. Inputs: values.
def inspect_common_parent(values=None):
    """Read-only, current candidate common to accepted receiver and local source.

    Only a diagnostic observation. It is NOT a durable deletion approval: the
    sender lock used by main() is released after reporting and source pruning
    could then remove the snapshot. Receiver deletion must not trust this alone.
    """
    values = receiver_values() if values is None else values
    require(isinstance(values, list), 'Invalid receiver parent list')
    candidates = []
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for candidate in values:
        if not isinstance(candidate, dict):
            raise RuntimeError('Invalid receiver candidate')
        stamp = candidate.get('snapshot')
        uuid = candidate.get('source_uuid')
        require(isinstance(stamp, str) and STAMP.fullmatch(stamp), 'Invalid receiver snapshot')
        require(isinstance(uuid, str) and re.fullmatch(r'[0-9a-f-]{36}', uuid), 'Invalid receiver UUID')
        candidates.append((stamp, uuid))
    require(len({stamp for stamp, _ in candidates}) == len(candidates), 'Duplicate receiver snapshot')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for stamp, uuid in sorted(candidates, reverse=True):
        try:
            info = local('inspect-source', stamp)
        except (subprocess.CalledProcessError, OSError, ValueError):
            continue
        if (info.get('flags') == 'readonly' and info.get('parent_uuid') == SOURCE_PARENT and
                info.get('received_uuid') in (None, '-') and info.get('uuid') == uuid):
            return {'snapshot': stamp, 'source_uuid': uuid, 'verified': True,
                    'authorizes_prune': False}
    raise RuntimeError('No verified common replication parent; pruning prohibited')




# FUNCTION protect_common_parent: Persist the chosen source-side parent pin before any operation
# that depends on it. Inputs: values.
def protect_common_parent(values=None):
    """Persistently pin a verified common parent on mars, without authorising prune.

    This intentionally leaves the pin in place. The privileged source endpoint
    serialises its pin update with source pruning via the manager lock. A failed
    follow-up receiver check must not release the pin automatically.
    """
    observed = inspect_common_parent(values)
    stamp, uuid = observed['snapshot'], observed['source_uuid']
    pinned = local('protect-prune-source', stamp)
    require(pinned.get('source_uuid') == uuid, 'Common-parent pin UUID mismatch')
    # Revalidate both ends after source pinning. Any failure leaves the pin
    # installed for operator review; no deletion permission is issued.
    checked = inspect_common_parent()
    require(checked['snapshot'] == stamp and checked['source_uuid'] == uuid,
            'Common-parent identity changed after pinning; source pin retained')
    return {'snapshot': stamp, 'source_uuid': uuid, 'source_pinned': True,
            'receiver_verified_at_check': True, 'authorizes_prune': False}



# FUNCTION prepare_prune_parent: Prepare source protection for a possible receiver-retention
# operation without authorizing deletion.
def prepare_prune_parent():
    """Pin on source, then independently validate receiver under its writer lock.

    This is a non-destructive cross-host readiness check, not a prune lease.
    The durable pin remains until deliberately released by a later protocol.
    """
    pinned = protect_common_parent()
    stamp, uuid = pinned['snapshot'], pinned['source_uuid']
    checked = json.loads(remote('--check-protected-parent', '--snapshot', stamp,
                                '--source-uuid', uuid))
    require(checked.get('snapshot') == stamp and checked.get('source_uuid') == uuid and
            checked.get('receiver_verified_under_lock') is True and
            checked.get('authorizes_prune') is False,
            'Receiver did not verify protected parent under lock; pin retained')
    return {'snapshot': stamp, 'source_uuid': uuid, 'source_pinned': True,
            'receiver_verified_under_lock': True, 'authorizes_prune': False}




# FUNCTION prune_preflight: Collect and validate the receiver preflight and its common-parent
# prerequisites.
def prune_preflight():
    """Sender-locked, durable-pin readiness gate; never grants deletion authority.

    The existing --latest send path is unchanged. This operation intentionally
    does not issue any receiver-delete command: the receiver has no safe
    cross-host prune executor yet. It keeps source protection on failures.
    """
    checked = prepare_prune_parent()
    values = receiver_values()
    common = [item for item in values if item.get('snapshot') == checked['snapshot']
              and item.get('source_uuid') == checked['source_uuid']]
    require(len(common) == 1, 'Protected parent is not uniquely accepted; pin retained')
    return {'operation': 'receiver-prune-preflight', 'common_parent': checked['snapshot'],
            'source_uuid': checked['source_uuid'], 'source_pinned': True,
            'receiver_verified_under_lock': True, 'accepted_receiver_snapshots': len(values),
            'retention_candidates': 'not_calculated', 'authorizes_prune': False,
            'deletion_executed': False}




# FUNCTION validate_protected_plan: Reject a retention plan that fails to retain the expected
# protected parent or has inconsistent fields. Inputs: plan, parent_stamp, parent_uuid.
def validate_protected_plan(plan, *, parent_stamp, parent_uuid):
    """Fail closed on inconsistent receiver planning data; never authorise deletion.

    This checks transport/identity/count invariants, not receiver-side Btrfs
    eligibility. Every target still needs live receiver revalidation at execution.
    """
    require(isinstance(plan, dict), 'Receiver protected retention decision is not an object')
    require(plan.get('snapshot') == parent_stamp and plan.get('source_uuid') == parent_uuid and
            plan.get('receiver_verified_under_lock') is True and
            plan.get('authorizes_prune') is False and
            plan.get('deletion_executed') is False,
            'Receiver protected retention decision identity or safety flags invalid')
    candidates = plan.get('candidates')
    require(isinstance(candidates, list) and
            all(isinstance(name, str) and STAMP.fullmatch(name) for name in candidates),
            'Invalid receiver candidate identifiers')
    require(len(candidates) == len(set(candidates)), 'Duplicate receiver retention candidate')
    require(parent_stamp not in candidates, 'Protected parent listed for deletion')
    total, retained = plan.get('total'), plan.get('retained')
    require(type(total) is int and type(retained) is int and
            1 <= total and 1 <= retained <= total and
            len(candidates) == total - retained,
            'Inconsistent receiver retention counts')
    require(len(candidates) == 0 or all(name < parent_stamp for name in candidates),
            'Receiver candidate is not older than protected common parent')
    return plan



# FUNCTION protected_prune_plan: Request the receiver retention plan under the selected
# protection contract.
def protected_prune_plan():
    """Sender-held source pin + receiver-lock retention decision, never delete."""
    checked = prepare_prune_parent()
    stamp, uuid = checked['snapshot'], checked['source_uuid']
    plan = json.loads(remote('--protected-retention-plan', '--snapshot', stamp, '--source-uuid', uuid))
    validated = validate_protected_plan(plan, parent_stamp=stamp, parent_uuid=uuid)
    return {'operation': 'protected-prune-plan', 'source_pinned': True, **validated}


# FUNCTION validate_session_challenge: Validate nonce/session challenge fields and bind them to
# the selected source parent. Inputs: challenge, stamp, uuid.
def validate_session_challenge(challenge, stamp, uuid):
    """Validate receiver challenge before renewing the durable pruning pin."""
    require(isinstance(challenge, dict) and challenge.get('kind') == 'pin-challenge' and
            challenge.get('snapshot') == stamp and challenge.get('source_uuid') == uuid and
            isinstance(challenge.get('nonce'), str) and
            re.fullmatch(r'[0-9a-f]{64}', challenge['nonce']),
            'Invalid receiver pin challenge')
    return challenge['nonce']



# FUNCTION prune_session_check: Perform a non-destructive source/receiver coordination challenge
# for receiver retention.
def prune_session_check():
    """Lock-held cross-host handshake. Never authorises or attempts deletion."""
    checked = prepare_prune_parent()
    stamp, uuid = checked['snapshot'], checked['source_uuid']
    process = subprocess.Popen(SSH + [REMOTE, '--prune-session-check', '--snapshot', stamp,
                                     '--source-uuid', uuid], stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        line = process.stdout.readline()
        require(line and len(line) <= 4096, 'Missing receiver challenge')
        nonce = validate_session_challenge(json.loads(line), stamp, uuid)
        # Source endpoint obtains the manager lock and persists/validates the SAME pin.
        observed = local('protect-prune-source', stamp)
        require(observed.get('source_uuid') == uuid, 'Source pin changed during challenge')
        process.stdin.write(json.dumps({'kind': 'pin-response', 'nonce': nonce,
                                        'snapshot': stamp, 'source_uuid': uuid}) + '\n')
        process.stdin.flush()
        process.stdin.close()
        result_line = process.stdout.readline()
        require(result_line and len(result_line) <= 4096, 'Missing session result')
        result = json.loads(result_line)
        require(process.wait(timeout=30) == 0 and
                result.get('kind') == 'session-checked' and result.get('snapshot') == stamp and
                result.get('source_uuid') == uuid and result.get('source_pinned') is True and
                result.get('authorizes_prune') is False and result.get('deletion_executed') is False,
                'Untrusted receiver session result')
        return result
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()




# FUNCTION validate_candidate_challenge: Validate a candidate-specific challenge, session
# identity and expected protected parent. Inputs: challenge, stamp, uuid, candidate.
def validate_candidate_challenge(challenge, stamp, uuid, candidate):
    require(isinstance(challenge, dict) and challenge.get('kind') == 'candidate-pin-challenge' and
            challenge.get('candidate') == candidate, 'Invalid receiver candidate challenge')
    return validate_session_challenge({**challenge, 'kind': 'pin-challenge'}, stamp, uuid)



# FUNCTION prune_candidate_check: Check candidate-level coordination without enabling production
# receiver deletion. Inputs: candidate.
def prune_candidate_check(candidate):
    """Candidate-scoped SSH session. Never grants authority or deletes."""
    require(isinstance(candidate, str) and STAMP.fullmatch(candidate), 'Invalid candidate')
    checked = prepare_prune_parent()
    stamp, uuid = checked['snapshot'], checked['source_uuid']
    require(candidate < stamp, 'Candidate must be older than protected parent')
    process = subprocess.Popen(SSH + [REMOTE, '--prune-candidate-check', '--snapshot', stamp,
                                     '--source-uuid', uuid, '--candidate', candidate],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True)
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        line = process.stdout.readline()
        require(line and len(line) <= 4096, 'Missing receiver candidate challenge')
        nonce = validate_candidate_challenge(json.loads(line), stamp, uuid, candidate)
        observed = local('protect-prune-source', stamp)
        require(observed.get('source_uuid') == uuid, 'Source prune pin changed')
        process.stdin.write(json.dumps({'kind': 'candidate-pin-response', 'nonce': nonce,
                                        'snapshot': stamp, 'source_uuid': uuid,
                                        'candidate': candidate}) + '\n')
        process.stdin.flush()
        process.stdin.close()
        line = process.stdout.readline()
        require(line and len(line) <= 4096, 'Missing receiver candidate result')
        result = json.loads(line)
        require(process.wait(timeout=30) == 0 and
                result.get('kind') == 'candidate-session-checked' and
                result.get('snapshot') == stamp and result.get('source_uuid') == uuid and
                result.get('candidate') == candidate and
                result.get('source_pinned') is True and
                result.get('receiver_verified_under_lock') is True and
                result.get('authorizes_prune') is False and
                result.get('deletion_executed') is False,
                'Untrusted receiver candidate result')
        return result
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()




# FUNCTION answer_transaction_challenges: Coordinate an internal candidate transaction against
# validated identities and the existing journal contract. Inputs: process, stamp, uuid,
# candidate, protect_pin.
def answer_transaction_challenges(process, stamp, uuid, candidate, *, protect_pin=local):
    """INTERNAL sender half of an unexposed two-round transaction protocol.

    Caller must hold the normal source push lock for the entire subprocess life.
    This adapter is deliberately not wired into main(): no production deletion
    permission, command-line switch, or remote invocation is introduced.
    The caller owns process creation/teardown and must keep source protection
    persistent after any failure (including SSH disconnection).
    """
    require(isinstance(candidate, str) and STAMP.fullmatch(candidate) and candidate < stamp,
            'Invalid transaction candidate')
    require(isinstance(uuid, str) and re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', uuid),
            'Invalid transaction parent UUID')
    seen = set()
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    # Require a fresh source-pin proof for both phases, rather than accepting
    # one old acknowledgement as continuing authority.
    for round_number in (1, 2):
        line = process.stdout.readline(4097)
        require(line and len(line) <= 4096, 'Missing transaction challenge')
        challenge = json.loads(line)
        require(isinstance(challenge, dict) and
                challenge.get('kind') == 'transaction-pin-challenge' and
                challenge.get('candidate') == candidate,
                'Invalid transaction challenge')
        nonce = validate_session_challenge(
            {**challenge, 'kind': 'pin-challenge'}, stamp, uuid)
        require(nonce not in seen, 'Repeated transaction nonce')
        seen.add(nonce)
        observed = protect_pin('protect-prune-source', stamp)
        require(isinstance(observed, dict) and observed.get('source_uuid') == uuid,
                'Source prune pin changed during transaction')
        process.stdin.write(json.dumps({
            'kind': 'transaction-pin-response', 'nonce': nonce,
            'snapshot': stamp, 'source_uuid': uuid, 'candidate': candidate}) + '\n')
        process.stdin.flush()
    # Never interpret a challenge/ack as deletion success. Only a final,
    # journal-backed completion message from a successful receiver process counts.
    line = process.stdout.readline(4097)
    require(line and len(line) <= 4096, 'Missing transaction completion')
    result = json.loads(line)
    require(isinstance(result, dict) and
            result.get('kind') == 'transaction-completed' and
            result.get('snapshot') == candidate and
            result.get('protected_parent') == stamp and
            result.get('protected_parent_uuid') == uuid and
            result.get('journal_transaction_completed') is True,
            'Untrusted transaction completion')
    require(process.wait(timeout=30) == 0, 'Receiver transaction process failed')
    return result





# FUNCTION bounded_private_source_pin: Validate or preserve the source-side common-parent pin;
# reject missing or mismatched protection. Inputs: role, stamp, timeout.
def bounded_private_source_pin(role, stamp, *, timeout=15):
    """Private source-pin renewal with a bounded privileged endpoint subprocess.

    Timeouts do not release an existing durable pin. A blocked endpoint is
    treated as an uncertain transaction, never as evidence of protection.
    """
    require(role == 'protect-prune-source' and STAMP.fullmatch(stamp),
            'Invalid private pin renewal')
    require(0 < timeout <= 60, 'Invalid source-pin timeout')
    result = subprocess.run(
        ['sudo', '-n', ENDPOINT, '--role', role, '--snapshot', stamp],
        capture_output=True, text=True, check=True, timeout=timeout)
    return json.loads(result.stdout)



# FUNCTION terminate_private_process_group: Clean up the private subprocess/process group so
# timeouts cannot leave descendants holding pipes or locks. Inputs: process, grace.
def terminate_private_process_group(process, *, grace):
    """Reap the owned group, including children retaining stdout/stderr pipes."""
    # Private owner always starts the child in a fresh process session.
    if process.pid is None:
        raise RuntimeError('Private subprocess PID unavailable')
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        process.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        pass
    # Parent exit alone is not sufficient: descendants may retain pipes.
    try:
        # Kill the whole owned process group, not merely the direct child.
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait()



# FUNCTION run_private_transaction_process: Run and supervise a private subprocess with bounded
# lifetime and explicit cleanup of child processes. Inputs: command, stamp, uuid, candidate,
# source_lock, protect_pin, spawn, abort_timeout, transaction_timeout.
def run_private_transaction_process(command, stamp, uuid, candidate, *,
                                    source_lock=LOCK, protect_pin=None,
                                    spawn=subprocess.Popen, abort_timeout=3, transaction_timeout=120,
                                    prepare_transaction=None):
    """INTERNAL process lifetime owner; deliberately not called by main().

    The caller supplies the disposable transport command. This does NOT create
    a receiver deletion endpoint, authorise a snapshot, or release the durable
    source pruning pin. The lock remains held through process reaping.

    The watchdog enforces a wall-clock deadline for blocking transport reads.
    Default source-pin renewal has a separate subprocess timeout; injected pin
    callbacks must be independently bounded. This remains an internal adapter.
    """
    lock_path = Path(source_lock)
    require(lock_path.is_absolute() and not lock_path.is_symlink() and
            lock_path.is_file(), 'Unsafe source transaction lock')
    metadata = lock_path.stat()
    require(metadata.st_nlink == 1 and
            __import__('stat').S_ISREG(metadata.st_mode), 'Unsafe source lock type')
    require(isinstance(transaction_timeout, (int, float)) and not isinstance(transaction_timeout, bool)
            and 0 < transaction_timeout <= 3600, 'Invalid transaction deadline')
    if prepare_transaction is None:
        require(isinstance(command, (list, tuple)) and command and
                all(isinstance(a, str) and a for a in command), 'Invalid private transport')
    else:
        require(callable(prepare_transaction), 'Invalid transaction preparation callback')
    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with lock_path.open('r+') as lock_handle:
        fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Set the shared deadline BEFORE any parent inspection, pin or SSH plan.
        deadline = time.monotonic() + transaction_timeout
        if prepare_transaction is not None:
            token = _PREPARE_DEADLINE.set(deadline)
            try:
                command, stamp, uuid, candidate = prepare_transaction()
                require(isinstance(command, (list, tuple)) and command and
                        all(isinstance(a, str) and a for a in command), 'Invalid prepared transport')
                require(isinstance(stamp, str) and STAMP.fullmatch(stamp) and
                        isinstance(candidate, str) and STAMP.fullmatch(candidate) and
                        candidate < stamp, 'Invalid prepared parent or candidate')
                require(isinstance(uuid, str) and
                        re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', uuid),
                        'Invalid prepared protected UUID')
            finally:
                _PREPARE_DEADLINE.reset(token)
        require(deadline - time.monotonic() > 0,
                'Private transaction deadline exceeded during preparation; source pin retained')
        process = None
        finished = threading.Event()
        expired = threading.Event()
        watcher = None
        if protect_pin is None:

            # FUNCTION protect_pin: Validate or preserve the source-side common-parent pin;
            # reject missing or mismatched protection. Inputs: role, pin_stamp.
            def protect_pin(role, pin_stamp):
                remaining = deadline - time.monotonic()
                require(remaining > 0, 'Private transaction deadline exceeded; source pin retained')
                return bounded_private_source_pin(role, pin_stamp, timeout=min(15, remaining))
        try:
            process = spawn(list(command), stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            text=True, bufsize=1, start_new_session=True)

            # FUNCTION enforce_deadline: Handle enforce deadline for the restricted native Btrfs
            # replication workflow; reject invalid or unsafe inputs.
            def enforce_deadline():
                if not finished.wait(max(0, deadline - time.monotonic())):
                    expired.set()
                    # Kill the whole session: children can retain pipe FDs
                    # after the immediate SSH process has exited.
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass

            watcher = threading.Thread(target=enforce_deadline, daemon=True)
            watcher.start()
            try:
                result = answer_transaction_challenges(
                    process, stamp, uuid, candidate, protect_pin=protect_pin)
            except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired,
                    subprocess.CalledProcessError) as exc:
                if expired.is_set():
                    raise RuntimeError('Private transaction deadline exceeded; source pin retained') from exc
                raise
            require(not expired.is_set(),
                    'Private transaction deadline exceeded; source pin retained')
            return result
        finally:
            finished.set()
            if watcher is not None:
                watcher.join(timeout=abort_timeout + 1)
            if process is not None:
                # Closing input signals EOF to a waiting receiver and permits
                # its two lock contexts to unwind without journal modification.
                if process.stdin is not None and not process.stdin.closed:
                    try:
                        process.stdin.close()
                    except OSError:
                        pass
                terminate_private_process_group(process, grace=abort_timeout)
                for stream in (process.stdout, process.stderr):
                    if stream is not None:
                        stream.close()
                # Deliberately never remove the durable source prune pin.



# The operational CLI dispatches this coordinator outside the normal push lock.
# Receiver deletion remains independently gated by manager, receipts and journal.
RECEIVER_PRUNE_GATEWAY = '/usr/local/sbin/btrfs-receiver-prune'


def build_receiver_prune_command(parent, parent_uuid, candidate):
    """Fixed receiver-only gateway; do not allow caller-supplied SSH or paths."""
    require(isinstance(parent, str) and STAMP.fullmatch(parent) and
            isinstance(candidate, str) and STAMP.fullmatch(candidate) and
            candidate < parent, 'Invalid receiver-only retention boundary')
    require(isinstance(parent_uuid, str) and
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', parent_uuid),
            'Invalid protected parent UUID')
    return SSH + ['sudo', '-n', RECEIVER_PRUNE_GATEWAY, '--transaction',
                  '--protected-parent', parent, '--parent-uuid', parent_uuid,
                  '--candidate', candidate]


def run_unattended_prune_one(candidate, *, run_transaction=run_private_transaction_process,
                             build_command=None, **runner_kwargs):
    """Prepare one retention candidate under the supervisor's SINGLE source lock.

    The receiver independently recalculates eligibility and enforces the
    deletion journal. A failure never removes the durable source pin.
    """
    require(isinstance(candidate, str) and STAMP.fullmatch(candidate),
            'Invalid unattended prune candidate')
    require(build_command is not None and callable(build_command),
            'Receiver transport command builder required')

    def prepare():
        parent = prepare_prune_parent()
        stamp, uuid = parent['snapshot'], parent['source_uuid']
        require(candidate < stamp, 'Candidate not older than common parent')
        raw = remote('--protected-retention-plan', '--snapshot', stamp,
                     '--source-uuid', uuid)
        plan = validate_protected_plan(json.loads(raw), parent_stamp=stamp,
                                       parent_uuid=uuid)
        require(candidate in plan['candidates'], 'Candidate not retained for deletion by plan')
        return build_command(stamp, uuid, candidate), stamp, uuid, candidate

    return run_transaction(None, None, None, None,
                           prepare_transaction=prepare, **runner_kwargs)


# 0040 Step 3: independent approval contract for a future manual receiver prune.
# This is deliberately an internal validator, NOT a command-line option or an
# authorization to invoke receiver deletion. The future coordinator must still
# acquire source/receiver locks, renew the source pin, and recheck retention.
def validate_prune_approval(path, *, candidate, parent_stamp, parent_uuid, now=None):
    """Validate a root-owned, one-target approval without executing an action.

    An approval is tied to a specific candidate and verified common-parent UUID.
    It expires at an explicit UTC second. No wildcards, broad grants or implicit
    fallback values are accepted. A later stage must add one-time consumption and
    lock-held transaction binding before production use.
    """
    import datetime
    import stat

    require(isinstance(path, Path) and path.is_absolute(), 'Approval path must be absolute')
    require(not path.is_symlink(), 'Approval symlink forbidden')
    require(path.parent.is_dir() and not path.parent.is_symlink(), 'Unsafe approval directory')
    metadata = path.stat()
    require(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1,
            'Approval must be a single regular file')
    require(metadata.st_uid == 0 and metadata.st_mode & 0o077 == 0,
            'Approval must be root-owned and inaccessible to group/others')
    require(STAMP.fullmatch(candidate) and STAMP.fullmatch(parent_stamp) and
            candidate < parent_stamp, 'Invalid ordered candidate and parent')
    require(isinstance(parent_uuid, str) and re.fullmatch(
            r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', parent_uuid),
            'Invalid parent source UUID')
    with path.open('rb') as approval:
        require(os.fstat(approval.fileno()).st_ino == metadata.st_ino and
                os.fstat(approval.fileno()).st_dev == metadata.st_dev,
                'Approval changed during opening')
        payload = approval.read(4097)
    require(len(payload) <= 4096, 'Approval oversized')
    data = json.loads(payload)
    require(isinstance(data, dict) and set(data) == {
        'schema', 'operation', 'candidate', 'protected_parent',
        'protected_parent_uuid', 'expires_at_utc', 'reason'},
        'Unexpected approval fields')
    require(type(data['schema']) is int and data['schema'] == 1 and
            data['operation'] == 'receiver-prune-one' and
            data['candidate'] == candidate and
            data['protected_parent'] == parent_stamp and
            data['protected_parent_uuid'] == parent_uuid and
            isinstance(data['reason'], str) and 1 <= len(data['reason'].strip()) <= 500,
            'Approval identity or justification mismatch')
    require(isinstance(data['expires_at_utc'], str) and re.fullmatch(
            r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z', data['expires_at_utc']),
            'Invalid approval expiry format')
    expiry = datetime.datetime.strptime(data['expires_at_utc'],
                                        '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=datetime.timezone.utc)
    clock = now if now is not None else datetime.datetime.now(datetime.timezone.utc)
    require(clock.tzinfo is not None and clock.utcoffset() is not None,
            'Clock must be timezone-aware')
    require(clock < expiry <= clock + datetime.timedelta(hours=1),
            'Approval expired or exceeds one-hour validity')
    return {'candidate': candidate, 'protected_parent': parent_stamp,
            'protected_parent_uuid': parent_uuid, 'expires_at_utc': data['expires_at_utc']}


# FUNCTION accepted: Interpret receiver acceptance only after verifying the status and agreed
# snapshot identity. Inputs: values, stamp, uuid.
def accepted(values, stamp, uuid):
    return any(item.get('snapshot') == stamp and item.get('source_uuid') == uuid for item in values)



# FUNCTION main: Parse the allowlisted command interface; validate inputs, acquire required
# locks and dispatch roles.
def main():
    parser = argparse.ArgumentParser()
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument('--snapshot')
    selection.add_argument('--latest', action='store_true', help='Push newest valid local snapshot incrementally; never reseed')
    selection.add_argument('--agreed-parent', metavar='TIMESTAMP', help='Guarded agreed-parent mode: read-only review only')
    selection.add_argument('--check-common-parent', action='store_true', help='Read-only parent observation; not a prune approval')
    selection.add_argument('--protect-common-parent', action='store_true', help='Persistently pin a verified common parent on mars; not a prune approval')
    selection.add_argument('--prepare-prune-parent', action='store_true', help='pin on mars, validate receiver under lock; no deletion approval')
    selection.add_argument('--prune-preflight', action='store_true', help='sender-held, pinned cross-host readiness preflight; never deletes')
    selection.add_argument('--prune-session-check', action='store_true', help='live challenge/response without deletion')
    selection.add_argument('--prune-candidate-check', metavar='TIMESTAMP', help='non-destructive candidate eligibility handshake')
    selection.add_argument('--protected-prune-plan', action='store_true', help='sender-held verified receiver retention plan; never deletes')
    selection.add_argument('--unattended-prune-one', metavar='TIMESTAMP', help='one receiver-only retention transaction; source snapshots never deleted')
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--reseed', action='store_true')
    args = parser.parse_args()
    require(os.geteuid() != 0, 'Run as ordinary operator')
    if args.agreed_parent is not None:
        require(not (args.preflight or args.full or args.reseed),
                '--agreed-parent accepts no legacy transfer options')
        require(STAMP.fullmatch(args.agreed_parent) is not None,
                'Invalid agreed-parent candidate timestamp')
        # No legacy parent selection, native transfer or release-source path is
        # reachable from this branch. The privileged read-only planner owns
        # both source locks, so DO NOT acquire the push lock here.
        planner = '/usr/local/libexec/btrfs-agreed-parent-locked-prepare-plan.py'
        result = subprocess.run(['sudo', '-n', planner, '--target', args.agreed_parent],
                                capture_output=True, text=True, check=True, timeout=90)
        require(len(result.stdout.encode('utf-8')) <= 65536, 'Oversized agreed-parent plan')
        plan = json.loads(result.stdout)
        require(type(plan) is dict and plan.get('status') == 'read-only-prepare-plan' and
                plan.get('schema') == 1, 'Invalid agreed-parent plan')
        required = ('authorizes_prepare', 'authorizes_source_prepare', 'authorizes_transfer',
                    'authorizes_promote', 'authorizes_prune', 'authorizes_release')
        require(all(plan.get(key) is False for key in required), 'Unexpected mutation authority')
        request = plan.get('request')
        require(type(request) is dict and request.get('operation') == 'prepare' and
                request.get('transaction_id') == args.agreed_parent and
                type(request.get('candidate')) is dict and
                request['candidate'].get('timestamp') == args.agreed_parent,
                'Agreed-parent candidate mismatch')
        print(json.dumps({'schema': 1, 'mode': 'agreed-parent', 'status': 'review-only',
                          'plan': plan, 'transfer_executed': False,
                          'state_changed': False, 'release_executed': False}, sort_keys=True))
        return
    require(not args.reseed or args.full, '--reseed requires --full')
    if args.unattended_prune_one is not None:
        require(not (args.preflight or args.full or args.reseed), 'Pruning accepts no transfer options')
        result = run_unattended_prune_one(
            args.unattended_prune_one, build_command=build_receiver_prune_command)
        print(json.dumps(result, sort_keys=True))
        return
    require(not (args.check_common_parent or args.protect_common_parent or args.prepare_prune_parent or args.prune_preflight or args.protected_prune_plan or args.prune_session_check or args.prune_candidate_check) or
            (not args.preflight and not args.full and not args.reseed),
            'Common-parent operations accept no transfer options')
    require(not args.latest or (not args.full and not args.reseed),
            '--latest is incremental-only; establish/reseed a baseline with explicit --snapshot')
    require(LOCK.is_file() and not LOCK.is_symlink() and LOCK.stat().st_nlink == 1, 'Unsafe push lock')
    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with LOCK.open('r+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.check_common_parent:
            print(json.dumps(inspect_common_parent(), sort_keys=True, indent=2))
            return
        if args.protect_common_parent:
            print(json.dumps(protect_common_parent(), sort_keys=True, indent=2))
            return
        if args.prepare_prune_parent:
            print(json.dumps(prepare_prune_parent(), sort_keys=True, indent=2))
            return
        if args.prune_preflight:
            print(json.dumps(prune_preflight(), sort_keys=True, indent=2))
            return
        if args.prune_session_check:
            print(json.dumps(prune_session_check(), indent=2, sort_keys=True))
            return
        if args.prune_candidate_check:
            print(json.dumps(prune_candidate_check(args.prune_candidate_check), indent=2, sort_keys=True))
            return
        if args.protected_prune_plan:
            print(json.dumps(protected_prune_plan(), sort_keys=True, indent=2))
            return
        if args.latest:
            snapshot, listed_uuid = choose_latest_source()
        else:
            snapshot, listed_uuid = args.snapshot, None
        require(snapshot is not None and STAMP.fullmatch(snapshot), 'Invalid timestamp')
        current = local('inspect-source', snapshot)
        require(current.get('flags') == 'readonly' and current.get('parent_uuid') == SOURCE_PARENT
                and current.get('received_uuid') in ('-', None), 'Invalid source snapshot')
        uuid = current['uuid']
        require(re.fullmatch(r'[0-9a-f-]{36}', uuid), 'Invalid source UUID')
        if listed_uuid is not None:
            require(uuid == listed_uuid, 'Latest-source UUID changed during selection')
        values = receiver_values()
        if accepted(values, snapshot, uuid):
            print(json.dumps({'source': snapshot, 'source_uuid': uuid, 'parent': None,
                              'action': 'already-accepted', 'dry_run': args.preflight,
                              'receiver': '10.254.22.1:39263'}, indent=2), flush=True)
            return
        parent, parent_uuid = (None, None) if args.full else choose_parent(snapshot, values)
        if args.latest:
            require(parent is not None,
                    '--latest requires an accepted common parent; use explicit --snapshot --full/--reseed for recovery')
        require(parent or args.full or not args.reseed, 'Invalid reseed selection')
        extra = ['--full'] if args.full or not parent else ['--parent', parent, '--parent-uuid', parent_uuid]
        if args.reseed:
            extra += ['--reseed']
        common = ['--snapshot', snapshot, '--source-uuid', uuid] + extra
        # Always ask receiver to validate its own receipts, parent, and destination.
        plan = json.loads(remote(*common))
        require(plan['snapshot'] == snapshot and plan['source_uuid'] == uuid, 'Receiver plan mismatch')
        print(json.dumps({'source': snapshot, 'source_uuid': uuid, 'parent': parent,
                          'action': plan['action'], 'dry_run': args.preflight,
                          'receiver': '10.254.22.1:39263'}, indent=2), flush=True)
        if args.preflight:
            return
        candidate = local('protect-source', snapshot)
        require(candidate['source_uuid'] == uuid, 'Candidate protection UUID mismatch')
        if parent:
            pinned = local('protect-source', parent)
            require(pinned['source_uuid'] == parent_uuid, 'Parent protection UUID mismatch')
        send = ['sudo', '-n', ENDPOINT, '--role', 'incremental-source' if parent else 'source', '--snapshot', snapshot]
        if parent:
            send += ['--parent', parent]
        with subprocess.Popen(send, stdout=subprocess.PIPE) as sender:
            with subprocess.Popen(SSH + [REMOTE] + common + ['--accept'], stdin=sender.stdout) as receiver:
                sender.stdout.close()
                receiver_rc = receiver.wait()
                send_rc = sender.wait()
        require(send_rc == 0 and receiver_rc == 0,
                f'Btrfs send/receive failed (send={send_rc}, receive={receiver_rc}); candidate stays protected')
        # A receiver receipt is authoritative; do not release parent on an absent receipt.
        listing = receiver_values()
        require(accepted(listing, snapshot, uuid),
                'Receiver has not accepted candidate; both snapshots stay protected')
        print('ACCEPTED: ' + snapshot, flush=True)
        if parent:
            try:
                local('release-source', parent, parent_uuid)
            except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
                print('WARNING: previous parent remains protected: ' + str(exc), file=sys.stderr)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, subprocess.CalledProcessError, BlockingIOError, KeyError) as exc:
        print('btrfs-native-push: ' + str(exc), file=sys.stderr)
        sys.exit(1)
