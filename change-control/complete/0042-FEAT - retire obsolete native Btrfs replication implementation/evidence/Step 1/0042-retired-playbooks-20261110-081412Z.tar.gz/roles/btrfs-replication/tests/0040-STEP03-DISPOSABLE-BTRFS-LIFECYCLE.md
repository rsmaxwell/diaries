# 0040-FEAT Step 3 — Isolated Btrfs lifecycle acceptance (sub-gate)

This script is **not** the completed approved receiver-delete transaction.
Its purpose is to demonstrate limited, real Btrfs creation/deletion safely in a
new namespace *outside* `/@data/mars-received` before testing transaction wiring.

- `--plan` (default recommended first): read-only preflight, mount and path checks.
- `--execute --accept-disposable-delete DELETE-ONLY-0040-DISPOSABLE`:
  explicit destructive rehearsal, requiring root. Creates a randomly named
  `/@data/.0040-disposable-acceptance-<32-hex>` subvolume and two children,
  writes one tiny file, creates a read-only Btrfs snapshot, validates it,
  and deletes exactly the three freshly created subvolumes.
- No `rm -rf`, glob deletion, traversing production snapshots or receipt mutation.
- On failures, do not auto-clean. Report exact path and inspect before any
  subsequent cleanup. The caller should confirm no existing namespace is present.
- Must never be added to sudoers or automated production schedules.
- No production `delete-receiver` privilege is enabled.

## Gates

1. Inspect script and run `--plan` on `backup` from `mango` via SSH.
2. Record plan, available capacity, and production journal `CLEAN`.
3. **Separate explicit operator approval** required before `--execute`.
4. Afterwards implement full isolated source-held approved transaction with
   actual manager journal, disposable receipts and interruption recovery.

Step 3 stays OPEN after this lifecycle rehearsal alone.
