#!/usr/bin/env python3
"""Dormant agreed-parent operator cycle; NOT a scheduled service.

Recovery of a committed transaction requires authenticated receipt verification
inside the sender; incomplete receives remain fail-closed, without retransmission.
"""
import argparse
import json
import re
import subprocess
import importlib.util
from pathlib import Path

SENDER = '/usr/local/bin/btrfs-agreed-parent-sender'
PREPARE = '/usr/local/bin/btrfs-agreed-parent-preparation-checkpoint'
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')

class Refused(RuntimeError):
    pass


def invoke(argv):
    result = subprocess.run(argv, capture_output=True, text=True, check=False)
    if result.returncode:
        raise Refused('%s failed (%s): %s' % (argv[0], result.returncode, result.stderr.strip()[:500]))
    try:
        return json.loads(result.stdout)
    except (ValueError, TypeError) as exc:
        raise Refused('unparseable command response') from exc


def cycle(target, *, execute=False, call=invoke):
    if not STAMP.fullmatch(target):
        raise Refused('invalid candidate timestamp')
    state_result = call([SENDER, '--inspect'])
    if state_result.get('status') != 'local-source-state-only' or state_result.get('authorizes_transfer') is not False:
        raise Refused('untrusted source inspection')
    state = state_result.get('state')
    if not isinstance(state, dict) or not isinstance(state.get('established'), dict):
        raise Refused('invalid source state')
    parent = state['established']['timestamp']
    if target <= parent:
        raise Refused('candidate must be newer than established parent')
    if state.get('pending') is not None:
        # An interrupted receive may have committed or left an incomplete destination.
        # No fresh send or automatic reconciliation is safe from local state alone.
        raise Refused('pending transaction requires authenticated receipt/journal reconciliation; no resend')
    if state.get('previous') is not None:
        if not execute:
            return {'status': 'previous-acknowledgement-required', 'state_changed': False}
        ack = call([SENDER, '--acknowledge-previous'])
        if ack.get('status') != 'both-previous-acknowledged' or ack.get('source_state') != ack.get('receiver_state'):
            raise Refused('previous acknowledgement not verified')
        state = ack['source_state']
        if state.get('pending') is not None or state.get('previous') is not None:
            raise Refused('state not idle after acknowledgement')
    review = call([PREPARE, '--target', target, '--review-only'])
    if review.get('status') != 'review-only' or review.get('state_changed') is not False:
        raise Refused('preparation review refused')
    if not execute:
        return {'status': 'cycle-review-only', 'target': target, 'parent': parent,
                'state_changed': False, 'authorizes_transfer': False}
    prepared = call([PREPARE, '--target', target, '--execute-preparation'])
    if prepared.get('status') != 'prepared-checkpoint' or prepared.get('source') != prepared.get('receiver'):
        raise Refused('preparation not durably confirmed; no transfer')
    done = call([SENDER, '--complete-prepared'])
    if (done.get('status') != 'prepared-cycle-ready' or
            done.get('source_state') != done.get('receiver_state') or
            done.get('authorizes_prune') is not False or done.get('authorizes_release') is not False):
        raise Refused('cycle completion not verified')
    final = done['source_state']
    if (final.get('pending') is not None or final.get('previous') is not None or
            final.get('established', {}).get('timestamp') != target):
        raise Refused('cycle finished in unexpected state')
    return {'status': 'cycle-ready', 'target': target, 'source_state': final,
            'receiver_state': done['receiver_state'], 'authorizes_prune': False,
            'authorizes_release': False}


def automatic_target(state, *, selector=None):
    """Choose a source candidate; only preparation may approve it."""
    if state.get('pending') is not None or state.get('previous') is not None:
        raise Refused('unfinished transaction requires reconciliation before selecting candidate')
    if selector is None:
        script = Path(__file__).with_name('btrfs-agreed-parent-candidate-selection.py')
        spec = importlib.util.spec_from_file_location('agreed_candidate_selection', script)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        selector = module.select_candidate
    candidate = selector(state['established']['timestamp'])
    return candidate['timestamp'] if candidate else None


def recover_unfinished(state, *, call=invoke):
    """Recover durable committed/promotion states without initiating a Btrfs send.

    The sender's committed recovery authenticates peer receipts independently.
    A pending provisional/incomplete receive will fail closed rather than resend.
    """
    if not isinstance(state, dict) or not isinstance(state.get('established'), dict):
        raise Refused('invalid source recovery state')
    pending, previous = state.get('pending'), state.get('previous')
    if pending is not None and previous is not None:
        raise Refused('ambiguous pending and previous state; no recovery mutation')
    if pending is None and previous is None:
        return {'status': 'already-idle', 'state_changed': False,
                'authorizes_prune': False, 'authorizes_release': False}
    expected = pending if pending is not None else state['established']
    if not isinstance(expected, dict) or not STAMP.fullmatch(str(expected.get('timestamp', ''))):
        raise Refused('invalid recovery candidate identity')
    if not expected.get('uuid'):
        raise Refused('recovery candidate UUID missing')
    operation = '--complete-committed' if pending is not None else '--acknowledge-previous'
    response = call([SENDER, operation])
    status = 'committed-cycle-ready' if pending is not None else 'both-previous-acknowledged'
    if (not isinstance(response, dict) or response.get('status') != status or
            response.get('authorizes_prune') is not False or
            response.get('authorizes_release') is not False or
            response.get('source_state') != response.get('receiver_state')):
        raise Refused('recovery not independently verified')
    final = response['source_state']
    if (not isinstance(final, dict) or final.get('established') != expected or
            final.get('pending') is not None or final.get('previous') is not None):
        raise Refused('recovery result differs from expected candidate or remains unfinished')
    return {'status': 'recovered-cycle-ready', 'recovery_operation': operation,
            'source_state': final, 'receiver_state': final,
            'authorizes_prune': False, 'authorizes_release': False}


def recovery_cycle(*, execute=False, call=invoke):
    """Explicit recovery-only entrypoint; never prepares/selects/sends a candidate."""
    observed = call([SENDER, '--inspect'])
    if (not isinstance(observed, dict) or
            observed.get('status') != 'local-source-state-only' or
            observed.get('authorizes_transfer') is not False):
        raise Refused('untrusted source inspection')
    state = observed.get('state')
    if not isinstance(state, dict) or not isinstance(state.get('established'), dict):
        raise Refused('invalid source state')
    if not execute:
        return {'status': 'recovery-review-only', 'pending': state.get('pending') is not None,
                'previous': state.get('previous') is not None,
                'state_changed': False, 'authorizes_transfer': False}
    return recover_unfinished(state, call=call)


def auto_cycle(*, execute=False, call=invoke, selector=None):
    """Select candidate from source, then use existing full preparation gates.

    Not scheduled. The preparation checkpoint owns the canonical locks across
    candidate selection and durable preparation. Transfer is an independent
    locked sender operation; it must revalidate the prepared identities.
    """
    if execute:
        # The checkpoint owns PUSH then MANAGER locks across selection,
        # identity validation and durable source/receiver preparation.
        # Never select a target in this process before the locked checkpoint.
        observed = call([SENDER, '--inspect'])
        if observed.get('status') != 'local-source-state-only' or observed.get('authorizes_transfer') is not False:
            raise Refused('untrusted source inspection')
        state = observed.get('state')
        if not isinstance(state, dict) or not isinstance(state.get('established'), dict):
            raise Refused('invalid source state')
        if state.get('pending') is not None or state.get('previous') is not None:
            # A recovery invocation never starts another send in the same cycle.
            return recover_unfinished(state, call=call)
        prepared = call([PREPARE, '--auto-target', '--execute-preparation'])
        if prepared.get('status') == 'no-eligible-candidate':
            if prepared.get('state_changed') is not False or prepared.get('transfer_executed') is not False:
                raise Refused('untrusted empty candidate response')
            return {'status':'no-eligible-candidate', 'state_changed':False}
        if (prepared.get('status') != 'prepared-checkpoint' or
                prepared.get('source') != prepared.get('receiver') or
                prepared.get('authorizes_transfer') is not False or
                prepared.get('authorizes_prune') is not False or
                prepared.get('authorizes_release') is not False):
            raise Refused('automatic preparation not durably confirmed; no transfer')
        pending = prepared['source'].get('pending')
        if not isinstance(pending, dict) or not STAMP.fullmatch(str(pending.get('timestamp', ''))):
            raise Refused('prepared candidate identity missing; no transfer')
        target = pending['timestamp']
        if target <= state['established']['timestamp']:
            raise Refused('prepared candidate not newer than observed parent')
        done = call([SENDER, '--complete-prepared'])
        if (done.get('status') != 'prepared-cycle-ready' or
                done.get('source_state') != done.get('receiver_state') or
                done.get('authorizes_prune') is not False or
                done.get('authorizes_release') is not False):
            raise Refused('automatic cycle completion not verified')
        final = done['source_state']
        if (not isinstance(final, dict) or final.get('pending') is not None or
                final.get('previous') is not None or
                final.get('established') != pending):
            raise Refused('automatic cycle ended in unexpected state')
        return {'status':'cycle-ready', 'target':target, 'auto_selected':True,
                'source_state':final, 'receiver_state':final,
                'authorizes_prune':False, 'authorizes_release':False}
    observed = call([SENDER, '--inspect'])
    if observed.get('status') != 'local-source-state-only' or observed.get('authorizes_transfer') is not False:
        raise Refused('untrusted source inspection')
    state = observed.get('state')
    if not isinstance(state, dict) or not isinstance(state.get('established'), dict):
        raise Refused('invalid source state')
    target = automatic_target(state, selector=selector)
    if target is None:
        return {'status': 'no-eligible-candidate', 'state_changed': False}
    result = cycle(target, execute=execute, call=call)
    result['auto_selected'] = True
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    targets = p.add_mutually_exclusive_group(required=True)
    targets.add_argument('--target')
    targets.add_argument('--auto-target', action='store_true')
    targets.add_argument('--recover-only', action='store_true')
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--review-only', action='store_true')
    g.add_argument('--execute', action='store_true')
    args = p.parse_args()
    result = (recovery_cycle(execute=args.execute) if args.recover_only else
              auto_cycle(execute=args.execute) if args.auto_target else
              cycle(args.target, execute=args.execute))
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (Refused, ValueError, KeyError, OSError) as exc:
        import sys
        print('agreed-parent cycle refused: ' + str(exc), file=sys.stderr)
        sys.exit(1)
