#!/usr/bin/python3
"""Source-level consolidation seam tests; no real SSH or Btrfs receive."""
import importlib.util
from pathlib import Path
import unittest

FILE=Path(__file__).resolve().parents[1] / 'files/btrfs-agreed-parent-receiver-entry.py'
spec=importlib.util.spec_from_file_location('entryconsolidation',FILE)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
A={'timestamp':'20261030-030033Z','uuid':'d901ddd2-66c7-0b42-b26c-ab6886273b7a'}
B={'timestamp':'20261030-170009Z','uuid':'a9b78fb9-4da6-cf4f-b242-13909f574193'}
class Stream:
    def read(self,n=-1): return b''
class Tests(unittest.TestCase):
    def test_default_refuses(self):
        with self.assertRaisesRegex(RuntimeError,'not enabled'):
            m.receive_candidate_internal(A,B,input_stream=Stream())
    def test_missing_stream_refuses(self):
        with self.assertRaisesRegex(RuntimeError,'binary stream'):
            m.receive_candidate_internal(A,B,input_stream=None)
    def test_single_delegation(self):
        seen=[]
        def integrated(a,b,*,input_stream):
            seen.append((a,b,input_stream))
            return {'status':'receiver-provisional-only','receipt_committed':False,
                    'transfer_finalized':False,'authorizes_transition':False,
                    'authorizes_prune':False,'authorizes_release':False}
        stream=Stream()
        r=m.receive_candidate_internal(A,B,input_stream=stream,dependencies={'integrated_receive':integrated})
        self.assertEqual(seen,[(A,B,stream)])
        self.assertFalse(r['receipt_committed'])
    def test_unsafe_result_refused(self):
        def unsafe(*a,**kw): return {'status':'receiver-provisional-only','receipt_committed':True}
        with self.assertRaisesRegex(RuntimeError,'unsafe'):
            m.receive_candidate_internal(A,B,input_stream=Stream(),dependencies={'integrated_receive':unsafe})
    def test_no_cli_execution_route(self):
        source=FILE.read_text()
        self.assertNotIn("add_argument('--execute",source)
        self.assertNotIn("add_argument('--accept",source)
        self.assertNotIn('receive_candidate_internal(parent, candidate, input_stream=sys.stdin',source)
    def test_dependencies_strict(self):
        with self.assertRaisesRegex(RuntimeError,'invalid internal'):
            m.receive_candidate_internal(A,B,input_stream=Stream(),dependencies={'integrated_receive':lambda *a:None,'extra':1})

if __name__=='__main__': unittest.main(verbosity=2)
