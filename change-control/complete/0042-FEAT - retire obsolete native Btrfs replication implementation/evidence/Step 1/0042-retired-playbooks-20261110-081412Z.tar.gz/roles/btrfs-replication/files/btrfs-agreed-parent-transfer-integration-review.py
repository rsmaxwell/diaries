#!/usr/bin/python3
"""0040-FEAT Step 12.3 Integration 04G: review-only transfer integration.

No transfer execution, receiver mutations, promotion, release or pruning.
A future production coordinator MUST independently validate receiver destination
absence and authenticated transfer execution identity before permitting a send.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/usr/local/libexec')


def load(name):
    path = ROOT / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('review04g_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_contract(review, commands, *, contract, adapter):
    """Pure, fail-closed A/B contract; never authorizes the proposed commands."""
    if type(review) is not dict or review.get('status') != 'prepared-transfer-review':
        raise RuntimeError('missing prepared transfer review')
    if any(review.get(k) is not False for k in (
            'state_changed', 'transfer_executed', 'release_executed',
            'authorizes_transfer', 'authorizes_promote', 'authorizes_prune',
            'authorizes_release')):
        raise RuntimeError('prepared review claimed authority')
    parent, candidate = review.get('parent'), review.get('candidate')
    if (type(parent) is not dict or type(candidate) is not dict or
            review.get('source') != review.get('receiver') or
            review['source'].get('established') != parent or
            review['source'].get('pending') != candidate or
            review['source'].get('previous') is not None):
        raise RuntimeError('prepared parent/candidate states disagree')
    if commands != contract.exact_incremental_commands(parent, candidate):
        raise RuntimeError('unexpected incremental transport contract')
    # Validate static command identities without launching processes.
    sender, receiver = adapter.exact_argv(commands, parent, candidate)
    if (not sender or not receiver or '--accept' not in receiver or
            '--role' not in sender):
        raise RuntimeError('unrecognized transport roles')
    return {'schema': 1, 'status': 'transfer-integration-review',
            'parent': parent, 'candidate': candidate,
            'source': review['source'], 'receiver': review['receiver'],
            'transport_contract_checked': True,
            'receiver_destination_absence_verified': False,
            'transport_execution_identity_verified': False,
            'state_changed': False, 'transfer_executed': False,
            'release_executed': False, 'authorizes_transfer': False,
            'authorizes_promote': False, 'authorizes_prune': False,
            'authorizes_release': False}


def run_review(timestamp, *, modules=None):
    if type(timestamp) is not str or not timestamp:
        raise RuntimeError('target required')
    d = modules if modules is not None else {
        name: load(name) for name in ('prepared-transfer-review',
                                      'transfer-transport-contract',
                                      'transfer-execution-adapter')}
    prepared = d['prepared-transfer-review'].review(timestamp)
    parent, candidate = prepared['parent'], prepared['candidate']
    commands = d['transfer-transport-contract'].exact_incremental_commands(parent, candidate)
    return check_contract(prepared, commands,
                          contract=d['transfer-transport-contract'],
                          adapter=d['transfer-execution-adapter'])


def main():
    p = argparse.ArgumentParser(description='Read-only integrated A/B transfer review')
    p.add_argument('--target', required=True)
    p.add_argument('--review-only', action='store_true', required=True)
    args = p.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(run_review(args.target), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        print('transfer integration review refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
