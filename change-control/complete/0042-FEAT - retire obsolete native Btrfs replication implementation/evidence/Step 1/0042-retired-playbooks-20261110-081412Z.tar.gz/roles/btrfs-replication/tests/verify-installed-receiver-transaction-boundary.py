#!/usr/bin/env python3
"""0040 Step 3: installed manager deletion contract, read-only proof.

Run on backup as root via stdin. Never supplies a real valid candidate,
never writes to the receiver repository, and never authorizes deletion.
"""
import dataclasses
import importlib.util
import json
from pathlib import Path
import sys
from unittest import mock

MANAGER = Path('/usr/local/sbin/btrfs-snapshot-manager')
CONFIG = Path('/etc/btrfs-snapshot-manager.json')


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    require(MANAGER.is_file() and not MANAGER.is_symlink(), 'installed manager unavailable or unsafe')
    require(CONFIG.is_file() and not CONFIG.is_symlink(), 'receiver config unavailable or unsafe')
    # Extensionless installed Python executables require an explicit source loader.
    from importlib.machinery import SourceFileLoader
    spec = importlib.util.spec_from_loader('step0040_installed_snapshot_manager',
                                        SourceFileLoader('step0040_installed_snapshot_manager', str(MANAGER)))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    config = module.load_config(CONFIG)
    require(config.mode == 'receiver', 'not in receiver mode')
    require(config.receiver_prune_enabled is False, 'receiver pruning enabled')
    require(config.receiver_state_dir is not None, 'receiver state missing')
    require(config.writer_lock_path == config.receiver_state_dir / 'writer.lock', 'writer lock mismatch')
    require(config.lock_path != config.writer_lock_path, 'manager/writer lock collision')
    require(config.checkpoint_holds_required, 'checkpoint holds not required')
    pending = config.receiver_state_dir / '.receiver-prune-pending.json'
    require(not pending.exists() and not pending.is_symlink(), 'pending recovery journal')

    # Invoke the actual installed receiver-manager transaction with syntactically
    # invalid identities, so it must reject before inventory, journal or deletion.
    callbacks = {'pin': 0, 'delete': 0}
    def pin():
        callbacks['pin'] += 1
        raise AssertionError('unexpected source-pin callback')
    def delete(_):
        callbacks['delete'] += 1
        raise AssertionError('unexpected deletion callback')

    with mock.patch.object(module, 'receiver_inventory', side_effect=AssertionError('unexpected inventory')):
        try:
            module.receiver_delete_one_locked(
                config, 'INVALID-CANDIDATE', protected_stamp='INVALID-PARENT',
                expected_parent_uuid='not-a-uuid', verify_source_pin=pin,
                delete_subvolume=delete)
        except module.SnapshotError:
            pass
        else:
            raise AssertionError('invalid transaction unexpectedly accepted')
    require(callbacks == {'pin': 0, 'delete': 0}, 'callback ran despite invalid identity')
    require(not pending.exists() and not pending.is_symlink(), 'unexpected journal after rejection')
    print('PASS: installed receiver-manager rejects invalid transaction before callbacks')
    print('PASS: manager/writer locks distinct; pruning disabled; holds required; pending journal absent')
    print('LIMIT: no live source lock, received fixture, approval consumption, or deletion tested')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'FAIL: {type(exc).__name__}: {exc}', file=sys.stderr)
        sys.exit(1)
