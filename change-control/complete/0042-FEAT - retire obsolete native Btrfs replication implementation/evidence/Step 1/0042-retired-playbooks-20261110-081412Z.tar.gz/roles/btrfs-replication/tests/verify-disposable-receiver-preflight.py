#!/usr/bin/env python3
"""0040 Step 3: read-only receiver disposable-acceptance preflight.

Never creates, modifies, mounts or deletes Btrfs subvolumes. Prints evidence
only; candidate disposable test filesystem must be selected separately.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

CONFIG = Path('/etc/btrfs-snapshot-manager.json')
RETENTION = Path('/etc/btrfs-receiver-retention.json')
HOLDS = Path('/etc/btrfs-receiver-checkpoint-holds.json')
MANAGER = Path('/usr/local/sbin/btrfs-snapshot-manager')

def check():
    if not CONFIG.is_file():
        raise RuntimeError(f'Missing receiver config: {CONFIG}')
    data = json.loads(CONFIG.read_text())
    if data.get('mode') != 'receiver' or data.get('receiver_prune_enabled') is not False:
        raise RuntimeError('Receiver must be in receiver mode with pruning disabled')
    state = Path(data['receiver_state_dir'])
    root = Path(data['snapshot_root'])
    if not state.is_dir() or not root.is_dir():
        raise RuntimeError('Receiver state or snapshot root missing')
    if data.get('writer_lock_path') != str(state / 'writer.lock'):
        raise RuntimeError('Writer lock mismatch')
    for path in [RETENTION, HOLDS, MANAGER, state / 'writer.lock']:
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f'Required existing file missing/unsafe: {path}')
    retention = json.loads(RETENTION.read_text())
    if retention.get('receiver_prune_enabled') is not False:
        raise RuntimeError('Receiver retention pruning is enabled')
    holds = json.loads(HOLDS.read_text())
    print('PASS: receiver config, retention, hold file, lock file and manager exist; pruning disabled')
    print('INFO: holds top-level keys:', sorted(holds))
    print('INFO: root:', root)
    cp = subprocess.run(['findmnt','-n','-o','SOURCE,FSTYPE,TARGET','--target',str(root)],
                        capture_output=True, text=True, check=True)
    print('INFO: receiver mount:', cp.stdout.strip())
    if 'btrfs' not in cp.stdout.lower():
        raise RuntimeError('Receiver snapshot root is not Btrfs')
    cp = subprocess.run(['df','-h',str(root)], capture_output=True, text=True, check=True)
    print('INFO: capacity:\n' + cp.stdout.strip())
    cp = subprocess.run(['sudo','-n',str(MANAGER),'--config',str(CONFIG),
                         'receiver-recovery-plan'],capture_output=True,text=True)
    if cp.returncode:
        print('INFO: recovery plan command failed:', cp.stderr.strip())
        raise RuntimeError('Unable to verify receiver recovery journal')
    print(cp.stdout.strip())
    if '"state": "CLEAN"' not in cp.stdout and '"state":"CLEAN"' not in cp.stdout:
        raise RuntimeError('Recovery journal not CLEAN; halt acceptance')
    print('PASS: read-only recovery check CLEAN')
    print('LIMIT: no disposable Btrfs subvolume allocated and no deletion tested')

if __name__ == '__main__':
    try:
        check()
    except Exception as exc:
        print('FAIL:', exc, file=sys.stderr)
        sys.exit(1)
