# 0040-FEAT Step 3 — Three received snapshots and isolated receipt identities

**Source baseline:** `4fa578f` (uploaded authoritative Playbooks archive). This package adds test files only. The existing gateway, sender/receiver, sudoers, native push scheduler, production manager and holds are unchanged.

The acceptance manager needs a deletion candidate distinct from a protected parent and newest retained snapshot. This disposable harness creates three incrementally received readonly snapshots, checks real `Received UUID` identity and matching isolated JSON receipt identity records, then cleans up only explicitly enumerated objects in a fresh UUID-named Btrfs namespace. It deliberately **does not** claim these test receipts alone satisfy full manager inventory validation or the retention/hold contract. Failed fixtures are preserved for investigation.

Run the read-only planning gate on **mango** after applying the ZIP:

```bash
cd /home/richard/playbooks || exit 1
python3 -m py_compile roles/btrfs-replication/tests/verify-three-received-receipt-fixture.py
ssh backup 'sudo -n python3 - --plan' < roles/btrfs-replication/tests/verify-three-received-receipt-fixture.py
git diff --check && git status --short
```

The separately gated destructive execution command (do not run without reviewing the plan) is:

```bash
ssh backup 'sudo -n python3 - --execute --accept-disposable-delete CREATE-DELETE-ONLY-0040-THREE-RECEIVED' < roles/btrfs-replication/tests/verify-three-received-receipt-fixture.py
```

This is **not** Step 3 integrated deletion acceptance. Still outstanding are an isolated manager configuration with true receipt schema and retention/holds, root approval and reservation, live source-held two challenges, an authorised privileged child lifecycle, journal-backed Btrfs deletion, interrupt recovery, and a reviewed cleanup/recovery procedure. Automatic production pruning remains disabled, and no privileged production deletion endpoint is exposed.
