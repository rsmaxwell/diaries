#!/usr/bin/python3
"""0040 Step 12.3 Integration 04E: dormant read-only attestation transport.

Uses existing SSH identity and endpoint route. This module grants no receiver
sudo permission and cannot execute send/receive, transitions, pruning or release.
Caller must hold source push lock. No automatic retry on uncertain response.
"""
import json
import re
import subprocess

STAMP = re.compile(r"\d{8}-\d{6}Z\Z")
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z")
SSH_BASE = ('/usr/sbin/runuser', '-u', 'richard', '--', 'ssh',
            '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
            '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1')
ENDPOINT = '/usr/local/libexec/btrfs-agreed-parent-transfer-attestation.py'
AUTH = ('authorizes_transfer', 'authorizes_promote', 'authorizes_prune', 'authorizes_release')

class AttestationError(RuntimeError):
    pass


def identity(item):
    if (type(item) is not dict or set(item) != {'timestamp', 'uuid'} or
            type(item['timestamp']) is not str or not STAMP.fullmatch(item['timestamp']) or
            type(item['uuid']) is not str or not UUID.fullmatch(item['uuid'])):
        raise AttestationError('invalid snapshot identity')
    return item


def verify_reply(reply, parent, candidate):
    """Validate entire envelope; receipt content is independently verified on backup."""
    if (type(reply) is not dict or set(reply) != {
            'schema', 'host', 'status', 'parent', 'candidate', 'state', 'verified',
            'receipt', 'state_changed', *AUTH} or
            type(reply['schema']) is not int or reply['schema'] != 1 or
            reply['host'] != 'backup' or reply['status'] != 'transfer-attested' or
            reply['state_changed'] is not False or any(reply[k] is not False for k in AUTH)):
        raise AttestationError('invalid or authoritative attestation response')
    if reply['parent'] != parent or reply['candidate'] != candidate or reply['verified'] != [parent, candidate]:
        raise AttestationError('wrong attested identities')
    state = reply['state']
    if (type(state) is not dict or set(state) != {'schema', 'established', 'pending', 'previous'} or
            type(state['schema']) is not int or state['schema'] != 1 or
            state['established'] != parent or state['pending'] != candidate or state['previous'] is not None):
        raise AttestationError('receiver agreed-parent state mismatch')
    receipt = reply['receipt']
    if (type(receipt) is not dict or receipt.get('schema') != 1 or
            receipt.get('snapshot') != candidate['timestamp'] or
            receipt.get('source_uuid') != candidate['uuid'] or
            receipt.get('received_uuid') != candidate['uuid'] or
            receipt.get('transport') != 'btrfs-incremental' or
            receipt.get('parent_snapshot') != parent['timestamp'] or
            receipt.get('parent_source_uuid') != parent['uuid'] or
            receipt.get('read_only_verified') is not True or
            type(receipt.get('source_send_exit')) is not int or receipt['source_send_exit'] != 0 or
            type(receipt.get('receiver_receive_exit')) is not int or receipt['receiver_receive_exit'] != 0):
        raise AttestationError('receipt details disagree with A/B')
    return {'schema': 1, 'parent': parent, 'candidate': candidate, 'state': state,
            'receipt_valid': True, 'readonly_received_uuid_valid': True,
            'authorizes_transfer': False, 'authorizes_promote': False,
            'authorizes_prune': False, 'authorizes_release': False}


def attest(parent, candidate, *, source_lock_held=False, run=subprocess.run):
    """One authenticated read only. Caller owns lock and fresh A/B verification."""
    identity(parent); identity(candidate)
    if source_lock_held is not True or candidate['timestamp'] <= parent['timestamp']:
        raise AttestationError('source lock or parent ordering not established')
    command = [*SSH_BASE, 'sudo', '-n', ENDPOINT,
               '--parent', parent['timestamp'], '--parent-uuid', parent['uuid'],
               '--candidate', candidate['timestamp'], '--candidate-uuid', candidate['uuid']]
    try:
        response = run(command, text=True, capture_output=True, timeout=90, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise AttestationError('uncertain attestation; do not automatically retry transfer') from exc
    if type(response.returncode) is not int or response.returncode != 0:
        raise AttestationError('read-only receiver attestation refused or SSH failed')
    if type(response.stdout) is not str or not 0 < len(response.stdout.encode('utf-8')) <= 65536:
        raise AttestationError('empty or oversized attestation')
    try:
        result = json.loads(response.stdout)
    except (ValueError, TypeError) as exc:
        raise AttestationError('malformed attestation') from exc
    return verify_reply(result, parent, candidate)
