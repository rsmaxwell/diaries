#!/usr/bin/env python3
"""0034 push receiver. Invoked over outbound SSH from mars; opt-in, no scheduling."""

# MODULE GUIDE: Receiver-side control protocol for mars-initiated native Btrfs replication.
# Runs on backup after an outbound SSH request from mars. Validates received subvolumes and
# persisted receipts, coordinates native receive under the writer lock, and exposes constrained
# read-only retention/coordination checks. Current Step 3 transaction helpers are internal, not
# a public permission to prune.  Failure is deliberately fail-closed: incomplete journals,
# mismatched UUIDs, missing holds or an unverifiable challenge must not authorize deletion.
# This is the btrfs-replication role implementation, including Step 3 work.

import argparse
from contextlib import ExitStack
import stat
import datetime
import fcntl
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import tempfile

# STAMP: Canonical UTC snapshot timestamp pattern; filters names before treating them as managed
# snapshots.
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
# ROOT: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
ROOT = Path('/@data/mars-received/@data')
# STATE: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
STATE = Path('/@data/mars-received/.replication-state')
# LOCK: Fixed managed path; never substitute a caller-supplied path at this privilege boundary.
LOCK = STATE / 'writer.lock'
# ENDPOINT: Restricted remote/privileged transport and endpoint; not general command forwarding.
ENDPOINT = '/usr/local/libexec/btrfs-native-endpoint'
# SOURCE_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
# RECEIVER_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
RECEIVER_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'



# FUNCTION require: Check a security or consistency precondition; reject immediately rather than
# continuing with unsafe state. Inputs: value, reason.
def require(value, reason):
    if not value:
        raise RuntimeError(reason)



# FUNCTION inspect: Collect validated subvolume identity for a specific timestamp without
# modifying snapshots. Inputs: stamp.
def inspect(stamp):
    result = subprocess.run(['sudo', '-n', ENDPOINT, '--role', 'inspect-receiver', '--snapshot', stamp],
                            capture_output=True, text=True, check=True)
    return json.loads(result.stdout)



# FUNCTION receipt: Read an accepted receiver receipt for a timestamp and verify it is shaped as
# expected. Inputs: stamp.
def receipt(stamp):
    path = STATE / (stamp + '.json')
    if path.is_symlink() or not path.is_file():
        return None
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        value = json.loads(path.read_text())
        if (value.get('schema') != 1 or value.get('snapshot') != stamp or
            value.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
            value.get('source_filesystem_uuid') != SOURCE_FS or
            value.get('receiver_filesystem_uuid') != RECEIVER_FS or
            value.get('destination') != str(ROOT / stamp) or
            value.get('read_only_verified') is not True or
            value.get('source_send_exit') != 0 or value.get('receiver_receive_exit') != 0 or
            not value.get('source_uuid') or value.get('source_uuid') != value.get('received_uuid')):
            return None
        observed = inspect(stamp)
        return value if observed.get('flags') == 'readonly' and observed.get('received_uuid') == value['source_uuid'] else None
    except (ValueError, OSError, subprocess.CalledProcessError, KeyError):
        return None



# FUNCTION check_protected_parent: Verify the designated common parent against stored receipt
# and Btrfs metadata. Inputs: stamp, source_uuid.
def check_protected_parent(stamp, source_uuid):
    """Observe a receiver parent under writer.lock; never authorise deletion.

    The caller must hold the sender's native-push lock and must have established
    a durable source-side protection pin before calling this operation.
    """
    require(isinstance(stamp, str) and STAMP.fullmatch(stamp), 'Invalid protected-parent timestamp')
    require(isinstance(source_uuid, str) and
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', source_uuid),
            'Invalid protected-parent source UUID')
    require(not (STATE / '.receiver-prune-pending.json').exists() and
            not (STATE / '.receiver-prune-pending.json').is_symlink(),
            'Pending receiver prune transaction')
    accepted = receipt(stamp)
    require(accepted is not None and accepted['source_uuid'] == source_uuid,
            'Protected parent receipt or received identity mismatch')
    result = {'snapshot': stamp, 'source_uuid': source_uuid,
              'receiver_verified_under_lock': True, 'source_pin_claimed_by_caller': True,
              'authorizes_prune': False}
    return result




# FUNCTION protected_retention_candidates: Enforce the replication-parent boundary on
# advisory candidate selection, after validating the received inventory.
def protected_retention_candidates(entries, base_keep, protected_stamp):
    """Retain the parent and all newer snapshots, independent of bucket policy.

    The caller must already have verified all snapshot receipts and the parent UUID.
    This helper has no Btrfs or filesystem side effects and authorises no pruning.
    """
    require(isinstance(protected_stamp, str) and STAMP.fullmatch(protected_stamp),
            'Invalid protected-parent timestamp')
    names = [name for name, _, _ in entries]
    require(all(isinstance(name, str) and STAMP.fullmatch(name) for name in names),
            'Invalid receiver snapshot timestamp')
    require(len(names) == len(set(names)) and names == sorted(names, reverse=True),
            'Unsorted or duplicate received snapshot inventory')
    require(protected_stamp in names, 'Protected parent missing from received inventory')
    require(set(base_keep).issubset(set(names)), 'Retention keep set references unknown snapshots')
    keep = set(base_keep)
    keep.update(name for name in names if name >= protected_stamp)
    candidates = [name for name in names if name not in keep]
    require(all(name < protected_stamp for name in candidates),
            'Receiver candidate is not older than protected common parent')
    return keep, candidates


# FUNCTION protected_retention_plan: Obtain retention classifications while ensuring the
# designated parent cannot be selected for pruning. Inputs: stamp, source_uuid.
def protected_retention_plan(stamp, source_uuid):
    """Advisory plan under receiver writer.lock; shared policy, no deletion authority.

    All receiver receipts must verify before any candidate is reported.
    This routine is invoked by the sender after installing its durable prune pin.
    """
    import importlib.util
    from datetime import datetime, timezone
    module_path = Path('/usr/local/sbin/btrfs-snapshot-manager')
    spec = importlib.util.spec_from_file_location('receiver_snapshot_manager', str(module_path))
    # The installed manager lacks a .py suffix, so use its source loader explicitly.
    from importlib.machinery import SourceFileLoader
    loader = SourceFileLoader('receiver_snapshot_manager', str(module_path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    manager = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = manager
    spec.loader.exec_module(manager)
    policy_path = Path('/etc/btrfs-receiver-retention.json')
    require(policy_path.is_file() and not policy_path.is_symlink(), 'Missing safe public retention policy')
    policy_info = policy_path.stat()
    require(policy_info.st_uid == 0 and not policy_info.st_mode & 0o022,
            'Unsafe public retention policy permissions')
    policy_data = json.loads(policy_path.read_text(encoding='utf-8'))
    require(policy_data.get('schema') == 1 and policy_data.get('mode') == 'receiver' and
            policy_data.get('snapshot_directory') == str(ROOT) and
            policy_data.get('receiver_state_dir') == str(STATE) and
            policy_data.get('receiver_prune_enabled') is False,
            'Unexpected receiver retention policy contract')
    values = policy_data.get('retention')
    require(isinstance(values, dict) and set(values) ==
            {'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'minimum_age_minutes'} and
            all(type(v) is int and 0 <= v <= 10000 for v in values.values()),
            'Unsafe retention policy values')
    policy = manager.RetentionPolicy(**values)
    require(not (STATE / '.receiver-prune-pending.json').exists() and
            not (STATE / '.receiver-prune-pending.json').is_symlink(),
            'Pending deletion transaction')
    checked = check_protected_parent(stamp, source_uuid)
    entries = [(name, manager.parse_timestamp(name), ROOT / name)
               for name in sorted((path.name for path in ROOT.iterdir()
                                   if path.is_dir() and STAMP.fullmatch(path.name)), reverse=True)]
    observed = {name for name, _, _ in entries}
    receipts = {path.stem for path in STATE.glob('*.json') if STAMP.fullmatch(path.stem)}
    require(len(entries) == len(observed) and observed == receipts,
            'Received snapshot/receipt inventory mismatch')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for name, _, _ in entries:
        require(receipt(name) is not None, 'Unverified received snapshot: ' + name)
    base_keep = manager.retention_keep_set(entries, policy, datetime.now(timezone.utc))
    keep, candidates = protected_retention_candidates(entries, base_keep, stamp)
    return {'snapshot': stamp, 'source_uuid': source_uuid,
            'receiver_verified_under_lock': checked['receiver_verified_under_lock'],
            'retained': len(keep), 'total': len(entries), 'candidates': candidates,
            'authorizes_prune': False, 'deletion_executed': False}


# FUNCTION validate: Validate the candidate, source identity and receiver prerequisites for an
# incoming replication request. Inputs: stamp, uuid, parent, parent_uuid, full, reseed.
def validate(stamp, uuid, parent, parent_uuid, full, reseed):
    require(not (STATE / '.agreed-parent-transfer-pending.json').exists() and
            not (STATE / '.agreed-parent-transfer-pending.json').is_symlink(),
            'Unfinished agreed-parent transfer requires manual reconciliation')
    require(STAMP.fullmatch(stamp), 'Invalid snapshot')
    require(re.fullmatch(r'[0-9a-f-]{36}', uuid), 'Invalid source UUID')
    require(not (ROOT / stamp).exists() and not (ROOT / stamp).is_symlink(), 'Destination already exists')
    require(not (STATE / (stamp + '.json')).exists(), 'Receipt already exists')
    require(not (reseed and not full), 'Reseed requires full')
    existing = list(STATE.glob('[0-9]*.json'))
    if full:
        require(parent is None and parent_uuid is None, 'Full send must not have parent')
        require(not existing or reseed, 'Existing receipts: explicit reseed required')
    else:
        require(parent and STAMP.fullmatch(parent) and parent < stamp, 'Invalid incremental parent')
        require(parent_uuid and re.fullmatch(r'[0-9a-f-]{36}', parent_uuid), 'Invalid parent UUID')
        old = receipt(parent)
        require(old is not None and old['source_uuid'] == parent_uuid, 'Parent is not a verified accepted receiver')
    return {'snapshot': stamp, 'source_uuid': uuid, 'parent': parent, 'parent_uuid': parent_uuid,
            'action': 'full-baseline' if full else 'incremental'}



# FUNCTION atomic_receipt: Write the completed receive receipt through a temporary file and
# atomic rename so partial state is not accepted. Inputs: data.
def atomic_receipt(data):
    target = STATE / (data['snapshot'] + '.json')
    require(not target.exists() and not target.is_symlink(), 'Receipt collision')
    fd, name = tempfile.mkstemp(prefix='.push-receipt-', dir=STATE)
    # SAFETY: Keep partial failures from being interpreted as successful replication or
    # deletion.
    try:
        with os.fdopen(fd, 'w') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(data, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, target)
        fd_dir = os.open(STATE, os.O_DIRECTORY)
        try: os.fsync(fd_dir)
        finally: os.close(fd_dir)
    finally:
        if os.path.exists(name): os.unlink(name)
    return target



# FUNCTION verify_session_response: Authenticate a single response against its pending one-time
# session challenge and expected parent. Inputs: response, stamp, uuid, nonce.
def verify_session_response(response, *, stamp, uuid, nonce):
    """Match a one-use challenge on the existing authenticated SSH channel."""
    require(isinstance(response, dict) and response.get('kind') == 'pin-response' and
            response.get('snapshot') == stamp and response.get('source_uuid') == uuid and
            response.get('nonce') == nonce, 'Invalid source pin response')



# FUNCTION prune_session_check: Perform a non-destructive source/receiver coordination challenge
# for receiver retention. Inputs: stamp, uuid, incoming, outgoing.
def prune_session_check(stamp, uuid, *, incoming=sys.stdin, outgoing=sys.stdout):
    """Receiver writer.lock is held by caller. No deletion and no privileges added."""
    checked = check_protected_parent(stamp, uuid)
    nonce = secrets.token_hex(32)
    print(json.dumps({'kind': 'pin-challenge', 'nonce': nonce, 'snapshot': stamp,
                      'source_uuid': uuid}), file=outgoing, flush=True)
    line = incoming.readline(4097)
    require(line and len(line) <= 4096, 'Missing or oversized source pin response')
    verify_session_response(json.loads(line), stamp=stamp, uuid=uuid, nonce=nonce)
    # Confirm receiver identity still holds within the same writer lock.
    check_protected_parent(stamp, uuid)
    result = {'kind': 'session-checked', 'snapshot': stamp, 'source_uuid': uuid,
              'source_pinned': True, 'receiver_verified_under_lock': True,
              'authorizes_prune': False, 'deletion_executed': False}
    print(json.dumps(result), file=outgoing, flush=True)
    return result




# FUNCTION candidate_session_check: Check a candidate-specific challenge and its binding to the
# protected common parent. Inputs: stamp, uuid, candidate, incoming, outgoing, planner.
def candidate_session_check(stamp, uuid, candidate, *, incoming=sys.stdin, outgoing=sys.stdout,
                            planner=protected_retention_plan):
    """Revalidate one candidate on both sides of a challenge; NEVER delete.

    The caller holds the existing receiver writer.lock throughout. Each call to
    planner rechecks the complete receipt/Btrfs inventory and shared policy.
    """
    require(isinstance(candidate, str) and STAMP.fullmatch(candidate),
            'Invalid prune candidate identifier')
    require(candidate < stamp, 'Candidate must precede protected parent')
    before = planner(stamp, uuid)
    require(before.get('authorizes_prune') is False and
            before.get('deletion_executed') is False and
            candidate in before.get('candidates', []),
            'Candidate is not eligible under receiver retention policy')
    nonce = secrets.token_hex(32)
    print(json.dumps({'kind': 'candidate-pin-challenge', 'nonce': nonce,
                      'snapshot': stamp, 'source_uuid': uuid, 'candidate': candidate}),
          file=outgoing, flush=True)
    line = incoming.readline(4097)
    require(line and len(line) <= 4096, 'Missing or oversized candidate pin response')
    response = json.loads(line)
    require(isinstance(response, dict) and response.get('kind') == 'candidate-pin-response' and
            response.get('candidate') == candidate, 'Candidate pin response mismatch')
    verify_session_response({**response, 'kind': 'pin-response'}, stamp=stamp, uuid=uuid,
                            nonce=nonce)
    after = planner(stamp, uuid)
    require(after.get('authorizes_prune') is False and
            after.get('deletion_executed') is False and
            candidate in after.get('candidates', []) and
            before.get('candidates') == after.get('candidates'),
            'Candidate eligibility changed during session')
    result = {'kind': 'candidate-session-checked', 'snapshot': stamp,
              'source_uuid': uuid, 'candidate': candidate, 'source_pinned': True,
              'receiver_verified_under_lock': True, 'authorizes_prune': False,
              'deletion_executed': False}
    print(json.dumps(result), file=outgoing, flush=True)
    return result




# FUNCTION execute_candidate_transaction_locked: Run the internal manager-bound candidate
# transaction while both receiver locks are held; fail closed. Inputs: stamp, uuid, candidate,
# planner, verify_pin, transaction.
# INTERNAL ONLY: the receiver writer/manager locks protect local atomicity;
# the source-held lease is a separate cross-host requirement. This callable
# does not expose a public prune command or bypass journal recovery.
def execute_candidate_transaction_locked(stamp, uuid, candidate, *,
                                         planner, verify_pin, transaction):
    """INTERNAL receiver coordinator; not exported by the command line.

    A future privileged service must hold BOTH manager and receiver writer locks,
    plus a source-bound session, for this entire call.  The provided callbacks
    are dependency-injection points for disposable Btrfs rehearsals.  The
    production CLI deliberately does not supply them or expose this function.

    The transaction callback must use receiver_delete_one_locked(), which
    performs final receiver inventory, retention and journal checks.  Returning
    a successful advisory handshake alone MUST NOT trigger deletion.
    """
    require(isinstance(stamp, str) and STAMP.fullmatch(stamp),
            'Invalid protected parent')
    require(isinstance(candidate, str) and STAMP.fullmatch(candidate)
            and candidate < stamp, 'Invalid candidate or protected parent')
    require(isinstance(uuid, str) and
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', uuid),
            'Invalid protected parent UUID')
    initial = planner(stamp, uuid)
    require(isinstance(initial, dict) and
            initial.get('snapshot') == stamp and initial.get('source_uuid') == uuid and
            initial.get('authorizes_prune') is False and
            initial.get('deletion_executed') is False and
            isinstance(initial.get('candidates'), list) and
            len(initial['candidates']) == len(set(initial['candidates'])) and
            candidate in initial['candidates'],
            'Candidate not approved by current advisory retention plan')
    # A real callback must round-trip on the SAME live, authenticated sender
    # session and renew/recheck the persistent source pruning pin. A boolean
    # supplied by a request is not acceptable proof.
    verify_pin(stamp, uuid, candidate)
    current = planner(stamp, uuid)
    require(current == initial, 'Receiver retention plan changed during session')
    # No snapshot mutation is possible until this explicitly injected callback.
    # The manager's journal is the recovery authority after a partial failure.
    transaction(candidate, protected_stamp=stamp, expected_parent_uuid=uuid,
                verify_source_pin=lambda: verify_pin(stamp, uuid, candidate))
    return {'snapshot': candidate, 'protected_parent': stamp,
            'protected_parent_uuid': uuid, 'transaction_completed': True}




# FUNCTION run_source_held_transaction_locked: Coordinate an internal candidate transaction
# against validated identities and the existing journal contract. Inputs: stamp, uuid,
# candidate, incoming, outgoing, planner, transaction.
def run_source_held_transaction_locked(stamp, uuid, candidate, *, incoming,
                                       outgoing, planner, transaction):
    """INTERNAL two-stage source-bound protocol for a future privileged executor.

    Caller must already hold manager and receiver writer locks, and supply a
    transaction wired to receiver_delete_one_locked(). This function is NOT
    reachable from main() or the installed receiver SSH command. It requires
    two fresh, distinct challenges on the same channel: before re-planning and
    immediately before the manager journal. The source must retain its own
    lock and durable pin throughout. A missing/closed sender fails closed.

    This is not a lease on its own: locking and privilege separation must be
    enforced by the future service, not asserted by an untrusted SSH request.
    """
    seen_nonces = set()


    # FUNCTION verify_pin: Validate or preserve the source-side common-parent pin; reject
    # missing or mismatched protection. Inputs: parent, source_uuid, target.
    def verify_pin(parent, source_uuid, target):
        require(parent == stamp and source_uuid == uuid and target == candidate,
                'Source pin context changed')
        nonce = secrets.token_hex(32)
        require(nonce not in seen_nonces, 'Duplicate source pin challenge')
        seen_nonces.add(nonce)
        print(json.dumps({'kind': 'transaction-pin-challenge', 'nonce': nonce,
                          'snapshot': stamp, 'source_uuid': uuid,
                          'candidate': candidate}), file=outgoing, flush=True)
        line = incoming.readline(4097)
        require(line and len(line) <= 4096,
                'Missing or oversized transaction pin response')
        response = json.loads(line)
        require(isinstance(response, dict) and
                response.get('kind') == 'transaction-pin-response' and
                response.get('candidate') == candidate,
                'Invalid transaction pin response')
        verify_session_response({**response, 'kind': 'pin-response'},
                                stamp=stamp, uuid=uuid, nonce=nonce)

    result = execute_candidate_transaction_locked(
        stamp, uuid, candidate, planner=planner,
        verify_pin=verify_pin, transaction=transaction)
    # Only report completion after the manager callback returns successfully.
    response = {'kind': 'transaction-completed', 'snapshot': candidate,
                'protected_parent': stamp, 'protected_parent_uuid': uuid,
                'journal_transaction_completed': result['transaction_completed']}
    print(json.dumps(response), file=outgoing, flush=True)
    return response




# FUNCTION run_manager_bound_transaction: Coordinate an internal candidate transaction against
# validated identities and the existing journal contract. Inputs: stamp, uuid, candidate,
# manager, config, incoming, outgoing, planner, delete_subvolume.
def run_manager_bound_transaction(stamp, uuid, candidate, *, manager, config,
                                  incoming, outgoing, planner, delete_subvolume):
    """PRIVATE integration adapter: locks -> two challenges -> manager journal.

    Not reachable from main(). The privileged Btrfs callback MUST be injected by
    a separately reviewed disposable test harness; production provides none.
    Lock ordering is manager then receiver, throughout the entire exchange.
    Never clears source pins or a pending recovery journal on error.
    """
    require(config.mode == 'receiver' and config.receiver_state_dir is not None,
            'Receiver manager configuration required')
    require(config.receiver_prune_enabled is False,
            'Refuse configuration that enables production pruning')
    manager_lock = config.lock_path
    writer_lock = config.writer_lock_path
    require(writer_lock == config.receiver_state_dir / 'writer.lock' and
            manager_lock != writer_lock, 'Unsafe transaction lock configuration')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for lock_path in (manager_lock, writer_lock):
        require(lock_path.is_absolute() and not lock_path.is_symlink() and
                lock_path.is_file(), 'Transaction lock missing or unsafe')
        metadata = lock_path.stat()
        require(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1,
                'Transaction lock is not a single regular file')

    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with ExitStack() as stack:
        for lock_path in (manager_lock, writer_lock):
            handle = stack.enter_context(lock_path.open('r+'))
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Lock-held only: the manager performs the final retention, historical
        # hold, receipt UUID, durable journal and failure-reconciliation checks.

        # FUNCTION manager_transaction: Coordinate an internal candidate transaction against
        # validated identities and the existing journal contract. Inputs: target,
        # protected_stamp, expected_parent_uuid, verify_source_pin.
        def manager_transaction(target, *, protected_stamp, expected_parent_uuid,
                                verify_source_pin):
            manager.receiver_delete_one_locked(
                config, target, protected_stamp=protected_stamp,
                expected_parent_uuid=expected_parent_uuid,
                verify_source_pin=verify_source_pin,
                delete_subvolume=delete_subvolume)

        return run_source_held_transaction_locked(
            stamp, uuid, candidate, incoming=incoming, outgoing=outgoing,
            planner=planner, transaction=manager_transaction)



# INTERNAL ONLY: bind a single-use approval to the already lock-held receiver
# transaction. This adapter is NOT reachable from main() or deployed sudoers.
def run_approved_manager_bound_transaction(stamp, uuid, candidate, *, manager, config,
                                           incoming, outgoing, planner, delete_subvolume,
                                           approval_path, consumed_dir,
                                           transaction_runner=run_source_held_transaction_locked):
    """Reserve an operator approval under both receiver locks before transaction.

    The supplied transaction_runner is test-injected. Production does not call
    this function. A reservation survives all exceptions, including failures
    before the manager can create its deletion journal. Recovery is manual.
    """
    # This adapter reads a root-owned 0600 approval file. Never invoke it from
    # the ordinary SSH receiver (whose public main() must stay unprivileged).
    # A future restricted root entry point must be reviewed separately.
    require(os.geteuid() == 0,
            'Approved receiver transaction requires a separate privileged entry point')
    require(config.mode == 'receiver' and config.receiver_prune_enabled is False,
            'Production receiver pruning must remain disabled')
    require(config.receiver_state_dir is not None and
            config.writer_lock_path == config.receiver_state_dir / 'writer.lock' and
            config.lock_path != config.writer_lock_path,
            'Receiver transaction lock configuration invalid')
    require(isinstance(approval_path, Path) and isinstance(consumed_dir, Path),
            'Explicit approval and consumption paths required')
    pending = config.receiver_state_dir / '.receiver-prune-pending.json'
    for path in (config.lock_path, config.writer_lock_path):
        require(path.is_absolute() and path.is_file() and not path.is_symlink(),
                'Required receiver lock missing or unsafe')
        st = path.stat()
        require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1,
                'Unsafe receiver lock inode')
    with ExitStack() as stack:
        for path in (config.lock_path, config.writer_lock_path):
            handle = stack.enter_context(path.open('r+'))
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        require(not pending.exists() and not pending.is_symlink(),
                'Existing receiver recovery journal requires reconciliation')
        # The source pin and candidate are checked independently by the
        # challenged transaction before manager deletion is attempted.
        validated = validate_receiver_prune_approval(
            approval_path, candidate=candidate, parent_stamp=stamp,
            parent_uuid=uuid, consumed_dir=consumed_dir)
        reservation = reserve_receiver_prune_approval(consumed_dir, validated)

        def manager_transaction(target, *, protected_stamp, expected_parent_uuid,
                                verify_source_pin):
            manager.receiver_delete_one_locked(
                config, target, protected_stamp=protected_stamp,
                expected_parent_uuid=expected_parent_uuid,
                verify_source_pin=verify_source_pin,
                delete_subvolume=delete_subvolume)

        result = transaction_runner(
            stamp, uuid, candidate, incoming=incoming, outgoing=outgoing,
            planner=planner, transaction=manager_transaction)
        return {'approval_reservation': str(reservation), 'result': result,
                'production_authorized': False}


# FUNCTION validate_receiver_prune_approval: Check a future root-authorised single-target
# approval against its matching source/receiver identities and a replay record.
def validate_receiver_prune_approval(approval_path, *, candidate, parent_stamp, parent_uuid,
                                     consumed_dir, now=None):
    """Read-only approval preflight for a future lock-held receiver transaction.

    This function grants NO deletion authority. The consuming transaction must
    revalidate identities and expiry under its locks, then atomically reserve the
    approval identifier before any destructive action. Failure must leave the
    source pin and recovery journal intact.
    """
    import hashlib

    require(isinstance(approval_path, Path) and approval_path.is_absolute(),
            'Approval path must be absolute')
    require(not approval_path.is_symlink(), 'Approval symlink forbidden')
    require(approval_path.parent.is_dir() and not approval_path.parent.is_symlink(),
            'Unsafe approval directory')
    require(isinstance(consumed_dir, Path) and consumed_dir.is_absolute() and
            consumed_dir.is_dir() and not consumed_dir.is_symlink(),
            'Unsafe approval consumption directory')
    require(isinstance(candidate, str) and STAMP.fullmatch(candidate) and
            isinstance(parent_stamp, str) and STAMP.fullmatch(parent_stamp) and
            candidate < parent_stamp, 'Invalid candidate or protected parent')
    require(isinstance(parent_uuid, str) and
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', parent_uuid),
            'Invalid protected parent UUID')
    metadata = approval_path.stat()
    require(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1 and
            metadata.st_uid == 0 and metadata.st_mode & 0o077 == 0,
            'Approval must be a single root-owned private regular file')
    with approval_path.open('rb') as handle:
        current = os.fstat(handle.fileno())
        require((current.st_dev, current.st_ino) == (metadata.st_dev, metadata.st_ino) and
                stat.S_ISREG(current.st_mode) and current.st_nlink == 1 and
                current.st_uid == 0 and current.st_mode & 0o077 == 0,
                'Approval identity or permissions changed')
        raw = handle.read(4097)
    require(len(raw) <= 4096, 'Approval oversized')
    data = json.loads(raw)
    require(isinstance(data, dict) and set(data) == {
        'schema', 'operation', 'candidate', 'protected_parent',
        'protected_parent_uuid', 'expires_at_utc', 'reason'},
        'Unexpected approval fields')
    require(type(data['schema']) is int and data['schema'] == 1 and
            data['operation'] == 'receiver-prune-one' and
            data['candidate'] == candidate and
            data['protected_parent'] == parent_stamp and
            data['protected_parent_uuid'] == parent_uuid and
            isinstance(data['reason'], str) and 1 <= len(data['reason'].strip()) <= 500,
            'Approval identity or reason mismatch')
    expiry_text = data['expires_at_utc']
    require(isinstance(expiry_text, str) and re.fullmatch(
            r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z', expiry_text),
            'Invalid approval expiry format')
    expiry = datetime.datetime.strptime(expiry_text, '%Y-%m-%dT%H:%M:%SZ').replace(
        tzinfo=datetime.timezone.utc)
    clock = now if now is not None else datetime.datetime.now(datetime.timezone.utc)
    require(isinstance(clock, datetime.datetime) and clock.tzinfo is not None and
            clock.utcoffset() is not None and
            clock < expiry <= clock + datetime.timedelta(hours=1),
            'Approval expired or exceeds maximum validity')
    # The replay identifier binds the exact bytes, not a user-supplied ID.
    approval_id = hashlib.sha256(raw).hexdigest()
    consumed = consumed_dir / (approval_id + '.json')
    require(not consumed.exists() and not consumed.is_symlink(),
            'Approval already consumed or unsafe replay record')
    return {'candidate': candidate, 'protected_parent': parent_stamp,
            'protected_parent_uuid': parent_uuid, 'approval_sha256': approval_id,
            'expires_at_utc': expiry_text, 'authorizes_deletion': False}


# FUNCTION reserve_receiver_prune_approval: Durably mark a validated, single-use
# approval as consumed. INTERNAL ONLY: never grants deletion permission.
def reserve_receiver_prune_approval(consumed_dir, validated):
    """Create an immutable replay marker using exclusive creation and fsync.

    The eventual caller MUST hold receiver manager and writer locks, have
    independently validated the approval and source pin, and must create this
    marker before its deletion journal or destructive operation. This helper
    does not implement or authorise that future transaction. Do not remove
    markers on interruption, timeouts or even a failed transaction.
    """
    require(isinstance(consumed_dir, Path) and consumed_dir.is_absolute() and
            consumed_dir.is_dir() and not consumed_dir.is_symlink(),
            'Unsafe replay directory')
    require(isinstance(validated, dict) and validated.get('authorizes_deletion') is False,
            'Missing non-authorising approval preflight')
    approval_id = validated.get('approval_sha256')
    require(isinstance(approval_id, str) and
            re.fullmatch(r'[0-9a-f]{64}', approval_id), 'Invalid approval identifier')
    require(isinstance(validated.get('candidate'), str) and
            STAMP.fullmatch(validated['candidate']) and
            isinstance(validated.get('protected_parent'), str) and
            STAMP.fullmatch(validated['protected_parent']) and
            isinstance(validated.get('protected_parent_uuid'), str) and
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',
                         validated['protected_parent_uuid']), 'Invalid approval binding')
    filename = approval_id + '.json'
    directory_fd = os.open(consumed_dir, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        # Never overwrite: simultaneous attempts have one winner, even if the
        # future caller violates the prescribed locking protocol.
        try:
            fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=directory_fd)
        except FileExistsError as exc:
            raise RuntimeError('Approval already consumed') from exc
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as output:
                os.fchmod(output.fileno(), 0o600)
                json.dump({'schema': 1, 'approval_sha256': approval_id,
                           'candidate': validated['candidate'],
                           'protected_parent': validated['protected_parent'],
                           'protected_parent_uuid': validated['protected_parent_uuid'],
                           'state': 'reserved-not-authorised'}, output, sort_keys=True)
                output.write('\n')
                output.flush()
                os.fsync(output.fileno())
            os.fsync(directory_fd)
        except Exception:
            # Fail closed: never unlink a possibly durable marker. An operator
            # must reconcile an incomplete marker before any future use.
            raise
    finally:
        os.close(directory_fd)
    return consumed_dir / filename


# FUNCTION main: Parse the allowlisted command interface; validate inputs, acquire required
# locks and dispatch roles.

# 0040 Step 12.3 — INTERNAL journal-first A/B receive transaction.
# Deliberately not connected to --accept or any installed SSH command.
# A privileged, independently reviewed entry point must own both locks and
# supply genuine prepared-state/absence verification and a bounded Btrfs receive.
def receive_prepared_candidate_reserved(parent, candidate, *,
                                       manager_lock, writer_lock, state_dir,
                                       verify_prepared, receive_stream,
                                       journal_module):
    """Reserve B before accepting data; preserve journal even on success.

    The callback must perform one bounded native Btrfs receive inside the
    locks. A successful return is NOT a final receipt or sender attestation.
    """
    require(callable(verify_prepared) and callable(receive_stream),
            'Missing trusted receive callbacks')
    require(manager_lock != writer_lock, 'Identical receiver lock paths')
    require(Path(state_dir).is_absolute(), 'Invalid receiver state path')
    for lock_path in (manager_lock, writer_lock):
        lock_path = Path(lock_path)
        require(lock_path.is_absolute() and lock_path.is_file() and
                not lock_path.is_symlink(), 'Missing safe receiver lock')
        metadata = lock_path.stat()
        require(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1,
                'Unsafe receiver lock')
    with ExitStack() as stack:
        for lock_path in (manager_lock, writer_lock):
            handle = stack.enter_context(Path(lock_path).open('r+'))
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Preflight runs under the same locks as the reservation and receive.
        require(verify_prepared(parent, candidate) is True,
                'A/B prepared-state and destination-absence preflight refused')
        journal = journal_module.reserve(
            state_dir, parent, candidate,
            manager_lock_held=True, writer_lock_held=True)
        # No cleanup, retry, receipt or parent transition on either outcome.
        # Only the future trusted executor may provide a real receive callback.
        result = receive_stream(parent, candidate)
        require(result is True, 'Candidate receive failed or incomplete')
        return {'schema': 1, 'status': 'receiver-provisional-only',
                'parent': parent, 'candidate': candidate, 'journal': str(journal),
                'transfer_finalized': False, 'receipt_committed': False,
                'authorizes_transition': False, 'authorizes_prune': False,
                'authorizes_release': False}

# 0040 Step 12.3 — INTERNAL bounded real receive adapter.
# It is deliberately NOT called by main/--accept. Call only through the
# journal-first transaction after independent A/B preflight under both locks.
def receive_prepared_binary_stream(parent, candidate, *, input_stream,
                                   runner=subprocess.run, timeout_seconds=1800,
                                   endpoint=ENDPOINT, inspect_received=inspect):
    """Receive exactly one Btrfs stream; never create a final receipt.

    The endpoint independently verifies the target name/path.  The caller
    retains the manager and writer locks and provisional journal throughout.
    subprocess timeout kills the immediate endpoint process; a privileged
    descendant may survive, so a timeout MUST be treated as an unresolved
    recovery incident rather than an automatic retry/cleanup.
    """
    require(isinstance(parent, dict) and isinstance(candidate, dict),
            'Missing exact A/B identities')
    for identity in (parent, candidate):
        require(set(identity) == {'timestamp', 'uuid'} and
                isinstance(identity['timestamp'], str) and
                STAMP.fullmatch(identity['timestamp']) and
                isinstance(identity['uuid'], str) and
                re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', identity['uuid']),
                'Invalid exact A/B identity')
    require(parent['timestamp'] < candidate['timestamp'], 'Invalid parent order')
    require(type(timeout_seconds) is int and 1 <= timeout_seconds <= 7200,
            'Invalid receive deadline')
    require(input_stream is not None and hasattr(input_stream, 'read'),
            'Missing binary stream')
    require(endpoint == ENDPOINT, 'Unexpected privileged receiver endpoint')
    command = ['sudo', '-n', endpoint, '--role', 'receiver',
               '--snapshot', candidate['timestamp']]
    try:
        completed = runner(command, stdin=input_stream, timeout=timeout_seconds,
                           check=False)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('Btrfs receive timed out; journal retained; manual reconciliation required') from exc
    require(type(completed.returncode) is int and completed.returncode == 0,
            'Btrfs receive failed; journal retained; manual reconciliation required')
    observed = inspect_received(candidate['timestamp'])
    require(isinstance(observed, dict) and observed.get('flags') == 'readonly' and
            observed.get('received_uuid') == candidate['uuid'],
            'Btrfs receive identity/read-only verification refused; journal retained')
    return True  # Local receive only; sender success remains unverified.



# 0040 Step 12.3 — INTERNAL integrated receive path; not exposed by main().
# The caller must supply the actual authenticated SSH stdin and fixed endpoint.
# This code does not attest sender completion, write receipts or transition A/B.
def receive_prepared_candidate_integrated(parent, candidate, *, input_stream,
                                          state_module, absence_module, endpoint_module,
                                          journal_module, manager_lock, writer_lock,
                                          state_dir, verify_parent=check_protected_parent,
                                          runner=subprocess.run, inspect_received=inspect,
                                          timeout_seconds=1800):
    """Real prepared-state preflight + durable reservation + bounded receive.

    All operations execute inside receive_prepared_candidate_reserved's two
    locks; the provisional journal remains after successful local receiving.
    The dependency parameters are an *internal test seam*, never wire input.
    """
    require(Path(state_dir) == STATE and Path(writer_lock) == LOCK and
            Path(manager_lock) == Path('/run/lock/btrfs-snapshot-manager.lock'),
            'Refusing noncanonical receiver paths')
    require(callable(verify_parent), 'Missing trusted parent verification')

    def preflight(a, b):
        endpoint_module.validate_filesystem()
        current = state_module.load(STATE / '.agreed-parent.json')
        evidence = absence_module.verify(a, b, current, state=state_module)
        require(evidence.get('destination_absent') is True and
                evidence.get('receipt_absent') is True and
                evidence.get('state_changed') is False,
                'Prepared candidate absence was not verified')
        verified_parent = verify_parent(a['timestamp'], a['uuid'])
        require(isinstance(verified_parent, dict) and
                verified_parent.get('receiver_verified_under_lock') is True and
                verified_parent.get('snapshot') == a['timestamp'] and
                verified_parent.get('source_uuid') == a['uuid'],
                'Established parent receipt/identity not verified')
        return True

    def receive(a, b):
        return receive_prepared_binary_stream(
            a, b, input_stream=input_stream, runner=runner,
            timeout_seconds=timeout_seconds, inspect_received=inspect_received)

    return receive_prepared_candidate_reserved(
        parent, candidate, manager_lock=manager_lock, writer_lock=writer_lock,
        state_dir=state_dir, verify_prepared=preflight,
        receive_stream=receive, journal_module=journal_module)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--check-protected-parent', action='store_true', help='lock-held receipt verification; never approves deletion')
    parser.add_argument('--prune-session-check', action='store_true', help='non-destructive source pin challenge')
    parser.add_argument('--prune-candidate-check', action='store_true', help='non-destructive lock-held candidate revalidation')
    parser.add_argument('--candidate')
    parser.add_argument('--protected-retention-plan', action='store_true', help='shared-policy plan under receiver lock; never deletes')
    parser.add_argument('--snapshot')
    parser.add_argument('--source-uuid')
    parser.add_argument('--parent')
    parser.add_argument('--parent-uuid')
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--reseed', action='store_true')
    parser.add_argument('--accept', action='store_true', help='Read native Btrfs stream from stdin')
    args = parser.parse_args()
    require(os.geteuid() != 0, 'Must run as unprivileged operator')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for directory in (ROOT, STATE):
        require(directory.is_dir() and not directory.is_symlink(), 'Missing safe repository path')
    require(LOCK.is_file() and not LOCK.is_symlink() and LOCK.stat().st_nlink == 1, 'Unsafe receiver lock')
    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with LOCK.open('r+') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.prune_candidate_check:
            require(args.snapshot and args.source_uuid and args.candidate and
                    not any((args.list, args.check_protected_parent, args.prune_session_check,
                             args.protected_retention_plan, args.parent, args.parent_uuid,
                             args.full, args.reseed, args.accept)),
                    'Candidate check accepts only parent, UUID and candidate')
            candidate_session_check(args.snapshot, args.source_uuid, args.candidate)
            return
        require(args.candidate is None, 'Candidate only allowed for candidate check')
        if args.prune_session_check:
            require(args.snapshot and args.source_uuid and not any((args.list, args.check_protected_parent,
                args.protected_retention_plan, args.parent, args.parent_uuid, args.full, args.reseed, args.accept)),
                'Prune session check accepts only snapshot and UUID')
            prune_session_check(args.snapshot, args.source_uuid)
            return
        if args.protected_retention_plan:
            require(args.snapshot and args.source_uuid and not any((args.list, args.check_protected_parent, args.parent, args.parent_uuid, args.full, args.reseed, args.accept)),
                    'Protected retention plan accepts only snapshot and UUID')
            print(json.dumps(protected_retention_plan(args.snapshot, args.source_uuid), sort_keys=True))
            return
        if args.check_protected_parent:
            require(args.snapshot and args.source_uuid and not any((args.list, args.protected_retention_plan, args.parent, args.parent_uuid, args.full, args.reseed, args.accept)),
                    'Protected-parent check accepts only snapshot and source UUID')
            print(json.dumps(check_protected_parent(args.snapshot, args.source_uuid), sort_keys=True))
            return
        if args.list:
            require(not any((args.snapshot, args.source_uuid, args.parent, args.parent_uuid, args.full, args.reseed, args.accept)), 'List accepts no transfer arguments')
            values = []
            for path in sorted(STATE.glob('*.json'), reverse=True):
                if STAMP.fullmatch(path.stem):
                    item = receipt(path.stem)
                    if item: values.append({'snapshot': path.stem, 'source_uuid': item['source_uuid']})
            print(json.dumps(values))
            return
        require(args.snapshot and args.source_uuid, 'Snapshot and UUID required')
        plan = validate(args.snapshot, args.source_uuid, args.parent, args.parent_uuid, args.full, args.reseed)
        if not args.accept:
            print(json.dumps(plan))
            return
        # No cleanup on failure; an incomplete destination must be investigated manually.
        command = ['sudo', '-n', ENDPOINT, '--role', 'receiver', '--snapshot', args.snapshot]
        rc = subprocess.run(command, stdin=sys.stdin.buffer).returncode
        require(rc == 0, f'Receive failed (exit={rc}); UNACCEPTED')
        received = inspect(args.snapshot)
        require(received.get('flags') == 'readonly', 'Received snapshot is not read-only')
        require(received.get('received_uuid') == args.source_uuid, 'Received source UUID mismatch')
        record = {'schema': 1, 'transport': 'btrfs-full' if args.full else 'btrfs-incremental',
                  'snapshot': args.snapshot, 'source_uuid': args.source_uuid,
                  'received_uuid': received['received_uuid'], 'parent_snapshot': args.parent,
                  'parent_source_uuid': args.parent_uuid, 'destination': str(ROOT / args.snapshot),
                  'source_filesystem_uuid': SOURCE_FS, 'receiver_filesystem_uuid': RECEIVER_FS,
                  'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'read_only_verified': True, 'source_send_exit': 0, 'receiver_receive_exit': 0}
        target = atomic_receipt(record)
        print('ACCEPTED: ' + str(target), flush=True)


if __name__ == '__main__':
    try: main()
    except (RuntimeError, OSError, ValueError, subprocess.CalledProcessError, BlockingIOError) as exc:
        print('btrfs-native-push-receiver: ' + str(exc), file=sys.stderr)
        sys.exit(1)
