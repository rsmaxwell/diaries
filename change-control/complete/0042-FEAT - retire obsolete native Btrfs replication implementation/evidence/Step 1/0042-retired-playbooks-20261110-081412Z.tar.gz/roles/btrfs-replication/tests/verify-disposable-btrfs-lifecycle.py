#!/usr/bin/env python3
"""0040 Step 3 isolated receiver Btrfs lifecycle rehearsal.

Default --plan is read-only. --execute is destructive ONLY within the uniquely
created disposable subvolume below /@data, never in the production receiver root.
This does not exercise source-held approvals, receipts or the manager journal.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

PARENT = Path('/@data')
NAME_PREFIX = '.0040-disposable-acceptance-'
FS = 'btrfs'


def run(*args):
    return subprocess.run(args, check=True, text=True, capture_output=True).stdout.strip()


def preflight():
    assert PARENT.is_dir() and not PARENT.is_symlink(), 'Missing safe /@data'
    assert Path('/@data/mars-received').is_dir(), 'Production receiver root absent'
    mounts = run('findmnt', '-n', '-o', 'FSTYPE', '-T', str(PARENT))
    assert mounts == FS, f'Expected Btrfs, got {mounts!r}'
    result = run('findmnt', '-n', '-o', 'TARGET', '-T', str(PARENT))
    assert result, 'Missing Btrfs mount identity'
    return {'parent': str(PARENT), 'fstype': mounts, 'mountpoint': result}


def create_and_delete():
    if os.geteuid() != 0:
        raise PermissionError('Execution requires root')
    label = NAME_PREFIX + uuid.uuid4().hex
    assert re.fullmatch(r'\.0040-disposable-acceptance-[a-f0-9]{32}', label)
    base = PARENT / label
    source = base / 'source'
    snapshot = base / 'snapshot'
    assert not base.exists() and not base.is_symlink(), 'Disposable namespace collision'
    events = []
    try:
        run('btrfs', 'subvolume', 'create', str(base)); events.append('base-created')
        run('btrfs', 'subvolume', 'create', str(source)); events.append('source-created')
        payload = source / 'fixture.txt'
        with payload.open('x', encoding='utf-8') as fh:
            fh.write('0040 disposable lifecycle fixture\n')
            fh.flush(); os.fsync(fh.fileno())
        run('btrfs', 'subvolume', 'snapshot', '-r', str(source), str(snapshot)); events.append('snapshot-created')
        assert (snapshot / 'fixture.txt').read_text() == '0040 disposable lifecycle fixture\n'
        run('btrfs', 'subvolume', 'delete', str(snapshot)); events.append('snapshot-delete-issued')
        assert not snapshot.exists(), 'Snapshot path still exists'
        run('btrfs', 'subvolume', 'delete', str(source)); events.append('source-delete-issued')
        assert not source.exists(), 'Source path still exists'
        run('btrfs', 'subvolume', 'delete', str(base)); events.append('base-delete-issued')
        assert not base.exists(), 'Base path still exists'
    except Exception:
        # Never recursively remove anything. Preserve failed test for manual review.
        print('FAIL: preserve disposable namespace for inspection: ' + str(base), file=sys.stderr)
        raise
    return {'namespace': str(base), 'events': events, 'success': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--execute', action='store_true')
    parser.add_argument('--accept-disposable-delete', default='', help='Must equal DELETE-ONLY-0040-DISPOSABLE')
    args = parser.parse_args()
    pre = preflight()
    if args.plan:
        assert not args.accept_disposable_delete, 'Delete acknowledgement not valid in plan mode'
        print('PASS: read-only disposable Btrfs preflight ' + json.dumps(pre, sort_keys=True))
        print('PLAN: would create a fresh /@data/.0040-disposable-acceptance-<uuid> Btrfs namespace')
        print('PLAN: would create a tiny source, readonly snapshot, verify payload, delete only these three subvolumes')
        print('LIMIT: does not test approved gateway, cross-host source lock, receipt or journal')
        return
    if args.accept_disposable_delete != 'DELETE-ONLY-0040-DISPOSABLE':
        raise PermissionError('Explicit disposable deletion acknowledgement required')
    print('PASS: disposable lifecycle ' + json.dumps(create_and_delete(), sort_keys=True))
    print('LIMIT: not a source-held receiver-manager deletion acceptance test')


if __name__ == '__main__':
    try:
        main()
    except (OSError, AssertionError, ValueError, PermissionError, subprocess.CalledProcessError) as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
