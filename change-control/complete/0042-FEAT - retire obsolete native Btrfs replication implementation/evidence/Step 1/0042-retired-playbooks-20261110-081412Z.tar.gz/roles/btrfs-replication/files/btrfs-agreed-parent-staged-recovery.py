#!/usr/bin/env python3
"""0040 Step 12.3: fail-closed read-only assessment of private-name receive.

Only receiver-side callers holding both canonical locks may use this module.
A previous-boot fence is required for classifying an interrupted transfer.
No result authorises deletion or retransmission. The sender completion proof
is handled separately by the authenticated finaliser.
"""
import re
import stat
from pathlib import Path
import subprocess

ROOT = Path('/@data/mars-received')
FINAL = ROOT / '@data'
STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
NONCE = re.compile(r'[0-9a-f]{64}\Z')

class Refused(RuntimeError):
    pass

def require(value, reason):
    if not value:
        raise Refused(reason)

def _directory(path):
    meta = path.lstat()
    require(stat.S_ISDIR(meta.st_mode) and not stat.S_ISLNK(meta.st_mode),
            'non-directory or symlinked receiver ancestor')
    return meta

def _btrfs_fields(path, runner):
    result = runner(['btrfs', 'subvolume', 'show', '--', str(path)],
                    capture_output=True, text=True, check=False)
    require(result.returncode == 0 and type(result.stdout) is str,
            'staged Btrfs identity cannot be established')
    found = {}
    for line in result.stdout.splitlines():
        if ':' not in line:
            continue
        key, value = line.strip().split(':', 1)
        if key in ('UUID', 'Received UUID', 'Flags'):
            require(key not in found, 'duplicate staged Btrfs identity field')
            found[key] = value.strip()
    require(type(found.get('UUID')) is str and UUID.fullmatch(found['UUID']),
            'missing staged Btrfs subvolume UUID')
    require(found.get('Flags') in ('readonly', '-'),
            'unrecognised staged Btrfs flags')
    require(type(found.get('Received UUID')) is str,
            'missing received UUID field')
    return found

def assess(parent, candidate, journal, *, state, receipt_absent,
           previous_boot_fence, locks_held=False, runner=subprocess.run,
           root=ROOT, final=FINAL):
    """Read-only disposition; no process or cleanup authority from a path name.

    `previous_boot_fence` is obtained from the independent receiver boot-ID
    comparison, NEVER from systemd scope disappearance or a bare flock.
    Caller holds the two locks across state/journal reading and this call.
    """
    require(locks_held is True, 'canonical receiver locks required')
    require(root == ROOT and final == FINAL, 'noncanonical receiver filesystem')
    require(type(parent) is dict and type(candidate) is dict and
            set(parent) == {'timestamp', 'uuid'} and
            set(candidate) == {'timestamp', 'uuid'}, 'invalid identities')
    for entry in (parent, candidate):
        require(type(entry['timestamp']) is str and STAMP.fullmatch(entry['timestamp']) and
                type(entry['uuid']) is str and UUID.fullmatch(entry['uuid']),
                'invalid snapshot identity')
    require(parent['timestamp'] < candidate['timestamp'], 'invalid snapshot order')
    require(type(state) is dict and state.get('schema') == 1 and
            state.get('established') == parent and state.get('pending') == candidate and
            state.get('previous') is None, 'receiver transaction state mismatch')
    require(receipt_absent is True, 'receipt committed or uncertain')
    require(type(journal) is dict and journal.get('schema') == 1 and
            journal.get('status') == 'receiving' and journal.get('parent') == parent and
            journal.get('candidate') == candidate, 'journal identity mismatch')
    nonce = journal.get('nonce')
    require(type(nonce) is str and NONCE.fullmatch(nonce), 'invalid journal nonce')
    require(set(journal) in (
        {'schema','status','parent','candidate','nonce','scope_unit','scope_binding','receiver_boot_id','staging'},
        {'schema','status','parent','candidate','nonce','scope_unit','scope_binding','receiver_boot_id','staging','publication_witness'}),
        'staged journal contract incomplete')
    binding = journal.get('staging')
    require(type(binding) is dict and set(binding) == {'directory_dev','directory_ino'} and
            type(binding['directory_dev']) is int and type(binding['directory_ino']) is int,
            'invalid staging parent binding')
    require(type(previous_boot_fence) is dict and
            previous_boot_fence.get('termination_proven') is True and
            previous_boot_fence.get('fencing') == 'receiver-reboot' and
            previous_boot_fence.get('nonce') == nonce and
            previous_boot_fence.get('scope_unit') == journal.get('scope_unit') and
            previous_boot_fence.get('cleanup_authorized') is False and
            previous_boot_fence.get('retransmit_authorized') is False,
            'independent previous-boot termination fence missing')
    main_meta = _directory(root)
    final_meta = _directory(final)
    require(main_meta.st_dev == final_meta.st_dev and final_meta.st_uid == 0 and
            (final_meta.st_dev, final_meta.st_ino) ==
            (binding['directory_dev'], binding['directory_ino']),
            'staging parent filesystem identity changed')
    published = final / candidate['timestamp']
    staged = final / ('.receive-' + nonce)
    require(not published.exists() and not published.is_symlink(),
            'published candidate must use witnessed finalisation recovery')
    require(not staged.is_symlink(), 'symlinked private candidate')
    base = {'schema': 1, 'parent': parent, 'candidate': candidate,
            'staged_path': str(staged), 'cleanup_authorized': False,
            'retransmit_authorized': False, 'publication_authorized': False,
            'prune_authorized': False, 'release_authorized': False,
            'previous_boot_fenced': True}
    if not staged.exists():
        require('publication_witness' not in journal,
                'witnessed stage disappeared; manual reconciliation required')
        return dict(base, status='private-stage-absent-unresolved')
    require(staged.is_dir(), 'private candidate not a directory')
    metadata = _btrfs_fields(staged, runner)
    if metadata['Received UUID'] == candidate['uuid'] and metadata['Flags'] == 'readonly':
        return dict(base, status='private-stage-complete-awaiting-sender-proof',
                    subvolume_uuid=metadata['UUID'])
    # An incomplete receive may be writable and lack Received UUID. It is
    # still NOT automatically owned for deletion merely because its name
    # contains a nonce. No deletion here, under any combination of fields.
    if metadata['Flags'] == '-' and metadata['Received UUID'] in ('-', ''):
        require('publication_witness' not in journal,
                'witnessed stage has incomplete identity')
        return dict(base, status='private-stage-incomplete-manual-recovery',
                    subvolume_uuid=metadata['UUID'])
    raise Refused('ambiguous staged received UUID/read-only combination')
