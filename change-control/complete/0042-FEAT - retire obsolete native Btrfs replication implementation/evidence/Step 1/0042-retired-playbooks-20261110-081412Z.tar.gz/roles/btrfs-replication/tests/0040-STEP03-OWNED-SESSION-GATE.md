# 0040 Step 3 — private disposable peer-process ownership gate

Baseline: accepted Playbooks source at `4fa578f`, plus `f6daf27` three-received fixture (unchanged).

This increment introduces an **undeployed private primitive** for owning a disposable peer process. It is deliberately not imported or invoked by the public privileged receiver CLI, and is not a production source-held lease.

The helper uses an explicit argv list (never a shell), a bounded per-line deadline and response size, closes the peer's stdin after callback completion, requires a successful peer exit, and terminates/reaps the peer process group after interrupted, stalled or failed callbacks. It returns the callback's result only after the peer exits successfully. Its fixture tests use Python subprocesses and no Btrfs data.

**Current limitation / stop gate:** This does not guarantee remote SSH process termination, prove sender lock/pin continuity, establish peer authentication, carry a production approval, or call receiver-manager deletion. The helper is not sufficient to authorise deletion. The receiving root entry point must remain verify-only; production sudoers and pruning settings must not change.

**Next acceptance:** Wire a restricted, reviewed, authenticated source-held channel that retains its lock and durable pin throughout manager locks, transaction and uncertainty, then test the real manager/receipt/journal path against three isolated received snapshots. Use read-only plan, explicit destructive gate and operator reconciliation for failures. Do not repeat already accepted basic Btrfs lifecycle or send/receive rehearsals.
