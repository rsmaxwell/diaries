#!/usr/bin/python3
"""0040 3H.5s: read-only receiver-pending/source-unprepared recovery decision.

No sender integration, no receiver prepare, state writes, retries or pruning.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/usr/local/libexec')
STATE_PATH = Path('/media/usb/@snapshots/.agreed-parent.json')
PUSH_LOCK = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
AUTH = ('authorizes_prepare', 'authorizes_promote', 'authorizes_transfer',
        'authorizes_prune', 'authorizes_release')

def load(name):
    path = ROOT / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('recovery_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def decide(source, receiver_reply, candidate, verified_candidate, verified_parent, *, validate):
    """Pure fail-closed decision. Inputs must come from locked live readers."""
    validate(source)
    if type(receiver_reply) is not dict or set(receiver_reply) != {'schema', 'receiver', *AUTH}:
        raise RuntimeError('invalid receiver observation envelope')
    if type(receiver_reply['schema']) is not int or receiver_reply['schema'] != 1:
        raise RuntimeError('invalid receiver observation schema')
    if any(receiver_reply[k] is not False for k in AUTH):
        raise RuntimeError('receiver observation claimed mutation authority')
    receiver = receiver_reply['receiver']
    validate(receiver)
    if (source['pending'] is not None or source['previous'] is not None or
            receiver['previous'] is not None):
        raise RuntimeError('unexpected transition state; manual investigation required')
    parent = source['established']
    if receiver['established'] != parent:
        raise RuntimeError('established parents disagree')
    if type(candidate) is not dict or set(candidate) != {'timestamp', 'uuid'}:
        raise RuntimeError('invalid candidate identity')
    if candidate['timestamp'] <= parent['timestamp']:
        raise RuntimeError('candidate not newer than parent')
    if verified_candidate != dict(candidate, verified=True) or verified_parent != dict(parent, verified=True):
        raise RuntimeError('source Btrfs identity verification failed')
    if receiver['pending'] != candidate:
        raise RuntimeError('receiver pending does not equal verified candidate')
    return {'schema': 1, 'status': 'receiver-prepared-source-unprepared',
            'transaction_id': candidate['timestamp'], 'established': dict(parent),
            'candidate': dict(candidate), 'source': source, 'receiver': receiver,
            'next_action': 'independent-source-prepare-review',
            'authorizes_source_prepare': False, 'authorizes_receiver_prepare': False,
            'authorizes_transfer': False, 'authorizes_promote': False,
            'authorizes_prune': False, 'authorizes_release': False}

def inspect(timestamp, *, modules=None, target_identity=None):
    """Own both source locks across all local evidence and remote observation."""
    if os.geteuid() != 0 and modules is None:
        raise RuntimeError('root required')
    locked, state, evidence, transport = modules or (
        load('locked-get-state'), load('state'), load('source-evidence'), load('get-state-transport'))
    if target_identity is None:
        target_identity = load('transfer-plan').target_identity
    with ExitStack() as stack:
        locked.acquire(stack, PUSH_LOCK)
        locked.acquire(stack, MANAGER_LOCK)
        source = state.load(STATE_PATH, require_root=True)
        state.validate(source)
        if source['pending'] is not None or source['previous'] is not None:
            raise RuntimeError('source is already in transition')
        parent = dict(source['established'])
        verified_parent = evidence.verify_source(parent)
        candidate = target_identity(timestamp)
        verified_candidate = evidence.verify_source(candidate)
        reply = transport.get_state(timestamp, source_lock_held=True)
        return decide(source, reply, candidate, verified_candidate, verified_parent, validate=state.validate)

def main():
    parser = argparse.ArgumentParser(description='Read-only, locked receiver-pending recovery check')
    parser.add_argument('--target', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(inspect(args.target), sort_keys=True))

if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        print('read-only recovery refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
