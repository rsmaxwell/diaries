#!/usr/bin/env python3
"""0040 Step 12.3: durable observation of the Btrfs subvolume created by a receive.

The witness is an independent root-owned sidecar, not a sender-supplied
attestation. It can only be captured while the privileged coordinator holds both
receiver locks and the exact scoped receive transaction is active. No deletion
or retransmission is authorised by the witness alone.
"""
import json
import os
from pathlib import Path
import re
import stat
import subprocess

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
NONCE = re.compile(r'[0-9a-f]{64}\Z')
JOURNAL = '.agreed-parent-transfer-pending.json'

class Refused(RuntimeError):
    pass

def require(ok, reason):
    if not ok:
        raise Refused(reason)

def sidecar_path(state_dir, nonce):
    require(type(nonce) is str and NONCE.fullmatch(nonce), 'invalid nonce')
    return Path(state_dir) / ('.agreed-parent-stage-ownership-' + nonce + '.json')

def _safe_file(path):
    meta = path.lstat()
    require(stat.S_ISREG(meta.st_mode) and not stat.S_ISLNK(meta.st_mode) and
            meta.st_uid == 0 and meta.st_nlink == 1 and
            stat.S_IMODE(meta.st_mode) == 0o600, 'unsafe receiver evidence file')
    return meta

def _load_journal(state_dir, candidate, nonce):
    path = Path(state_dir) / JOURNAL
    _safe_file(path)
    data = json.loads(path.read_text())
    require(type(data) is dict and data.get('schema') == 1 and
            data.get('status') == 'receiving' and data.get('candidate') == candidate and
            data.get('nonce') == nonce and
            type(data.get('staging')) is dict and
            set(data['staging']) == {'directory_dev', 'directory_ino'} and
            data.get('scope_binding') == 'reserved-not-termination-evidence' and
            type(data.get('scope_unit')) is str and
            type(data.get('receiver_boot_id')) is str and
            UUID.fullmatch(data['receiver_boot_id']), 'untrusted staged journal')
    return data

def _btrfs_uuid(path, runner):
    result = runner(['btrfs', 'subvolume', 'show', '--', str(path)],
                    capture_output=True, text=True, check=False)
    require(result.returncode == 0 and type(result.stdout) is str,
            'stage is not an inspectable Btrfs subvolume')
    values = {}
    for line in result.stdout.splitlines():
        if ':' in line:
            key, value = line.strip().split(':', 1)
            if key in ('UUID', 'Received UUID', 'Flags'):
                require(key not in values, 'duplicate Btrfs identity')
                values[key] = value.strip()
    require(type(values.get('UUID')) is str and UUID.fullmatch(values['UUID']),
            'invalid stage subvolume UUID')
    require(values.get('Flags') in ('-', 'readonly'), 'invalid stage flags')
    require(type(values.get('Received UUID')) is str,
            'missing received UUID')
    return values

def capture(candidate, nonce, *, state_dir, final_dir, locks_held=False,
            runner=subprocess.run, boot_id_reader=None):
    """Observe and durably bind the exact new stage during scoped receive.

    Returns False if the stage has not yet appeared. This never grants cleanup.
    A stage that appears and disappears without a witness remains manual-only.
    """
    require(locks_held is True and os.geteuid() == 0, 'root and both locks required')
    require(type(candidate) is dict and set(candidate) == {'timestamp', 'uuid'} and
            STAMP.fullmatch(candidate['timestamp']) and UUID.fullmatch(candidate['uuid']),
            'invalid candidate')
    state_dir = Path(state_dir)
    final_dir = Path(final_dir)
    state_meta = state_dir.lstat()
    parent_meta = final_dir.lstat()
    require(stat.S_ISDIR(state_meta.st_mode) and state_meta.st_uid == 0 and
            not stat.S_ISLNK(state_meta.st_mode) and
            (stat.S_IMODE(state_meta.st_mode) & 0o022) == 0,
            'unsafe state parent')
    require(stat.S_ISDIR(parent_meta.st_mode) and parent_meta.st_uid == 0 and
            not stat.S_ISLNK(parent_meta.st_mode) and
            (stat.S_IMODE(parent_meta.st_mode) & 0o022) == 0,
            'unsafe stage parent')
    journal = _load_journal(state_dir, candidate, nonce)
    current_boot = (Path('/proc/sys/kernel/random/boot_id').read_text().strip()
                    if boot_id_reader is None else boot_id_reader())
    require(current_boot == journal['receiver_boot_id'],
            'stage witness cannot be created outside the receiving boot')
    require((parent_meta.st_dev, parent_meta.st_ino) ==
            (journal['staging']['directory_dev'], journal['staging']['directory_ino']),
            'staging parent changed')
    stage = final_dir / ('.receive-' + nonce)
    published = final_dir / candidate['timestamp']
    require(not (published.exists() or published.is_symlink()),
            'published candidate present')
    if not stage.exists() and not stage.is_symlink():
        return False
    require(not stage.is_symlink(), 'stage symlink')
    info = stage.lstat()
    require(stat.S_ISDIR(info.st_mode) and info.st_uid == 0,
            'unowned stage')
    fields = _btrfs_uuid(stage, runner)
    witness = {'schema': 1, 'nonce': nonce, 'candidate': candidate,
               'scope_unit': journal['scope_unit'],
               'receiver_boot_id': journal['receiver_boot_id'],
               'parent_dev': parent_meta.st_dev, 'parent_ino': parent_meta.st_ino,
               'stage_dev': info.st_dev, 'stage_ino': info.st_ino,
               'subvolume_uuid': fields['UUID']}
    path = sidecar_path(state_dir, nonce)
    if path.exists() or path.is_symlink():
        require(load(candidate, nonce, state_dir=state_dir) == witness,
                'stage ownership witness changed')
        return True
    raw = (json.dumps(witness, sort_keys=True) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as output:
            output.write(raw)
            output.flush()
            os.fsync(output.fileno())
        dfd = os.open(state_dir, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    except BaseException:
        # Preserve incident evidence even if durability cannot be established.
        raise
    return True

def load(candidate, nonce, *, state_dir):
    path = sidecar_path(state_dir, nonce)
    _safe_file(path)
    value = json.loads(path.read_text())
    require(type(value) is dict and set(value) ==
            {'schema','nonce','candidate','scope_unit','receiver_boot_id',
             'parent_dev','parent_ino','stage_dev','stage_ino','subvolume_uuid'} and
            value['schema'] == 1 and value['nonce'] == nonce and
            value['candidate'] == candidate and
            type(value['scope_unit']) is str and
            type(value['receiver_boot_id']) is str and
            UUID.fullmatch(value['receiver_boot_id']) and
            type(value['subvolume_uuid']) is str and
            UUID.fullmatch(value['subvolume_uuid']) and
            all(type(value[k]) is int and value[k] > 0
                for k in ('parent_dev','parent_ino','stage_dev','stage_ino')),
            'invalid stage ownership witness')
    return value
