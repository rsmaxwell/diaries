#!/usr/bin/env python3
"""0040 Step 12.3 sender-side two-phase execution boundary (internal only).

No public CLI or changes to the legacy sender. The authenticated receiver
finalisation command is a fixed trusted adapter; never accept a success flag
from an untrusted remote payload. This function does not promote parent pins.
"""
import re

STAMP = re.compile(r"[0-9]{8}-[0-9]{6}Z\Z")
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z")

class SenderTransactionRefused(RuntimeError):
    pass

def _identity(value):
    if (type(value) is not dict or set(value) != {'timestamp', 'uuid'} or
            type(value['timestamp']) is not str or not STAMP.fullmatch(value['timestamp']) or
            type(value['uuid']) is not str or not UUID.fullmatch(value['uuid'])):
        raise SenderTransactionRefused('invalid snapshot identity')

def send_then_finalize(parent, candidate, *, pinned_parent_verified,
                       receive_transfer, finalise_authenticated,
                       verify_final_receipt):
    """Run one transfer and then one independently authenticated finalise.

    Caller MUST select adapters from fixed installed code while holding the
    source transaction lock. receive_transfer is required to wait/reap BOTH
    source-send and SSH/receiver processes and return their local exit codes;
    no exception/timeout may be translated into success. The receiver independently
    authenticates the SSH finalise request and binds it to the provisional journal.
    """
    _identity(parent); _identity(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise SenderTransactionRefused('invalid parent ordering')
    if not all(callable(x) for x in (pinned_parent_verified,receive_transfer,
                                    finalise_authenticated,verify_final_receipt)):
        raise SenderTransactionRefused('missing trusted adapters')
    if pinned_parent_verified(parent, candidate) is not True:
        raise SenderTransactionRefused('source pin or prepared state unverified')
    try:
        exits = receive_transfer(parent, candidate)
    except BaseException as exc:
        raise SenderTransactionRefused('receive uncertain: source pin and journal retained') from exc
    if (type(exits) is not dict or set(exits) != {'source_send_exit','ssh_exit'} or
            type(exits['source_send_exit']) is not int or
            type(exits['ssh_exit']) is not int or
            exits['source_send_exit'] != 0 or exits['ssh_exit'] != 0):
        raise SenderTransactionRefused('send/SSH outcome not proven: retain source pin')
    try:
        acknowledgement = finalise_authenticated(parent, candidate)
    except BaseException as exc:
        raise SenderTransactionRefused('finalisation uncertain: manual reconciliation') from exc
    if (type(acknowledgement) is not dict or
            acknowledgement.get('status') != 'receiver-receipt-committed-promotion-pending' or
            acknowledgement.get('parent') != parent or acknowledgement.get('candidate') != candidate or
            acknowledgement.get('receipt_committed') is not True or
            acknowledgement.get('state_changed') is not False or
            acknowledgement.get('authorizes_prune') is not False or
            acknowledgement.get('authorizes_release') is not False):
        raise SenderTransactionRefused('finalisation acknowledgement unsafe or ambiguous')
    if verify_final_receipt(parent, candidate) is not True:
        raise SenderTransactionRefused('receiver receipt unverified: manual reconciliation')
    return {'status':'receiver-committed-promotion-pending', 'parent':parent,
            'candidate':candidate, 'source_pin_retained':True,
            'authorizes_prune':False, 'authorizes_transition':False,
            'authorizes_release':False}


def send_then_finalize_fixed(parent, candidate, *, pinned_parent_verified,
                             command_builder, stream_adapter, finalise_ssh,
                             verify_final_receipt, timeout_seconds=1800):
    """Compose the fixed-command builder with the binary transport and receipt gate.

    The installed caller, not a remote request, must supply trustworthy adapters.
    `finalise_ssh` must authenticate the receiver and parse its exact receipt-only
    acknowledgement; this helper deliberately cannot accept arbitrary remote
    success claims or promote a parent.
    """
    if (command_builder is None or stream_adapter is None or
            not callable(finalise_ssh) or
            type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 7200):
        raise SenderTransactionRefused('missing trusted execution dependencies')

    def transfer(a, b):
        send_cmd, ssh_cmd = command_builder.receive_commands(a, b)
        return stream_adapter.run_binary_send_ssh(
            send_cmd, ssh_cmd, timeout_seconds=timeout_seconds)

    def finalise(a, b):
        command = command_builder.finalise_command(a, b)
        return finalise_ssh(command, a, b)

    return send_then_finalize(
        parent, candidate, pinned_parent_verified=pinned_parent_verified,
        receive_transfer=transfer, finalise_authenticated=finalise,
        verify_final_receipt=verify_final_receipt)
