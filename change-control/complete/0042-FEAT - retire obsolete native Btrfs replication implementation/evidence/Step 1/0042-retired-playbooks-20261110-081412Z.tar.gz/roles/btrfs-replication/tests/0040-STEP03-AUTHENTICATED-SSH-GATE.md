# 0040 Step 3 — Authenticated SSH source-held fixture

Status: test implementation ready for read-only/non-destructive execution; not yet accepted.

The regression is run on mars, piped from mango. It opens the already configured
BatchMode SSH connection to `richard@10.254.22.1:39263` using strict host-key
checking, no forwarding and a fixed, non-destructive remote Python challenge.
It owns a disposable flock and pin for the entire round trip, validates a fresh
cryptographic nonce, waits for SSH to exit and cleans up the disposable fixture.
It never invokes `sudo`, Btrfs, the receiver manager or the privileged gateway.

This is not source-production-lock continuity or remote PID-reaping evidence.
It is not approval, retention, journal or deletion acceptance. Production pruning
and sudoers remain unchanged. The 03:30 UTC push timer remains undisturbed.

Command (mango SSH terminal):

    cd /home/richard/playbooks
    python3 -m py_compile roles/btrfs-replication/tests/verify-authenticated-owned-ssh.py
    ssh mars 'python3 -' < roles/btrfs-replication/tests/verify-authenticated-owned-ssh.py
    git diff --check && git status --short

Stop on failure; do not run the destructive integrated transaction until the
production-compatible privileged transport and source lock/pin lifetime are
implemented and approved separately.
