#!/usr/bin/env python3
"""0040 Step 12.3: offline privileged deletion guard; no Btrfs mutations."""
import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase, main, mock

SOURCE = Path(__file__).resolve().parents[1] / 'files/btrfs-native-endpoint.py'
spec = importlib.util.spec_from_file_location('endpoint_guard_0040', SOURCE)
endpoint = importlib.util.module_from_spec(spec)
spec.loader.exec_module(endpoint)

class Guard(TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.state = Path(self.tmp.name)
        self.pending = self.state / '.agreed-parent-transfer-pending.json'
        self.patch = mock.patch.object(endpoint, 'RECEIVER_STATE', self.state)
        self.patch.start()
        self.addCleanup(self.patch.stop)
        self.patch = mock.patch.object(endpoint, 'AGREED_TRANSFER_PENDING', self.pending)
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def test_absent_marker_allows_subsequent_validation(self):
        endpoint.refuse_unfinished_agreed_transfer()

    def test_regular_marker_blocks(self):
        self.pending.write_text('{}')
        with self.assertRaisesRegex(RuntimeError, 'Unfinished agreed-parent'):
            endpoint.refuse_unfinished_agreed_transfer()

    def test_dangling_symlink_blocks(self):
        self.pending.symlink_to(self.state / 'missing')
        with self.assertRaisesRegex(RuntimeError, 'Unfinished agreed-parent'):
            endpoint.refuse_unfinished_agreed_transfer()

    def test_wrong_state_directory_refused(self):
        self.state.rmdir()
        with self.assertRaisesRegex(RuntimeError, 'Unsafe receiver state'):
            endpoint.refuse_unfinished_agreed_transfer()

    def test_delete_entry_refuses_before_btrfs(self):
        self.pending.write_text('{}')
        with mock.patch.object(endpoint, 'run', side_effect=AssertionError('Btrfs reached')):
            with self.assertRaisesRegex(RuntimeError, 'Unfinished agreed-parent'):
                endpoint.delete_receiver('20261020-010000Z')

    def test_guard_rechecked_at_destructive_boundary(self):
        import inspect
        source=inspect.getsource(endpoint.delete_receiver)
        self.assertGreaterEqual(source.count('refuse_unfinished_agreed_transfer()'), 2)
        self.assertLess(source.rfind('refuse_unfinished_agreed_transfer()'), source.index("run('btrfs', 'subvolume', 'delete'"))

if __name__ == '__main__':
    main(verbosity=2)
