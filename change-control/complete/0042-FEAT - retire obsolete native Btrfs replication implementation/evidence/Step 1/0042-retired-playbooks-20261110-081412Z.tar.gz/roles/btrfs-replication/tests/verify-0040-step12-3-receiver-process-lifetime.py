#!/usr/bin/env python3
"""0040 Step 12.3: receiver child-group lifetime regression (no real Btrfs)."""
import importlib.util
from pathlib import Path
import signal
import subprocess
import unittest
from types import SimpleNamespace

PATH=Path(__file__).resolve().parents[1]/'files'/'btrfs-agreed-parent-receive-core.py'
spec=importlib.util.spec_from_file_location('agreed_receive_lifetime',PATH)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class FakeProcess:
    pid=12345
    returncode=0
    def __init__(self, events, *, timeout=False, rc=0):
        self.events=events;self.timeout=timeout;self.returncode=rc
    def communicate(self,timeout=None):
        self.events.append(('communicate',timeout))
        if self.timeout:
            self.timeout=False
            raise subprocess.TimeoutExpired(['receiver'],timeout)
        return b'',b''
    def wait(self,timeout=None):
        self.events.append(('wait',timeout))
        return self.returncode

class Tests(unittest.TestCase):
    def setup(self, *, timeout=False, rc=0, alive=False):
        events=[]
        p=FakeProcess(events,timeout=timeout,rc=rc)
        def popen(cmd,**kw):
            self.assertTrue(kw['start_new_session'])
            self.assertIs(kw['stderr'],subprocess.PIPE)
            events.append(('popen',cmd))
            return p
        def kill(pid,sig):
            events.append(('signal',sig))
            if sig==0 and not alive:raise ProcessLookupError
        return events,popen,kill
    def test_success_group_gone(self):
        e,p,k=self.setup()
        mod.run_bounded_receive_group(['receiver'],stdin=object(),timeout=10,popen=p,kill_group=k,clock=lambda:0)
        self.assertEqual([x[1] for x in e if x[0]=='signal'],[0])
    def test_timeout_terminates_group(self):
        e,p,k=self.setup(timeout=True)
        with self.assertRaisesRegex(RuntimeError,'journal retained'):
            mod.run_bounded_receive_group(['receiver'],stdin=object(),timeout=10,popen=p,kill_group=k,clock=lambda:0)
        self.assertIn(('signal',signal.SIGTERM),e)
        self.assertIn(('signal',signal.SIGKILL),e)
    def test_surviving_group_refused(self):
        e,p,k=self.setup(alive=True)
        with self.assertRaisesRegex(RuntimeError,'remains alive'):
            mod.run_bounded_receive_group(['receiver'],stdin=object(),timeout=10,popen=p,kill_group=k,clock=lambda:0)
        self.assertIn(('signal',signal.SIGKILL),e)
    def test_failed_exit_refused(self):
        e,p,k=self.setup(rc=1)
        with self.assertRaisesRegex(RuntimeError,'Btrfs receive failed'):
            mod.run_bounded_receive_group(['receiver'],stdin=object(),timeout=10,popen=p,kill_group=k,clock=lambda:0)
    def test_bad_deadline_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'Invalid receive deadline'):
            mod.run_bounded_receive_group(['receiver'],stdin=object(),timeout=0,popen=lambda *a,**kw:None)
    def test_no_production_cli(self):
        src=PATH.read_text()
        self.assertNotIn("if __name__ == '__main__'",src)
        self.assertNotIn('def main(',src)

if __name__=='__main__':unittest.main(verbosity=2)
