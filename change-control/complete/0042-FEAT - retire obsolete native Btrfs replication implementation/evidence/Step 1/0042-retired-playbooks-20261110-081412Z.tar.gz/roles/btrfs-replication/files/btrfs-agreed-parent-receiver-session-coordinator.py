#!/usr/bin/python3
"""0040/12.3/04R: dormant lock-scoped receiver session coordinator.

Only caller-injected test adapters can register channels. No CLI, sockets, SSH,
Btrfs receive, receipt writes, or production transfer authority. The proof
factory must be a trusted adapter, never data submitted by a remote client.
"""
from contextlib import ExitStack
import importlib.util
from pathlib import Path


class CoordinatorRefused(RuntimeError):
    pass


def load_binding(path=None):
    path = Path(path or '/usr/local/libexec/btrfs-agreed-parent-receiver-session-binding.py')
    spec = importlib.util.spec_from_file_location('receiver_session_binding_04r', path)
    module = importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def review(parent, candidate, *, acquire_lock, observe_prepared, trusted_registration,
           binding, lock_owner, clock=None, duration=120):
    """Hold both receiver locks over A/B observation and simulated registrations.

    All supplied callbacks are TEST SEAMS, not verified runtime transports.
    `trusted_registration` must return two (channel, token, TransportProof)
    tuples created by a trusted test adapter. Refuse any other form.
    """
    if (not all(callable(f) for f in (acquire_lock, observe_prepared, trusted_registration))
            or not isinstance(lock_owner, str) or not lock_owner):
        raise CoordinatorRefused('invalid review adapters or lock owner')
    with ExitStack() as stack:
        acquire_lock(stack, 'manager')
        acquire_lock(stack, 'writer')
        if observe_prepared(parent, candidate) is not True:
            raise CoordinatorRefused('prepared-state and absence review refused')
        kwargs = {'lock_owner': lock_owner, 'duration': duration}
        if clock is not None:
            kwargs['clock'] = clock
        session = binding.ReceiverSession(parent, candidate, **kwargs)
        try:
            registrations = trusted_registration(session.token, parent, candidate)
            if type(registrations) not in (list, tuple) or len(registrations) != 2:
                raise CoordinatorRefused('exactly two trusted registrations required')
            for item in registrations:
                if type(item) is not tuple or len(item) != 3:
                    raise CoordinatorRefused('invalid trusted registration')
                channel, token, proof = item
                session.register(channel, token=token, parent=parent, candidate=candidate,
                                 proof=proof, locks_held=True, lock_owner=lock_owner)
            session.bound(locks_held=True, lock_owner=lock_owner)
            return {'schema': 1, 'status': 'receiver-session-coordination-review',
                    'channels_registered': ['control', 'data'], 'locks_held_during_review': True,
                    'transfer_executed': False, 'receipt_committed': False,
                    'authorizes_transfer': False, 'authorizes_promote': False,
                    'authorizes_prune': False, 'authorizes_release': False}
        finally:
            session.close()
