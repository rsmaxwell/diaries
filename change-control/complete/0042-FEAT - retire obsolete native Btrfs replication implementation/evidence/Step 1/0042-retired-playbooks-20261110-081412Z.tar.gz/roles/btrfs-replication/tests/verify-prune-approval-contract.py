#!/usr/bin/env python3
"""Non-destructive 0040 approval-contract regression (requires root for valid fixture)."""
import datetime
import importlib.util
import json
import os
from pathlib import Path
import tempfile

source = Path(__file__).resolve().parents[1] / 'files/btrfs-native-push.py'
spec = importlib.util.spec_from_file_location('push', source)
push = importlib.util.module_from_spec(spec)
spec.loader.exec_module(push)
assert not hasattr(push, 'execute_production_prune')
STAMP = '20261020-030026Z'
PARENT = '20261024-030038Z'
UUID = '22e0ca45-0f49-c745-85b0-af6b6cfb915c'
clock = datetime.datetime(2026, 10, 24, 7, tzinfo=datetime.timezone.utc)
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / 'approval.json'
    data = dict(schema=1, operation='receiver-prune-one', candidate=STAMP,
                protected_parent=PARENT, protected_parent_uuid=UUID,
                expires_at_utc='2026-10-24T07:30:00Z', reason='Disposable test')
    def write():
        path.write_text(json.dumps(data))
        path.chmod(0o600)
    write()
    if os.geteuid() == 0:
        result = push.validate_prune_approval(path, candidate=STAMP,
                 parent_stamp=PARENT, parent_uuid=UUID, now=clock)
        assert result['candidate'] == STAMP
    else:
        try:
            push.validate_prune_approval(path, candidate=STAMP,
                 parent_stamp=PARENT, parent_uuid=UUID, now=clock)
        except RuntimeError as exc:
            assert 'root-owned' in str(exc)
        else:
            raise AssertionError('Unprivileged fixture was accepted')
    for field, altered in [
        ('candidate', '20261019-030038Z'),
        ('protected_parent_uuid', '00000000-0000-0000-0000-000000000000'),
        ('expires_at_utc', '2026-10-24T06:59:59Z'),
        ('operation', 'receiver-prune-all')]:
        data[field] = altered
        write()
        try:
            push.validate_prune_approval(path, candidate=STAMP,
                     parent_stamp=PARENT, parent_uuid=UUID, now=clock)
        except (RuntimeError, ValueError):
            pass
        else:
            raise AssertionError('Invalid approval accepted: ' + field)
        data[field] = dict(schema=1, operation='receiver-prune-one', candidate=STAMP,
                           protected_parent=PARENT, protected_parent_uuid=UUID,
                           expires_at_utc='2026-10-24T07:30:00Z', reason='Disposable test')[field]
    write()
    path.chmod(0o644)
    try:
        push.validate_prune_approval(path, candidate=STAMP,
                parent_stamp=PARENT, parent_uuid=UUID, now=clock)
    except RuntimeError:
        pass
    else:
        raise AssertionError('Insecure permissions accepted')
    path.chmod(0o600)
    link = Path(tmp) / 'link.json'
    link.symlink_to(path)
    try:
        push.validate_prune_approval(link, candidate=STAMP,
                parent_stamp=PARENT, parent_uuid=UUID, now=clock)
    except RuntimeError:
        pass
    else:
        raise AssertionError('Symlink accepted')
print('PASS: approval identity, bounded expiry, ownership, permissions, symlink rejection')
