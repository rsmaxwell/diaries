#!/usr/bin/env python3
"""Manual receiver-first previous-parent acknowledgement, never snapshot release."""
from contextlib import ExitStack
from pathlib import Path
import json
import subprocess

STATE = Path('/media/usb/@snapshots/.agreed-parent.json')
PUSH = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')

class PreviousAckRefused(RuntimeError):
    pass

def _wire(command, *, run=subprocess.run):
    try:
        outcome = run(command, input=b'', stdout=subprocess.PIPE,
                      stderr=subprocess.PIPE, timeout=60, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise PreviousAckRefused('receiver acknowledgement/readback uncertain') from exc
    if outcome.returncode != 0 or not isinstance(outcome.stdout, bytes) or len(outcome.stdout) > 65536:
        raise PreviousAckRefused('receiver acknowledgement/readback refused')
    try:
        return json.loads(outcome.stdout)
    except (UnicodeError, ValueError) as exc:
        raise PreviousAckRefused('malformed receiver acknowledgement') from exc

def run(*, observer, state, evidence, receipt, promotion, commands, run_ssh=subprocess.run):
    """Caller supplies fixed trusted modules, not CLI user inputs.

    Retried after a lost acknowledgement: receiver can already be clear;
    source still has A previous. No snapshot deletion occurs.
    """
    with ExitStack() as stack:
        observer.lock(stack, PUSH)
        observer.lock(stack, MANAGER)
        current = state.load(STATE, require_root=True)
        state.validate(current)
        a, b = current['previous'], current['established']
        if a is None or current['pending'] is not None:
            raise PreviousAckRefused('source previous-parent acknowledgement not prepared')
        if a['timestamp'] >= b['timestamp']:
            raise PreviousAckRefused('invalid A/B ordering')
        for identity in (a, b):
            if evidence.verify_source(identity) != dict(identity, verified=True):
                raise PreviousAckRefused('source snapshot identity not verified')
        # Independently confirm receiver still has the committed A->B receipt
        # and that B was durably promoted while A was pinned.
        if receipt(a, b, commands=commands) is not True:
            raise PreviousAckRefused('receiver committed receipt not verified')
        expected_promoted = {'schema': 1, 'established': b, 'pending': None, 'previous': a}
        expected_cleared = {'schema': 1, 'established': b, 'pending': None, 'previous': None}
        # Read committed receiver state through fixed SSH. If the previous
        # acknowledgement was already committed, resume at the source write.
        try:
            checked = _wire(commands.previous_readback_command(a, b), run=run_ssh)
            receiver_already_clear = checked == expected_cleared
        except PreviousAckRefused:
            receiver_already_clear = False
        if not receiver_already_clear:
            promoted = promotion.receiver_readback(a, b, commands=commands)
            if promoted != expected_promoted:
                raise PreviousAckRefused('receiver promoted state confirmation refused')
            result = _wire(commands.acknowledge_previous_command(a, b), run=run_ssh)
            if result != expected_cleared:
                raise PreviousAckRefused('receiver previous-parent acknowledgement mismatch')
        checked = _wire(commands.previous_readback_command(a, b), run=run_ssh)
        if checked != expected_cleared:
            raise PreviousAckRefused('receiver previous-parent independent readback mismatch')
        # The source update is last, under both canonical source locks.
        state.save(STATE, state.acknowledge_previous(current), require_root=True)
        observed = state.load(STATE, require_root=True)
        if observed != expected_cleared:
            raise PreviousAckRefused('source acknowledgement durable readback mismatch')
        return {'status': 'both-previous-acknowledged', 'source_state': observed,
                'receiver_state': checked, 'authorizes_prune': False,
                'authorizes_release': False}
