#!/usr/bin/env python3
"""Read-only, lock-consistent source candidate observation for Step 12.3.

Not an execution permit. Holds canonical push and manager locks during source
state and Btrfs candidate inspection. No receiver mutation, preparation or send.
"""
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

LIB = Path('/usr/local/libexec')
PUSH = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
STATE = Path('/media/usb/@snapshots/.agreed-parent.json')


def load_module(name, *, root=LIB):
    source = root / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('candidate_' + name.replace('-', '_'), source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def review(*, acquire, load_state, validate_state, select, push=PUSH, manager=MANAGER,
           state_file=STATE):
    with ExitStack() as stack:
        acquire(stack, push)
        acquire(stack, manager)
        current = load_state(state_file, require_root=True)
        validate_state(current)
        if current.get('pending') is not None or current.get('previous') is not None:
            return {'status': 'transaction-reconciliation-required',
                    'state_changed': False, 'authorizes_transfer': False}
        parent = current['established']
        if not isinstance(parent, dict) or not isinstance(parent.get('timestamp'), str):
            raise RuntimeError('invalid established parent')
        candidate = select(parent['timestamp'])
        if candidate is None:
            return {'status': 'no-eligible-candidate', 'parent': parent,
                    'state_changed': False, 'authorizes_transfer': False}
        if (not isinstance(candidate, dict) or
                candidate.get('timestamp', '') <= parent['timestamp'] or
                not isinstance(candidate.get('uuid'), str)):
            raise RuntimeError('invalid candidate selection')
        return {'status': 'locked-candidate-review', 'parent': parent,
                'candidate': candidate, 'state_changed': False,
                'authorizes_transfer': False, 'authorizes_prune': False,
                'authorizes_release': False}


def main():
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    locks = load_module('locked-get-state')
    state = load_module('state')
    candidates = load_module('candidate-selection')
    print(json.dumps(review(acquire=locks.acquire, load_state=state.load,
                            validate_state=state.validate,
                            select=candidates.select_candidate), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as exc:
        print('locked candidate review refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
