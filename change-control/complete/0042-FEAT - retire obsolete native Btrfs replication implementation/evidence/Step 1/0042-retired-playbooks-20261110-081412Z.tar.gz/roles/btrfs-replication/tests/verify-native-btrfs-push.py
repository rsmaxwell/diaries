#!/usr/bin/env python3
"""Offline push contract tests: no SSH, send, receive, or filesystem changes."""
import importlib.util
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

files = Path(__file__).resolve().parents[1] / 'files'
def load(name, path):
    spec=importlib.util.spec_from_file_location(name, files/path)
    obj=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

push=load('push','btrfs-native-push.py')
recv=load('receiver','btrfs-native-push-receiver.py')
S='20261012-100003Z'
N='20261012-190000Z'
UUID='7ad1f171-d1c7-0545-82a1-52e84adac979'
NEXT='98765000-d1c7-0545-82a1-52e84adac979'
with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    (base/'state').mkdir()
    (base/'received').mkdir()
    with patch.object(recv, 'ROOT', base/'received'), patch.object(recv,'STATE',base/'state'):
        full=recv.validate(S,UUID,None,None,True,False)
        assert full['action']=='full-baseline'
        # Create a real-shaped acceptance receipt, then require an explicit reseed for new full.
        old={'schema':1,'snapshot':S,'source_uuid':UUID,'received_uuid':UUID,
            'transport':'btrfs-full','source_filesystem_uuid':recv.SOURCE_FS,
            'receiver_filesystem_uuid':recv.RECEIVER_FS,
            'destination':str(base/'received'/S), 'read_only_verified':True,
            'source_send_exit':0,'receiver_receive_exit':0}
        (base/'state'/(S+'.json')).write_text(json.dumps(old))
        with patch.object(recv,'inspect',return_value={'flags':'readonly','received_uuid':UUID}):
            assert recv.receipt(S)['source_uuid']==UUID
            assert recv.validate(N,NEXT,S,UUID,False,False)['action']=='incremental'
            for par in ('mismatch',''):
                try: recv.validate(N,NEXT,S,par,False,False)
                except RuntimeError: pass
                else: raise AssertionError('Invalid parent accepted')
            try: recv.validate(N,NEXT,None,None,True,False)
            except RuntimeError: pass
            else: raise AssertionError('Implicit reseed accepted')
            assert recv.validate(N,NEXT,None,None,True,True)['action']=='full-baseline'
        with patch.object(recv,'inspect',return_value={'flags':'readonly','received_uuid':'wrong'}):
            assert recv.receipt(S) is None
            try: recv.validate(N,NEXT,S,UUID,False,False)
            except RuntimeError: pass
            else: raise AssertionError('Mismatched received UUID accepted')
        # Simulated source-side selection uses only receiver-verified receipts and local UUID.
        with patch.object(push,'remote',return_value=json.dumps([{'snapshot':S,'source_uuid':UUID}])), \
             patch.object(push,'local',return_value={'flags':'readonly','parent_uuid':push.SOURCE_PARENT,'received_uuid':'-','uuid':UUID}):
            assert push.choose_parent(N)==(S,UUID)
        with patch.object(push,'remote',return_value=json.dumps([{'snapshot':S,'source_uuid':UUID}])), \
             patch.object(push,'local',return_value={'flags':'readonly','parent_uuid':push.SOURCE_PARENT,'received_uuid':'-','uuid':'wrong'}):
            assert push.choose_parent(N)==(None,None)
        with patch.object(push, 'local_sources', return_value=[
                {'snapshot': S, 'uuid': UUID}, {'snapshot': N, 'uuid': NEXT}]):
            assert push.choose_latest_source() == (N, NEXT)
        assert push.accepted([{'snapshot': N, 'source_uuid': NEXT}], N, NEXT)
        assert not push.accepted([{'snapshot': S, 'source_uuid': UUID}], N, NEXT)
        # Receipt can be created once, never overwritten.
        with patch.object(recv,'STATE',base/'state'):
            try: recv.atomic_receipt(old)
            except RuntimeError: pass
            else: raise AssertionError('Existing acceptance receipt overwritten')
assert push.SSH[-1]=='richard@10.254.22.1' and '39263' in push.SSH
print('PASS: native push full/incremental, verified parent, reseed and receipt guards')
