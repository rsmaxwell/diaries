# 0040-FEAT Step 3 — Installed manager boundary and next integration gate

## Baseline

Latest accepted Playbooks revision reported on `mango`: `9059df9`.
The accepted disposable lifecycle rehearsal created and removed test Btrfs subvolumes on `backup`, and the subsequent receiver recovery state was `CLEAN`.

## Read-only boundary verification

`verify-installed-receiver-transaction-boundary.py` loads the installed receiver manager and production configuration, verifies lock separation, disabled pruning, required holds and absence of a pending journal, then passes deliberately invalid identities into the real internal deletion function. It asserts rejection occurs before inventory or the injected pin/deletion callbacks. It does not call a valid transaction, modify a receipt, or write a journal.

## Remaining integrated acceptance (NOT accomplished by this test)

1. Refresh source baseline from `mango` `9059df9` or newer before modifying operational code. The uploaded 2026-10-24 11:19 Playbooks bundle predates some accepted changes.
2. Create an isolated Btrfs send/receive fixture, not merely a read-only snapshot: the receiver manager validates real `Received UUID` values and binds them to receipt records.
3. Use completely separate fixture `snapshot_root`, `receiver_state_dir`, manager/writer locks, receipts, retention configuration and root-owned checkpoint-holds file. Never point fixture configuration at `/@data/mars-received` or its state directory.
4. Prove the candidate is eligible according to the *existing* receiver retention checks; preserve newest and held snapshots. Do not disable validations or monkey-patch them for destructive acceptance.
5. Run the existing root-only approved adapter, keep the manager-before-writer lock ordering, exercise the two live source challenges over a held session, and inject a deletion callback restricted to the fixture directory only.
6. Verify single-use approval marker, receipt unlink only after confirmed Btrfs deletion, journal clear on success and retained journal on interrupted execution; verify recovery requires operator reconciliation.
7. Observe process lifetime over a real SSH disconnect, including receiver child exit (not just local SSH exit), with a source pin persisting after uncertain outcomes.
8. Require a separate explicit destructive authorisation after reviewing the fully isolated script and a read-only `--plan` output; stop if the current `backup` recovery journal is not `CLEAN`.

Production sudoers, pruning setting, 03:30 UTC push, retention and hold files must not change during acceptance. Do not mark Step 3 CLOSED until the full gate is proved.
