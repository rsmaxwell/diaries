# 0040-FEAT Step 3 — live executor interface audit

Commit baseline: c823dfa (receiver endpoint permission source). The audit is read-only and does not claim live end-to-end acceptance.

The production `delete-receiver` endpoint checks the **production** receiver journal, receipts and Btrfs UUIDs. It is not an isolated test fixture callback. Its availability under sudoers does not establish source-held approval.

The future privileged executor must: bind fixed root-owned approval/consumed directories to one eligible candidate; hold manager then receiver writer locks; maintain one authenticated source-held connection and two fresh pin challenges; call `receiver_delete_one_locked` with the real production-path endpoint callback; report completion only after journal and receipt finish; preserve approval consumption and journal upon uncertainty. The sender must independently hold the durable source pin and lock for the whole transaction.

Before any deletion, verify the operator approval, parent UUID, retention and mandatory historical holds, deployment rollback and source trust boundary. Protect the 20261013-171228Z and 20261018-165453Z checkpoints. Automatic pruning must remain disabled. **Do not use the production endpoint to delete a disposable fixture:** it can only address the fixed managed receiver collection.

Run on mango:

```
cd /home/richard/playbooks && python3 roles/btrfs-replication/tests/0040-live-receiver-contract-audit.py
```

This audit identifies interfaces and blockers; it does not complete Stage 2 or authorise a production deletion.
