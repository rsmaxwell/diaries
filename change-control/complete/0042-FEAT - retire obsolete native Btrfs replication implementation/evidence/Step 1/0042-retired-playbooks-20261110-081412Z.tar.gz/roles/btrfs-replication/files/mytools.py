#!/usr/bin/python3

import subprocess
import codecs
import sys
import json
import os
import getpass





def dump_command(command):
    strcommand = ""
    for item in command:
        strcommand = strcommand + item + ' '

    print(strcommand)


def dump_command_result(returncode, stdout, stderr):
    print("returncode: ", returncode)
    print("---[ stdout ]----------------")
    print(stdout)
    print("---[ stderr ]----------------")
    print(stderr)
    print("-----------------------------")

def dump_result(result):
    dump_command_result(result["rc"], result["stdout"], result["stderr"])

def dump_CompletedProcess(cp):
    dump_command_result(cp.returncode, cp.stdout, cp.stderr)

def dump_output(returncode, output):
    dump_command_result(returncode, output[0], output[1])




def find_program(program):
    command = ["which", program]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    if (result.returncode == 0):
        return {
            "rc": 0,
            "found": True,
            "path": result.stdout.decode().rstrip()
        }
    elif (result.returncode == 1):
        return {
            "rc": 0,
            "found": False
        }

    print("Unexpected error, returncode:", result.returncode)
    dump_command(command)
    dump_CompletedProcess(result)
    return {
        "rc": 3
    }





def find_mount(directory):
    command = ["findmnt", directory]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    if (result.returncode == 0):
        return {
            "rc": 0,
            "mounted": True
        }
    elif (result.returncode == 1):
        return {
            "rc": 0,
            "mounted": False
        }
    else:
        print("Unexpected error, returncode:", result.returncode)
        dump_command(command)
        dump_CompletedProcess(result)
        return {
            "rc": 3
        }



def unmount_filesystem(directory):
    command = ["umount", directory]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    if (result.returncode == 0):
        print("directory '" + directory + "' was unmounted sucessfully")
        return {
            "rc": 0,
            "changed": True
        }
    elif (result.returncode == 32):
        print("directory '" + directory + "' was not mounted")
        return {
            "rc": 0,
            "changed": True
        }
    elif (result.returncode != 0):
        print("Unexpected error, returncode:", result.returncode)
        dump_command(command)
        dump_CompletedProcess(result)
        return {
            "rc": 3
        }

    return {
        "rc": 0
    }




def execute_command(command, working_directory):

    sys.stdout.flush()
    sys.stderr.flush()

    p = subprocess.Popen(command, cwd=working_directory, stdout=sys.stdout, stderr=sys.stderr)

    try: 
        output = p.communicate()
    except:
        traceback.print_exc()
        return {
            "rc": 3
        }


    if (p.returncode != 0):
        dump_command(command)
        dump_output(p.returncode, output)
        return {
            "rc": 3
        }

    return {
        "rc": 0,
        "stdout": output[0],
        "stderr": output[1]
    }



def list_crontab(crontab, output_file):

    with open(output_file, "w") as out:

        command = [crontab, "-l"]
        p = subprocess.Popen(command, stdout=out, stderr=subprocess.PIPE)

        try: 
            output = p.communicate()
        except:
            traceback.print_exc()
            return {
                "rc": 3
            }

        if (p.returncode != 0):
            dump_command(command)
            dump_output(p.returncode, output)
            return {
                "rc": 3
            }

    return {
        "rc": 0
    }



def dump_cacti_database(mysqldump, user, password, database, output_file):

    with open(output_file, "w") as out:

        command = [mysqldump, "--user", user, "--password=" + password, "--add-drop-table", "--databases", database]
        p = subprocess.Popen(command, stdout=out, stderr=subprocess.PIPE)

        try: 
            output = p.communicate()
        except:
            traceback.print_exc()
            return {
                "rc": 3
            }

        if (p.returncode != 0):
            dump_command(command)
            dump_output(p.returncode, output)
            return {
                "rc": 3
            }

    return {
        "rc": 0,
        "changed": True
    }


def print_file(filename):

    print("---[ ", filename, " ]---------")
    with open(filename) as f:
        print(f.read())
    print("--------------------------")
