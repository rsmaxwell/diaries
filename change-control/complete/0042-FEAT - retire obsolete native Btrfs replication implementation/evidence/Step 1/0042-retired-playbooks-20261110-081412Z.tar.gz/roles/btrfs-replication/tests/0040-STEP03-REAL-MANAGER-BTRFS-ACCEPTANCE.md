# 0040 Step 3 — Real receiver-manager Btrfs acceptance

This fixture exercises the **installed, unmodified** `receiver_delete_one_locked()` and Btrfs kernel deletion on `backup` against **three genuinely received snapshots**, isolated under a fresh `/@data/.0040-manager-transaction-<uuid>` Btrfs subvolume. It builds test-only receipts, manager/writer locks, and a root-owned 0600 checkpoint-hold file. It uses the actual receiver inventory, retention, checkpoint-hold, candidate validation, durable journal and receipt-removal code.

## Gates

1. Apply this package through Beyond Compare to Playbooks, but do **not deploy** it.
2. Run the `--plan` action on `backup` from `mango`; inspect the output and source.
3. Only after explicit review, run `--execute --accept-disposable-delete DELETE-ONLY-ISOLATED-0040-MANAGER`. **This creates and destroys only newly created disposable Btrfs subvolumes.**
4. Verify the exact namespace is absent, the installed production receiver recovery plan is CLEAN, and production receipts/holds remain unchanged. Commit evidence only after review.

All unsuccessful runs preserve the entire fixture (including pending journal) for manual examination: **do not automatically rerun or clean up a failed fixture**. This is a real destructive rehearsal, not a simulation.

## Limitations

This test uses a *disposable local source pin under a held lock*, not the authenticated live `mars` source-held SSH transaction. It does **not** exercise root-owned one-time approval consumption or remote-process termination. It must **not** be represented as full Stage 2 acceptance or used to enable production sudoers/pruning. Those remain separate acceptance requirements. It does not replace or change the production receiver manager code.
