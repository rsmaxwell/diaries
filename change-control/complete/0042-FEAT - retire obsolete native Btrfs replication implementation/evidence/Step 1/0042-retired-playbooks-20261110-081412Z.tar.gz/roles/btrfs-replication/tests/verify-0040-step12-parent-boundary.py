#!/usr/bin/env python3
"""0040 Step 12.1: offline parent-aware receiver plan tests; no Btrfs or SSH."""
import importlib.util
from pathlib import Path

source = Path(__file__).resolve().parents[1] / 'files/btrfs-native-push-receiver.py'
spec = importlib.util.spec_from_file_location('step12_receiver_boundary', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def entries(*stamps):
    return [(stamp, None, None) for stamp in stamps]


def rejects(items, keep, parent):
    try:
        module.protected_retention_candidates(items, keep, parent)
    except RuntimeError:
        return
    raise AssertionError('Unsafe retention plan accepted')


newest = '20261026-100000Z'
intermediate = '20261026-090000Z'
parent = '20261026-080000Z'
older = '20261026-070000Z'
oldest = '20261026-060000Z'
items = entries(newest, intermediate, parent, older, oldest)

keep, candidates = module.protected_retention_candidates(items, {newest, older}, parent)
assert keep == {newest, intermediate, parent, older}, keep
assert candidates == [oldest], candidates
print('PASS: parent not newest; parent and all newer snapshots retained')

keep, candidates = module.protected_retention_candidates(items, set(), parent)
assert candidates == [older, oldest], candidates
print('PASS: unretained older snapshots remain eligible as advisory candidates')

keep, candidates = module.protected_retention_candidates(items, set(), oldest)
assert not candidates and len(keep) == len(items)
keep, candidates = module.protected_retention_candidates(items, set(), newest)
assert candidates == [intermediate, parent, older, oldest]
print('PASS: oldest and newest parent boundaries')

rejects(items, set(), '20261026-050000Z')
rejects(items, { '20261026-040000Z' }, parent)
rejects(entries(newest, parent, parent), set(), parent)
rejects(entries(oldest, parent), set(), parent)
rejects(entries(newest, 'NOT-A-STAMP', parent), set(), parent)
rejects(items, set(), 'NOT-A-PARENT')
print('PASS: missing parent, unknown keep, duplicate/unsorted/invalid identities fail closed')
print('LIMIT: pure selection tests; no live source pin, locks, receipt verification or deletion')
