#!/usr/bin/env python3
"""0040 disposable three-received-snapshot identity and receipt rehearsal.

Runs only on backup using sudo and a fresh namespace underneath /@data.
--plan is read-only; --execute modifies and deletes ONLY disposable subvolumes.
This is NOT the approved manager deletion transaction.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

PARENT = Path('/@data')
PREFIX = '.0040-three-received-'
ACK = 'CREATE-DELETE-ONLY-0040-THREE-RECEIVED'
STAMPS = ('20261024-000001Z', '20261024-000002Z', '20261024-000003Z')

def run(*argv):
    return subprocess.run(argv, check=True, text=True, capture_output=True).stdout

def get_uuid(path, field):
    value = run('btrfs', 'subvolume', 'show', str(path))
    match = re.search(r'^\s*' + re.escape(field) + r':\s*(\S+)', value, re.M)
    if match is None or match.group(1).lower() in ('-', 'none'):
        raise RuntimeError('Missing ' + field + ' on ' + str(path))
    return match.group(1)

def check():
    if not PARENT.is_dir() or PARENT.is_symlink():
        raise RuntimeError('Unsafe test parent')
    if run('findmnt', '-n', '-o', 'FSTYPE', '--target', str(PARENT)).strip() != 'btrfs':
        raise RuntimeError('Test parent must use Btrfs')
    if not Path('/usr/bin/btrfs').is_file():
        raise RuntimeError('btrfs binary missing')

def receive(snapshot, dst, base=None):
    args = ['btrfs', 'send']
    if base is not None:
        args += ['-p', str(base)]
    args.append(str(snapshot))
    sender = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        receiver = subprocess.run(['btrfs', 'receive', str(dst)], stdin=sender.stdout,
                                  capture_output=True)
    finally:
        sender.stdout.close()
    sender_error = sender.communicate()[1]
    if sender.returncode != 0 or receiver.returncode != 0:
        raise RuntimeError('Send/receive failed: send=%s receive=%s %s %s' %
                           (sender.returncode, receiver.returncode,
                            sender_error.decode(errors='replace')[-300:],
                            receiver.stderr.decode(errors='replace')[-300:]))

def execute():
    if os.geteuid() != 0:
        raise PermissionError('root required for disposable fixture')
    ns = PARENT / (PREFIX + uuid.uuid4().hex)
    if ns.exists() or ns.is_symlink():
        raise RuntimeError('Namespace collision')
    run('btrfs', 'subvolume', 'create', str(ns))
    print('FIXTURE: ' + str(ns), flush=True)
    source, origin, incoming, state = (ns / s for s in ('source','origin','received','state'))
    try:
        origin.mkdir(); incoming.mkdir(); state.mkdir(mode=0o700)
        run('btrfs', 'subvolume', 'create', str(source))
        parent = None
        for i, stamp in enumerate(STAMPS):
            (source / 'payload.txt').write_text('0040-disposable-%d\n' % i)
            snapshot = origin / stamp
            run('btrfs', 'subvolume', 'snapshot', '-r', str(source), str(snapshot))
            receive(snapshot, incoming, parent)
            original_uuid = get_uuid(snapshot, 'UUID')
            received_uuid = get_uuid(incoming / stamp, 'Received UUID')
            if original_uuid.lower() != received_uuid.lower():
                raise RuntimeError('Received UUID mismatch: ' + stamp)
            if (incoming / stamp / 'payload.txt').read_text() != '0040-disposable-%d\n' % i:
                raise RuntimeError('Payload mismatch: ' + stamp)
            # Test-only receipt material. Do not place into production receipt/state directories.
            receipt = {'schema': 1, 'snapshot': stamp, 'source_uuid': original_uuid,
                       'received_uuid': received_uuid, 'destination': str(incoming / stamp),
                       'read_only_verified': True, 'transport': 'btrfs-full' if i == 0 else 'btrfs-incremental'}
            file = state / (stamp + '.json')
            with file.open('x', encoding='utf-8') as f:
                json.dump(receipt, f, sort_keys=True); f.write('\n')
            file.chmod(0o600)
            parent = snapshot
        assert len(list(state.glob('*.json'))) == 3
        print('PASS: three real received UUIDs and isolated matching receipt identity files', flush=True)
        # No manager deletion is attempted: cleanup is an explicit exact-path fixture lifecycle.
        for stamp in reversed(STAMPS):
            target = incoming / stamp
            if not target.is_relative_to(ns) or target.is_symlink():
                raise RuntimeError('Unsafe deletion target')
            run('btrfs', 'subvolume', 'delete', str(target))
        for stamp in reversed(STAMPS):
            target = origin / stamp
            if not target.is_relative_to(ns) or target.is_symlink():
                raise RuntimeError('Unsafe origin deletion target')
            run('btrfs', 'subvolume', 'delete', str(target))
        run('btrfs', 'subvolume', 'delete', str(source))
        for stamp in STAMPS:
            (state / (stamp + '.json')).unlink()
        state.rmdir(); incoming.rmdir(); origin.rmdir()
        run('btrfs', 'subvolume', 'delete', str(ns))
        if ns.exists():
            raise RuntimeError('Fixture namespace still exists')
        print('PASS: exact disposable namespace absent', flush=True)
    except Exception:
        print('FAIL: preserve fixture for inspection: ' + str(ns), file=sys.stderr)
        raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--execute', action='store_true')
    parser.add_argument('--accept-disposable-delete', default='')
    args = parser.parse_args()
    check()
    if args.plan:
        if args.accept_disposable_delete:
            parser.error('No acknowledgement accepted in read-only mode')
        print('PASS: read-only Btrfs preflight')
        print('PLAN: fresh /@data/.0040-three-received-<uuid>; 3 Btrfs send/receives, UUID and receipt checks; exact isolated cleanup')
        print('LIMIT: no actual manager deletion, root approval, source-held lock, hold evaluation or journal')
        return
    if args.accept_disposable_delete != ACK:
        parser.error('Expected --accept-disposable-delete ' + ACK)
    execute()

if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, PermissionError, OSError, subprocess.CalledProcessError) as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
