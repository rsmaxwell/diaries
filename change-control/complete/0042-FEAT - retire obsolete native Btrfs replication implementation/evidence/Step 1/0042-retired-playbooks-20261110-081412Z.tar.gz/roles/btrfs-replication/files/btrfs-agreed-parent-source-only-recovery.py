#!/usr/bin/python3
"""0040 Step 12.3 Integration 03: explicit source-only prepared-state recovery.

Never invokes receiver prepare, snapshot send/receive, promotion, pruning or release.
The source push lock covers both review and the single source transition.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/usr/local/libexec')
PUSH = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
STATE = Path('/media/usb/@snapshots/.agreed-parent.json')
AUTH = ('authorizes_prepare', 'authorizes_promote', 'authorizes_transfer',
        'authorizes_prune', 'authorizes_release')


def load(name):
    path = ROOT / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('source_only_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def recover(timestamp, *, execute=False, deps=None):
    d = deps if deps is not None else {name: load(name) for name in (
        'locked-get-state', 'state', 'source-evidence', 'transfer-plan',
        'get-state-transport', 'source-transition', 'source-recovery-integration',
        'recovery-decision')}
    lock, state, evidence, transfer, get = (d[name] for name in (
        'locked-get-state', 'state', 'source-evidence', 'transfer-plan', 'get-state-transport'))
    with ExitStack() as push_stack:
        lock.acquire(push_stack, PUSH)
        with ExitStack() as manager_stack:
            lock.acquire(manager_stack, MANAGER)
            source = state.load(STATE, require_root=True)
            state.validate(source)
            if source['pending'] is not None or source['previous'] is not None:
                raise RuntimeError('source is already in transition; do not retry')
            candidate = transfer.target_identity(timestamp)
            parent = source['established']
            verified_parent = evidence.verify_source(parent)
            verified_candidate = evidence.verify_source(candidate)
            reply = get.get_state(timestamp, source_lock_held=True)
            decision = d['recovery-decision'].decide(
                source, reply, candidate, verified_candidate, verified_parent,
                validate=state.validate)
            if decision.get('status') != 'receiver-prepared-source-unprepared' or any(
                    decision.get(k) is not False for k in (
                        'authorizes_source_prepare', 'authorizes_receiver_prepare',
                        'authorizes_transfer', 'authorizes_promote',
                        'authorizes_prune', 'authorizes_release')):
                raise RuntimeError('unsafe or unexpected recovery decision')
            if not execute:
                return {'schema': 1, 'status': 'source-only-recovery-review',
                        'decision': decision, 'state_changed': False,
                        'transfer_executed': False, 'release_executed': False}
        # The manager lock must be released here: the source transition obtains
        # it again and makes its own fresh authenticated receiver observation.
        result = d['source-recovery-integration'].prepare_source(
            source_before=source, candidate=candidate, state_path=STATE,
            manager_lock=MANAGER, push_lock_held=True,
            acquire_manager=lock.acquire, verify_source=evidence.verify_source,
            read_receiver=lambda tid: get.get_state(tid, source_lock_held=True),
            transition=d['source-transition'], recovery=d['recovery-decision'])
        if result.get('status') != 'source-prepared-verified' or result.get('source') != state.prepare(source, candidate):
            raise RuntimeError('source preparation not confirmed: inspect both states, do not retry')
        return {'schema': 1, 'status': 'source-only-recovery-prepared',
                'source': result['source'], 'receiver': decision['receiver'],
                'transfer_executed': False, 'release_executed': False,
                'authorizes_transfer': False, 'authorizes_promote': False,
                'authorizes_prune': False, 'authorizes_release': False}


def main():
    parser = argparse.ArgumentParser(description='Source-only agreed-parent recovery; no receiver prepare or transfer')
    parser.add_argument('--target', required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--review-only', action='store_true')
    mode.add_argument('--execute-source-recovery', action='store_true')
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(recover(args.target, execute=args.execute_source_recovery), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        print('source-only recovery refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
