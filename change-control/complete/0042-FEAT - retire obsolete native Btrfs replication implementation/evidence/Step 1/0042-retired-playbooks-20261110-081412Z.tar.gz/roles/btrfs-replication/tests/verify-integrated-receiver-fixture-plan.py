#!/usr/bin/env python3
"""0040 Step 3: read-only, fail-closed plan for isolated integrated receiver acceptance.

No execute mode by design. This does not grant deletion authority.
Run on backup as root through stdin, after source review on mango.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys

PARENT = Path('/@data')
PRODUCTION = Path('/@data/mars-received')
PREFIX = '.0040-integrated-acceptance-'
MANAGER = Path('/usr/local/sbin/btrfs-snapshot-manager')
CONFIG = Path('/etc/btrfs-snapshot-manager.json')


def checked(command):
    result = subprocess.run(command, text=True, capture_output=True, check=True, timeout=20)
    return result.stdout.strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true', required=True)
    args = parser.parse_args()
    assert args.plan
    if os.geteuid() != 0:
        raise RuntimeError('root privileges required to read receiver configuration')
    if not PARENT.is_dir() or PARENT.is_symlink():
        raise RuntimeError('unsafe disposable parent')
    if not MANAGER.is_file() or MANAGER.is_symlink():
        raise RuntimeError('installed manager missing/unsafe')
    if not CONFIG.is_file() or CONFIG.is_symlink():
        raise RuntimeError('installed receiver config missing/unsafe')
    raw = json.loads(CONFIG.read_text())
    if raw.get('mode') != 'receiver' or raw.get('receiver_prune_enabled') is not False:
        raise RuntimeError('production receiver config not fail-closed')
    snapshot_root = Path(raw['snapshot_root'])
    state_root = Path(raw['receiver_state_dir'])
    if snapshot_root != PRODUCTION or state_root != PRODUCTION / '.replication-state':
        raise RuntimeError('unexpected production receiver path: review before fixture')
    fs = checked(['findmnt', '-n', '-o', 'FSTYPE', '-T', str(PARENT)])
    if fs != 'btrfs':
        raise RuntimeError('disposable parent must be Btrfs')
    # The fixture names are illustrative until a future *separate* execution package.
    proposed = PARENT / (PREFIX + '<fresh-random-uuid>')
    roots = ['source', 'origin', 'received', 'state', 'approval', 'consumed', 'holds']
    if any(PARENT / name == PRODUCTION for name in roots):
        raise RuntimeError('path overlap')
    # Read-only production journal check; do not invoke a repair command.
    recovery = checked([str(MANAGER), '--config', str(CONFIG), 'receiver-recovery-plan'])
    if not re.search(r'"state"\s*:\s*"CLEAN"', recovery) or not re.search(r'"authorizes_repair"\s*:\s*false', recovery):
        raise RuntimeError('production receiver recovery not clean')
    print('PASS: read-only integrated-acceptance baseline; Btrfs and receiver recovery CLEAN')
    print('PLAN: namespace=' + str(proposed))
    print('PLAN: isolated child directories=' + ', '.join(roots))
    print('PLAN: source snapshot sequence: candidate (oldest), protected parent, newest; real Btrfs received UUIDs and matching receipts')
    print('PLAN: isolated receiver mode, root-owned 0600 holds + approvals, manager-before-writer locks, distinct state and receipts')
    print('PLAN: candidate must be retention eligible; protected parent must be explicitly held; newest must be retained')
    print('PLAN: after successful journal-backed deletion: candidate subvolume and receipt absent, journal resolved, parent + newest present')
    print('PLAN: separate failure rehearsal: interrupt after journal creation; preserve journal, approval reservation and protected source pin')
    print('LIMIT: no test namespace created; no receipt, approval or journal written; no transaction or deletion attempted')
    print('BLOCKED: full cross-host source-held execution and restricted privileged process channel still need implementation and safety review')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
