#!/usr/bin/env python3
"""Source-only regression: no network, sudo or Btrfs modification."""
import importlib.util
from pathlib import Path
from unittest import mock
import fcntl, json, tempfile

source = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-native-push.py'
spec = importlib.util.spec_from_file_location('sender_unattended_test', source)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
parent = '20261028-030000Z'
candidate = '20261020-030000Z'
uuid = '11111111-1111-1111-1111-111111111111'
plan = {'snapshot': parent, 'source_uuid': uuid, 'receiver_verified_under_lock': True,
        'authorizes_prune': False, 'deletion_executed': False, 'candidates': [candidate],
        'total': 2, 'retained': 1}

with tempfile.TemporaryDirectory() as temp:
    lock = Path(temp) / 'push.lock'
    lock.touch()
    called = []
    def mocked_runner(command, stamp, source_uuid, name, *, prepare_transaction, **kw):
        with lock.open('r+') as fd:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            resolved = prepare_transaction()
            assert resolved == (['ssh', 'receiver', '--transaction', parent, uuid, candidate], parent, uuid, candidate)
            called.append(resolved)
        return {'kind': 'transaction-completed', 'snapshot': candidate}
    with mock.patch.object(m, 'prepare_prune_parent', return_value={'snapshot':parent, 'source_uuid':uuid}), \
         mock.patch.object(m, 'remote', return_value=json.dumps(plan)):
        response = m.run_unattended_prune_one(candidate, run_transaction=mocked_runner,
            build_command=lambda *args: ['ssh','receiver','--transaction',*args])
        assert response['snapshot'] == candidate and len(called) == 1
        bad_plan = {**plan, 'candidates':[], 'retained':2}
        with mock.patch.object(m, 'remote', return_value=json.dumps(bad_plan)):
            try:
                m.run_unattended_prune_one(candidate, run_transaction=mocked_runner,
                    build_command=lambda *args: ['ssh','receiver','--transaction',*args])
            except RuntimeError as exc:
                assert 'Candidate not retained' in str(exc)
            else:
                raise AssertionError('Rejected candidate was accepted')
    assert len(called) == 1
print('PASS: single-lock source preparation, validated plan and rejected candidate')
