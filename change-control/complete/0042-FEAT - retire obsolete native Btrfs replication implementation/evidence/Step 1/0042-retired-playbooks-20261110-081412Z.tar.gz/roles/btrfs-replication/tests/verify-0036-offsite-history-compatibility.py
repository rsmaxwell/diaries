#!/usr/bin/env python3
"""0036 Step 6: disposable, offline compatibility of fixed-source snapshots with 0034/0035.
No Btrfs send, SSH, production files, or scheduler operations are performed.
"""
import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROLES = Path(__file__).resolve().parents[2]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

push = load('step6push', ROLES/'btrfs-replication/files/btrfs-native-push.py')
receiver = load('step6receiver', ROLES/'btrfs-replication/files/btrfs-native-push-receiver.py')
history = load('step6history', ROLES/'snapshots/files/diaries-backup-history.py')
old_stamp, new_stamp = '20261015-090000Z', '20261016-090000Z'
old_id, new_id = '20261015-084500Z', '20261016-084500Z'
old_uuid, new_uuid = '7ad1f171-d1c7-0545-82a1-52e84adac979', '98765000-d1c7-0545-82a1-52e84adac979'

with tempfile.TemporaryDirectory(prefix='0036-step6-') as tmp:
    base = Path(tmp)
    root = base/'@snapshots'/'@data'
    # Historical generation-backed snapshot, as published by 0034.
    historic = root/old_stamp
    old_dataset = historic/'backup/pluto/.diaries-backup-generations'/old_id
    old_dataset.mkdir(parents=True)
    (historic/'backup/pluto/diaries-backup').symlink_to(Path('.diaries-backup-generations')/old_id)
    # New snapshot of 0036 fixed working directory: NOT a symlink.
    modern = root/new_stamp
    new_dataset = modern/'backup/pluto/diaries-backup'
    new_dataset.mkdir(parents=True)
    for stamp, dataset, backup_id in [(old_stamp,old_dataset,old_id),(new_stamp,new_dataset,new_id)]:
        content = {'schemaVersion':2,'backupId':backup_id,'logicalDataset':'production'}
        manifest = dataset/'dataset-manifest.json'
        manifest.write_text(json.dumps(content, sort_keys=True))
        digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
        marker = {'state':'verified-published','snapshotEligible':True,
                  'backupId':backup_id,'logicalDataset':'production',
                  'datasetRelativePath':'backup/pluto/diaries-backup','manifestSha256':digest}
        (root/stamp/'backup/.diaries-snapshot-verified.json').write_text(json.dumps(marker))
    cfg = history.HistoryConfig(base/'@snapshots','@data','backup/pluto/diaries-backup',
              'backup/.diaries-snapshot-verified.json', Path('/fake/schema2-verifier'))
    occurrences, warnings = history.enumerate_occurrences(cfg)
    assert not warnings, warnings
    assert {(o.snapshot,o.backup_id) for o in occurrences} == {(old_stamp,old_id),(new_stamp,new_id)}
    assert not history.conflicted_groups(history.group_occurrences(occurrences))
    print('PASS: historical symlink generation and new fixed-directory snapshots coexist in read-only history')
    assert not (modern/'backup/pluto/diaries-backup').is_symlink()
    assert (historic/'backup/pluto/diaries-backup').is_symlink()
    print('PASS: historical schema-2 restore references remain discoverable without rewriting old snapshots')
    # Push selects snapshots by immutable timestamp/UUID, independent of internal dataset storage layout.
    local_state = {old_stamp: old_uuid, new_stamp: new_uuid}
    def inspect(role, stamp, expected=None):
        return {'flags':'readonly','parent_uuid':push.SOURCE_PARENT,
                'received_uuid':'-','uuid':local_state[stamp]}
    with patch.object(push,'local',side_effect=inspect):
        assert push.choose_parent(new_stamp,[{'snapshot':old_stamp,'source_uuid':old_uuid}]) == (old_stamp,old_uuid)
        assert push.choose_parent(new_stamp,[{'snapshot':old_stamp,'source_uuid':'incorrect'}]) == (None,None)
    print('PASS: off-site incremental parent selection uses verified source UUID, not dataset directory layout')
    state = base/'receipts'; state.mkdir()
    received = base/'received'; received.mkdir()
    receipt = {'schema':1,'snapshot':old_stamp,'source_uuid':old_uuid,'received_uuid':old_uuid,
       'transport':'btrfs-full','source_filesystem_uuid':receiver.SOURCE_FS,
       'receiver_filesystem_uuid':receiver.RECEIVER_FS,
       'destination':str(received/old_stamp),'read_only_verified':True,
       'source_send_exit':0,'receiver_receive_exit':0}
    (state/(old_stamp+'.json')).write_text(json.dumps(receipt))
    with patch.object(receiver,'ROOT',received),patch.object(receiver,'STATE',state),\
         patch.object(receiver,'inspect',return_value={'flags':'readonly','received_uuid':old_uuid}):
        assert receiver.receipt(old_stamp)['source_uuid'] == old_uuid
        assert receiver.validate(new_stamp,new_uuid,old_stamp,old_uuid,False,False)['action']=='incremental'
        for invalid in ('wrong', None):
            try: receiver.validate(new_stamp,new_uuid,old_stamp,invalid,False,False)
            except RuntimeError: pass
            else: raise AssertionError('invalid incremental ancestry was accepted')
    print('PASS: receiver receipt validates incremental ancestry and rejects incorrect parent UUID')
print('PASS: 0036 Step 6 off-site and historical compatibility (offline)')
