#!/usr/bin/env python3
"""Offline static source-initiated Btrfs replication invariants."""
import ast
from pathlib import Path
root = Path(__file__).resolve().parents[1]
endpoint = (root / 'files/btrfs-native-endpoint.py').read_text()
push = (root / 'files/btrfs-native-push.py').read_text()
receiver = (root / 'files/btrfs-native-push-receiver.py').read_text()
for source in (endpoint, push, receiver): ast.parse(source)
assert "'btrfs', 'send'" in endpoint and "'btrfs', 'receive'" in endpoint
assert 'STAMP.fullmatch' in endpoint
assert 'list-source' in endpoint and 'def list_source' in endpoint
assert 'SOURCE_FS' in endpoint and 'RECEIVE_FS' in endpoint
assert 'Received UUID' in endpoint
assert 'fcntl.flock' in push
assert 'subprocess.Popen' in push
assert 'send_rc == 0 and receiver_rc == 0' in push
assert "local('protect-source', snapshot)" in push
assert "local('protect-source', parent)" in push
assert "local('release-source', parent, parent_uuid)" in push
assert "remote('--list')" in push
assert "selection.add_argument('--latest'" in push
assert 'already-accepted' in push and 'accepted common parent' in push
assert 'os.replace' in receiver or 'os.link' in receiver or 'O_EXCL' in receiver
assert 'rsync' not in push
assert 'btrfs_native_endpoint_role' in (root / 'tasks/native.yaml').read_text()
tasks = (root / 'tasks/native.yaml').read_text()
assert 'src: btrfs-native-pull.py' not in tasks
assert 'btrfs-native-push.timer' in tasks and 'Refuse dual off-site transports' in tasks
assert 'btrfs_native_push_schedule_enabled: false' in (root / 'defaults/main.yaml').read_text()
print('PASS: static source-initiated native Btrfs safety contract')
