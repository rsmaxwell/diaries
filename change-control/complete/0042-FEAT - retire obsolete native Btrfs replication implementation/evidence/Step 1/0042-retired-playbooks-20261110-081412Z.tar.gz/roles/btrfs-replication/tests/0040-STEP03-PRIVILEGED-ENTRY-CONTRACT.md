# 0040 Step 3 — privileged entry contract (not deletion authority)

This increment is a **non-destructive** executable contract gate, not the final
production transaction. It fixes the planned command boundary to a root-only,
fixed-configuration endpoint that cannot accept user-selected repository paths
and rejects production pruning enabled. The entrypoint accepts only
`--verify-boundary` and does not load a deletion callback, consume approvals,
acquire transaction locks, or mutate snapshots.

Never deploy or sudoers-allowlist this script before a separate acceptance
review. Its purpose is to establish command-line privilege separation without
changing the unprivileged SSH receiver or its existing writer lock.

Still required: a reliable source-held stream/IPC into the privileged process,
manager-before-writer lock-held transaction and narrowly constrained deletion
callback, journal+reservation recovery through real interruption, and disposable
Btrfs end-to-end acceptance. Existing snapshots and checkpoint holds are out
of scope; pruning stays disabled. Step 3 remains OPEN.
