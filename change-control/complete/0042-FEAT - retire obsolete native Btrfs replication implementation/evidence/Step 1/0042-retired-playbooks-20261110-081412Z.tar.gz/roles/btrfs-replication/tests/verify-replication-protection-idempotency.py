#!/usr/bin/env python3
"""Regression for semantic replication-protection enforcement."""

import json
from pathlib import Path

TASKS = Path(__file__).resolve().parents[1] / "tasks/native.yaml"

text = TASKS.read_text(encoding="utf-8")
task = text.split(
    "- name: Native Btrfs | Activate fail-closed protection in existing 0035 config",
    1,
)[1].split(
    "- name: Native Btrfs | Install fixed-path privileged endpoint",
    1,
)[0]

assert "from_json" in task
assert "combine(" in task
assert "recursive=true" in task
assert "!=" in task
assert "btrfs_native_endpoint_role == 'source'" in task

expected = {
    "required": True,
    "path": "/media/usb/@snapshots/.replication-protection.json",
}


def needs_change(config):
    updated = dict(config)
    protection = dict(updated.get("replication_protection") or {})
    protection.update(expected)
    updated["replication_protection"] = protection
    return updated != config


base = {
    "snapshot_root": "/media/usb/@snapshots",
    "retention": {"daily": 14, "hourly": 48},
    "replication_protection": dict(expected),
}

assert not needs_change(base)
assert not needs_change(json.loads(json.dumps(base, indent=4, sort_keys=True)))
print("PASS: equivalent JSON formatting requires no change")

missing = dict(base)
missing.pop("replication_protection")
assert needs_change(missing)
print("PASS: missing protection requires correction")

disabled = dict(base)
disabled["replication_protection"] = {**expected, "required": False}
assert needs_change(disabled)
print("PASS: disabled protection requires correction")

wrong_path = dict(base)
wrong_path["replication_protection"] = {**expected, "path": "/incorrect/path"}
assert needs_change(wrong_path)
print("PASS: incorrect protection path requires correction")

print("PASS: replication-protection source contract")
