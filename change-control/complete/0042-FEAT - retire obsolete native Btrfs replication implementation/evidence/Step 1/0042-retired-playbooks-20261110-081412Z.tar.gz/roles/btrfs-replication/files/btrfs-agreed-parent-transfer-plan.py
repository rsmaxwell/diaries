#!/usr/bin/python3
"""0040 3H.5b: read-only locked agreed-parent transfer planning.

Not installed; never authorises or performs a transfer. No fallback parent.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/usr/local/libexec')
SOURCE_LOCK = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
STATE_PATH = Path('/media/usb/@snapshots/.agreed-parent.json')
SOURCE_SNAPSHOTS = Path('/media/usb/@snapshots/@data')
SSH = ('/usr/sbin/runuser', '-u', 'richard', '--', 'ssh', '-o', 'BatchMode=yes',
       '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1',
       'sudo', '-n', '/usr/local/libexec/btrfs-agreed-parent-endpoint.py', '--observe-receiver')
STAMP = re.compile(r'^\d{8}-\d{6}Z$')
UUID = re.compile(r'^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$')


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def modules():
    return (load_module(ROOT / 'btrfs-agreed-parent-source-observer.py', 'locked_observer'),
            load_module(ROOT / 'btrfs-agreed-parent-state.py', 'locked_state'),
            load_module(ROOT / 'btrfs-agreed-parent-source-evidence.py', 'locked_evidence'),
            load_module(ROOT / 'btrfs-agreed-parent-observation-bridge.py', 'locked_bridge'),
            load_module(ROOT / 'btrfs-agreed-parent-selection.py', 'locked_selection'))


def target_identity(timestamp, *, runner=subprocess.run, snapshot_dir=SOURCE_SNAPSHOTS):
    if type(timestamp) is not str or STAMP.fullmatch(timestamp) is None:
        raise RuntimeError('invalid target timestamp')
    if snapshot_dir.is_symlink() or not snapshot_dir.is_dir():
        raise RuntimeError('unsafe snapshot directory')
    path = snapshot_dir / timestamp
    if path.is_symlink() or not path.is_dir():
        raise RuntimeError('missing or unsafe target snapshot')
    result = runner(['btrfs', 'subvolume', 'show', str(path)], capture_output=True, text=True,
                    timeout=20, check=False)
    if type(result.returncode) is not int or result.returncode != 0 or type(result.stdout) is not str or len(result.stdout) > 65536:
        raise RuntimeError('target Btrfs inspection failed')
    fields = {}
    for line in result.stdout.splitlines():
        if ':' in line:
            key, val = line.strip().split(':', 1)
            fields[key.strip()] = val.strip()
    uuid = fields.get('UUID')
    if type(uuid) is not str or UUID.fullmatch(uuid) is None or fields.get('Flags') != 'readonly' or fields.get('Received UUID') not in ('-', 'none'):
        raise RuntimeError('target Btrfs identity/readonly mismatch')
    return {'timestamp': timestamp, 'uuid': uuid}


def plan(timestamp, *, dependencies=None):
    """Injected dependency object is offline-test-only; production loads fixed modules."""
    observer, state, evidence, bridge, selection = dependencies or modules()
    with ExitStack() as stack:
        observer.lock(stack, SOURCE_LOCK)
        observer.lock(stack, MANAGER_LOCK)
        local = state.load(STATE_PATH, require_root=True)
        state.validate(local)
        if local['pending'] is not None or local['previous'] is not None:
            raise RuntimeError('unfinished transition requires recovery')
        parent = dict(local['established'])
        verified_parent = evidence.verify_source(parent)
        if verified_parent != dict(parent, verified=True):
            raise RuntimeError('source parent verification mismatch')
        target = target_identity(timestamp)
        verified_target = evidence.verify_source(target)
        if verified_target != dict(target, verified=True):
            raise RuntimeError('source target verification mismatch')
        response = subprocess.run(list(SSH), capture_output=True, text=True, timeout=60, check=False)
        if type(response.returncode) is not int or response.returncode != 0:
            raise RuntimeError('receiver observation SSH failed')
        comparison = bridge.inspect(local, response.stdout, ssh_exit=response.returncode)
        if comparison['comparison'] != 'matched' or comparison['authorizes_transition'] is not False or comparison['authorizes_prune'] is not False:
            raise RuntimeError('receiver state disagreement or authority claim')
        # The bridge validated the receiver's protected snapshot receipts under
        # the receiver endpoint's lock, including the established parent.
        receipts = [{'snapshot': parent['timestamp'], 'source_uuid': parent['uuid']}]
        result = selection.select(source_state=local, receiver_state=comparison['receiver'],
                                  target=target, source_parent=parent, receiver_receipts=receipts)
        if result['authorizes_transfer'] is not False or result['authorizes_release'] is not False:
            raise RuntimeError('selection unexpectedly authorised mutation')
        return {'schema': 1, 'target': target, 'parent': result['parent'],
                'parent_uuid': result['parent_uuid'], 'mode': 'incremental',
                'comparison': 'matched', 'authorizes_transfer': False,
                'authorizes_transition': False, 'authorizes_prune': False,
                'authorizes_release': False}


def main():
    parser = argparse.ArgumentParser(description='Read-only agreed-parent transfer plan; no send')
    parser.add_argument('--target', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(plan(args.target), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
        print(f'agreed-parent plan refused: {exc}', file=sys.stderr)
        raise SystemExit(1)
