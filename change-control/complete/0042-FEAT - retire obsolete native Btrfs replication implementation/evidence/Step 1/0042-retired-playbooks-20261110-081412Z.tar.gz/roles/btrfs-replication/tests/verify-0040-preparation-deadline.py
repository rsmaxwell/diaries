#!/usr/bin/env python3
"""Disposable regression: preparation subprocess times out before SSH deletion starts."""
import importlib.util
import fcntl
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from unittest import mock

source = Path(__file__).resolve().parents[1] / 'files/btrfs-native-push.py'
spec = importlib.util.spec_from_file_location('sender_deadline_test', source)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
with tempfile.TemporaryDirectory(prefix='0040-deadline-') as temp:
    root = Path(temp)
    lock = root / 'push.lock'
    lock.touch(mode=0o600)
    pin = root / 'pin.json'
    pin.write_text(json.dumps({'snapshot':'20261028-030000Z'}))
    started = time.monotonic()
    observed = []
    def preparation():
        timeout = m.preparation_subprocess_timeout()
        observed.append(timeout)
        subprocess.run([sys.executable, '-c', 'import time;time.sleep(5)'],
                       check=True, timeout=timeout)
        raise AssertionError('Unreachable after timed-out subprocess')
    with mock.patch.object(m, 'answer_transaction_challenges', side_effect=AssertionError('must not start')):
        try:
            m.run_private_transaction_process(None, None, None, None,
                source_lock=lock, transaction_timeout=.20,
                prepare_transaction=preparation)
        except subprocess.TimeoutExpired:
            pass
        else:
            raise AssertionError('Preparation did not time out')
    assert time.monotonic()-started < 2, 'Preparation exceeded deadline'
    assert observed and 0 < observed[0] <= .20, observed
    assert json.loads(pin.read_text()) == {'snapshot':'20261028-030000Z'}
    with lock.open('r+') as fd:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert m._PREPARE_DEADLINE.get() is None, 'Deadline context leaked'
    print('PASS: preparation subprocess bounded; no transaction spawned; lock released, pin retained')
