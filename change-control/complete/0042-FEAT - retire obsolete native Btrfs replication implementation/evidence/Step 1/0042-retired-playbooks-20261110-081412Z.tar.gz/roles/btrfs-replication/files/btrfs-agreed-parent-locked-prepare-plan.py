#!/usr/bin/python3
"""0040 3H.5m: read-only, locked receiver-prepare request review.

Delegates all live observation to the 3H.5j preflight (which owns both
source locks for the complete source/receiver verification). Independently
validates the proposed prepare request against the 3H.5k contract.
This command NEVER invokes prepare, writes state or grants authority.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent


def load(name):
    path = BASE / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('locked_plan_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build(timestamp, *, inspect=None, contract=None):
    """Obtain independently verified preflight and check exact contract.

    Injectable functions are reserved for offline tests. The production CLI
    always loads fixed installed modules with fixed paths and SSH identity.
    """
    result = (inspect or load('prepare-preflight').inspect)(timestamp)
    c = contract or load('prepare-transport-contract')
    if type(result) is not dict or set(result) != {
        'schema', 'status', 'request', 'authorizes_prepare',
        'authorizes_source_prepare', 'authorizes_transfer',
        'authorizes_promote', 'authorizes_prune', 'authorizes_release'
    } or type(result['schema']) is not int or result['schema'] != 1 or result['status'] != 'ready-for-independent-review':
        raise RuntimeError('unverified preflight result')
    if any(result[key] is not False for key in result if key.startswith('authorizes_')):
        raise RuntimeError('preflight claimed mutation authority')
    request = result['request']
    if type(request) is not dict or set(request) != {
        'schema', 'operation', 'transaction_id', 'expected_before', 'candidate'
    }:
        raise RuntimeError('malformed proposed request')
    expected = c.prepare_request(request['expected_before'], request['expected_before'], request['candidate'])
    if request != expected:
        raise RuntimeError('prepare request differs from validated contract')
    post = c.expected_after(request)
    if post['established'] != request['expected_before']['established'] or post['previous'] is not None:
        raise RuntimeError('prepare would alter established/previous parent')
    return {'schema': 1, 'status': 'read-only-prepare-plan',
            'request': request, 'expected_receiver_after': post,
            'authorizes_prepare': False, 'authorizes_source_prepare': False,
            'authorizes_transfer': False, 'authorizes_promote': False,
            'authorizes_prune': False, 'authorizes_release': False}


def main():
    parser = argparse.ArgumentParser(description='Read-only locked prepare plan; no mutation')
    parser.add_argument('--target', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(build(args.target), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        print('locked prepare plan refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
