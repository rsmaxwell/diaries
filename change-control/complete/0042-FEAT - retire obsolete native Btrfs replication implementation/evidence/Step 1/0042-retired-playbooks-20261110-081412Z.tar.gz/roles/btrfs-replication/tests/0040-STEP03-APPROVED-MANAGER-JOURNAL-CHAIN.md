# 0040-FEAT Step 3 — Approved manager journal chain

## Baseline and scope

Built against exported source at `4fa578f`, with no edits to operational sources. Later accepted regression and owned-SSH changes remain authoritative on mango. This source-only acceptance joins the real two-challenge sender/receiver protocol, root-owned single-use approval reservation, manager-before-writer lock ordering, and the **real** snapshot-manager journal/receipt transaction in one test.

Run from `/home/richard/playbooks` on mango:

```sh
python3 -m py_compile roles/btrfs-replication/tests/verify-approved-manager-journal-chain.py
sudo python3 roles/btrfs-replication/tests/verify-approved-manager-journal-chain.py
python3 roles/btrfs-replication/tests/verify-step03-production-boundary.py
git diff --check
```

## Accepted only when

- Root-only 0600 approval is reserved exactly once, with two fresh source protection checks.
- Successful transaction writes then resolves the authentic manager journal and removes candidate receipt.
- Interruption after journal creation retains candidate, receipt, approval reservation and journal; recovery reports BEFORE_DELETE.
- Parent and newest snapshots/receipts remain unchanged; production CLI remains deletion-disabled.

## Explicit limits and next gate

This fixture uses temporary directories and socketpair streams. **Btrfs kernel inventory/deletion functions and retention/holds evaluation are substituted.** This is not proof of authenticated mars→backup live coordination, actual Btrfs deletion, or a production-authorised gateway. Do not add `delete-receiver` to sudoers or enable receiver pruning based on this test. A separate, reviewed disposable end-to-end transaction and interruption acceptance is mandatory. Preserve all production checkpoints, receipts, schedules and rollback options.
