#!/usr/bin/env python3
"""Non-destructive regression: root-only internal approved receiver adapter.

This does not create an entry point or authorize receiver deletion.
"""
import importlib.util
import os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

receiver_file = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-native-push-receiver.py'
spec = importlib.util.spec_from_file_location('receiver_under_test', receiver_file)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

config = SimpleNamespace(mode='receiver', receiver_prune_enabled=False,
                         receiver_state_dir=Path('/not-a-real-receiver-state'),
                         writer_lock_path=Path('/not-a-real-receiver-state/writer.lock'),
                         lock_path=Path('/not-a-real-manager-lock'))
args = dict(manager=None, config=config, incoming=None, outgoing=None,
            planner=None, delete_subvolume=None, approval_path=Path('/not-real-approval'),
            consumed_dir=Path('/not-real-consumed'))
with patch.object(module.os, 'geteuid', return_value=1000):
    try:
        module.run_approved_manager_bound_transaction('20261024-030000Z',
            '11111111-1111-1111-1111-111111111111', '20261023-030000Z', **args)
    except RuntimeError as exc:
        assert 'separate privileged entry point' in str(exc), str(exc)
    else:
        raise AssertionError('Unprivileged approved transaction was accepted')
print('PASS: unprivileged approved adapter rejected before lock, approval or deletion')

# Root does not itself grant deletion: the root call must still satisfy manager
# configuration and all later locks, journal, approval and source-pin checks.
with patch.object(module.os, 'geteuid', return_value=0):
    try:
        module.run_approved_manager_bound_transaction('20261024-030000Z',
            '11111111-1111-1111-1111-111111111111', '20261023-030000Z', **args)
    except (RuntimeError, AttributeError) as exc:
        assert 'separate privileged entry point' not in str(exc)
    else:
        raise AssertionError('Invalid root transaction unexpectedly succeeded')
print('PASS: root identity alone does not authorize receiver transaction')
