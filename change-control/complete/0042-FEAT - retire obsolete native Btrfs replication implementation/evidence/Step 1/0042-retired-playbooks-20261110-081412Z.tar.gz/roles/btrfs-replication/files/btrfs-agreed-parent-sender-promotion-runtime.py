#!/usr/bin/env python3
"""0040 Step 12.3: trusted sender-side receiver-first promotion adapters.

Caller owns both canonical source locks for the entire transaction. No CLI,
no automatic recovery, pruning, old-parent release, or scheduler cutover.
"""
import json
import subprocess

class PromotionRuntimeRefused(RuntimeError):
    pass


def _query(command, *, run=subprocess.run):
    """Execute one exact argv over the fixed authenticated SSH identity."""
    try:
        result = run(command, input=b'', stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise PromotionRuntimeRefused('receiver promotion SSH outcome uncertain') from exc
    if type(result.returncode) is not int or result.returncode != 0:
        raise PromotionRuntimeRefused('receiver promotion SSH refused')
    if type(result.stdout) is not bytes or len(result.stdout) > 16384:
        raise PromotionRuntimeRefused('unsafe receiver promotion response')
    try:
        response = json.loads(result.stdout)
    except (ValueError, UnicodeError) as exc:
        raise PromotionRuntimeRefused('malformed receiver promotion response') from exc
    if type(response) is not dict:
        raise PromotionRuntimeRefused('invalid receiver response shape')
    return response


def _state(obj, parent, candidate):
    return (type(obj) is dict and set(obj) ==
            {'schema', 'established', 'pending', 'previous'} and
            type(obj['schema']) is int and obj['schema'] == 1 and
            obj['established'] == candidate and obj['pending'] is None and
            obj['previous'] == parent)


def receiver_promote(parent, candidate, *, commands, run=subprocess.run):
    response = _query(commands.promote_command(parent, candidate), run=run)
    # The receiver promotion binding performs the receipt-gated promotion and
    # an independent locked readback; its wire result is the promoted state,
    # not the internal promote_fixed acknowledgement envelope. The sender
    # validates the complete state shape and still does its OWN subsequent
    # promoted-readback before allowing source state to advance.
    if not _state(response, parent, candidate):
        raise PromotionRuntimeRefused('receiver promotion acknowledgement refused')
    return response


def receiver_readback(parent, candidate, *, commands, run=subprocess.run):
    observed = _query(commands.promoted_readback_command(parent, candidate), run=run)
    if not _state(observed, parent, candidate):
        raise PromotionRuntimeRefused('receiver independent promoted-state readback refused')
    return observed


def promote_source_locked(parent, candidate, *, state_module, state_path,
                          verify_source, receiver_readback_verified):
    """Durable source B promotion; caller holds push and manager locks.

    The receiver readback is invoked here, immediately before source mutation,
    not inferred from an acknowledgement returned earlier.
    """
    if not callable(verify_source) or not callable(receiver_readback_verified):
        raise PromotionRuntimeRefused('missing source or peer verifier')
    old = state_module.load(state_path, require_root=True)
    if (type(old) is not dict or set(old) !=
            {'schema', 'established', 'pending', 'previous'} or
            old.get('established') != parent or old.get('pending') != candidate or
            old.get('previous') is not None):
        raise PromotionRuntimeRefused('source no longer prepared for A/B')
    for identity in (parent, candidate):
        result = verify_source(identity)
        if result != dict(identity, verified=True):
            raise PromotionRuntimeRefused('source snapshot identity refused')
    peer = receiver_readback_verified(parent, candidate)
    if not _state(peer, parent, candidate):
        raise PromotionRuntimeRefused('receiver B not independently read back')
    after = state_module.promote(old)
    if not _state(after, parent, candidate):
        raise PromotionRuntimeRefused('unsafe source promotion postcondition')
    state_module.save(state_path, after, require_root=True)
    persisted = state_module.load(state_path, require_root=True)
    if persisted != after:
        raise PromotionRuntimeRefused('source promotion durable readback failed')
    return persisted
