# 0040 Step 3 — disposable Btrfs acceptance preflight

This is a **read-only preparation gate**, not the acceptance test itself.

Run from mango, streaming the script to backup without copying it to /tmp:

```bash
cd /home/richard/playbooks || exit 1
ssh backup 'python3 -' < roles/btrfs-replication/tests/verify-disposable-receiver-preflight.py
```

The target must have passwordless `sudo -n` access to the read-only
`receiver-recovery-plan` operation. If it does not, report the error; do not
change sudoers just for this script.

The preflight reads installed configs, required hold-file presence, mount,
capacity and recovery state. It does not enumerate or alter held snapshots.
It does not establish an isolated disposable filesystem, prove SSH process
reaping, test source-pin continuity or delete Btrfs subvolumes. The remaining
controlled acceptance requires a separate scratch Btrfs filesystem and a
reviewed executable callback, still unavailable through production sudoers.
