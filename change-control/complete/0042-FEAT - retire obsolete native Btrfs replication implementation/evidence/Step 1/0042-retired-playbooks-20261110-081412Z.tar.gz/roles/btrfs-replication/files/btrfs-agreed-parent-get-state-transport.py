#!/usr/bin/python3
"""0040 3H.5e dormant, get-state ONLY receiver transport.

Caller must own the source push/manager locks and independently validate the
source state. The dedicated receiver get-state endpoint is installed and this
module is not wired into any scheduled or live sender process.
"""
import json
import re
import subprocess

STAMP = re.compile(r'^\d{8}-\d{6}Z$')
SSH = ('/usr/sbin/runuser', '-u', 'richard', '--', 'ssh',
       '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1',
       'sudo', '-n', '/usr/local/libexec/btrfs-agreed-parent-get-state-endpoint.py', '--request')

class ObservationFailure(RuntimeError):
    pass


def validate_state(value):
    if type(value) is not dict or set(value) != {'schema', 'established', 'pending', 'previous'} or type(value['schema']) is not int or value['schema'] != 1:
        raise ObservationFailure('invalid agreed-parent state')
    seen = set()
    for key in ('established', 'pending', 'previous'):
        item = value[key]
        if item is None:
            if key == 'established':
                raise ObservationFailure('no established parent')
            continue
        if type(item) is not dict or set(item) != {'timestamp', 'uuid'}:
            raise ObservationFailure('invalid snapshot identity')
        ts, uid = item['timestamp'], item['uuid']
        if type(ts) is not str or not STAMP.fullmatch(ts) or type(uid) is not str or not re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', uid) or ts in seen:
            raise ObservationFailure('invalid or duplicate snapshot identity')
        seen.add(ts)
    if value['pending'] is not None and value['previous'] is not None:
        raise ObservationFailure('conflicting transition')
    return value


def get_state(transaction_id, *, run=subprocess.run, source_lock_held=False):
    """Single authenticated read. No fallback, mutation, or automatic retries.

    `source_lock_held` must come from the owning coordinator, never user input.
    Production integration must replace this boolean with lock ownership proof.
    """
    if source_lock_held is not True:
        raise ObservationFailure('source transaction lock not established')
    if type(transaction_id) is not str or not STAMP.fullmatch(transaction_id):
        raise ObservationFailure('invalid transaction ID')
    request = {'schema': 1, 'operation': 'get-state', 'transaction_id': transaction_id,
               'expected_before': None, 'candidate': None}
    try:
        outcome = run(list(SSH), input=json.dumps(request, separators=(',', ':')),
                      capture_output=True, text=True, timeout=60, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ObservationFailure('receiver observation uncertain') from exc
    if type(outcome.returncode) is not int or outcome.returncode != 0:
        raise ObservationFailure('receiver SSH/read-only endpoint failed')
    raw = outcome.stdout
    if type(raw) is not str or not 0 < len(raw.encode('utf-8')) <= 65536:
        raise ObservationFailure('missing/oversized receiver reply')
    try:
        reply = json.loads(raw)
    except (ValueError, TypeError) as exc:
        raise ObservationFailure('malformed receiver reply') from exc
    if (type(reply) is not dict or set(reply) != {'schema', 'operation', 'transaction_id', 'status', 'state'} or
            type(reply['schema']) is not int or reply['schema'] != 1 or
            reply['operation'] != 'get-state' or reply['transaction_id'] != transaction_id or
            reply['status'] != 'success'):
        raise ObservationFailure('invalid receiver reply contract')
    return {'schema': 1, 'receiver': validate_state(reply['state']),
            'authorizes_prepare': False, 'authorizes_promote': False,
            'authorizes_transfer': False, 'authorizes_prune': False,
            'authorizes_release': False}
