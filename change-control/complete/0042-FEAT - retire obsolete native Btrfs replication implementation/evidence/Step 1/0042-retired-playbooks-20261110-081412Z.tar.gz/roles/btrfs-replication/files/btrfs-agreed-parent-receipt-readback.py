#!/usr/bin/env python3
"""Strict read-only sender verification of the receiver's final receipt.

Internal only: no sender CLI, parent advancement, pruning or pin release.
"""
import json
import subprocess

class ReceiptRefused(RuntimeError):
    pass


def verify_receipt_over_ssh(parent, candidate, *, commands, run=subprocess.run):
    cmd = commands.receipt_command(parent, candidate)
    try:
        result = run(cmd, input=b'', stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ReceiptRefused('receipt SSH readback uncertain') from exc
    if type(result.returncode) is not int or result.returncode != 0:
        raise ReceiptRefused('receipt SSH readback failed')
    if type(result.stdout) is not bytes or len(result.stdout) > 65536:
        raise ReceiptRefused('unsafe receipt readback length')
    try:
        payload = json.loads(result.stdout)
    except (ValueError, UnicodeDecodeError) as exc:
        raise ReceiptRefused('malformed receiver receipt evidence') from exc
    receipt = payload.get('receipt') if type(payload) is dict else None
    if (type(payload) is not dict or payload.get('schema') != 1 or
            payload.get('status') != 'receiver-final-receipt-verified' or
            payload.get('parent') != parent or payload.get('candidate') != candidate or
            payload.get('receipt_committed') is not True or
            any(payload.get(k) is not False for k in
                ('authorizes_transition', 'authorizes_prune', 'authorizes_release')) or
            type(receipt) is not dict or receipt.get('schema') != 1 or
            receipt.get('snapshot') != candidate['timestamp'] or
            receipt.get('source_uuid') != candidate['uuid'] or
            receipt.get('received_uuid') != candidate['uuid'] or
            receipt.get('destination') != '/@data/mars-received/@data/' + candidate['timestamp'] or
            receipt.get('parent_snapshot') != parent['timestamp'] or
            receipt.get('parent_source_uuid') != parent['uuid'] or
            receipt.get('read_only_verified') is not True or
            type(receipt.get('source_send_exit')) is not int or receipt.get('source_send_exit') != 0 or
            type(receipt.get('receiver_receive_exit')) is not int or receipt.get('receiver_receive_exit') != 0):
        raise ReceiptRefused('receiver receipt readback identity refused')
    return True
