#!/usr/bin/env python3
"""Non-destructive real subprocess lifecycle and bounded stream regression."""
import importlib.util
from pathlib import Path
import sys
import time

source = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-owned-session.py'
spec = importlib.util.spec_from_file_location('owned_session', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

python = sys.executable

def echo(reader, writer):
    writer.write('challenge\n')
    assert reader.readline() == 'response\n'
    return 'verified'

assert module.run_owned_disposable_peer(
    [python, '-u', '-c', 'import sys; assert sys.stdin.readline()=="challenge\\n"; sys.stdout.write("response\\n"); sys.stdout.flush()'],
    echo) == 'verified'
print('PASS: owned peer challenged, completed and exited successfully')

def fail(reader, writer):
    raise OSError('simulated receiver failure')

start = time.monotonic()
try:
    module.run_owned_disposable_peer([python, '-u', '-c', 'import time; time.sleep(30)'], fail)
except OSError as exc:
    assert 'simulated' in str(exc)
else:
    raise AssertionError('Receiver failure hidden')
assert time.monotonic() - start < 5
print('PASS: receiver interruption propagated and live peer terminated and reaped')

start = time.monotonic()
try:
    module.run_owned_disposable_peer([python, '-u', '-c', 'import time; time.sleep(30)'],
                                      lambda r, w: r.readline(), line_timeout=0.2)
except TimeoutError:
    pass
else:
    raise AssertionError('Stalled peer accepted')
assert time.monotonic() - start < 5
print('PASS: stalled peer timed out, terminated and reaped')

try:
    module.run_owned_disposable_peer([python, '-u', '-c', 'pass'], lambda r,w:r.readline())
except EOFError:
    pass
else:
    raise AssertionError('Disconnected peer accepted')
print('PASS: disconnected peer rejected')

assert 'delete-receiver' not in source.read_text()
assert 'sudo' not in source.read_text()
print('LIMIT: disposable subprocess only; no trusted SSH peer, source lock, Btrfs or deletion')
