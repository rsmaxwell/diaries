#!/usr/bin/env python3
"""0034 Step 10.3: constrained privileged Btrfs send/receive endpoints.

Installed independently on mars (--role source) and backup (--role receiver).
No generic command forwarding; both roles validate pinned filesystem identities.
Step 11.4 also exposes a constrained read-only source listing for unattended selection.
"""

# MODULE GUIDE: Constrained privileged endpoint for native Btrfs snapshot replication.  The
# source-side role runs on mars; the receiving role runs on backup. Each operation is chosen
# from a fixed allowlist and checks path, filesystem and snapshot identity instead of forwarding
# arbitrary shell commands. The endpoint is a privileged boundary: callers cannot select
# arbitrary paths or programs.  The receiver's writer lock and source protection state are
# different safety mechanisms: one serializes receiver writes, the other prevents pruning the
# common parent while it may still be used for incremental send/receive.  This is the btrfs-
# replication role implementation, including Step 3 work.

import argparse
import fcntl
import json
import tempfile
import stat
import os
from pathlib import Path
import re
import subprocess
import sys

# STAMP: Canonical UTC snapshot timestamp pattern; filters names before treating them as managed
# snapshots.
STAMP = re.compile(r"^[0-9]{8}-[0-9]{6}Z$")
# SOURCE_DIR: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
SOURCE_DIR = Path('/media/usb/@snapshots/@data')
# SOURCE_MOUNT: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
SOURCE_MOUNT = Path('/media/usb')
# RECEIVE_DIR: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
RECEIVE_DIR = Path('/@data/mars-received/@data')
# RECEIVE_MOUNT: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
RECEIVE_MOUNT = Path('/')
# SOURCE_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
# RECEIVE_FS: Pinned filesystem or replication ancestry identity; mismatches must fail closed.
RECEIVE_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'
# PROTECTION: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
PROTECTION = Path('/media/usb/@snapshots/.replication-protection.json')
# Optional 0040 state: absent preserves legacy operation; present protects all
# established/pending/previous parents. Installed only after separate gate.
AGREED_PARENT = Path('/media/usb/@snapshots/.agreed-parent.json')
# MANAGER_LOCK: Fixed managed path; never substitute a caller-supplied path at this privilege
# boundary.
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
# EXPECTED_ORIGIN: Pinned filesystem or replication ancestry identity; mismatches must fail
# closed.
EXPECTED_ORIGIN = 'fc4585b5-1649-b94c-bcb6-a9253c9cf080'



# FUNCTION run: Invoke a fixed subprocess and return captured output; failures propagate to the
# caller.
def run(*args):
    return subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout



# FUNCTION require: Check a security or consistency precondition; reject immediately rather than
# continuing with unsafe state. Inputs: condition, message.
def require(condition, message):
    if not condition:
        raise RuntimeError(message)



# FUNCTION safe_path: Validate that the requested path stays within the fixed managed Btrfs
# directories. Inputs: path, parent.
def safe_path(path, parent):
    require(path.parent == parent, 'Unexpected location')
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for item in (parent, *reversed(parent.parents)):
        if item == Path('/'):
            continue
        require(item.is_dir() and not item.is_symlink(), f'Unsafe directory {item}')
    if path.exists() or path.is_symlink():
        require(not path.is_symlink(), f'Symlink forbidden: {path}')



# FUNCTION show: Read Btrfs subvolume metadata (UUID, parent/received identity and flags) for
# identity checks. Inputs: path.
def show(path):
    output = run('btrfs', 'subvolume', 'show', str(path))
    result = {}
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for line in output.splitlines():
        if ':' in line:
            key, value = line.strip().split(':', 1)
            result[key.strip()] = value.strip()
    return result



# FUNCTION fs_check: Check the filesystem/mount identity before any privileged Btrfs operation.
# Inputs: path, expected.
def fs_check(path, expected):
    output = run('btrfs', 'filesystem', 'show', str(path))
    require(re.search(r'\buuid:\s*' + re.escape(expected) + r'\b', output, re.I) is not None,
            'Wrong Btrfs filesystem UUID')



# FUNCTION source: Resolve the named source snapshot only after checking its timestamp and
# managed location. Inputs: snapshot, parent_stamp.
def source(snapshot, parent_stamp=None):
    parent = SOURCE_DIR
    path = parent / snapshot
    safe_path(path, parent)
    fs_check(SOURCE_MOUNT, SOURCE_FS)
    require(path.is_dir(), 'Source snapshot absent')
    info = show(path)
    require(info.get('Flags') == 'readonly', 'Source must be read-only')
    require(info.get('Parent UUID') == EXPECTED_ORIGIN, 'Source is not @data snapshot')
    require(info.get('Received UUID') in ('-', None), 'Unexpected received snapshot')
    # Send binary stream straight to stdout; never print text on stdout.
    command = ['btrfs', 'send']
    if parent_stamp is not None:
        require(STAMP.fullmatch(parent_stamp) is not None and parent_stamp < snapshot,
                'Invalid incremental parent timestamp')
        parent_path = parent / parent_stamp
        safe_path(parent_path, parent)
        require(parent_path.is_dir(), 'Incremental parent absent')
        parent_info = show(parent_path)
        require(parent_info.get('Flags') == 'readonly', 'Parent must be read-only')
        require(parent_info.get('Parent UUID') == EXPECTED_ORIGIN, 'Parent has unexpected lineage')
        require(parent_info.get('Received UUID') in ('-', None), 'Unexpected parent received lineage')
        command.extend(['-p', str(parent_path)])
    command.append(str(path))
    os.execvp('btrfs', command)



# FUNCTION inspect: Collect validated subvolume identity for a specific timestamp without
# modifying snapshots. Inputs: snapshot, role.
def inspect(snapshot, role):
    parent = SOURCE_DIR if role == 'inspect-source' else RECEIVE_DIR
    fs_check(SOURCE_MOUNT if role == 'inspect-source' else RECEIVE_MOUNT,
             SOURCE_FS if role == 'inspect-source' else RECEIVE_FS)
    path = parent / snapshot
    safe_path(path, parent)
    require(path.is_dir(), 'Snapshot absent')
    info = show(path)
    require(info.get('Flags') == 'readonly', 'Snapshot not read-only')
    if role == 'inspect-source':
        require(info.get('Parent UUID') == EXPECTED_ORIGIN, 'Unexpected source lineage')
    import json
    print(json.dumps({'uuid': info.get('UUID'), 'received_uuid': info.get('Received UUID'), 'flags': info.get('Flags'), 'parent_uuid': info.get('Parent UUID')}))



# FUNCTION receive: Accept a constrained Btrfs receive stream into the configured receiver tree.
# Inputs: snapshot.
def receive(snapshot):
    parent = RECEIVE_DIR
    path = parent / snapshot
    safe_path(path, parent)
    fs_check(RECEIVE_MOUNT, RECEIVE_FS)
    require(not path.exists() and not path.is_symlink(), 'Destination already exists')
    # btrfs receive creates a subvolume named by the send stream; for this
    # endpoint source names must be exact timestamps. A failure leaves an
    # unaccepted destination for explicit operator inspection (no auto delete).
    os.execvp('btrfs', ['btrfs', 'receive', str(parent)])





# 0040: delete-receiver is permitted by constrained sudoers, but requires a
# matching durable journal. It is not exposed by the unprivileged receiver CLI
# and does not itself authorise automated receiver pruning.
RECEIVER_STATE = Path('/@data/mars-received/.replication-state')
RECEIVER_PENDING = RECEIVER_STATE / '.receiver-prune-pending.json'
AGREED_TRANSFER_PENDING = RECEIVER_STATE / '.agreed-parent-transfer-pending.json'


def refuse_unfinished_agreed_transfer():
    """Fail closed at privileged deletion boundary, including dangling links."""
    require(RECEIVER_STATE.is_dir() and not RECEIVER_STATE.is_symlink(),
            'Unsafe receiver state')
    require(not AGREED_TRANSFER_PENDING.exists() and
            not AGREED_TRANSFER_PENDING.is_symlink(),
            'Unfinished agreed-parent transfer blocks receiver deletion')




# FUNCTION delete_receiver: Constrain receiver deletion to the exact verified managed snapshot
# and privilege boundary. Inputs: snapshot.
def delete_receiver(snapshot):
    """Constrained privileged deletion, callable only with an existing journal.

    The unprivileged coordinator must hold the receiver's writer lock, create
    the durable journal, and maintain the source pin. This function independently
    checks the Btrfs identity before touching the destination. It never touches
    receipts or journals; the coordinator reconciles them after success.
    """
    refuse_unfinished_agreed_transfer()
    destination = RECEIVE_DIR / snapshot
    safe_path(destination, RECEIVE_DIR)
    safe_path(RECEIVER_PENDING, RECEIVER_STATE)
    require(RECEIVER_STATE.is_dir() and not RECEIVER_STATE.is_symlink(), 'Unsafe receiver state')
    require(RECEIVER_PENDING.is_file() and not RECEIVER_PENDING.is_symlink(),
            'Missing safe pending receiver transaction')
    require(RECEIVER_PENDING.stat().st_nlink == 1, 'Unsafe pending journal links')
    transaction = json.loads(RECEIVER_PENDING.read_text(encoding='utf-8'))
    require(isinstance(transaction, dict) and transaction.get('schema') == 1 and
            transaction.get('snapshot') == snapshot and
            transaction.get('destination') == str(destination) and
            transaction.get('receipt') == str(RECEIVER_STATE / (snapshot + '.json')),
            'Pending transaction does not match destination')
    expected_uuid = transaction.get('source_uuid')
    require(isinstance(expected_uuid, str) and
            re.fullmatch(r'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', expected_uuid),
            'Invalid transaction UUID')
    parent_stamp = transaction.get('protected_parent')
    parent_uuid = transaction.get('protected_parent_uuid')
    require(isinstance(parent_stamp, str) and STAMP.fullmatch(parent_stamp) and
            snapshot < parent_stamp, 'Candidate must be older than protected parent')
    require(isinstance(parent_uuid, str) and
            re.fullmatch(r'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', parent_uuid),
            'Missing protected parent source UUID')
    parent_path = RECEIVE_DIR / parent_stamp
    safe_path(parent_path, RECEIVE_DIR)
    require(parent_path.is_dir(), 'Protected parent absent')
    fs_check(RECEIVE_MOUNT, RECEIVE_FS)
    parent_info = show(parent_path)
    require(parent_info.get('Flags') == 'readonly' and
            parent_info.get('Received UUID') == parent_uuid,
            'Protected parent received UUID mismatch')
    parent_receipt_path = RECEIVER_STATE / (parent_stamp + '.json')
    safe_path(parent_receipt_path, RECEIVER_STATE)
    require(parent_receipt_path.is_file() and not parent_receipt_path.is_symlink() and
            parent_receipt_path.stat().st_nlink == 1, 'Protected parent receipt absent or unsafe')
    parent_receipt = json.loads(parent_receipt_path.read_text(encoding='utf-8'))
    require(parent_receipt.get('schema') == 1 and
            parent_receipt.get('snapshot') == parent_stamp and
            parent_receipt.get('destination') == str(parent_path) and
            parent_receipt.get('source_uuid') == parent_uuid and
            parent_receipt.get('received_uuid') == parent_uuid and
            parent_receipt.get('read_only_verified') is True,
            'Protected parent receipt identity mismatch')
    receipt_file = RECEIVER_STATE / (snapshot + '.json')
    safe_path(receipt_file, RECEIVER_STATE)
    require(receipt_file.is_file() and not receipt_file.is_symlink() and
            receipt_file.stat().st_nlink == 1, 'Unsafe receipt')
    receipt = json.loads(receipt_file.read_text(encoding='utf-8'))
    require(receipt.get('schema') == 1 and receipt.get('snapshot') == snapshot and
            receipt.get('destination') == str(destination) and
            receipt.get('source_uuid') == expected_uuid and
            receipt.get('received_uuid') == expected_uuid and
            receipt.get('read_only_verified') is True,
            'Receipt does not match pending transaction')
    require(destination.is_dir(), 'Received snapshot absent')
    info = show(destination)
    require(info.get('Flags') == 'readonly' and info.get('Received UUID') == expected_uuid,
            'Received Btrfs snapshot identity mismatch')
    # Recheck immediately at the destructive boundary. The caller must hold
    # the receiver manager and writer locks for the complete transaction.
    refuse_unfinished_agreed_transfer()
    # Explicit command and no shell. Receipt and journal are NEVER deleted here.
    run('btrfs', 'subvolume', 'delete', str(destination))
    require(not destination.exists() and not destination.is_symlink(),
            'Btrfs deletion did not remove destination')
    print(json.dumps({'deleted': snapshot, 'receipt_preserved': True,
                      'journal_preserved': True}, sort_keys=True))



# FUNCTION list_source: List eligible source snapshot timestamps from the fixed managed source
# collection.
def list_source():
    fs_check(SOURCE_MOUNT, SOURCE_FS)
    require(SOURCE_DIR.is_dir() and not SOURCE_DIR.is_symlink(), 'Source snapshot directory missing/unsafe')
    values = []
    # SAFETY: Process each managed item individually; every iteration must pass the same safety
    # checks.
    for path in sorted(SOURCE_DIR.iterdir(), key=lambda item: item.name, reverse=True):
        if not STAMP.fullmatch(path.name) or not path.is_dir() or path.is_symlink():
            continue
        safe_path(path, SOURCE_DIR)
        try:
            info = show(path)
        except subprocess.CalledProcessError:
            continue
        if (info.get('Flags') == 'readonly' and info.get('Parent UUID') == EXPECTED_ORIGIN and
                info.get('Received UUID') in ('-', None) and info.get('UUID')):
            values.append({'snapshot': path.name, 'uuid': info.get('UUID')})
    print(json.dumps(values))



def agreed_parent_protected(path):
    """Read optional schema-1 state without granting any pruning authority.

    Must be called while holding the existing snapshot manager lock. A missing
    state file preserves legacy behavior; unsafe or corrupt state fails closed.
    """
    if not path.exists() and not path.is_symlink():
        return {}
    require(path.is_file() and not path.is_symlink(), 'Unsafe agreed-parent state')
    info = path.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and
            info.st_uid == 0 and not info.st_mode & 0o022,
            'Unsafe agreed-parent state permissions')
    require(info.st_size <= 65536, 'Oversized agreed-parent state')
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError, UnicodeError) as exc:
        raise RuntimeError('Unreadable agreed-parent state') from exc
    require(type(data) is dict and set(data) ==
            {'schema', 'established', 'pending', 'previous'} and
            type(data['schema']) is int and data['schema'] == 1,
            'Invalid agreed-parent schema')
    pins = {}
    for field in ('established', 'pending', 'previous'):
        item = data[field]
        if item is None:
            continue
        require(type(item) is dict and set(item) == {'timestamp', 'uuid'} and
                type(item['timestamp']) is str and STAMP.fullmatch(item['timestamp']) and
                type(item['uuid']) is str and
                re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', item['uuid']),
                'Invalid agreed-parent identity')
        require(item['timestamp'] not in pins, 'Duplicate agreed-parent timestamp')
        pins[item['timestamp']] = item['uuid']
    require(data['established'] is not None and
            not (data['pending'] is not None and data['previous'] is not None),
            'Invalid agreed-parent transition')
    return pins


# FUNCTION protection_update: Persist source snapshot pin state under the manager lock using
# guarded atomic replacement. Inputs: stamp, operation, expected_uuid.
# Pin records are persistent protection against source-side pruning. Treat a
# missing or corrupt file as unsafe; never recreate it from an untrusted peer.
def protection_update(stamp, *, operation, expected_uuid=None):
    """Serialize with 0035 prune using its existing manager lock."""
    require(PROTECTION.parent.is_dir() and not PROTECTION.parent.is_symlink(), 'Unsafe protection parent')
    require(MANAGER_LOCK.exists() and not MANAGER_LOCK.is_symlink(), 'Snapshot manager lock absent')
    # SAFETY: Constrain resource lifetime so files, locks or sessions close on every exit path.
    with MANAGER_LOCK.open('r+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        require(PROTECTION.is_file() and not PROTECTION.is_symlink(), 'Protection state missing')
        metadata = PROTECTION.stat()
        require(metadata.st_uid == 0 and not metadata.st_mode & 0o022, 'Unsafe protection permissions')
        state = json.loads(PROTECTION.read_text())
        require(state.get('schema') == 1 and isinstance(state.get('protected'), dict), 'Bad protection state')
        pins = state['protected']
        prune_pins = state.setdefault('prune_protected', {})
        require(isinstance(prune_pins, dict), 'Bad pruning protection state')
        if operation in ('protect', 'protect-prune'):
            source_path = SOURCE_DIR / stamp
            safe_path(source_path, SOURCE_DIR)
            require(source_path.is_dir(), 'Source snapshot absent')
            fs_check(SOURCE_MOUNT, SOURCE_FS)
            info = show(source_path)
            require(info.get('Flags') == 'readonly' and info.get('Parent UUID') == EXPECTED_ORIGIN,
                    'Invalid protected source')
            value = info.get('UUID')
            require(bool(value) and (stamp not in pins or pins[stamp] == value), 'Protection UUID conflict')
            pins[stamp] = value
            if operation == 'protect-prune':
                require(stamp not in prune_pins or prune_pins[stamp] == value,
                        'Prune protection UUID conflict')
                prune_pins[stamp] = value
        else:
            # Read under the manager lock, immediately before any legacy release.
            # Never silently bypass an unsafe or corrupt agreed-parent record.
            agreed = agreed_parent_protected(AGREED_PARENT)
            require(stamp not in agreed,
                    'Agreed parent is protected; coordinated transition required')
            require(stamp not in prune_pins,
                    'Source is protected for receiver pruning; explicit reconciliation required')
            require(expected_uuid and pins.get(stamp) == expected_uuid, 'Release requires matching protected UUID')
            del pins[stamp]
        fd, temp = tempfile.mkstemp(prefix='.replication-protection-', dir=PROTECTION.parent)
        try:
            with os.fdopen(fd, 'w') as output:
                os.fchmod(output.fileno(), 0o600)
                json.dump(state, output, indent=2, sort_keys=True)
                output.write('\n')
                output.flush()
                os.fsync(output.fileno())
            os.replace(temp, PROTECTION)
            directory_fd = os.open(PROTECTION.parent, os.O_DIRECTORY)
            try: os.fsync(directory_fd)
            finally: os.close(directory_fd)
        finally:
            if os.path.exists(temp): os.unlink(temp)
        print(json.dumps({'operation': operation, 'snapshot': stamp,
                          'source_uuid': pins.get(stamp, expected_uuid)}))


# FUNCTION main: Parse the allowlisted command interface; validate inputs, acquire required
# locks and dispatch roles.
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--role', required=True, choices=('source', 'incremental-source', 'receiver', 'inspect-source', 'inspect-receiver', 'protect-source', 'protect-prune-source', 'release-source', 'list-source', 'delete-receiver'))
    parser.add_argument('--snapshot')
    parser.add_argument('--parent')
    parser.add_argument('--expected-uuid')
    args = parser.parse_args()
    require(os.geteuid() == 0, 'Requires root')
    if args.role == 'list-source':
        require(args.snapshot is None and args.parent is None and args.expected_uuid is None,
                'list-source accepts no snapshot arguments')
        list_source()
        return
    require(args.snapshot is not None and STAMP.fullmatch(args.snapshot) is not None, 'Invalid snapshot name')
    require((args.parent is not None) == (args.role == 'incremental-source'),
            'Parent only permitted for incremental-source')
    require((args.expected_uuid is not None) == (args.role == 'release-source'), 'Expected UUID only permitted on release')
    if args.role == 'protect-source':
        protection_update(args.snapshot, operation='protect')
    elif args.role == 'protect-prune-source':
        protection_update(args.snapshot, operation='protect-prune')
    elif args.role == 'release-source':
        protection_update(args.snapshot, operation='release', expected_uuid=args.expected_uuid)
    elif args.role == 'delete-receiver':
        delete_receiver(args.snapshot)
    elif args.role == 'source':
        source(args.snapshot)
    elif args.role == 'incremental-source':
        source(args.snapshot, args.parent)
    elif args.role == 'receiver':
        receive(args.snapshot)
    else:
        inspect(args.snapshot, args.role)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, subprocess.CalledProcessError, OSError) as exc:
        print(f'btrfs-native-endpoint: {exc}', file=sys.stderr)
        sys.exit(1)
