#!/usr/bin/env python3
"""Verify filesystem UUID lookup uses actual mounts, never arbitrary nested directories."""
import ast
from pathlib import Path
path = Path(__file__).resolve().parents[1] / 'files/btrfs-native-endpoint.py'
tree = ast.parse(path.read_text())
assignments = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0], ast.Name):
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'Path':
            assignments[node.targets[0].id] = ast.literal_eval(node.value.args[0])
assert assignments['SOURCE_MOUNT'] == '/media/usb'
assert assignments['RECEIVE_MOUNT'] == '/'
fs_args = []
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'fs_check':
        fs_args.append(ast.unparse(node.args[0]))
assert set(fs_args) == {'SOURCE_MOUNT', "SOURCE_MOUNT if role == 'inspect-source' else RECEIVE_MOUNT", 'RECEIVE_MOUNT'}, fs_args
assert fs_args.count('SOURCE_MOUNT') >= 2, fs_args  # initial send and protection checks
print('PASS: pinned Btrfs mount-point UUID checks')
