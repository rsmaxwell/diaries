# 0040-FEAT Step 3 — Manager journal integration regression

This regression uses **the actual** `receiver_delete_one_locked`, `receiver_journal_write`,
`receiver_journal_finish`, and `receiver_recovery_plan` implementation from Playbooks.

It verifies two cases within temporary, self-contained filesystem directories:

- Successful approved callback: durable pending journal exists before delete callback, the
  candidate and its receipt disappear, journal is removed, parent and newest remain.
- Interrupted callback after journal write: journal, candidate and receipt survive; recovery
  remains operator-gated; a replay is rejected.

The test patches the Btrfs inventory and kernel operations only. It **does not validate**
actual received-UUID inventory, source locks, two-challenge approval reservation, or
real deletion. This is a Stage 2 **source regression**, not Stage 2 closure.

## Execution on mango (non-destructive)

`python3 roles/btrfs-replication/tests/verify-manager-journal-integration.py`

## Next acceptance gate

Connect the trusted SSH source-held coordinator to the privileged receiver gateway
and run a fully isolated three-received-snapshot Btrfs transaction. Do not expose
`delete-receiver` in production sudoers or enable automatic pruning.
