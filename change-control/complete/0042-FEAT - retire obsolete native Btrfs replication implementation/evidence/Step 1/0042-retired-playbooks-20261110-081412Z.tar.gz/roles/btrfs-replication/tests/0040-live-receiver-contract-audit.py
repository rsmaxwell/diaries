#!/usr/bin/env python3
"""0040 Step 3: pre-deployment contract audit for a privileged live receiver executor.

Read-only. This is NOT an executor, and deliberately offers no delete flag.
Uses the exact committed sources and reports incompatibilities before wiring a
privileged production transaction. Run on mango against the Playbooks checkout.
"""
import ast
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
RECEIVER = ROOT / 'files/btrfs-native-push-receiver.py'
MANAGER = ROOT.parent / 'snapshots/files/btrfs-snapshot-manager.py'
ENDPOINT = ROOT / 'files/btrfs-native-endpoint.py'
BRIDGE = ROOT / 'files/btrfs-receiver-prune.py'
SUDOERS = ROOT / 'templates/btrfs-native-sudoers.j2'


def funcs(path):
    tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    return {item.name: item for item in tree.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))}


def argnames(fn):
    return {a.arg for a in fn.args.posonlyargs + fn.args.args + fn.args.kwonlyargs}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)
    print('PASS: ' + message)


def main():
    receiver = funcs(RECEIVER)
    manager = funcs(MANAGER)
    endpoint = funcs(ENDPOINT)
    bridge = funcs(BRIDGE)
    expected = {
        'run_approved_manager_bound_transaction': {'stamp', 'uuid', 'candidate', 'manager', 'config', 'incoming', 'outgoing', 'planner', 'delete_subvolume', 'approval_path', 'consumed_dir'},
        'run_source_held_transaction_locked': {'stamp', 'uuid', 'candidate', 'incoming', 'outgoing', 'planner', 'transaction'},
        'protected_retention_plan': {'stamp', 'source_uuid'},
    }
    for name, args in expected.items():
        require(name in receiver and args.issubset(argnames(receiver[name])), f'receiver {name} interface unchanged')
    require('receiver_delete_one_locked' in manager and
            {'config', 'stamp', 'protected_stamp', 'expected_parent_uuid', 'verify_source_pin', 'delete_subvolume'}.issubset(
                argnames(manager['receiver_delete_one_locked'])), 'manager transaction interface unchanged')
    require('delete_receiver' in endpoint and {'snapshot'}.issubset(argnames(endpoint['delete_receiver'])),
            'endpoint deletion interface unchanged')
    require('run_internal_approved_transaction' in bridge, 'privileged bridge still internal')
    body = ast.get_source_segment(RECEIVER.read_text(), receiver['run_approved_manager_bound_transaction'])
    require('reserve_receiver_prune_approval' in body and 'receiver_delete_one_locked' in body,
            'approval reservation and real manager transaction remain coupled')
    journal = ast.get_source_segment(MANAGER.read_text(), manager['receiver_delete_one_locked'])
    require('receiver_journal_write' in journal and 'receiver_journal_finish' in journal,
            'manager owns journal lifecycle')
    command = ast.get_source_segment(ENDPOINT.read_text(), endpoint['delete_receiver'])
    require('RECEIVER_PENDING' in command and "'btrfs', 'subvolume', 'delete'" in command,
            'endpoint requires journal and invokes exact Btrfs delete')
    template = SUDOERS.read_text()
    require("btrfs_native_enable_receiver_delete_endpoint | default(false) | bool" in template,
            'sudoers privilege is default-off in source (requires c823dfa or later)')
    config = Path('/etc/btrfs-snapshot-manager.json')
    print('BOUNDARY: installed production manager config must be root-owned, receiver-mode and prune-disabled:', config)
    print('BLOCKER: live authenticated mars source-holder has not been wired to the privileged bridge')
    print('BLOCKER: the existing delete-receiver endpoint is production-path-bound; it is not a disposable fixture callback')
    print('BLOCKER: explicit approval and consumed-record paths, installation and rollback are not yet defined')
    print('RESULT: read-only contract audit complete; NO deletion or production authorisation')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, SyntaxError) as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        sys.exit(1)
