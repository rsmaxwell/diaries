# 0040-FEAT Step 3: isolated integrated receiver transaction plan

## Scope and status

Planning gate only. The companion script is **read-only**, accepts only `--plan`, and has no execution/deletion mode. Source baseline: Playbooks commit `d5f7181` (the script does not replace operational source). Previously accepted Btrfs lifecycle and full/incremental received-UUID rehearsals are not repeated.

## Required execution fixture (future package, not implemented here)

- Generate a cryptographically random, new namespace strictly under `/@data/.0040-integrated-acceptance-<uuid>` on `backup`. Do not follow symlinks. Never use `/@data/mars-received` or production manager configuration/state.
- Build **three** distinct timestamp-named, read-only source snapshots and receive them with actual Btrfs send/receive into an isolated receiver collection. Ensure each receipt matches its subvolume's `Received UUID`. Configure one isolated receiver source, dedicated manager/writer locks, dedicated approval consumption and pending-journal state, root-owned mode-0600 checkpoint hold file, and a retention policy which actually selects the oldest candidate.
- Hold the middle, protected-parent checkpoint explicitly and retain the newest independently. Use real retention evaluation, UUID/receipt and checkpoint-hold gates; do not mock or bypass any of these in the final acceptance.
- Coordinate the sender source lock and pin over a **live cross-host** communication channel; run the existing two-challenge exchange and root-only approved adapter. Protect root-owned approval material from the ordinary unprivileged receiver and acquire manager lock before writer lock.
- Implement a restricted, auditable privileged process/channel for the real deletion callback. Do not add `delete-receiver` to production sudoers, and do not use the production paths. Require bounded process lifetime, sender-child reaping and explicit error handling on SSH disconnection.
- On success, prove precisely one candidate deleted and its receipt removed, journal resolved, parent/newest unaffected, and approval permanently consumed. On an interruption after journalling, prove journal, reservation and source protection persist and additional deletions fail closed pending operator reconciliation.
- Use a separate explicit destructive-test approval gate before running. Preserve a failed fixture for investigation; cleanup must delete only enumerated disposable subvolumes and leave a verifiable absent namespace. Check production recovery journal remains CLEAN.

## Why an extra planning gate is necessary

`receiver_delete_one_locked()` checks inventory, receipt UUIDs, retention and root-owned mandatory holds *before* calling its injected deletion callback. The earlier two-snapshot fixture and basic lifecycle tests do not establish candidate eligibility or a root-owned approval lifecycle. Linking the public receiver to root while it holds `writer.lock` also risks lock inversion, so the approved transaction must be invoked by a separately constrained manager-first process.

## Invocation on mango

```bash
cd /home/richard/playbooks || exit 1
python3 -m py_compile roles/btrfs-replication/tests/verify-integrated-receiver-fixture-plan.py
ssh backup 'sudo -n python3 - --plan' < roles/btrfs-replication/tests/verify-integrated-receiver-fixture-plan.py
git diff --check
git status --short
```

Do not mark full Step 3 transaction acceptance CLOSED on the basis of this planning check.
