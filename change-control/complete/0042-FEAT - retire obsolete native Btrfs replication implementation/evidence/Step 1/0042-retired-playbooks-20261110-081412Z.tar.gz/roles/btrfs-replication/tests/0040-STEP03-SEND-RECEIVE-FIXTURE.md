# 0040 Step 3 — Isolated Btrfs send/receive fixture

Status: **NOT ACCEPTED** pending execution review. Source basis: latest uploaded Playbooks bundle; this package adds test files only and does not overwrite later commits.

## Purpose

Produce and verify a genuine disposable received parent and incremental child with matching Btrfs `Received UUID`s. This addresses the identity prerequisite for the manager transaction. It deliberately does **not** manufacture production receipts or invoke the privileged transaction. A subsequent harness must integrate manager locks, valid isolated retention/holds, one-time root approval, live source challenge and journal-backed deletion.

## Isolation

All changes occur under a fresh `/@data/.0040-send-receive-<uuid>` Btrfs subvolume on `backup`. No path arguments accepted; no production receiver paths used. On any failure, the fixture is retained for investigation; do not automatically cleanup a failed fixture. No sudoers or Ansible deployment changes.

## Acceptance gates

1. Compile and run `--plan` on backup (read-only). Review output and source.
2. After explicit review, separately authorize `--execute --accept-disposable-delete CREATE-DELETE-ONLY-0040-SEND-RECEIVE`. This **creates and deletes** only the unique disposable subvolumes.
3. Verify namespace absent, production receiver recovery `CLEAN`, historical holds unchanged; capture evidence.

This is a prerequisite fixture, **not** the final integrated transaction acceptance. Keep 0040-FEAT Step 3 OPEN, receiver pruning disabled, and delete-receiver absent from sudoers.
