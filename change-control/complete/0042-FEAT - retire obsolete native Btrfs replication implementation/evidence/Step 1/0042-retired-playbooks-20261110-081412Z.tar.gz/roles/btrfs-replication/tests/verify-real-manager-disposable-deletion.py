#!/usr/bin/env python3
"""0040 Step 3: real Btrfs manager deletion, isolated entirely under a fresh namespace.

--plan is read-only. --execute deletes only one newly received disposable candidate;
no production manager, approvals, receipts, snapshots, sudoers or locks are used.
This does NOT authorise production pruning or verify the live cross-host approval protocol.
"""
import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import fcntl
import importlib.util
from importlib.machinery import SourceFileLoader
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

ROOT = Path('/@data')
PREFIX = '.0040-manager-transaction-'
ACK = 'DELETE-ONLY-ISOLATED-0040-MANAGER'
STAMPS = ('20261020-010000Z', '20261021-010000Z', '20261022-010000Z')
CANDIDATE, PARENT, NEWEST = STAMPS
MANAGER_PATH = Path('/usr/local/sbin/btrfs-snapshot-manager')


def run(*args):
    result = subprocess.run(args, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(f'command failed: {args!r}: {result.stderr[-500:]}')
    return result.stdout


def identity(path, field):
    value = run('btrfs', 'subvolume', 'show', str(path))
    m = re.search(r'^\s*' + re.escape(field) + r':\s*(\S+)\s*$', value, re.M)
    if m is None or m.group(1).lower() in ('-', 'none'):
        raise RuntimeError(f'Unverified {field}: {path}')
    return m.group(1).lower()


def preflight():
    if ROOT.is_symlink() or not ROOT.is_dir():
        raise RuntimeError('Unsafe Btrfs test root')
    if run('findmnt', '-n', '-o', 'FSTYPE', '--target', str(ROOT)).strip() != 'btrfs':
        raise RuntimeError('Test root must be Btrfs')
    if not MANAGER_PATH.is_file() or MANAGER_PATH.is_symlink():
        raise RuntimeError('Installed manager absent/unsafe')
    if not Path('/usr/bin/btrfs').is_file():
        raise RuntimeError('btrfs executable absent')


def manager_module():
    name = 'isolated_0040_manager'
    loader = SourceFileLoader(name, str(MANAGER_PATH))
    spec = importlib.util.spec_from_loader(name, loader)
    if spec is None or spec.loader is None:
        raise RuntimeError('Unable to load installed manager Python source')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    if not hasattr(mod, 'receiver_delete_one_locked'):
        raise RuntimeError('Installed manager lacks receiver transaction')
    return mod


def send_receive(snapshot, target, parent=None):
    command = ['btrfs', 'send']
    if parent:
        command += ['-p', str(parent)]
    command += [str(snapshot)]
    sender = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        receiver = subprocess.run(['btrfs', 'receive', str(target)], stdin=sender.stdout,
                                  capture_output=True)
    finally:
        sender.stdout.close()
    stderr = sender.communicate()[1]
    if sender.returncode or receiver.returncode:
        raise RuntimeError('Btrfs transfer failed: ' + stderr.decode(errors='replace')[-300:] +
                           receiver.stderr.decode(errors='replace')[-300:])


def execute():
    if os.geteuid() != 0:
        raise PermissionError('root required')
    manager = manager_module()
    ns = ROOT / (PREFIX + uuid.uuid4().hex)
    if ns.exists() or ns.is_symlink():
        raise RuntimeError('Namespace collision')
    run('btrfs', 'subvolume', 'create', str(ns))
    print('FIXTURE: ' + str(ns), flush=True)
    source = ns/'source'
    origin = ns/'origin'
    received = ns/'received'
    state = ns/'state'
    try:
        for path in (origin, received, state):
            path.mkdir(mode=0o700)
        run('btrfs', 'subvolume', 'create', str(source))
        previous = None
        uuids = {}
        for i, stamp in enumerate(STAMPS):
            (source/'payload.txt').write_text(f'0040-isolated-{i}\n')
            out = origin/stamp
            run('btrfs', 'subvolume', 'snapshot', '-r', str(source), str(out))
            send_receive(out, received, previous)
            source_uuid = identity(out, 'UUID')
            if identity(received/stamp, 'Received UUID') != source_uuid:
                raise RuntimeError('Received UUID mismatch')
            uuids[stamp] = source_uuid
            if (received/stamp/'payload.txt').read_text() != f'0040-isolated-{i}\n':
                raise RuntimeError('Received payload mismatch')
            data = {'schema':1, 'snapshot':stamp, 'source_uuid':source_uuid,
                    'received_uuid':source_uuid, 'destination':str(received/stamp),
                    'read_only_verified':True}
            (state/(stamp+'.json')).write_text(json.dumps(data)+'\n')
            (state/(stamp+'.json')).chmod(0o600)
            previous = out
        holdfile = ns/'holds.json'
        holdfile.write_text(json.dumps({'schema':1, 'holds':{PARENT:{'reason':'0040 disposable protection',
                                    'source_uuids':{'mars':uuids[PARENT]}}}})+'\n')
        holdfile.chmod(0o600)
        (ns/'manager.lock').touch(mode=0o600)
        (state/'writer.lock').touch(mode=0o600)
        pinfile = ns/'source-pin.json'
        pinfile.write_text(json.dumps({'stamp':PARENT,'uuid':uuids[PARENT]})+'\n')
        pinfile.chmod(0o600)
        config = manager.Config(snapshot_root=ns,lock_path=ns/'manager.lock',
            writer_lock_path=state/'writer.lock',
            sources=(manager.SnapshotSource('mars',None,received),),
            retention=manager.RetentionPolicy(0,0,0,0,0,0),
            verification=manager.VerificationPolicy(False,'','','',None),
            checkpoint_holds_file=holdfile,checkpoint_holds_required=True,
            mode='receiver',receiver_state_dir=state,receiver_prune_enabled=False)
        challenged=[]
        def verify_source_pin():
            record=json.loads(pinfile.read_text())
            if record != {'stamp':PARENT,'uuid':uuids[PARENT]}:
                raise RuntimeError('Disposable source pin changed')
            challenged.append(True)
        def delete_subvolume(path):
            if path != received/CANDIDATE or not path.is_relative_to(ns) or path.is_symlink():
                raise RuntimeError('Deletion target outside approved disposable candidate')
            if not (state/'.receiver-prune-pending.json').is_file():
                raise RuntimeError('Manager journal missing before deletion')
            run('btrfs','subvolume','delete',str(path))
        # Match the production manager-before-writer lock acquisition order.
        with ExitStack() as stack:
            for lockfile in (ns/'manager.lock',state/'writer.lock'):
                handle=stack.enter_context(lockfile.open('r+'))
                fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
            entries = manager.receiver_inventory(config)
            if len(entries)!=3:
                raise RuntimeError('Receiver inventory not exactly three verified snapshots')
            if CANDIDATE in manager.retention_keep_set(entries,config.retention,datetime.now(timezone.utc)):
                raise RuntimeError('Candidate unexpectedly retained')
            if manager.receiver_verified_checkpoint_holds(config,entries)!={PARENT}:
                raise RuntimeError('Protected parent hold invalid')
            manager.receiver_delete_one_locked(config,CANDIDATE,protected_stamp=PARENT,
                expected_parent_uuid=uuids[PARENT],verify_source_pin=verify_source_pin,
                delete_subvolume=delete_subvolume)
            if not challenged or (received/CANDIDATE).exists() or (state/(CANDIDATE+'.json')).exists():
                raise RuntimeError('Candidate/receipt not fully deleted')
            if manager.receiver_recovery_plan(config)['state']!='CLEAN':
                raise RuntimeError('Manager recovery journal not clean')
            for stamp in (PARENT,NEWEST):
                if not (received/stamp).is_dir() or not (state/(stamp+'.json')).is_file():
                    raise RuntimeError('Retained receiver snapshot missing')
        print('PASS: real manager retention/holds/receipt verification and journal-backed disposable Btrfs deletion')
        print('PASS: candidate and receipt absent; parent/newest retained; journal CLEAN')
        # Cleanup only explicit files and exact disposable subvolumes.
        for stamp in reversed((PARENT,NEWEST)):
            run('btrfs','subvolume','delete',str(received/stamp))
        for stamp in reversed(STAMPS):
            run('btrfs','subvolume','delete',str(origin/stamp))
        run('btrfs','subvolume','delete',str(source))
        for stamp in STAMPS[1:]:
            (state/(stamp+'.json')).unlink()
        for p in (state/'writer.lock',ns/'manager.lock',ns/'holds.json',ns/'source-pin.json'):
            p.unlink()
        state.rmdir(); received.rmdir(); origin.rmdir()
        run('btrfs','subvolume','delete',str(ns))
        if ns.exists():
            raise RuntimeError('Disposable namespace cleanup incomplete')
        print('PASS: exact disposable namespace absent')
    except Exception:
        print('FAIL: preserve entire fixture for inspection: '+str(ns),file=sys.stderr)
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan',action='store_true')
    mode.add_argument('--execute',action='store_true')
    parser.add_argument('--accept-disposable-delete',default='')
    args=parser.parse_args()
    preflight()
    if args.plan:
        if args.accept_disposable_delete:
            parser.error('No delete acknowledgement permitted in plan mode')
        print('PASS: read-only Btrfs and installed manager preflight')
        print('PLAN: fresh isolated namespace; 3 real Btrfs receives and receipts; real manager inventory, retention, hold and journal deletion; exact cleanup')
        print('LIMIT: no live authenticated mars-to-backup source-held approval transaction')
        return
    if args.accept_disposable_delete!=ACK:
        parser.error('Expected --accept-disposable-delete '+ACK)
    execute()

if __name__=='__main__':
    try:
        main()
    except (RuntimeError,OSError,PermissionError,subprocess.SubprocessError) as exc:
        print('FAIL: '+str(exc),file=sys.stderr)
        sys.exit(1)
