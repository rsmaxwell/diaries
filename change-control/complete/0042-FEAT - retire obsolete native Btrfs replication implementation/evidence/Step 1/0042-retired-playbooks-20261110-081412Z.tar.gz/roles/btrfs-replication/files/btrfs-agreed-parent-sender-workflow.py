#!/usr/bin/env python3
"""0040 Step 12.3: source-lock-owned transaction and committed-receipt recovery.

Internal integration for a prepared A/B pair, not an unattended scheduler entry.
Never replay an uncertain binary receive or finalisation. Never release A.
"""
from contextlib import ExitStack
from pathlib import Path

STATE = Path('/media/usb/@snapshots/.agreed-parent.json')
PUSH = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')

class WorkflowRefused(RuntimeError):
    pass


def _prepared(state, a, b):
    return (type(state) is dict and set(state) ==
            {'schema', 'established', 'pending', 'previous'} and
            type(state['schema']) is int and state['schema'] == 1 and
            state['established'] == a and state['pending'] == b and
            state['previous'] is None)


def _promoted(state, a, b):
    return (type(state) is dict and set(state) ==
            {'schema', 'established', 'pending', 'previous'} and
            type(state['schema']) is int and state['schema'] == 1 and
            state['established'] == b and state['pending'] is None and
            state['previous'] == a)


def run(parent, candidate, *, mode, observer, state_module, evidence,
        execution, receipt_reader, promotion_runtime, commands,
        state_path=STATE, push_lock=PUSH, manager_lock=MANAGER):
    """Execute prepared A->B or reconcile ONLY a committed receipt.

    All effects and SSH calls remain under both canonical source locks. The
    execute mode performs exactly one transfer; resume-committed never sends.
    A lost receipt acknowledgement must use resume-committed, not execute.
    Dependency overrides exist for offline tests, never as CLI parameters.
    """
    if mode not in ('execute', 'resume-committed') or (Path(state_path), Path(push_lock), Path(manager_lock)) != (STATE, PUSH, MANAGER):
        raise WorkflowRefused('invalid transaction mode or noncanonical paths')
    if not all(callable(x) for x in (execution, receipt_reader)):
        raise WorkflowRefused('missing trusted transport/receipt verification')
    state_module.snapshot(parent)
    state_module.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise WorkflowRefused('invalid A/B ordering')
    with ExitStack() as stack:
        observer.lock(stack, PUSH)
        observer.lock(stack, MANAGER)
        current = state_module.load(STATE, require_root=True)
        state_module.validate(current)
        if not (_prepared(current, parent, candidate) or
                (mode == 'resume-committed' and _promoted(current, parent, candidate))):
            raise WorkflowRefused('source is not prepared or previously promoted for A/B')
        for identity in (parent, candidate):
            if evidence.verify_source(identity) != dict(identity, verified=True):
                raise WorkflowRefused('source Btrfs snapshot identity mismatch')
        if mode == 'execute':
            outcome = execution(parent, candidate, pinned_parent_verified=lambda a, b: a == parent and b == candidate)
            if (type(outcome) is not dict or outcome.get('status') != 'receiver-committed-promotion-pending' or
                outcome.get('parent') != parent or outcome.get('candidate') != candidate or
                any(outcome.get(k) is not False for k in ('authorizes_prune','authorizes_release','authorizes_transition'))):
                raise WorkflowRefused('sender transfer did not establish a committed receiver receipt')
        # This is an independent fresh SSH readback, even when execute returned
        # a receipt verified during finalisation.
        if receipt_reader(parent, candidate, commands=commands) is not True:
            raise WorkflowRefused('receiver committed receipt not independently verified')
        if _promoted(current, parent, candidate):
            peer = promotion_runtime.receiver_readback(parent, candidate, commands=commands)
            if not _promoted(peer, parent, candidate):
                raise WorkflowRefused('source promoted but receiver readback is uncertain')
            return {'status': 'both-promoted-previous-pinned', 'authorizes_prune': False,
                    'authorizes_release': False, 'source_state': current, 'receiver_state': peer}
        # Receiver first; recover from lost receiver promotion acknowledgement by
        # explicit resume-committed, requiring a receipt and independent readback.
        promotion_runtime.receiver_promote(parent, candidate, commands=commands)
        peer = promotion_runtime.receiver_readback(parent, candidate, commands=commands)
        if not _promoted(peer, parent, candidate):
            raise WorkflowRefused('receiver B durable readback refused')
        local = promotion_runtime.promote_source_locked(
            parent, candidate, state_module=state_module, state_path=STATE,
            verify_source=evidence.verify_source,
            receiver_readback_verified=lambda a, b: promotion_runtime.receiver_readback(a, b, commands=commands))
        if not _promoted(local, parent, candidate):
            raise WorkflowRefused('source durable promotion refused')
        return {'status': 'both-promoted-previous-pinned', 'authorizes_prune': False,
                'authorizes_release': False, 'source_state': local, 'receiver_state': peer}
