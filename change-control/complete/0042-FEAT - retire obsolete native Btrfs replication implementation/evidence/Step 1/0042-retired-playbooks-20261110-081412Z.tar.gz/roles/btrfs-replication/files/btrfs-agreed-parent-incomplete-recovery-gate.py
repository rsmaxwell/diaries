#!/usr/bin/env python3
"""0040 Step 12.3: pure, fail-closed evidence gate for partial receive recovery.

This is NOT a cleanup command. A caller must hold the canonical receiver
manager/writer locks, independently prove the stream process has terminated,
and use transaction-owned destination evidence before considering cleanup.
No snapshot deletion or journal mutation is authorized by this module.
"""
import re

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')

class RecoveryRefused(RuntimeError):
    pass


def _identity(value):
    if (type(value) is not dict or set(value) != {'timestamp', 'uuid'} or
        type(value['timestamp']) is not str or not STAMP.fullmatch(value['timestamp']) or
        type(value['uuid']) is not str or not UUID.fullmatch(value['uuid'])):
        raise RecoveryRefused('invalid snapshot identity')
    return value


def assess(*, parent, candidate, source_state, receiver_state, journal,
           receipt_state, destination_state, locks_held, stream_terminated,
           destination_owned):
    """Assess one candidate, without making cleanup or retransmit permissible.

    Independent trusted observers must supply explicit booleans for canonical
    receiver locks, stream-process fencing, and destination ownership. A false
    or unknown proof must refuse. `destination_state` is one of absent,
    incomplete or readonly-matching. `receipt_state` is absent or committed.
    """
    a, b = _identity(parent), _identity(candidate)
    if a['timestamp'] >= b['timestamp']:
        raise RecoveryRefused('non-increasing candidate')
    prepared = {'schema': 1, 'established': a, 'pending': b, 'previous': None}
    if source_state != prepared or receiver_state != prepared:
        raise RecoveryRefused('source and receiver not identically prepared')
    if (type(journal) is not dict or set(journal) !=
            {'schema', 'status', 'parent', 'candidate', 'nonce'} or
            journal['schema'] != 1 or journal['status'] != 'receiving' or
            journal['parent'] != a or journal['candidate'] != b or
            type(journal['nonce']) is not str or
            re.fullmatch('[0-9a-f]{64}', journal['nonce']) is None):
        raise RecoveryRefused('missing, inconsistent or invalid provisional journal')
    if locks_held is not True or stream_terminated is not True:
        raise RecoveryRefused('canonical locks and completed stream fencing required')
    if receipt_state != 'absent':
        raise RecoveryRefused('committed or uncertain receipt blocks recovery cleanup')
    if destination_state not in ('absent', 'incomplete'):
        raise RecoveryRefused('matching readonly or ambiguous destination must be preserved')
    if destination_state == 'incomplete' and destination_owned is not True:
        raise RecoveryRefused('incomplete destination lacks independent transaction ownership')
    # Even a verified partial destination needs a separate, audited privileged
    # reconciler to act. This gate cannot authorize deletion or retransmission.
    return {'status': 'fenced-incomplete-receive-evidence',
            'candidate': b, 'destination_state': destination_state,
            'cleanup_authorized': False, 'retransmit_authorized': False,
            'release_authorized': False, 'prune_authorized': False}
