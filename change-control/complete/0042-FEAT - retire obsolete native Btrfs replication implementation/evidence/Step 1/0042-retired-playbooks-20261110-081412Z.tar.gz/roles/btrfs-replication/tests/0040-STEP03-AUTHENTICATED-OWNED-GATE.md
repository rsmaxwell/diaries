# 0040 Step 3 — Authenticated owned two-challenge gate

Uses current `btrfs-owned-session.py` on mango; streams a single-purpose composite
Python fixture to unprivileged mars. mars connects to backup using fixed SSH
identity and port 39263; backup runs a literal echo-only Python command.

The fixture holds a disposable lock and pin across two distinct challenges on
one SSH session, then a separate deliberately interrupted SSH exchange.
The accepted owned-process helper must terminate and reap the local process.
The test does **not** prove remote PID reaping, production source pin continuity,
root approval reservation, Btrfs deletion, or journal recovery.

Invoke on mango (non-destructive):

```bash
cd /home/richard/playbooks || exit 1
bash roles/btrfs-replication/tests/run-authenticated-owned-two-challenge.sh
```

No sudoers or production configuration change is made. Do not deploy these
scripts to the receiver. The actual isolated deletion transaction remains the
next safety gate.
