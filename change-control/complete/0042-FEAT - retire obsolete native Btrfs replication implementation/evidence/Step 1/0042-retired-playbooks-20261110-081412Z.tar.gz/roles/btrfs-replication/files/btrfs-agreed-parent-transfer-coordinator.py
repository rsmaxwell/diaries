#!/usr/bin/python3
"""0040 Step 12.3 Integration 04C: fail-closed transfer transaction core.

Not installed or callable from CLI. Production adapters must independently prove
source push lock ownership, fresh locked source/receiver prepared state, exact
receiver plan and post-transfer receipt/Btrfs evidence. Never promote or release.
An uncertain execution result MUST be reconciled; never retry automatically.
"""

class TransferRefused(RuntimeError):
    pass


def transact(*, timestamp, read_prepared, exact_commands, receiver_plan,
             execute_once, attest_receiver, transfer_enabled=False):
    """Run one transfer only with separately installed, trusted adapters.

    read_prepared must re-observe under a held source push lock and return the
    vetted 04A result. The 04A observation alone conveys NO mutation authority.
    attest_receiver must independently prove a safe B receipt plus readonly
    received UUID while receiver locks are held, and must not mutate state.
    """
    if type(timestamp) is not str or not timestamp:
        raise TransferRefused('missing fixed candidate')
    if not all(callable(fn) for fn in (read_prepared, exact_commands,
                                      receiver_plan, execute_once, attest_receiver)):
        raise TransferRefused('trusted adapters required')
    if transfer_enabled is not True:
        raise TransferRefused('transfer adapter not enabled; production execution prohibited')
    reviewed = read_prepared(timestamp)
    if (type(reviewed) is not dict or reviewed.get('status') != 'prepared-transfer-review'
            or reviewed.get('state_changed') is not False
            or reviewed.get('transfer_executed') is not False
            or reviewed.get('release_executed') is not False
            or any(reviewed.get(k) is not False for k in (
                'authorizes_transfer', 'authorizes_promote',
                'authorizes_prune', 'authorizes_release'))):
        raise TransferRefused('fresh prepared-state evidence missing or unsafe')
    source, receiver = reviewed.get('source'), reviewed.get('receiver')
    parent, candidate = reviewed.get('parent'), reviewed.get('candidate')
    if (type(source) is not dict or source != receiver or
            source.get('established') != parent or source.get('pending') != candidate or
            source.get('previous') is not None or not isinstance(candidate, dict) or
            candidate.get('timestamp') != timestamp):
        raise TransferRefused('agreed-parent transaction mismatch')
    commands = exact_commands(parent, candidate)
    if (type(commands) is not dict or commands.get('parent') != parent or
            commands.get('candidate') != candidate or
            any(commands.get(k) is not False for k in (
                'authorizes_transfer', 'authorizes_prune', 'authorizes_release'))):
        raise TransferRefused('unsafe exact transport contract')
    # Receiver's existing validation rejects an already existing destination or
    # receipt. A stale/partial receive is NEVER overwritten.
    proposed = receiver_plan(commands)
    expected = dict(snapshot=timestamp, source_uuid=candidate['uuid'],
                    parent=parent['timestamp'], parent_uuid=parent['uuid'],
                    action='incremental')
    if type(proposed) is not dict or proposed != expected:
        raise TransferRefused('receiver plan disagrees with A/B contract')
    try:
        outcome = execute_once(commands)
    except Exception as exc:
        raise TransferRefused('uncertain transfer outcome; inspect receiver, NEVER retry') from exc
    if type(outcome) is not dict or outcome != {'source_send_exit': 0, 'receiver_receive_exit': 0}:
        raise TransferRefused('unconfirmed transfer; inspect receiver, NEVER retry')
    try:
        evidence = attest_receiver(parent, candidate)
    except Exception as exc:
        raise TransferRefused('receiver attestation unavailable; inspect, NEVER retry') from exc
    if (type(evidence) is not dict or evidence.get('receipt_valid') is not True
            or evidence.get('readonly_received_uuid_valid') is not True
            or evidence.get('parent') != parent or evidence.get('candidate') != candidate
            or evidence.get('state') != receiver):
        raise TransferRefused('receiver B not fully attested; inspect, NEVER retry')
    return {'schema': 1, 'status': 'transferred-pending-unpromoted',
            'parent': parent, 'candidate': candidate,
            'source': source, 'receiver': receiver,
            'transfer_executed': True, 'release_executed': False,
            'state_changed': False, 'authorizes_promote': False,
            'authorizes_prune': False, 'authorizes_release': False}
