#!/usr/bin/env python3
"""0040-FEAT: dormant fail-closed parent selection from durable agreed state.

No SSH, filesystem writes or Btrfs commands. Must be called with a trusted
locked local state and independently validated receiver observation/receipts.
Not yet wired into the live sender, where legacy selection remains in use.
"""
import re

STAMP = re.compile(r"^[0-9]{8}-[0-9]{6}Z$")
UUID = re.compile(r"^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$")

class ParentSelectionError(RuntimeError):
    pass

def require(ok, message):
    if not ok:
        raise ParentSelectionError(message)

def identity(item):
    require(type(item) is dict and set(item)=={'timestamp','uuid'}, 'invalid snapshot identity')
    require(type(item['timestamp']) is str and STAMP.fullmatch(item['timestamp']) is not None, 'invalid timestamp')
    require(type(item['uuid']) is str and UUID.fullmatch(item['uuid']) is not None, 'invalid UUID')
    return dict(item)

def validated_state(state):
    require(type(state) is dict and set(state)=={'schema','established','pending','previous'}, 'invalid state fields')
    require(type(state['schema']) is int and state['schema']==1, 'invalid schema')
    require(state['established'] is not None, 'missing established parent')
    items=[identity(state[key]) for key in ('established','pending','previous') if state[key] is not None]
    require(len(set(x['timestamp'] for x in items))==len(items), 'duplicate timestamp')
    require(state['pending'] is None or state['previous'] is None, 'overlapping transitions')
    return state

def select(*, source_state, receiver_state, target, source_parent, receiver_receipts):
    """Select ONLY established A; never fall back to newest-common or full send.

    source_parent is a freshly verified readonly local Btrfs source identity.
    receiver_receipts is a list from an independently verified receiver RPC;
    accepted receipt items use snapshot and source_uuid keys.
    Caller must hold source push lock and independently authenticate receiver.
    """
    validated_state(source_state); validated_state(receiver_state)
    identity(target)
    require(source_state == receiver_state, 'source/receiver durable state differs')
    require(source_state['pending'] is None and source_state['previous'] is None, 'unfinished transition: recovery required')
    parent=identity(source_state['established'])
    require(parent['timestamp'] < target['timestamp'], 'candidate must follow established parent')
    require(identity(source_parent)==parent, 'source Btrfs parent identity mismatch')
    require(type(receiver_receipts) is list, 'invalid receiver receipts')
    matches=0
    for entry in receiver_receipts:
        require(type(entry) is dict and type(entry.get('snapshot')) is str and type(entry.get('source_uuid')) is str, 'malformed receipt')
        if entry['snapshot']==parent['timestamp']:
            require(entry['source_uuid']==parent['uuid'], 'conflicting established parent receipt')
            matches+=1
    require(matches==1, 'exactly one established parent receipt required')
    return {'parent':parent['timestamp'],'parent_uuid':parent['uuid'], 'mode':'incremental', 'authorizes_transfer':False,'authorizes_release':False}
