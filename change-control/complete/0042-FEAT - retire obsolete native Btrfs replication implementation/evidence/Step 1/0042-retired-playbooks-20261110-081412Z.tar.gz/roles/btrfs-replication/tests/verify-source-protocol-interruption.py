#!/usr/bin/env python3
"""0040 Step 3 disposable sender protocol interruption regression.

Runs only local Python subprocess fixtures. Never invokes SSH, sudo, Btrfs,
receiver deletion, or production state. Checks a receiver disappearing after a
valid source pin challenge and a receiver stalling after a challenge.
"""
import fcntl
import importlib.util
import json
from pathlib import Path
import sys
import tempfile

SOURCE = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-native-push.py'
spec = importlib.util.spec_from_file_location('step3_native_sender_interrupt', SOURCE)
sender = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sender)
STAMP = '20261024-030038Z'
UUID = '22e0ca45-0f49-c745-85b0-af6b6cfb915c'
CANDIDATE = '20261012-100003Z'

# The child models the *protocol* only. It does not call a receiver function.
# It writes one correct nonce challenge, reads the response, then either exits
# without a completion record or hangs so sender watchdog must kill the group.
CHILD = r'''
import json, sys, time
mode, stamp, uid, candidate = sys.argv[1:]
print(json.dumps({'kind':'transaction-pin-challenge', 'nonce':'ab'*32,
                  'snapshot':stamp, 'source_uuid':uid, 'candidate':candidate}), flush=True)
line = sys.stdin.readline()
if not line:
    sys.exit(4)
response = json.loads(line)
if response.get('nonce') != 'ab'*32 or response.get('candidate') != candidate:
    sys.exit(5)
if mode == 'disconnect':
    sys.exit(0)
time.sleep(30)
'''

with tempfile.TemporaryDirectory(prefix='0040-protocol-interrupt-') as td:
    folder = Path(td)
    lock = folder / 'source.lock'
    lock.touch(mode=0o600)
    pin = folder / 'durable-pin.json'
    pinned = {'snapshot': STAMP, 'source_uuid': UUID, 'prune_protected': True}
    pin.write_text(json.dumps(pinned))
    for mode in ('disconnect', 'stall'):
        calls = []
        def protect(role, stamp):
            assert role == 'protect-prune-source' and stamp == STAMP
            calls.append(role)
            assert json.loads(pin.read_text()) == pinned
            return {'source_uuid': UUID}
        command = [sys.executable, '-c', CHILD, mode, STAMP, UUID, CANDIDATE]
        try:
            sender.run_private_transaction_process(
                command, STAMP, UUID, CANDIDATE,
                source_lock=lock, protect_pin=protect,
                transaction_timeout=3, abort_timeout=0.2)
        except (RuntimeError, OSError, ValueError) as error:
            message = str(error).lower()
            assert ('missing transaction challenge' in message or
                    'deadline exceeded' in message), message
        else:
            raise AssertionError('Receiver interruption was incorrectly accepted')
        assert calls == ['protect-prune-source'], (mode, calls)
        assert json.loads(pin.read_text()) == pinned, mode
        with lock.open('r+') as f:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(f, fcntl.LOCK_UN)
        print(f'PASS: {mode} after challenged pin; no success, pin preserved, lock released after reap')
print('PASS: protocol interruption fixtures; no SSH, sudo, Btrfs or deletion')
