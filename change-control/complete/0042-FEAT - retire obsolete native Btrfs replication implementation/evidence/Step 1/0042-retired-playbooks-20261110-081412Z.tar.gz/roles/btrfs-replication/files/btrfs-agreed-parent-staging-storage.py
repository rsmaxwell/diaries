#!/usr/bin/env python3
"""0040 Step 12.3 nonce-private same-parent Btrfs staging and no-overwrite publish.

Internal root-only helpers. Publication requires canonical receiver locks,
independent Btrfs inspection, and authenticated sender completion. No deletion.
"""
import ctypes
import os
from pathlib import Path
import re
import stat

ROOT = Path('/@data/mars-received')
FINAL = ROOT / '@data'
STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
NONCE = re.compile(r'[0-9a-f]{64}\Z')

class Refused(RuntimeError):
    pass

def require(ok, msg):
    if not ok:
        raise Refused(msg)

def _dir(path):
    data = path.lstat()
    require(stat.S_ISDIR(data.st_mode) and not stat.S_ISLNK(data.st_mode),
            'unsafe receiver directory')
    return data

def _validate(stamp, nonce, locks_held):
    require(locks_held is True, 'both receiver locks required')
    require(type(stamp) is str and STAMP.fullmatch(stamp), 'invalid snapshot stamp')
    require(type(nonce) is str and NONCE.fullmatch(nonce), 'invalid transaction nonce')
    root = _dir(ROOT)
    final = _dir(FINAL)
    require(root.st_dev == final.st_dev and final.st_uid == 0,
            'receiver destination must be root-owned on the pinned filesystem')
    return FINAL, FINAL / ('.receive-' + nonce), FINAL / stamp

def reserve(stamp, nonce, *, locks_held=False):
    """Bind journal to existing final parent; btrfs receive creates private name.

    No private directory/subvolume exists before streaming: deliberately
    refuse a reused nonce or published destination. Nothing is deleted.
    """
    parent, staged, published = _validate(stamp, nonce, locks_held)
    require(not (staged.exists() or staged.is_symlink() or
                 published.exists() or published.is_symlink()),
            'staging nonce or published candidate already present')
    info = _dir(parent)
    return {'staging_parent': str(parent), 'staged_subvolume': str(staged),
            'published_subvolume': str(published), 'directory_dev': info.st_dev,
            'directory_ino': info.st_ino}

def verify_reserved(stamp, nonce, *, directory_dev, directory_ino, locks_held=False):
    parent, stage, final = _validate(stamp, nonce, locks_held)
    require(type(directory_dev) is int and type(directory_ino) is int and
            directory_dev >= 0 and directory_ino > 0,
            'invalid staging journal directory identity')
    info = _dir(parent)
    require((info.st_dev, info.st_ino) == (directory_dev, directory_ino),
            'staging parent identity changed')
    require(not stage.is_symlink() and not final.is_symlink(),
            'unsafe staged or published symlink')
    return parent, stage, final

def _rename(parent, source, destination, identity):
    libc = ctypes.CDLL(None, use_errno=True)
    renameat2 = getattr(libc, 'renameat2', None)
    require(renameat2 is not None, 'renameat2 unavailable')
    renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p,
                          ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    renameat2.restype = ctypes.c_int
    descriptor = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        fd_info = os.fstat(descriptor)
        require((fd_info.st_dev, fd_info.st_ino) == identity,
                'staging parent changed at publication')
        if renameat2(descriptor, os.fsencode(source), descriptor,
                     os.fsencode(destination), 1) != 0:
            code = ctypes.get_errno()
            raise Refused(f'atomic no-replace publication refused: {os.strerror(code)}')
        # After rename, fsync failure leaves a recoverable publication incident.
        os.fsync(descriptor)
    finally:
        os.close(descriptor)

def publish(stamp, nonce, *, directory_dev, directory_ino,
            locks_held=False, verified_receive=False, sender_authenticated=False,
            btrfs_identity_verified=False):
    parent, stage, final = verify_reserved(
        stamp, nonce, directory_dev=directory_dev, directory_ino=directory_ino,
        locks_held=locks_held)
    require(verified_receive is True and sender_authenticated is True and
            btrfs_identity_verified is True,
            'missing authenticated and receiver-local verification')
    require(stage.is_dir() and not stage.is_symlink(), 'staged subvolume absent')
    require(not (final.exists() or final.is_symlink()), 'published snapshot exists')
    _rename(parent, stage.name, final.name, (directory_dev, directory_ino))
    return {'published_subvolume': str(final), 'staged_subvolume': str(stage),
            'status': 'published-awaiting-receipt', 'receipt_committed': False,
            'cleanup_authorized': False}

def published_absent(stamp, *, locks_held=False):
    require(locks_held is True, 'both receiver locks required')
    require(type(stamp) is str and STAMP.fullmatch(stamp), 'invalid snapshot')
    _dir(ROOT); _dir(FINAL)
    final = FINAL / stamp
    return not (final.exists() or final.is_symlink())
