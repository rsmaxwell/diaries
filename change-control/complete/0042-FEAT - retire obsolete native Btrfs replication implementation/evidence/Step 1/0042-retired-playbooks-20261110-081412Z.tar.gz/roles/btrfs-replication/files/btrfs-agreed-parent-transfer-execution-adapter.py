#!/usr/bin/python3
"""0040 Step 12.3 Integration 04F: dormant one-shot incremental transport adapter.

Import only. It must be called under the sender's push lock AFTER a fresh,
locked prepared-state check by a separately reviewed coordinator. Never retry.
This module cannot promote, prune, release, or delete either endpoint.
"""
import subprocess


class TransferExecutionRefused(RuntimeError):
    pass


def exact_argv(commands, parent, candidate):
    """Validate the complete trusted 04B command contract, rejecting substitutions."""
    if type(commands) is not dict or set(commands) != {
            'parent', 'candidate', 'receiver_plan', 'sender', 'receiver_accept',
            'authorizes_transfer', 'authorizes_prune', 'authorizes_release'}:
        raise TransferExecutionRefused('unexpected transport contract shape')
    if commands['parent'] != parent or commands['candidate'] != candidate:
        raise TransferExecutionRefused('parent/candidate mismatch')
    if any(commands[key] is not False for key in (
            'authorizes_transfer', 'authorizes_prune', 'authorizes_release')):
        raise TransferExecutionRefused('unsafe authority')
    if type(parent) is not dict or type(candidate) is not dict:
        raise TransferExecutionRefused('missing exact A/B identities')
    a, b = parent.get('timestamp'), candidate.get('timestamp')
    au, bu = parent.get('uuid'), candidate.get('uuid')
    if not (type(a) is str and type(b) is str and a < b and
            type(au) is str and type(bu) is str):
        raise TransferExecutionRefused('invalid A/B identities')
    common = ('--snapshot', b, '--source-uuid', bu,
              '--parent', a, '--parent-uuid', au)
    sender = ('sudo', '-n', '/usr/local/libexec/btrfs-native-endpoint',
              '--role', 'incremental-source', '--snapshot', b, '--parent', a)
    ssh = ('ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
           '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1')
    receiver = (*ssh, '/usr/local/bin/btrfs-native-push-receiver', *common, '--accept')
    planner = ('/usr/local/bin/btrfs-native-push-receiver', *common)
    if (commands['sender'] != sender or commands['receiver_accept'] != receiver
            or commands['receiver_plan'] != planner):
        raise TransferExecutionRefused('unexpected sender or receiver executable/arguments')
    return sender, receiver


def transfer_once(commands, parent, candidate, *, push_lock_held=False,
                  execution_enabled=False, popen=subprocess.Popen):
    """One binary-stream send/receive, without shell, retries or post-transfer actions.

    The caller MUST verify source/receiver prepared states while holding the
    push lock and must arrange separate receiver preflight and attestation.
    A failure is ambiguous: inspect receiver snapshot/receipt before ANY retry.
    """
    if push_lock_held is not True or execution_enabled is not True:
        raise TransferExecutionRefused('transfer not explicitly enabled under source push lock')
    sender_argv, receiver_argv = exact_argv(commands, parent, candidate)
    source = None
    receiver = None
    try:
        source = popen(list(sender_argv), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        # Stream binary stdout; no decoding, buffering or shell pipeline.
        receiver = popen(list(receiver_argv), stdin=source.stdout,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        source.stdout.close()  # permit SIGPIPE if receiver exits early
        receiver_rc = receiver.wait()
        source_rc = source.wait()
    except Exception as exc:
        # Never abandon either process after a failed launch/wait.
        for process in (receiver, source):
            if process is not None and process.poll() is None:
                process.kill()
        for process in (receiver, source):
            if process is not None:
                process.wait()
        raise TransferExecutionRefused('uncertain transfer: inspect receiver; never retry') from exc
    if source_rc != 0 or receiver_rc != 0:
        raise TransferExecutionRefused('nonzero send/receive: inspect receiver; never retry')
    return {'source_send_exit': 0, 'receiver_receive_exit': 0}
