#!/usr/bin/python3
"""0040 Step 12.3 Integration 04H: read-only authenticated absence transport.

The existing SSH identity is richard on mars, not root. No transfer execution.
"""
import json
import subprocess

SSH = ('/usr/sbin/runuser', '-u', 'richard', '--', 'ssh',
       '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=15', '-p', '39263', 'richard@10.254.22.1')
REMOTE = '/usr/local/libexec/btrfs-agreed-parent-transfer-absence.py'


def command(parent, candidate, *, identity):
    identity(parent); identity(candidate)
    if candidate['timestamp'] <= parent['timestamp']:
        raise RuntimeError('invalid A/B order')
    return [*SSH, 'sudo', '-n', REMOTE,
            '--parent', parent['timestamp'], '--parent-uuid', parent['uuid'],
            '--candidate', candidate['timestamp'], '--candidate-uuid', candidate['uuid']]


def validate(result, parent, candidate):
    if (type(result) is not dict or set(result) != {
        'schema','status','host','parent','candidate','state','destination_absent',
        'receipt_absent','state_changed','authorizes_transfer','authorizes_promote',
        'authorizes_prune','authorizes_release'} or
        type(result['schema']) is not int or result['schema']!=1 or
        result['host']!='backup' or result['status']!='receiver-destination-absent' or
        result['parent']!=parent or result['candidate']!=candidate or
        result['destination_absent'] is not True or result['receipt_absent'] is not True or
        any(result[k] is not False for k in ('state_changed','authorizes_transfer',
            'authorizes_promote','authorizes_prune','authorizes_release'))):
        raise RuntimeError('invalid receiver absence response')
    state=result['state']
    if (type(state) is not dict or set(state)!={'schema','established','pending','previous'} or
        type(state['schema']) is not int or state['schema']!=1 or
        state['established']!=parent or state['pending']!=candidate or state['previous'] is not None):
        raise RuntimeError('receiver prepared state mismatch')
    return result


def observe(parent, candidate, *, source_lock_held=False, identity=None, run=subprocess.run):
    if source_lock_held is not True or not callable(identity):
        raise RuntimeError('source push lock and identity verifier required')
    argv=command(parent,candidate,identity=identity)
    try:
        reply=run(argv,text=True,capture_output=True,timeout=90,check=False)
    except (OSError,subprocess.TimeoutExpired) as exc:
        raise RuntimeError('uncertain receiver absence; do not transfer') from exc
    if type(reply.returncode) is not int or reply.returncode != 0:
        raise RuntimeError('receiver absence refused or SSH failed')
    if type(reply.stdout) is not str or not 0 < len(reply.stdout.encode('utf8')) <= 65536:
        raise RuntimeError('missing or oversized receiver reply')
    try: content=json.loads(reply.stdout)
    except (ValueError,TypeError) as exc: raise RuntimeError('malformed receiver reply') from exc
    return validate(content,parent,candidate)
