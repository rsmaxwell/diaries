# 0040 Step 3 — Owned gateway stream bridge

Status: source acceptance only. Not a privileged executor or production authorisation.

`run_owned_gateway_transaction` binds the only input/output streams supplied to a private gateway callback to one locally owned and reaped child. The caller cannot inject replacement streams. All exceptions propagate; a stalled or interrupted peer is terminated and reaped by the established owner.

## Review and acceptance

- On mango: `python3 roles/btrfs-replication/tests/verify-owned-gateway-bridge.py`
- Also run existing `verify-owned-disposable-session.py`, then `git diff --check`.
- No Ansible deployment or sudoers changes are part of this increment.

## Outstanding mandatory gates

A trusted SSH peer with authenticated endpoint identity, a source-owned lock and durable parent pin across the complete transaction, production-process trust boundary, isolated real manager deletion/receipt/journal acceptance, and safe recovery from uncertain outcomes are **not demonstrated**. Receiver pruning and deletion privilege must remain disabled until separately accepted. Never infer remote process reaping from local SSH process cleanup alone.
