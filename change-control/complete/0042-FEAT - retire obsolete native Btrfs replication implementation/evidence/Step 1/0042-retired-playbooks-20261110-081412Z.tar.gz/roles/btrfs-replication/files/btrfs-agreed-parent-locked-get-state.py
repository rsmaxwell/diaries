#!/usr/bin/python3
"""0040 3H.5f: dormant source-lock-owned, read-only receiver get-state.

No live sender integration; fixed read-only receiver endpoint only.
The public API has no caller-supplied 'lock held' Boolean.
"""
from contextlib import ExitStack
import fcntl
import importlib.util
import os
import argparse
import json
import sys
from pathlib import Path
import stat
import pwd

PUSH_LOCK = Path('/media/usb/@snapshots/.native-push.lock')
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
TRANSPORT = Path(__file__).with_name('btrfs-agreed-parent-get-state-transport.py')


def expected_owner(path):
    """The push lock is Ansible-owned by richard; manager lock by root."""
    if path == PUSH_LOCK:
        return pwd.getpwnam('richard').pw_uid
    if path == MANAGER_LOCK:
        return 0
    raise RuntimeError('unknown source lock path')


def validate_lock_metadata(info, owner):
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
            stat.S_IMODE(info.st_mode) != 0o600 or info.st_uid != owner):
        raise RuntimeError('unsafe source lock ownership or permissions')


def acquire(stack, path):
    """Acquire an existing Ansible-managed lock without replacing it."""
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise RuntimeError('missing/unsafe source lock')
    info = path.stat()
    owner = expected_owner(path)
    validate_lock_metadata(info, owner)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    handle = stack.enter_context(os.fdopen(fd, 'rb'))
    opened = os.fstat(handle.fileno())
    validate_lock_metadata(opened, owner)
    if (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino):
        raise RuntimeError('source lock changed during open')
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return handle


def get_state(transaction_id, *, acquire_lock=acquire, transport=None):
    """Hold source push then manager lock throughout one receiver read.

    Injection is for offline tests only. Caller may not claim lock ownership.
    Do not call inside btrfs-native-push.py while it already owns PUSH_LOCK.
    """
    if os.geteuid() != 0 and transport is None:
        raise RuntimeError('root required')
    if transport is None:
        spec = importlib.util.spec_from_file_location('agreed_parent_transport', TRANSPORT)
        transport = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(transport)
    with ExitStack() as stack:
        acquire_lock(stack, PUSH_LOCK)
        acquire_lock(stack, MANAGER_LOCK)
        result = transport.get_state(transaction_id, source_lock_held=True)
        if not isinstance(result, dict) or any(result.get(k) is not False for k in (
                'authorizes_prepare', 'authorizes_promote', 'authorizes_transfer',
                'authorizes_prune', 'authorizes_release')):
            raise RuntimeError('read-only transport claimed mutation authority')
        return result


def main():
    parser = argparse.ArgumentParser(description='Read-only locked receiver agreed-parent state')
    parser.add_argument('--transaction-id', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(get_state(args.transaction_id), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError) as exc:
        print('locked get-state refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
