#!/usr/bin/env python3
"""0040 Step 12.3: fixed, operator-invoked sender execution and receipt recovery.

This program requires an existing, independently prepared A/B agreement.
It NEVER prepares, reseeds, prunes, releases A or alters the production timer.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys

LIB = Path('/usr/local/libexec')
RUNUSER = ('/usr/sbin/runuser', '-u', 'richard', '--')
MODULES = {
    'observer': ('snapshots', 'source-observer'),
    'state': ('snapshots', 'state'),
    'evidence': ('snapshots', 'source-evidence'),
    'execution': ('replication', 'sender-execution'),
    'transaction': ('replication', 'sender-transaction'),
    'commands': ('replication', 'fixed-commands'),
    'transport': ('replication', 'stream-adapter'),
    'handoff': ('replication', 'sender-proof-handoff'),
    'proof': ('replication', 'session-proof'),
    'receipt': ('replication', 'receipt-readback'),
    'promotion': ('replication', 'sender-promotion-runtime'),
    'workflow': ('replication', 'sender-workflow'),
    'previous_ack': ('replication', 'sender-previous-ack'),
}
STATE = Path('/media/usb/@snapshots/.agreed-parent.json')

class OperatorRefused(RuntimeError):
    pass


def load_fixed(*, directory=LIB):
    if os.geteuid() != 0:
        raise OperatorRefused('root required')
    directory = Path(directory)
    info = directory.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise OperatorRefused('unsafe module directory')
    loaded = {}
    for key, (_, name) in MODULES.items():
        path = directory / ('btrfs-agreed-parent-' + name + '.py')
        info = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or
                info.st_nlink != 1 or info.st_mode & 0o022):
            raise OperatorRefused('unsafe installed module: ' + name)
        spec = importlib.util.spec_from_file_location('agreed_sender_' + key, path)
        if spec is None or spec.loader is None:
            raise OperatorRefused('unable to load ' + name)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        loaded[key] = module
    return loaded


class ExistingSSHIdentity:
    """Only allow the compiled-in peer, using richard's established host key."""
    def __init__(self, fixed):
        self._fixed = fixed
        expected = ('ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
                    '-o', 'ConnectTimeout=15', '-T', '-p', '39263', 'richard@10.254.22.1')
        if tuple(fixed.SSH) != expected:
            raise OperatorRefused('unexpected fixed SSH target')

    def _wrap(self, command):
        if tuple(command[:len(self._fixed.SSH)]) != tuple(self._fixed.SSH):
            raise OperatorRefused('SSH command escaped fixed endpoint')
        return [*RUNUSER, *command]

    def receive_commands(self, a, b):
        send, ssh = self._fixed.receive_commands(a, b)
        return send, self._wrap(ssh)

    def finalise_command(self, a, b):
        return self._wrap(self._fixed.finalise_command(a, b))

    def session_command(self, a, b):
        return self._wrap(self._fixed.session_command(a, b))

    def receipt_command(self, a, b):
        return self._wrap(self._fixed.receipt_command(a, b))

    def promote_command(self, a, b):
        return self._wrap(self._fixed.promote_command(a, b))

    def acknowledge_previous_command(self, a, b):
        return self._wrap(self._fixed.acknowledge_previous_command(a, b))

    def previous_readback_command(self, a, b):
        return self._wrap(self._fixed.previous_readback_command(a, b))

    def promoted_readback_command(self, a, b):
        return self._wrap(self._fixed.promoted_readback_command(a, b))


def run(mode, *, modules=None):
    m = load_fixed() if modules is None else modules
    state = m['state'].load(STATE, require_root=True)
    m['state'].validate(state)
    if mode == 'inspect':
        return {'status': 'local-source-state-only', 'state': state,
                'authorizes_transfer': False, 'authorizes_prune': False}
    if mode == 'acknowledge-previous':
        return m['previous_ack'].run(observer=m['observer'], state=m['state'],
            evidence=m['evidence'], receipt=m['receipt'].verify_receipt_over_ssh,
            promotion=m['promotion'], commands=ExistingSSHIdentity(m['commands']))
    parent, candidate = state['established'], state['pending']
    if mode == 'resume-committed' and candidate is None:
        parent, candidate = state['previous'], state['established']
    if not parent or not candidate:
        raise OperatorRefused('no prepared or recoverable A/B pair')
    commands = ExistingSSHIdentity(m['commands'])
    receipt = m['receipt'].verify_receipt_over_ssh
    if mode == 'execute':
        # Fail before sending any bytes if shared authenticated proof isn't available.
        m['handoff'].read_sender_key()
        def execute(a, b, *, pinned_parent_verified):
            return m['execution'].execute_provisional_then_receipt(
                a, b, transaction=m['transaction'], fixed_commands=commands,
                binary_transport=m['transport'], sender_handoff=m['handoff'],
                session_proof=m['proof'], read_sender_key=m['handoff'].read_sender_key,
                pinned_parent_verified=pinned_parent_verified,
                verify_final_receipt=lambda x, y: receipt(x, y, commands=commands))
    else:
        def execute(*args, **kwargs):
            raise OperatorRefused('resume must never transmit')
    return m['workflow'].run(parent, candidate, mode=mode,
                             observer=m['observer'], state_module=m['state'],
                             evidence=m['evidence'], execution=execute,
                             receipt_reader=receipt,
                             promotion_runtime=m['promotion'], commands=commands)



def complete_committed(*, invoke=None):
    """Finish only an already committed transfer; never initiate a send.

    Each underlying operation owns the canonical source locks and performs
    authenticated peer receipt/readback validation. On any uncertain outcome
    propagate the refusal; a later invocation can safely retry.
    """
    invoke = run if invoke is None else invoke
    stages = []
    first = invoke('resume-committed')
    if first.get('status') != 'both-promoted-previous-pinned' or first.get('authorizes_prune') is not False or first.get('authorizes_release') is not False:
        raise OperatorRefused('committed promotion did not establish both endpoints with previous pinned')
    if first.get('source_state') != first.get('receiver_state'):
        raise OperatorRefused('committed promotion state mismatch')
    promoted = first['source_state']
    if (promoted.get('pending') is not None or not promoted.get('previous') or
            not promoted.get('established')):
        raise OperatorRefused('committed promotion did not retain established and previous parent')
    stages.append('resume-committed')
    second = invoke('acknowledge-previous')
    if second.get('status') != 'both-previous-acknowledged' or second.get('authorizes_prune') is not False or second.get('authorizes_release') is not False:
        raise OperatorRefused('previous parent acknowledgement not independently verified')
    if second.get('source_state') != second.get('receiver_state'):
        raise OperatorRefused('acknowledged state mismatch')
    final = second['source_state']
    if (final.get('pending') is not None or final.get('previous') is not None or
            final.get('established') != promoted['established']):
        raise OperatorRefused('cycle not ready after acknowledgement')
    stages.append('acknowledge-previous')
    return {'status': 'committed-cycle-ready', 'stages': stages,
            'source_state': final, 'receiver_state': second['receiver_state'],
            'authorizes_prune': False, 'authorizes_release': False}


def complete_prepared(*, invoke=None):
    """Execute one prepared pair and acknowledge its previous parent.

    This is deliberately NOT a retry loop. On an uncertain receive or a lost
    acknowledgement, callers must inspect durable state and use the committed
    recovery path; never send the same candidate a second time blindly.
    """
    invoke = run if invoke is None else invoke
    first = invoke('execute')
    if (type(first) is not dict or first.get('status') != 'both-promoted-previous-pinned' or
            first.get('authorizes_prune') is not False or first.get('authorizes_release') is not False or
            first.get('source_state') != first.get('receiver_state')):
        raise OperatorRefused('prepared execution did not establish verified promotion')
    promoted = first['source_state']
    if (type(promoted) is not dict or promoted.get('pending') is not None or
            not promoted.get('previous') or not promoted.get('established')):
        raise OperatorRefused('prepared execution did not pin previous parent')
    second = invoke('acknowledge-previous')
    if (type(second) is not dict or second.get('status') != 'both-previous-acknowledged' or
            second.get('authorizes_prune') is not False or second.get('authorizes_release') is not False or
            second.get('source_state') != second.get('receiver_state')):
        raise OperatorRefused('previous-parent acknowledgement was not verified')
    final = second['source_state']
    if (type(final) is not dict or final.get('established') != promoted['established'] or
            final.get('previous') is not None or final.get('pending') is not None):
        raise OperatorRefused('prepared cycle did not end ready')
    return {'status': 'prepared-cycle-ready', 'stages': ['execute-prepared', 'acknowledge-previous'],
            'source_state': final, 'receiver_state': second['receiver_state'],
            'authorizes_prune': False, 'authorizes_release': False}

def main(argv=None):
    parser = argparse.ArgumentParser(description='0040 agreed-parent manual source transaction')
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--inspect', action='store_true')
    actions.add_argument('--execute-prepared', action='store_true')
    actions.add_argument('--resume-committed', action='store_true')
    actions.add_argument('--acknowledge-previous', action='store_true')
    actions.add_argument('--complete-committed', action='store_true')
    actions.add_argument('--complete-prepared', action='store_true')
    args = parser.parse_args(argv)
    mode = 'inspect' if args.inspect else ('execute' if args.execute_prepared else ('acknowledge-previous' if args.acknowledge_previous else 'resume-committed'))
    result = (complete_prepared() if args.complete_prepared else
              complete_committed() if args.complete_committed else run(mode))
    print(json.dumps(result, sort_keys=True))

if __name__ == '__main__':
    try:
        main()
    except (OperatorRefused, OSError, ValueError, RuntimeError) as exc:
        print('agreed-parent sender refused: ' + str(exc), file=sys.stderr)
        sys.exit(1)
