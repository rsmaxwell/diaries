#!/usr/bin/env python3
"""Non-destructive contract tests: internal gateway delegation, no Btrfs or SSH."""
import importlib.util
import io
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

source = Path(__file__).resolve().parents[1] / 'files' / 'btrfs-receiver-prune.py'
spec = importlib.util.spec_from_file_location('approved_gateway', source)
gateway = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gateway)

config = SimpleNamespace(mode='receiver', receiver_prune_enabled=False,
    receiver_state_dir=Path('/disposable-fixture/state'),
    writer_lock_path=Path('/disposable-fixture/state/writer.lock'),
    lock_path=Path('/disposable-fixture/manager.lock'))
called=[]
def adapter(stamp, uuid, candidate, **kwargs):
    called.append((stamp, uuid, candidate, kwargs))
    return {'approval_reservation': '/fixture/reserved', 'result': {},
            'production_authorized': False}
args=dict(receiver_module=None, manager=object(), receiver_config=config,
          incoming=io.StringIO(), outgoing=io.StringIO(), planner=lambda: None,
          delete_subvolume=lambda p: None, stamp='20261024-030000Z',
          uuid='00000000-0000-0000-0000-000000000001', candidate='20261023-030000Z',
          approval_path=Path('/fixture/approval'), consumed_dir=Path('/fixture/consumed'),
          approved_adapter=adapter)
# No privileged config on developer host: substitute the already-tested boundary
# checker, rather than faking root-owned files.
with mock.patch.object(gateway, 'verify_root_and_config', return_value={'mode':'receiver'}):
    result=gateway.run_internal_approved_transaction(**args)
    assert result['production_authorized'] is False and len(called)==1
    assert called[0][3]['incoming'] is args['incoming']
    assert called[0][3]['delete_subvolume'] is args['delete_subvolume']
    print('PASS: manager-first adapter receives original live streams and callbacks')
    called.clear()
    bad = SimpleNamespace(**vars(config)); bad.writer_lock_path = Path('/wrong/lock')
    try:
        gateway.run_internal_approved_transaction(**{**args,'receiver_config':bad})
    except RuntimeError as exc: assert 'lock' in str(exc)
    else: raise AssertionError('Accepted wrong writer lock')
    assert not called
    print('PASS: invalid lock topology rejected before adapter invocation')
    def broken(*a, **kw):
        raise OSError('interrupted fixture transport')
    try:
        gateway.run_internal_approved_transaction(**{**args,'approved_adapter':broken})
    except OSError as exc: assert 'interrupted' in str(exc)
    else: raise AssertionError('Transport failure swallowed')
    print('PASS: interruption error propagated without reporting success')
    try:
        gateway.run_internal_approved_transaction(**{**args,'approved_adapter':lambda *a,**k: {'production_authorized': True}})
    except RuntimeError as exc: assert 'authority' in str(exc)
    else: raise AssertionError('Accepted production-authorised result')
    print('PASS: production-authorised result rejected')

# The public CLI explicitly invokes the approved receiver transaction.
# The existing delegation, lock and exception regressions remain unchanged.
src=source.read_text()
main=src.split('def main(argv=None):',1)[1]
assert 'run_internal_approved_transaction(' not in main
assert 'run_unattended_receiver_transaction(' in main
assert 'run_receiver_prune_transaction(' not in main
assert "selection.add_argument('--transaction'" in main
print('PASS: explicit receiver transaction dispatch; delegation checks preserved')
