#!/usr/bin/python3
"""0040 Increment 3C: dormant read-only receiver observation endpoint core.

No CLI, SSH allowlist or Ansible installation. Caller must supply trusted fixed
paths and audited receipt/metadata reader. Locks are held through all reads.
Never use the observation as authority to mutate state or prune.
"""
from contextlib import ExitStack
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import stat


def _load(name):
    path = Path(__file__).with_name('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('agreed_0040_' + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

state = _load('state')
StateError = state.StateError


def _lock(stack, path):
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise StateError('missing or unsafe receiver lock')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_mode & 0o022:
        raise StateError('unsafe receiver lock permissions')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    handle = stack.enter_context(os.fdopen(fd, 'rb'))
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)


def observe(*, state_path, receipt_dir, snapshot_dir, manager_lock, writer_lock,
            inspect, source_fs, receiver_fs):
    """Return only JSON-compatible evidence, under both receiver locks.

    'inspect(stamp)' must use the existing pinned privileged read-only
    inspect-receiver endpoint, not a caller-controlled shell command.
    """
    paths = (state_path, receipt_dir, snapshot_dir, manager_lock, writer_lock)
    if any(not isinstance(p, Path) or not p.is_absolute() for p in paths):
        raise StateError('absolute fixed paths required')
    if manager_lock == writer_lock or writer_lock != receipt_dir / 'writer.lock':
        raise StateError('receiver lock configuration mismatch')
    if not callable(inspect) or not source_fs or not receiver_fs:
        raise StateError('missing receiver evidence provider')
    if receipt_dir.is_symlink() or snapshot_dir.is_symlink() or not receipt_dir.is_dir() or not snapshot_dir.is_dir():
        raise StateError('unsafe receiver directories')
    with ExitStack() as stack:
        _lock(stack, manager_lock)
        _lock(stack, writer_lock)
        journal = receipt_dir / '.receiver-prune-pending.json'
        if journal.exists() or journal.is_symlink():
            raise StateError('pending receiver deletion blocks observation')
        current = state.load(state_path)
        verified = []
        # Pending B is protected from pruning but may not yet have been received.
        # Receipt/Btrfs verification is mandatory for established and previous.
        required = {current['established']['timestamp']: current['established']['uuid']}
        if current['previous'] is not None:
            required[current['previous']['timestamp']] = current['previous']['uuid']
        for stamp, uuid in sorted(required.items()):
            receipt_path = receipt_dir / (stamp + '.json')
            if receipt_path.is_symlink() or not receipt_path.is_file():
                raise StateError('missing or unsafe receiver receipt')
            if receipt_path.stat().st_size > 65536:
                raise StateError('oversized receiver receipt')
            try:
                receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
                observed = inspect(stamp)
            except (OSError, ValueError, UnicodeError) as exc:
                raise StateError('unreadable receiver identity') from exc
            if not isinstance(receipt, dict) or not isinstance(observed, dict):
                raise StateError('invalid receiver evidence')
            destination = snapshot_dir / stamp
            if (destination.is_symlink() or not destination.is_dir() or
                    receipt.get('schema') != 1 or receipt.get('snapshot') != stamp or
                    receipt.get('source_uuid') != uuid or receipt.get('received_uuid') != uuid or
                    receipt.get('destination') != str(destination) or
                    receipt.get('source_filesystem_uuid') != source_fs or
                    receipt.get('receiver_filesystem_uuid') != receiver_fs or
                    receipt.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
                    receipt.get('read_only_verified') is not True or
                    type(receipt.get('source_send_exit')) is not int or receipt['source_send_exit'] != 0 or
                    type(receipt.get('receiver_receive_exit')) is not int or receipt['receiver_receive_exit'] != 0 or
                    observed.get('flags') != 'readonly' or observed.get('received_uuid') != uuid):
                raise StateError('receiver receipt / snapshot identity mismatch')
            verified.append({'timestamp': stamp, 'uuid': uuid})
        return {'schema': 1, 'host': 'backup', 'state': current,
                'verified': verified, 'authorizes_transition': False,
                'authorizes_prune': False}
