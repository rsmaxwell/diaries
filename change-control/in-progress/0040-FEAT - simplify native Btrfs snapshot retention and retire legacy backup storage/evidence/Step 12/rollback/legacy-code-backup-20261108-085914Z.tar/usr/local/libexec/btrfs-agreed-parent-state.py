#!/usr/bin/python3
"""0040-FEAT: dormant, durable agreed-parent state primitive.

Not wired to replication or pruning. Operators must not use this as proof
that the peer has persisted the same state; peer confirmation is a separate gate.
"""
from __future__ import annotations

import json
import os
import re
import stat
import tempfile
from pathlib import Path

STAMP = re.compile(r"^[0-9]{8}-[0-9]{6}Z$")
UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


class StateError(RuntimeError):
    pass


def snapshot(value):
    if not isinstance(value, dict) or set(value) != {"timestamp", "uuid"}:
        raise StateError("snapshot must contain exactly timestamp and uuid")
    if not isinstance(value["timestamp"], str) or not STAMP.fullmatch(value["timestamp"]):
        raise StateError("invalid snapshot timestamp")
    if not isinstance(value["uuid"], str) or not UUID.fullmatch(value["uuid"]):
        raise StateError("invalid snapshot uuid")
    return dict(value)


def validate(data):
    if not isinstance(data, dict) or set(data) != {"schema", "established", "pending", "previous"} or type(data["schema"]) is not int or data["schema"] != 1:
        raise StateError("invalid agreed-parent schema")
    for field in ("established", "pending", "previous"):
        if data[field] is not None:
            snapshot(data[field])
    if data["established"] is None:
        raise StateError("established parent is required")
    snapshots = [data[k] for k in ("established", "pending", "previous") if data[k] is not None]
    if len({v["timestamp"] for v in snapshots}) != len(snapshots):
        raise StateError("duplicate snapshot timestamp in state")
    if data["pending"] is not None and data["previous"] is not None:
        raise StateError("cannot prepare while previous parent awaits peer confirmation")
    return data


def initial(established):
    return validate({"schema": 1, "established": snapshot(established), "pending": None, "previous": None})


def prepare(state, candidate):
    validate(state)
    if state["pending"] is not None or state["previous"] is not None:
        raise StateError("transition already in progress")
    result = dict(state, pending=snapshot(candidate))
    return validate(result)


def promote(state):
    """Peer replication acknowledged; keep old parent until *both* peers confirm promotion."""
    validate(state)
    if state["pending"] is None:
        raise StateError("no pending parent")
    return validate(dict(state, previous=state["established"], established=state["pending"], pending=None))


def acknowledge_previous(state):
    """Only after independent durable confirmation from BOTH ends; never automatic."""
    validate(state)
    if state["pending"] is not None or state["previous"] is None:
        raise StateError("no previous parent ready for acknowledgement")
    return validate(dict(state, previous=None))


def protected(state):
    validate(state)
    return {v["timestamp"]: v["uuid"] for v in (state["established"], state["pending"], state["previous"]) if v is not None}


def _check_parent(path):
    if not path.is_absolute() or path.parent.is_symlink() or not path.parent.is_dir():
        raise StateError("state parent must be an existing non-symlink absolute directory")
    mode = path.parent.stat()
    if mode.st_mode & 0o022:
        raise StateError("state directory must not be group/world writable")


def load(path: Path, *, require_root=False):
    _check_parent(path)
    if path.is_symlink() or not path.is_file():
        raise StateError("missing or unsafe state file")
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o022 or (require_root and info.st_uid != 0):
        raise StateError("unsafe ownership or file permissions")
    try:
        return validate(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, ValueError, UnicodeError) as exc:
        raise StateError("invalid/unreadable state") from exc


def save(path: Path, state, *, require_root=False):
    """Atomic replacement; callers must hold a stable external exclusive lock.

    No implicit recovery from missing/corrupt state; fail closed on read.
    """
    validate(state)
    _check_parent(path)
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise StateError("unsafe destination")
    if require_root and os.geteuid() != 0:
        raise StateError("root required")
    if path.exists():
        load(path, require_root=require_root)
    tmp = None
    try:
        fd, name = tempfile.mkstemp(prefix=".agreed-parent-", dir=str(path.parent))
        tmp = Path(name)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(state, stream, sort_keys=True, separators=(",", ":"))
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
        dir_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        if tmp is not None and tmp.exists():
            tmp.unlink()
