#!/usr/bin/env python3
"""Dormant internal binding: existing receiver promotion + independent locked readback.

No CLI, SSH exposure, pruning or release. Deployment requires a separate review.
"""
import importlib.util
import os
from pathlib import Path

LIB = Path('/usr/local/libexec')


def _load_file(stem):
    path = LIB / ('btrfs-agreed-parent-' + stem + '.py')
    spec = importlib.util.spec_from_file_location('agreed_parent_binding_' + stem.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def promote_verified_receiver(parent, candidate, *, modules=None):
    """Run receiver promotion and separate locked readback (no release of A).

    `modules` is only an offline regression seam, never passed from CLI.
    The caller must hold a trusted privileged receiver execution context;
    the two underlying operations each acquire their canonical locks.
    """
    if os.geteuid() != 0 and modules is None:
        raise RuntimeError('root required for operational receiver binding')
    deps = modules if modules is not None else {
        'entry': _load_file('receiver-entry'),
        'adapter': _load_file('receiver-promotion-adapter'),
        'readback': _load_file('receiver-promoted-readback'),
    }
    if type(deps) is not dict or set(deps) != {'entry', 'adapter', 'readback'}:
        raise RuntimeError('invalid internal binding dependencies')
    entry, adapter, readback = (deps[k] for k in ('entry', 'adapter', 'readback'))
    if not callable(getattr(entry, 'promote_receiver_fixed', None)) or not callable(getattr(adapter, 'promote_and_readback', None)) or not callable(getattr(readback, 'read_promoted_state', None)):
        raise RuntimeError('incomplete internal receiver binding')
    return adapter.promote_and_readback(
        parent, candidate,
        promote_fixed=entry.promote_receiver_fixed,
        read_locked_state=readback.read_promoted_state,
    )
