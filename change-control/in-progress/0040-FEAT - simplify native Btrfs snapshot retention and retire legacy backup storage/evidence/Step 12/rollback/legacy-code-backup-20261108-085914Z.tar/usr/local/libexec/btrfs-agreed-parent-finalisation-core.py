#!/usr/bin/env python3
"""0040 Step 12.3: INTERNAL, fail-closed receiver finalisation transaction.

No CLI, SSH endpoint, pin promotion or prune authority. This composes trusted
lock-held readers/writers; adapters MUST be selected by fixed installed code,
never by remote caller. The source-success assertion is not itself evidence:
its authenticated binding and independent sender exit verification remain an
external prerequisite, deliberately required by this interface.
"""
import re
import uuid

NONCE = re.compile(r'[0-9a-f]{64}\Z')

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')

class FinalisationRefused(RuntimeError):
    pass


def identity(item):
    if (type(item) is not dict or set(item) != {'timestamp', 'uuid'} or
            type(item['timestamp']) is not str or not STAMP.fullmatch(item['timestamp']) or
            type(item['uuid']) is not str or not UUID.fullmatch(item['uuid'])):
        raise FinalisationRefused('invalid A/B identity')
    return item


def validate_provisional_journal(journal, parent, candidate):
    """Accept only the legacy or boot-bound scoped reservation schema.

    Scope reservation is not termination or cleanup evidence. Finalisation
    still requires independently authenticated source/receiver completion.
    """
    legacy = {'schema', 'status', 'parent', 'candidate', 'nonce'}
    scoped = legacy | {'scope_unit', 'scope_binding', 'receiver_boot_id'}
    if (type(journal) is not dict or set(journal) not in (legacy, scoped) or
            type(journal.get('schema')) is not int or journal['schema'] != 1 or
            journal.get('status') != 'receiving' or
            journal.get('parent') != parent or journal.get('candidate') != candidate or
            type(journal.get('nonce')) is not str or
            NONCE.fullmatch(journal['nonce']) is None):
        raise FinalisationRefused('provisional journal mismatch')
    if set(journal) == scoped:
        expected = ('btrfs-agreed-receive-' + candidate['timestamp'] + '-' +
                    journal['nonce'][:16] + '.scope')
        if (journal['scope_unit'] != expected or
                journal['scope_binding'] != 'reserved-not-termination-evidence' or
                type(journal['receiver_boot_id']) is not str):
            raise FinalisationRefused('invalid scoped journal binding')
        try:
            boot = uuid.UUID(journal['receiver_boot_id'])
        except (ValueError, AttributeError) as exc:
            raise FinalisationRefused('invalid scoped journal boot ID') from exc
        if str(boot) != journal['receiver_boot_id'] or boot.version != 4:
            raise FinalisationRefused('invalid scoped journal boot ID')
    return journal


def finalize_locked(parent, candidate, *, read_state, read_journal,
                    verify_source_completion, inspect_received, receipt_absent,
                    commit_receipt, receipt_fields, manager_lock_held=False,
                    writer_lock_held=False):
    """Write a B receipt only after strict reconciliation under BOTH locks.

    No journal deletion: unresolved or completed provisional journal is retained
    until a separately reviewed promotion/recovery protocol has been accepted.
    An uncertain commit is never retried automatically.
    """
    identity(parent); identity(candidate)
    if not parent['timestamp'] < candidate['timestamp']:
        raise FinalisationRefused('invalid incremental ordering')
    if manager_lock_held is not True or writer_lock_held is not True:
        raise FinalisationRefused('receiver locks not held')
    callbacks = (read_state, read_journal, verify_source_completion,
                 inspect_received, receipt_absent, commit_receipt)
    if not all(callable(fn) for fn in callbacks):
        raise FinalisationRefused('missing trusted finalisation adapters')
    state = read_state()
    if (type(state) is not dict or set(state) != {'schema', 'established', 'pending', 'previous'} or
            type(state['schema']) is not int or state['schema'] != 1 or
            state['established'] != parent or state['pending'] != candidate or state['previous'] is not None):
        raise FinalisationRefused('agreed-parent state changed')
    journal = read_journal()
    validate_provisional_journal(journal, parent, candidate)
    # This trusted callback MUST establish authenticated session binding and
    # independently observed source-send AND SSH exit == 0; never a wire flag.
    proof = verify_source_completion(parent, candidate, journal['nonce'])
    if proof != {'authenticated_session': True, 'source_send_exit': 0,
                 'ssh_exit': 0, 'receiver_receive_exit': 0,
                 'parent': parent, 'candidate': candidate}:
        raise FinalisationRefused('authenticated sender completion unproven')
    observed = inspect_received(candidate['timestamp'])
    if (type(observed) is not dict or observed.get('flags') != 'readonly' or
            observed.get('received_uuid') != candidate['uuid'] or
            type(observed.get('uuid')) is not str or not observed['uuid']):
        raise FinalisationRefused('received B identity unverified')
    if receipt_absent(candidate['timestamp']) is not True:
        raise FinalisationRefused('receipt exists or absence uncertain')
    if (type(receipt_fields) is not dict or
            receipt_fields.get('snapshot') != candidate['timestamp'] or
            receipt_fields.get('source_uuid') != candidate['uuid'] or
            receipt_fields.get('received_uuid') != candidate['uuid'] or
            receipt_fields.get('parent_snapshot') != parent['timestamp'] or
            receipt_fields.get('parent_source_uuid') != parent['uuid'] or
            receipt_fields.get('transport') != 'btrfs-incremental' or
            receipt_fields.get('read_only_verified') is not True or
            type(receipt_fields.get('source_send_exit')) is not int or
            receipt_fields['source_send_exit'] != 0 or
            type(receipt_fields.get('receiver_receive_exit')) is not int or
            receipt_fields['receiver_receive_exit'] != 0):
        raise FinalisationRefused('unsafe receipt contents')
    try:
        commit_receipt(candidate['timestamp'], receipt_fields)
    except Exception as exc:
        raise FinalisationRefused('uncertain receipt commit; manual reconciliation') from exc
    return {'schema': 1, 'status': 'receiver-receipt-committed-promotion-pending',
            'parent': parent, 'candidate': candidate, 'journal_retained': True,
            'receipt_committed': True, 'state_changed': False,
            'authorizes_transition': False, 'authorizes_prune': False,
            'authorizes_release': False}
