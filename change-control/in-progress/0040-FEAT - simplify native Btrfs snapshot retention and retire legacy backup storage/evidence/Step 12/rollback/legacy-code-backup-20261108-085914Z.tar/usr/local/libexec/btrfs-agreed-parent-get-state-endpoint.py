#!/usr/bin/python3
"""0040 3H.5g: fixed-path, strictly read-only receiver get-state RPC.

Never imports the transition endpoint/core; no state writes, prepare or promote.
Uses the existing root-only verified receiver observer (locks, receipts, Btrfs).
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

BASE = Path(__file__).resolve().parent
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
MAX_REQUEST = 65536


def module(name):
    path = BASE / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('get_state_' + name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def parse_request(raw, *, state_module=None):
    if type(raw) is not str or not 0 < len(raw.encode('utf-8')) <= MAX_REQUEST:
        raise ValueError('missing/oversized request')
    data = json.loads(raw)
    if type(data) is not dict or set(data) != {'schema', 'operation', 'transaction_id', 'expected_before', 'candidate'}:
        raise ValueError('unexpected request fields')
    if (type(data['schema']) is not int or data['schema'] != 1 or
            type(data['operation']) is not str or data['operation'] != 'get-state' or
            type(data['transaction_id']) is not str or STAMP.fullmatch(data['transaction_id']) is None or
            data['candidate'] is not None):
        raise ValueError('get-state-only contract violation')
    if data['expected_before'] is not None:
        (state_module or module('state')).validate(data['expected_before'])
    return data


def dispatch(request, *, observe=None):
    # Caller has already parsed a fixed read-only request; injected observer is
    # exclusively for regression tests. Real observer holds its own receiver locks.
    result = (observe or module('endpoint').observe)()
    if (type(result) is not dict or
            set(result) != {'schema', 'host', 'state', 'verified', 'authorizes_transition', 'authorizes_prune'} or
            type(result['schema']) is not int or result['schema'] != 1 or
            result['host'] != 'backup' or
            result['authorizes_transition'] is not False or result['authorizes_prune'] is not False or
            type(result['verified']) is not list):
        raise ValueError('invalid read-only receiver observation')
    state = module('state')
    state.validate(result['state'])
    expected = [{'timestamp': k, 'uuid': v} for k, v in sorted({item['timestamp']: item['uuid'] for item in (result['state']['established'], result['state']['previous']) if item is not None}.items())]
    if result['verified'] != expected:
        raise ValueError('receiver verification incomplete')
    if request['expected_before'] is not None and request['expected_before'] != result['state']:
        raise ValueError('receiver state differs from expected')
    return {'schema': 1, 'operation': 'get-state', 'transaction_id': request['transaction_id'],
            'status': 'success', 'state': result['state']}


def main():
    if sys.argv != [sys.argv[0], '--request'] or os.geteuid() != 0:
        raise ValueError('root and exact --request argument required')
    raw = sys.stdin.buffer.read(MAX_REQUEST + 1)
    if len(raw) > MAX_REQUEST:
        raise ValueError('oversized request')
    request = parse_request(raw.decode('utf-8'))
    print(json.dumps(dispatch(request), sort_keys=True, separators=(',', ':')))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, RuntimeError, OSError, UnicodeError) as exc:
        print('receiver get-state refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
