#!/usr/bin/env python3
"""0040 Step 12.3: dormant receiver operation dispatch contract.

No CLI, SSH route, policy installation, or production activation.
Only a future authenticated *fixed-command* boundary may call dispatch().
The caller must authorise the SSH principal and exact command externally;
root alone is NOT authorisation. Injected deps are solely for offline tests.
"""
import importlib.util
import os
from pathlib import Path

LIB = Path('/usr/local/libexec')
OPERATIONS = frozenset(('promote', 'promoted-readback'))


def _load(stem):
    path = LIB / ('btrfs-agreed-parent-' + stem + '.py')
    spec = importlib.util.spec_from_file_location('receiver_ops_' + stem.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def dispatch(request, *, dependencies=None):
    """Execute one strictly shaped internal request, never a shell command.

    This function does not verify an SSH identity: do not expose it via a
    general purpose sudo command, arbitrary argument forwarding, or remote
    shell. Any eventual CLI must enforce an independently reviewed whitelist.
    """
    if type(request) is not dict or set(request) != {'operation', 'parent', 'candidate'}:
        raise ValueError('invalid receiver request shape')
    operation = request['operation']
    if type(operation) is not str or operation not in OPERATIONS:
        raise ValueError('receiver operation not permitted')
    parent, candidate = request['parent'], request['candidate']
    if type(dependencies) is not dict and dependencies is not None:
        raise ValueError('invalid internal dependencies')
    if dependencies is None and os.geteuid() != 0:
        raise PermissionError('root required for internal receiver operation')
    deps = dependencies if dependencies is not None else {
        'state': _load('state'),
        'binding': _load('receiver-promotion-binding'),
        'readback': _load('receiver-promoted-readback'),
    }
    if set(deps) != {'state', 'binding', 'readback'}:
        raise ValueError('incomplete internal dependencies')
    # Validate BEFORE invoking any operation or acquiring locks.
    deps['state'].snapshot(parent)
    deps['state'].snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise ValueError('invalid parent/candidate order')
    if operation == 'promote':
        result = deps['binding'].promote_verified_receiver(parent, candidate)
    else:
        result = deps['readback'].read_promoted_state(parent, candidate)
    # Never infer authority to prune or release from successful promotion.
    return {'schema': 1, 'operation': operation, 'parent': parent,
            'candidate': candidate, 'result': result,
            'authorizes_prune': False, 'authorizes_release': False}
