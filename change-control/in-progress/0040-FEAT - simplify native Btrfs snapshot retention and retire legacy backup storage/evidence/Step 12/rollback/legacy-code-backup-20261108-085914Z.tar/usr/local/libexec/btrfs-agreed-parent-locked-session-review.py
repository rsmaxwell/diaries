#!/usr/bin/python3
"""0040/12.3/04S: real receiver locks + prepared-state + dormant session review.

No SSH listener, channel registration, receive, receipt creation or state writes.
Review sessions exist only inside the lock-owning process and are always closed.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

LIB = Path('/usr/local/libexec')
STATE_DIR = Path('/@data/mars-received/.replication-state')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER = STATE_DIR / 'writer.lock'


def load(filename, *, directory=LIB):
    path = directory / filename
    spec = importlib.util.spec_from_file_location('review04s_' + filename.replace('-', '_').replace('.', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def review(parent, candidate, *, deps=None, lock_paths=(MANAGER, WRITER)):
    """Real dependency defaults; injected dependencies only for offline regressions."""
    d = deps if deps is not None else {
        'receiver': load('btrfs-agreed-parent-receiver.py'),
        'endpoint': load('btrfs-agreed-parent-endpoint.py'),
        'state': load('btrfs-agreed-parent-state.py'),
        'absence': load('btrfs-agreed-parent-transfer-absence.py'),
        'boundary': load('btrfs-agreed-parent-receive-boundary.py'),
        'binding': load('btrfs-agreed-parent-receiver-session-binding.py'),
    }
    state = d['state']
    state.snapshot(parent)
    state.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid candidate order')
    with ExitStack() as stack:
        # These actual receiver lock files are the same as the 04J transaction.
        d['receiver']._lock(stack, lock_paths[0])
        d['receiver']._lock(stack, lock_paths[1])
        d['endpoint'].validate_filesystem()
        before = state.load(STATE_DIR / '.agreed-parent.json')
        absence = d['absence'].verify(parent, candidate, before, state=state)
        if absence.get('destination_absent') is not True or absence.get('receipt_absent') is not True:
            raise RuntimeError('receiver absence not verified')
        d['boundary'].verify_before_receive(before, parent, candidate, {
            'snapshot_absent': True, 'receipt_absent': True,
            'partial_artifacts_absent': True, 'prune_journal_absent': True,
        }, manager_lock_held=True, writer_lock_held=True)
        session = d['binding'].ReceiverSession(parent, candidate, lock_owner='04s-review')
        try:
            # Deliberately do NOT disclose the token, register SSH channels,
            # call a receive callback or authorize any transfer.
            if session.phase != 'registering':
                raise RuntimeError('receiver session not initialized')
            return {
                'schema': 1, 'status': 'receiver-locked-session-review',
                'parent': parent, 'candidate': candidate, 'state': before,
                'receiver_locks_held_during_review': True,
                'receiver_session_created': True,
                'channels_registered': [], 'destination_absent': True,
                'receipt_absent': True, 'transfer_executed': False,
                'receipt_committed': False, 'state_changed': False,
                'authorizes_transfer': False, 'authorizes_promote': False,
                'authorizes_prune': False, 'authorizes_release': False,
            }
        finally:
            session.close()


def main():
    ap = argparse.ArgumentParser(description='04S receiver locked session review (no transfer)')
    for name in ('parent', 'parent-uuid', 'candidate', 'candidate-uuid'):
        ap.add_argument('--' + name, required=True)
    ap.add_argument('--review-only', action='store_true', required=True)
    args = ap.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    result = review({'timestamp': args.parent, 'uuid': args.parent_uuid},
                    {'timestamp': args.candidate, 'uuid': args.candidate_uuid})
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, KeyError, TypeError, OSError) as exc:
        print('04S locked session review refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
