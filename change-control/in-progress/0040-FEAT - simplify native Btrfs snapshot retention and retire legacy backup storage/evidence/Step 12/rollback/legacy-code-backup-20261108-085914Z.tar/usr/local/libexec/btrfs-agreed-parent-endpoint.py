#!/usr/bin/python3
"""0040 3D: dormant fixed-path read-only receiver observation candidate.

NOT installed by Ansible or permitted via sudoers. Requires an explicitly
provisioned, trusted agreed-parent state before activation; missing state fails.
"""
import importlib.util
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
STATE_DIR = Path('/@data/mars-received/.replication-state')
SNAPSHOT_DIR = Path('/@data/mars-received/@data')
STATE_PATH = STATE_DIR / '.agreed-parent.json'
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER_LOCK = STATE_DIR / 'writer.lock'
RECEIVER_MOUNT = Path('/')
SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
RECEIVER_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'
UUID = re.compile(r'^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$')


def load_receiver():
    module_path = BASE / 'btrfs-agreed-parent-receiver.py'
    spec = importlib.util.spec_from_file_location('agreed_parent_receiver_3d', module_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def btrfs_run(args, *, runner=subprocess.run):
    result = runner(args, text=True, capture_output=True, timeout=15, check=False)
    if result.returncode:
        raise RuntimeError('Btrfs observation failed')
    if len(result.stdout) > 65536:
        raise RuntimeError('oversized Btrfs response')
    return result.stdout


def validate_filesystem(*, runner=subprocess.run):
    text = btrfs_run(['btrfs', 'filesystem', 'show', str(RECEIVER_MOUNT)], runner=runner)
    if not re.search(r'\buuid:\s*' + re.escape(RECEIVER_FS) + r'\b', text, re.I):
        raise RuntimeError('receiver filesystem identity mismatch')


def inspect_snapshot(stamp, *, runner=subprocess.run):
    if not re.fullmatch(r'\d{8}-\d{6}Z', stamp):
        raise RuntimeError('invalid timestamp')
    path = SNAPSHOT_DIR / stamp
    if not SNAPSHOT_DIR.is_dir() or SNAPSHOT_DIR.is_symlink() or not path.is_dir() or path.is_symlink():
        raise RuntimeError('unsafe or missing receiver snapshot')
    output = btrfs_run(['btrfs', 'subvolume', 'show', str(path)], runner=runner)
    values = {}
    for line in output.splitlines():
        if ':' in line:
            key, value = line.strip().split(':', 1)
            values[key.strip()] = value.strip()
    received = values.get('Received UUID', '')
    if values.get('Flags') != 'readonly' or not UUID.fullmatch(received):
        raise RuntimeError('invalid receiver subvolume identity')
    return {'flags': 'readonly', 'received_uuid': received}


def observe(*, runner=subprocess.run, receiver_module=None):
    """Read-only result. The receiver module owns lock ordering and receipts.

    Callback executes under locks. Do not treat JSON output as mutation authority.
    """
    module = receiver_module if receiver_module is not None else load_receiver()
    # Filesystem must also be rechecked under receiver locks for mutable action.
    # This is observation only, so validation here cannot confer such authority.
    validate_filesystem(runner=runner)
    result = module.observe(state_path=STATE_PATH, receipt_dir=STATE_DIR,
                          snapshot_dir=SNAPSHOT_DIR, manager_lock=MANAGER_LOCK,
                          writer_lock=WRITER_LOCK, source_fs=SOURCE_FS,
                          receiver_fs=RECEIVER_FS,
                          inspect=lambda stamp: inspect_snapshot(stamp, runner=runner))
    if (not isinstance(result, dict) or result.get('authorizes_transition') is not False or
            result.get('authorizes_prune') is not False):
        raise RuntimeError('unsafe receiver observation result')
    return result


def main():
    import argparse
    import os
    parser = argparse.ArgumentParser()
    parser.add_argument('--observe-receiver', action='store_true', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    if args.observe_receiver:
        print(json.dumps(observe(), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.TimeoutExpired, ValueError) as exc:
        import sys
        print(f'agreed-parent observation refused: {exc}', file=sys.stderr)
        raise SystemExit(1)
