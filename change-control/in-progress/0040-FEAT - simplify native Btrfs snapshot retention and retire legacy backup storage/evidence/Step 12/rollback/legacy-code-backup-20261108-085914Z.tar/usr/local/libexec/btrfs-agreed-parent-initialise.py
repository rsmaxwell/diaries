#!/usr/bin/python3
"""0040-FEAT Increment 3G: staged, fixed-path initialisation.

Not deployed by any role. No timers or pruning are controlled by this tool.
Receiver-first operation; source requires explicit independently checked receiver confirmation.
"""
import argparse
from contextlib import ExitStack
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess

STAMP = '20261030-030033Z'
UUID = 'd901ddd2-66c7-0b42-b26c-ab6886273b7a'
ROOT = {'source': Path('/media/usb/@snapshots'), 'receiver': Path('/@data/mars-received/.replication-state')}
SNAPSHOT = {'source': Path('/media/usb/@snapshots/@data') / STAMP,
            'receiver': Path('/@data/mars-received/@data') / STAMP}
LOCKS = {'source': [Path('/media/usb/@snapshots/.native-push.lock'), Path('/run/lock/btrfs-snapshot-manager.lock')],
         'receiver': [Path('/run/lock/btrfs-snapshot-manager.lock'), Path('/@data/mars-received/.replication-state/writer.lock')]}


def state_module():
    path = Path(__file__).with_name('btrfs-agreed-parent-state.py')
    spec = importlib.util.spec_from_file_location('agreed_state', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(*argv):
    return subprocess.check_output(argv, text=True, stderr=subprocess.STDOUT)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def check_quiescence(endpoint, *, active=None):
    if active is None:
        units = ['btrfs-native-push.timer', 'btrfs-native-push.service',
                 'btrfs-snapshot-prune.timer', 'btrfs-snapshot-prune.service'] if endpoint == 'source' else []
        active = {unit: run('systemctl', 'show', unit, '--property=ActiveState', '--value').strip() for unit in units}
    require(all(value == 'inactive' for value in active.values()), 'replication/pruning is not isolated')


def parse_subvolume(raw, endpoint):
    key = 'UUID' if endpoint == 'source' else 'Received UUID'
    observed = dict(re.findall(r'^\s*([^:\n]+):\s*(.*?)\s*$', raw, flags=re.MULTILINE))
    require(observed.get(key) == UUID, 'Btrfs identity mismatch')
    require(observed.get('Flags') == 'readonly', 'snapshot is not read-only')


def check_evidence(endpoint, *, show=None, protection=None, receipt=None, config=None):
    snap = SNAPSHOT[endpoint]
    require(not snap.is_symlink() and snap.is_dir(), 'missing/unsafe snapshot')
    if show is None:
        show = run('btrfs', 'subvolume', 'show', str(snap))
    parse_subvolume(show, endpoint)
    if endpoint == 'source':
        if protection is None:
            protection = json.loads(Path('/media/usb/@snapshots/.replication-protection.json').read_text())
        require(protection.get('schema') == 1 and
                all(protection.get(k, {}).get(STAMP) == UUID for k in ('protected', 'prune_protected')),
                'source protection pins missing or inconsistent')
    else:
        if config is None:
            config = json.loads(Path('/etc/btrfs-snapshot-manager.json').read_text())
        require(config.get('mode') == 'receiver' and config.get('receiver_prune_enabled') is False,
                'receiver pruning must remain disabled')
        if receipt is None:
            receipt = json.loads((ROOT['receiver'] / (STAMP + '.json')).read_text())
        require(receipt.get('schema') == 1 and receipt.get('snapshot') == STAMP and
                receipt.get('source_uuid') == UUID and receipt.get('received_uuid') == UUID and
                receipt.get('destination') == str(snap) and receipt.get('read_only_verified') is True and
                type(receipt.get('source_send_exit')) is int and receipt['source_send_exit'] == 0 and
                type(receipt.get('receiver_receive_exit')) is int and receipt['receiver_receive_exit'] == 0,
                'receiver receipt not verified')


def acquire(stack, lock):
    require(not lock.is_symlink() and lock.is_file(), 'missing/unsafe lock: ' + str(lock))
    info = lock.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not info.st_mode & 0o022,
            'unsafe lock metadata')
    fd = os.open(lock, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    handle = stack.enter_context(os.fdopen(fd, 'rb'))
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)


def initialise(endpoint, *, apply=False, peer_confirmed=False, checker=None):
    state = state_module()
    require(endpoint in ROOT, 'invalid endpoint')
    if apply:
        require(os.geteuid() == 0, 'root required for state write')
        require(endpoint == 'receiver' or peer_confirmed, 'receiver must be independently verified first')
    path = ROOT[endpoint] / '.agreed-parent.json'
    with ExitStack() as stack:
        for lock in LOCKS[endpoint]:
            acquire(stack, lock)
        check_quiescence(endpoint)
        if checker is None:
            check_evidence(endpoint)
        else:
            checker(endpoint)
        wanted = state.initial({'timestamp': STAMP, 'uuid': UUID})
        if path.exists() or path.is_symlink():
            existing = state.load(path, require_root=True)
            require(existing == wanted, 'conflicting agreed-parent state')
            result = 'unchanged'
        elif apply:
            state.save(path, wanted, require_root=True)
            require(state.load(path, require_root=True) == wanted, 'read-back mismatch')
            info = path.stat()
            require(info.st_uid == 0 and stat.S_IMODE(info.st_mode) == 0o600, 'state mode mismatch')
            result = 'created'
        else:
            result = 'would-create'
    return {'endpoint': endpoint, 'candidate': wanted['established'], 'result': result,
            'state_path': str(path), 'authorizes_prune': False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--endpoint', choices=('source', 'receiver'), required=True)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--apply', action='store_true')
    p.add_argument('--receiver-confirmed', action='store_true', help='required before source apply; operator must independently verify remote persisted state')
    args = p.parse_args()
    print(json.dumps(initialise(args.endpoint, apply=args.apply, peer_confirmed=args.receiver_confirmed), sort_keys=True))


if __name__ == '__main__':
    main()
