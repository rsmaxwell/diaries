#!/usr/bin/env python3
"""0040 Step 12.3: strict, read-only systemd scope observation.

Observation is NOT proof of transaction ownership or cleanup authority.
A durable journal binding and independently verifiable receive lifecycle are
required before this can feed a destructive reconciler.
"""
import re
import subprocess

SCOPE = re.compile(r'btrfs-agreed-receive-[0-9]{8}-[0-9]{6}Z(?:-[0-9a-f]{16})?\.scope\Z')
PROPERTIES = ('Id', 'LoadState', 'ActiveState', 'SubState', 'ControlGroup', 'TasksCurrent')

class ScopeRefused(RuntimeError):
    pass


def inspect_scope(unit, *, runner=subprocess.run):
    if type(unit) is not str or not SCOPE.fullmatch(unit):
        raise ScopeRefused('invalid scope name')
    try:
        result = runner(['systemctl', '--system', 'show', '--no-pager',
                         *('-p=' + key for key in PROPERTIES), unit],
                        capture_output=True, text=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ScopeRefused('scope observation unavailable') from exc
    if result.returncode != 0 or type(result.stdout) is not str:
        raise ScopeRefused('scope observation failed')
    observed = {}
    for line in result.stdout.splitlines():
        if '=' not in line:
            raise ScopeRefused('malformed scope response')
        key, value = line.split('=', 1)
        if key not in PROPERTIES or key in observed:
            raise ScopeRefused('unexpected or repeated scope property')
        observed[key] = value
    if set(observed) != set(PROPERTIES) or observed['Id'] != unit:
        raise ScopeRefused('scope identity mismatch')
    if observed['LoadState'] != 'loaded' or observed['ActiveState'] != 'inactive' or observed['SubState'] != 'dead':
        raise ScopeRefused('scope not proven terminated')
    # An empty control group path is ambiguous: systemd may have unloaded the
    # unit, or it might not represent the lifetime of this transaction.
    path = observed['ControlGroup']
    if not path.startswith('/system.slice/') or not path.endswith('/' + unit):
        raise ScopeRefused('scope control group identity missing')
    if observed['TasksCurrent'] != '0':
        raise ScopeRefused('scope task count not proven empty')
    return {'schema': 1, 'unit': unit, 'active_state': 'inactive',
            'tasks_current': 0, 'control_group': path,
            'cleanup_authorized': False, 'journal_bound': False}


def inspect_scope_lifecycle(unit, *, runner=subprocess.run):
    """Classify live systemd observations, without issuing fencing authority.

    Ubuntu systemd 255 normally unloads completed transient scopes.  An
    unloaded scope is observationally indistinguishable from a never-started
    one; callers MUST NOT turn this report into cleanup permission.
    """
    if type(unit) is not str or not SCOPE.fullmatch(unit):
        raise ScopeRefused('invalid scope name')
    try:
        result = runner(['systemctl', '--system', 'show', '--no-pager',
                         *('-p=' + key for key in PROPERTIES), unit],
                        capture_output=True, text=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ScopeRefused('scope observation unavailable') from exc
    if result.returncode != 0 or type(result.stdout) is not str:
        raise ScopeRefused('scope observation failed')
    observed = {}
    for line in result.stdout.splitlines():
        if '=' not in line:
            raise ScopeRefused('malformed scope response')
        key, value = line.split('=', 1)
        if key not in PROPERTIES or key in observed:
            raise ScopeRefused('unexpected or repeated scope property')
        observed[key] = value
    if set(observed) != set(PROPERTIES) or observed['Id'] != unit:
        raise ScopeRefused('scope identity mismatch')
    if observed['LoadState'] == 'loaded':
        path = observed['ControlGroup']
        if path != '/system.slice/' + unit:
            raise ScopeRefused('scope control group identity missing')
        count = observed['TasksCurrent']
        if not count.isdecimal():
            raise ScopeRefused('scope task count unknown')
        tasks = int(count)
        if observed['ActiveState'] == 'active' and observed['SubState'] == 'running' and tasks > 0:
            status = 'active'
        elif observed['ActiveState'] == 'inactive' and observed['SubState'] == 'dead' and tasks == 0:
            status = 'loaded-and-empty'
        else:
            raise ScopeRefused('contradictory scope state')
    elif (observed['LoadState'] == 'not-found' and
          observed['ActiveState'] == 'inactive' and observed['SubState'] == 'dead' and
          observed['ControlGroup'] == '' and observed['TasksCurrent'] == '[not set]'):
        status, tasks = 'unloaded-ambiguous', None
    else:
        raise ScopeRefused('unrecognised scope lifecycle state')
    return {'schema': 1, 'unit': unit, 'status': status, 'tasks_current': tasks,
            'journal_bound': False, 'started_independently_proven': False,
            'terminated_independently_proven': False, 'cleanup_authorized': False,
            'retransmit_authorized': False}
