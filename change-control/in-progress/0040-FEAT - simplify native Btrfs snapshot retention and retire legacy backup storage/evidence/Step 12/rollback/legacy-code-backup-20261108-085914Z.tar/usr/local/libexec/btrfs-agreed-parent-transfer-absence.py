#!/usr/bin/python3
"""0040 Step 12.3 Integration 04H: read-only prepared B destination absence.

Absence is evidence at one instant, not authority to start a later receive.
The transfer coordinator MUST repeat this check and serialize the receive.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
STATE_DIR = Path('/@data/mars-received/.replication-state')
SNAPSHOTS = Path('/@data/mars-received/@data')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER = STATE_DIR / 'writer.lock'


def load(name):
    spec = importlib.util.spec_from_file_location('absence_' + name.replace('-', '_'), BASE / ('btrfs-agreed-parent-' + name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify(parent, candidate, current, *, state, snapshot_dir=SNAPSHOTS, receipt_dir=STATE_DIR):
    state.snapshot(parent); state.snapshot(candidate); state.validate(current)
    if current['established'] != parent or current['pending'] != candidate or current['previous'] is not None:
        raise RuntimeError('receiver not in exact prepared A/B state')
    if candidate['timestamp'] <= parent['timestamp']:
        raise RuntimeError('invalid candidate order')
    for root in (snapshot_dir, receipt_dir):
        if root.is_symlink() or not root.is_dir():
            raise RuntimeError('unsafe receiver directory')
    b = candidate['timestamp']
    target = snapshot_dir / b
    receipt = receipt_dir / (b + '.json')
    if target.exists() or target.is_symlink() or receipt.exists() or receipt.is_symlink():
        raise RuntimeError('candidate destination or receipt already exists; inspect, never retry')
    for journal in ('.receiver-prune-pending.json',):
        path = receipt_dir / journal
        if path.exists() or path.is_symlink():
            raise RuntimeError('receiver transaction journal pending')
    # Also reject unaccepted directories or unsafe links with the same B prefix.
    if any(snapshot_dir.glob(b + '*')) or any(receipt_dir.glob(b + '*')):
        raise RuntimeError('candidate-associated receiver artifacts exist')
    return {'schema': 1, 'status': 'receiver-destination-absent', 'host': 'backup',
            'parent': parent, 'candidate': candidate, 'state': current,
            'destination_absent': True, 'receipt_absent': True,
            'state_changed': False, 'authorizes_transfer': False,
            'authorizes_promote': False, 'authorizes_prune': False, 'authorizes_release': False}


def inspect(parent, candidate, *, modules=None):
    d = modules or {'state':load('state'), 'receiver':load('receiver'), 'endpoint':load('endpoint')}
    with ExitStack() as stack:
        d['receiver']._lock(stack, MANAGER)
        d['receiver']._lock(stack, WRITER)
        d['endpoint'].validate_filesystem()
        current = d['state'].load(STATE_DIR / '.agreed-parent.json')
        return verify(parent, candidate, current, state=d['state'])


def main():
    ap=argparse.ArgumentParser(description='Read-only receiver B absence check')
    for name in ('parent', 'parent-uuid', 'candidate', 'candidate-uuid'):
        ap.add_argument('--'+name, required=True)
    args=ap.parse_args()
    if os.geteuid()!=0: raise RuntimeError('root required')
    print(json.dumps(inspect({'timestamp':args.parent,'uuid':args.parent_uuid},
                             {'timestamp':args.candidate,'uuid':args.candidate_uuid}), sort_keys=True))

if __name__=='__main__':
    try: main()
    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as exc:
        print('receiver absence refused: '+str(exc), file=sys.stderr)
        raise SystemExit(1)
