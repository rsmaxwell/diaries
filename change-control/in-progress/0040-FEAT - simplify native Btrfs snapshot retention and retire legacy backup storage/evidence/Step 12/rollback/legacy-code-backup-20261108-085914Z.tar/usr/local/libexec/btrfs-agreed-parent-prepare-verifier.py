#!/usr/bin/python3
"""0040 receiver verified-parent evidence. Import-only; no CLI or mutation."""
import importlib.util
import json
from pathlib import Path

SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
RECEIVER_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'

def load_observer():
    path = Path(__file__).with_name('btrfs-agreed-parent-endpoint.py')
    spec = importlib.util.spec_from_file_location('prepare_verifier_observer', path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

def verify_snapshot(snapshot, receipt_dir, snapshot_dir, *, observer=None):
    """Called only while transition core holds manager+writer locks."""
    observer = observer or load_observer()
    observer.validate_filesystem()
    stamp, uuid = snapshot['timestamp'], snapshot['uuid']
    observed = observer.inspect_snapshot(stamp)
    path = receipt_dir / (stamp + '.json')
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
        raise ValueError('missing/unsafe receipt')
    receipt = json.loads(path.read_text(encoding='utf-8'))
    if (type(receipt) is not dict or receipt.get('schema') != 1 or
            receipt.get('snapshot') != stamp or receipt.get('source_uuid') != uuid or
            receipt.get('received_uuid') != uuid or
            receipt.get('destination') != str(snapshot_dir / stamp) or
            receipt.get('source_filesystem_uuid') != SOURCE_FS or
            receipt.get('receiver_filesystem_uuid') != RECEIVER_FS or
            receipt.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
            receipt.get('read_only_verified') is not True or
            type(receipt.get('source_send_exit')) is not int or receipt['source_send_exit'] != 0 or
            type(receipt.get('receiver_receive_exit')) is not int or receipt['receiver_receive_exit'] != 0 or
            observed.get('flags') != 'readonly' or observed.get('received_uuid') != uuid):
        raise ValueError('receiver evidence mismatch')

