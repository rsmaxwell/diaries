#!/usr/bin/env python3
"""Receiver-first, idempotent previous-parent acknowledgement; no prune/release."""
from contextlib import ExitStack
from pathlib import Path
import importlib.util
import os

LIB = Path('/usr/local/libexec')
STATE = Path('/@data/mars-received/.replication-state/.agreed-parent.json')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER = STATE.parent / 'writer.lock'

def _load(name):
    path = LIB / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('prev_ack_' + name.replace('-', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def acknowledge(parent, candidate, *, dependencies=None):
    if os.geteuid() != 0 and dependencies is None:
        raise RuntimeError('root required')
    d = dependencies or {'receiver': _load('receiver'), 'state': _load('state'),
                         'receipt': _load('receiver-entry')}
    st = d['state']
    st.snapshot(parent); st.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid previous-parent ordering')
    with ExitStack() as stack:
        d['receiver']._lock(stack, MANAGER)
        d['receiver']._lock(stack, WRITER)
        current = st.load(STATE, require_root=True)
        if current['established'] != candidate or current['pending'] is not None or current['previous'] not in (parent, None):
            raise RuntimeError('receiver not in exact previous-parent acknowledgement state')
        # Verify authoritative committed receipt and readonly Btrfs identity even on retry.
        proof = d['receipt']._receipt_locked(parent, candidate,
                    storage=_load('finalisation-storage'), receive_core=_load('receive-core'))
        if proof.get('receipt_committed') is not True:
            raise RuntimeError('missing committed receiver receipt')
        if current['previous'] == parent:
            st.save(STATE, st.acknowledge_previous(current), require_root=True)
        observed = st.load(STATE, require_root=True)
        if observed != {'schema': 1, 'established': candidate, 'pending': None, 'previous': None}:
            raise RuntimeError('receiver previous acknowledgement readback refused')
        return observed

def readback(parent, candidate, *, dependencies=None):
    if os.geteuid() != 0 and dependencies is None:
        raise RuntimeError('root required')
    d = dependencies or {'receiver': _load('receiver'), 'state': _load('state')}
    st = d['state']
    st.snapshot(parent); st.snapshot(candidate)
    with ExitStack() as stack:
        d['receiver']._lock(stack, MANAGER)
        d['receiver']._lock(stack, WRITER)
        observed = st.load(STATE, require_root=True)
        if observed != {'schema': 1, 'established': candidate, 'pending': None, 'previous': None}:
            raise RuntimeError('receiver previous acknowledgement not durable')
        return observed
