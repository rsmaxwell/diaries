#!/usr/bin/env python3
"""0040 Step 12.3: agreed-parent provisional receiving implementation.

Internal-only, no CLI, no automatic receipt or promotion. This module is the
migration target; legacy receiver still exists for rollback until cutover.
"""
from contextlib import ExitStack
from pathlib import Path
import fcntl
import json
import re
import stat
import subprocess
import os
import signal
import time

STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')
STATE = Path('/@data/mars-received/.replication-state')
LOCK = STATE / 'writer.lock'
ENDPOINT = '/usr/local/libexec/btrfs-native-endpoint'

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def inspect(stamp):
    result = subprocess.run(['sudo', '-n', ENDPOINT, '--role', 'inspect-receiver', '--snapshot', stamp],
                            capture_output=True, text=True, check=True)
    return json.loads(result.stdout)

def check_protected_parent(stamp, source_uuid):
    # Execution is deliberately disabled until a trusted independent parent
    # verification adapter is wired into this module.
    raise RuntimeError('trusted agreed-parent verification not configured')

def receive_prepared_candidate_reserved(parent, candidate, *,
                                       manager_lock, writer_lock, state_dir,
                                       verify_prepared, receive_stream,
                                       journal_module, inherit_receive_locks=False, scoped=False):
    """Reserve B before accepting data; preserve journal even on success.

    The callback must perform one bounded native Btrfs receive inside the
    locks. A successful return is NOT a final receipt or sender attestation.
    """
    require(callable(verify_prepared) and callable(receive_stream),
            'Missing trusted receive callbacks')
    require(manager_lock != writer_lock, 'Identical receiver lock paths')
    require(Path(state_dir).is_absolute(), 'Invalid receiver state path')
    for lock_path in (manager_lock, writer_lock):
        lock_path = Path(lock_path)
        require(lock_path.is_absolute() and lock_path.is_file() and
                not lock_path.is_symlink(), 'Missing safe receiver lock')
        metadata = lock_path.stat()
        require(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1,
                'Unsafe receiver lock')
    with ExitStack() as stack:
        locked_handles = []
        for lock_path in (manager_lock, writer_lock):
            handle = stack.enter_context(Path(lock_path).open('r+'))
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked_handles.append(handle)
        # Preflight runs under the same locks as the reservation and receive.
        require(verify_prepared(parent, candidate) is True,
                'A/B prepared-state and destination-absence preflight refused')
        reservation_args = {'manager_lock_held': True, 'writer_lock_held': True}
        if scoped:
            reservation_args['scoped'] = True
        journal = journal_module.reserve(state_dir, parent, candidate, **reservation_args)
        # No cleanup, retry, receipt or parent transition on either outcome.
        if scoped:
            reservation = json.loads(journal.read_text())
            unit = reservation.get('scope_unit')
            require(type(unit) is str and reservation.get('scope_binding') ==
                    'reserved-not-termination-evidence', 'Missing durable scope binding')
        else:
            unit = None
        # Only the future trusted executor may provide a real receive callback.
        if inherit_receive_locks:
            # flock locks are attached to open file descriptions. Pass both
            # descriptors through exec into Btrfs so a surviving receiver
            # retains exclusion if this coordinator terminates unexpectedly.
            args = {'lock_fds': tuple(handle.fileno() for handle in locked_handles)}
        else:
            args = {}
        if scoped:
            args['scope_unit'] = unit
        result = receive_stream(parent, candidate, **args)
        require(result is True, 'Candidate receive failed or incomplete')
        return {'schema': 1, 'status': 'receiver-provisional-only',
                'parent': parent, 'candidate': candidate, 'journal': str(journal),
                'transfer_finalized': False, 'receipt_committed': False,
                'authorizes_transition': False, 'authorizes_prune': False,
                'authorizes_release': False}

# 0040 Step 12.3 — INTERNAL bounded real receive adapter.
# It is deliberately NOT called by main/--accept. Call only through the
# journal-first transaction after independent A/B preflight under both locks.
def run_bounded_receive_group(command, *, stdin, timeout, popen=subprocess.Popen,
                              kill_group=os.killpg, clock=time.monotonic, lock_fds=(),
                              scope_unit=None, scope_query=None, scope_lifecycle=False):
    """Supervise receiver process group; unresolved descendants fail closed.

    An endpoint escaping its process group requires separate production audit.
    """
    require(type(timeout) is int and 1 <= timeout <= 7200, 'Invalid receive deadline')
    require(type(lock_fds) is tuple and all(type(fd) is int and fd >= 0 for fd in lock_fds)
            and len(set(lock_fds)) == len(lock_fds), 'Invalid inherited lock descriptors')
    # Opt-in systemd containment. No cleanup or automatic retry is authorized
    # by this check. In particular, a disappearing/unknown unit is ambiguous.
    if scope_unit is not None:
        require(type(scope_unit) is str and
                re.fullmatch(r'btrfs-agreed-receive-[0-9]{8}-[0-9]{6}Z(?:-[0-9a-f]{16})?\.scope', scope_unit),
                'Invalid receiver scope identity')
        require(callable(scope_query), 'Missing independent systemd scope observer')
        command = ['systemd-run', '--system', '--scope', '--quiet',
                   '--unit=' + scope_unit, '--', *command]
    options = {'stdin': stdin, 'start_new_session': True,
               'stdout': subprocess.DEVNULL, 'stderr': subprocess.PIPE}
    if lock_fds:
        options['pass_fds'] = lock_fds
    proc = popen(command, **options)
    require(type(proc.pid) is int and proc.pid > 0, 'Invalid receiver PID')
    deadline = clock() + timeout
    observed_live = False
    def stop_group():
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                kill_group(proc.pid, sig)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
        try:
            proc.communicate(timeout=5)
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError('Receiver descendants not reaped; journal retained') from exc
    try:
        if scope_lifecycle:
            require(scope_unit is not None and callable(scope_query),
                    'Missing scoped lifecycle observer')
            # Sample the live unit during the supervised receive, not only
            # after the transient unit has been unloaded by systemd.
            while True:
                remaining = deadline - clock()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(command, timeout)
                try:
                    proc.communicate(timeout=min(0.25, remaining))
                    break
                except subprocess.TimeoutExpired:
                    snapshot = scope_query(scope_unit)
                    require(type(snapshot) is dict and snapshot.get('unit') == scope_unit and
                            snapshot.get('cleanup_authorized') is False and
                            snapshot.get('terminated_independently_proven') is False,
                            'Untrusted live scope observation')
                    if snapshot.get('status') == 'active' and snapshot.get('tasks_current', 0) > 0:
                        observed_live = True
                    elif snapshot.get('status') != 'unloaded-ambiguous':
                        raise RuntimeError('Contradictory live scope; journal retained')
        else:
            remaining = deadline - clock()
            if remaining <= 0:
                raise subprocess.TimeoutExpired(command, timeout)
            proc.communicate(timeout=remaining)
    except BaseException as exc:
        stop_group()
        raise RuntimeError('Receiver interrupted/timed out; journal retained') from exc
    try:
        kill_group(proc.pid, 0)
    except ProcessLookupError:
        pass
    else:
        stop_group()
        raise RuntimeError('Receiver process group remains alive; journal retained')
    if scope_unit is not None:
        try:
            observed = scope_query(scope_unit)
        except Exception as exc:
            raise RuntimeError('Receiver scope observation failed; journal retained') from exc
        if scope_lifecycle:
            # A vanished transient scope is NOT fencing evidence. It is
            # consistent with normal successful execution only when we also
            # observed this exact scope active while supervising the command.
            require(observed_live and type(observed) is dict and
                    observed.get('unit') == scope_unit and
                    observed.get('status') in ('unloaded-ambiguous', 'loaded-and-empty') and
                    observed.get('cleanup_authorized') is False and
                    observed.get('terminated_independently_proven') is False,
                    'Receiver lifecycle ambiguous; journal retained')
        else:
            require(type(observed) is dict and observed.get('unit') == scope_unit and
                    observed.get('active_state') == 'inactive' and
                    type(observed.get('tasks_current')) is int and observed['tasks_current'] == 0 and
                    observed.get('cleanup_authorized') is False and
                    observed.get('journal_bound') is False,
                    'Receiver scope not independently empty; journal retained')
    require(type(proc.returncode) is int and proc.returncode == 0,
            'Btrfs receive failed; journal retained; manual reconciliation required')
    return proc


def receive_prepared_binary_stream(parent, candidate, *, input_stream,
                                   runner=None, timeout_seconds=1800,
                                   endpoint=ENDPOINT, inspect_received=inspect,
                                   lock_fds=(), scope_unit=None, scope_query=None, scope_lifecycle=False):
    """Receive exactly one Btrfs stream; never create a final receipt.

    The endpoint independently verifies the target name/path.  The caller
    retains the manager and writer locks and provisional journal throughout.
    subprocess timeout kills the immediate endpoint process; a privileged
    descendant may survive, so a timeout MUST be treated as an unresolved
    recovery incident rather than an automatic retry/cleanup.
    """
    require(isinstance(parent, dict) and isinstance(candidate, dict),
            'Missing exact A/B identities')
    for identity in (parent, candidate):
        require(set(identity) == {'timestamp', 'uuid'} and
                isinstance(identity['timestamp'], str) and
                STAMP.fullmatch(identity['timestamp']) and
                isinstance(identity['uuid'], str) and
                re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', identity['uuid']),
                'Invalid exact A/B identity')
    require(parent['timestamp'] < candidate['timestamp'], 'Invalid parent order')
    require(type(timeout_seconds) is int and 1 <= timeout_seconds <= 7200,
            'Invalid receive deadline')
    require(input_stream is not None and hasattr(input_stream, 'read'),
            'Missing binary stream')
    require(endpoint == ENDPOINT, 'Unexpected privileged receiver endpoint')
    if lock_fds:
        # Only a root-owned coordinator may pass flock descriptors to the
        # directly exec'd privileged endpoint. sudo may close inherited fds.
        require(os.geteuid() == 0 and len(lock_fds) == 2,
                'Privileged lock-owning coordinator required')
        command = [endpoint, '--role', 'receiver', '--snapshot', candidate['timestamp']]
    else:
        command = ['sudo', '-n', endpoint, '--role', 'receiver',
                   '--snapshot', candidate['timestamp']]
    if runner is None:
        completed = run_bounded_receive_group(command, stdin=input_stream, timeout=timeout_seconds,
                                              lock_fds=lock_fds, scope_unit=scope_unit, scope_query=scope_query, scope_lifecycle=scope_lifecycle)
    else:
        require(scope_unit is None, 'Injected legacy runner cannot attest scoped execution')
        # Injected runner is for offline regression only.
        try:
            completed = runner(command, stdin=input_stream, timeout=timeout_seconds, check=False)
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError('Btrfs receive timed out; journal retained; manual reconciliation required') from exc
    require(type(completed.returncode) is int and completed.returncode == 0,
            'Btrfs receive failed; journal retained; manual reconciliation required')
    observed = inspect_received(candidate['timestamp'])
    require(isinstance(observed, dict) and observed.get('flags') == 'readonly' and
            observed.get('received_uuid') == candidate['uuid'],
            'Btrfs receive identity/read-only verification refused; journal retained')
    return True  # Local receive only; sender success remains unverified.



# 0040 Step 12.3 — INTERNAL integrated receive path; not exposed by main().
# The caller must supply the actual authenticated SSH stdin and fixed endpoint.
# This code does not attest sender completion, write receipts or transition A/B.
def receive_prepared_candidate_integrated(parent, candidate, *, input_stream,
                                          state_module, absence_module, endpoint_module,
                                          journal_module, manager_lock, writer_lock,
                                          state_dir, verify_parent=check_protected_parent,
                                          runner=None, inspect_received=inspect,
                                          timeout_seconds=1800, scoped=False, scope_query=None, scope_lifecycle=False):
    """Real prepared-state preflight + durable reservation + bounded receive.

    All operations execute inside receive_prepared_candidate_reserved's two
    locks; the provisional journal remains after successful local receiving.
    The dependency parameters are an *internal test seam*, never wire input.
    """
    require(Path(state_dir) == STATE and Path(writer_lock) == LOCK and
            Path(manager_lock) == Path('/run/lock/btrfs-snapshot-manager.lock'),
            'Refusing noncanonical receiver paths')
    require(callable(verify_parent), 'Missing trusted parent verification')
    require(type(scoped) is bool, 'Invalid scoped receive setting')
    if scoped:
        require(runner is None and callable(scope_query),
                'Scoped receive requires real bounded executor and trusted scope observer')

    def preflight(a, b):
        endpoint_module.validate_filesystem()
        current = state_module.load(STATE / '.agreed-parent.json')
        evidence = absence_module.verify(a, b, current, state=state_module)
        require(evidence.get('destination_absent') is True and
                evidence.get('receipt_absent') is True and
                evidence.get('state_changed') is False,
                'Prepared candidate absence was not verified')
        verified_parent = verify_parent(a['timestamp'], a['uuid'])
        require(isinstance(verified_parent, dict) and
                verified_parent.get('receiver_verified_under_lock') is True and
                verified_parent.get('snapshot') == a['timestamp'] and
                verified_parent.get('source_uuid') == a['uuid'],
                'Established parent receipt/identity not verified')
        return True

    def receive(a, b, *, lock_fds=(), scope_unit=None):
        return receive_prepared_binary_stream(
            a, b, input_stream=input_stream, runner=runner,
            timeout_seconds=timeout_seconds, inspect_received=inspect_received,
            lock_fds=lock_fds, scope_unit=scope_unit, scope_query=scope_query, scope_lifecycle=scope_lifecycle)

    return receive_prepared_candidate_reserved(
        parent, candidate, manager_lock=manager_lock, writer_lock=writer_lock,
        state_dir=state_dir, verify_prepared=preflight,
        receive_stream=receive, journal_module=journal_module,
        inherit_receive_locks=(runner is None), scoped=scoped)

