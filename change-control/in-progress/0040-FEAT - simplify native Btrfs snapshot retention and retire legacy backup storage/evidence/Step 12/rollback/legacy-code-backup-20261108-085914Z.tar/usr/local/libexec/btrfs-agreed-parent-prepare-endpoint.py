#!/usr/bin/python3
"""0040 3H.5o: DORMANT receiver prepare-only endpoint. Installation separately gated; NOT authorised for live execution.

This is a state-changing command when explicitly deployed. No deploy task,
SSH entrypoint, sudo grant, promote, ack or pruning capability is included.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

BASE = Path(__file__).resolve().parent
STATE_DIR = Path('/@data/mars-received/.replication-state')
SNAPSHOTS = Path('/@data/mars-received/@data')
STATE_FILE = STATE_DIR / '.agreed-parent.json'
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER_LOCK = STATE_DIR / 'writer.lock'
MAX_REQUEST = 65536
STAMP = re.compile(r'^[0-9]{8}-[0-9]{6}Z$')


def load(name):
    path = BASE / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('prepare_only_' + name.replace('-', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def parse_request(raw, *, state=None):
    if type(raw) is not str or not 0 < len(raw.encode('utf-8')) <= MAX_REQUEST:
        raise ValueError('missing or oversized request')
    obj = json.loads(raw)
    if type(obj) is not dict or set(obj) != {'schema', 'operation', 'transaction_id', 'expected_before', 'candidate'}:
        raise ValueError('invalid request fields')
    if (type(obj['schema']) is not int or obj['schema'] != 1 or
            type(obj['operation']) is not str or obj['operation'] != 'prepare' or
            type(obj['transaction_id']) is not str or STAMP.fullmatch(obj['transaction_id']) is None):
        raise ValueError('prepare-only contract violation')
    state = state or load('state')
    state.validate(obj['expected_before'])
    state.snapshot(obj['candidate'])
    if (obj['candidate']['timestamp'] != obj['transaction_id'] or
            obj['expected_before']['pending'] is not None or
            obj['expected_before']['previous'] is not None or
            obj['candidate']['timestamp'] <= obj['expected_before']['established']['timestamp']):
        raise ValueError('conflicting or stale prepare request')
    return obj


def dispatch(request, *, core=None, verify=None):
    """Core owns manager→writer locks, A evidence and atomic state readback.

    Verification deliberately checks established A, NOT untransferred B.
    Dependencies may be injected only by offline regression tests.
    """
    core = core or load('transition')
    verify = verify or load('prepare-verifier').verify_snapshot
    response = core.transition(
        operation='prepare', transaction_id=request['transaction_id'],
        expected_before=request['expected_before'], candidate=request['candidate'],
        state_path=STATE_FILE, receipt_dir=STATE_DIR, snapshot_dir=SNAPSHOTS,
        manager_lock=MANAGER_LOCK, writer_lock=WRITER_LOCK, verify=verify)
    expected = load('state').prepare(request['expected_before'], request['candidate'])
    if (type(response) is not dict or set(response) != {'schema', 'operation', 'transaction_id', 'status', 'state'} or
            type(response['schema']) is not int or response['schema'] != 1 or
            response['operation'] != 'prepare' or response['transaction_id'] != request['transaction_id'] or
            response['status'] != 'success' or response['state'] != expected):
        raise RuntimeError('receiver prepare postcondition mismatch')
    return response


def main():
    if sys.argv != [sys.argv[0], '--request'] or os.geteuid() != 0:
        raise ValueError('root and exact --request required')
    data = sys.stdin.buffer.read(MAX_REQUEST + 1)
    if len(data) > MAX_REQUEST:
        raise ValueError('oversized request')
    request = parse_request(data.decode('utf-8'))
    print(json.dumps(dispatch(request), separators=(',', ':'), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, RuntimeError, OSError, UnicodeError) as exc:
        print('receiver prepare refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
