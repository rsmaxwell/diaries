#!/usr/bin/python3
"""0040 Step 12.3 Integration 04D: read-only exact-parent receiver attestation.

No transfer, agreed-parent state mutation, promotion, pruning or release. This
endpoint is NOT an SSH authorization; access control must be reviewed separately.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

BASE = Path(__file__).resolve().parent
STATE_DIR = Path('/@data/mars-received/.replication-state')
SNAPSHOTS = Path('/@data/mars-received/@data')
STATE_PATH = STATE_DIR / '.agreed-parent.json'
MANAGER_LOCK = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER_LOCK = STATE_DIR / 'writer.lock'
SOURCE_FS = '72d1d8ea-900e-4fca-837f-1b1febec036c'
RECEIVER_FS = 'b915f967-7cb4-4c14-b11b-f52209637a22'


def load(name):
    path = BASE / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('attestation_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def strict_receipt(path, stamp):
    """Reject links, permission abuse, oversized and malformed receipts."""
    if path.is_symlink() or not path.is_file():
        raise RuntimeError('missing or unsafe receiver receipt: ' + stamp)
    info = path.stat()
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
            info.st_mode & 0o077 or info.st_size > 65536 or info.st_size < 2 or
            info.st_uid not in (0, STATE_DIR.stat().st_uid)):
        raise RuntimeError('unsafe receipt metadata: ' + stamp)
    value = json.loads(path.read_text(encoding='utf-8'))
    if type(value) is not dict:
        raise RuntimeError('invalid receiver receipt')
    return value


def attest(parent, candidate, *, deps=None):
    """Caller supplies A and B identities; all evidence read under receiver locks."""
    d = deps if deps is not None else {
        'state': load('state'), 'receiver': load('receiver'),
        'endpoint': load('endpoint')}
    state, receiver, endpoint = (d[x] for x in ('state', 'receiver', 'endpoint'))
    state.snapshot(parent)
    state.snapshot(candidate)
    if candidate['timestamp'] <= parent['timestamp']:
        raise RuntimeError('candidate must be newer than established parent')
    if (STATE_DIR.is_symlink() or not STATE_DIR.is_dir() or
            SNAPSHOTS.is_symlink() or not SNAPSHOTS.is_dir()):
        raise RuntimeError('unsafe receiver directories')
    with ExitStack() as stack:
        # Same order as established receiver observation: manager then writer.
        receiver._lock(stack, MANAGER_LOCK)
        receiver._lock(stack, WRITER_LOCK)
        journal = STATE_DIR / '.receiver-prune-pending.json'
        if journal.exists() or journal.is_symlink():
            raise RuntimeError('receiver prune transaction pending')
        current = state.load(STATE_PATH)
        if (current['established'] != parent or current['pending'] != candidate or
                current['previous'] is not None):
            raise RuntimeError('receiver not in exact prepared A/B state')
        endpoint.validate_filesystem()
        # Both A and B must be real, readonly received subvolumes with receipts.
        results = {}
        for item in (parent, candidate):
            stamp, uuid = item['timestamp'], item['uuid']
            path = SNAPSHOTS / stamp
            if path.is_symlink() or not path.is_dir():
                raise RuntimeError('missing or unsafe receiver subvolume: ' + stamp)
            evidence = endpoint.inspect_snapshot(stamp)
            if (type(evidence) is not dict or evidence.get('flags') != 'readonly' or
                    evidence.get('received_uuid') != uuid):
                raise RuntimeError('received Btrfs identity mismatch: ' + stamp)
            receipt = strict_receipt(STATE_DIR / (stamp + '.json'), stamp)
            if (receipt.get('schema') != 1 or receipt.get('snapshot') != stamp or
                    receipt.get('source_uuid') != uuid or receipt.get('received_uuid') != uuid or
                    receipt.get('destination') != str(path) or
                    receipt.get('source_filesystem_uuid') != SOURCE_FS or
                    receipt.get('receiver_filesystem_uuid') != RECEIVER_FS or
                    receipt.get('transport') not in ('btrfs-full', 'btrfs-incremental') or
                    receipt.get('read_only_verified') is not True or
                    type(receipt.get('source_send_exit')) is not int or receipt['source_send_exit'] != 0 or
                    type(receipt.get('receiver_receive_exit')) is not int or receipt['receiver_receive_exit'] != 0):
                raise RuntimeError('receipt identity/status mismatch: ' + stamp)
            results[stamp] = receipt
        b_receipt = results[candidate['timestamp']]
        if (b_receipt['transport'] != 'btrfs-incremental' or
                b_receipt.get('parent_snapshot') != parent['timestamp'] or
                b_receipt.get('parent_source_uuid') != parent['uuid']):
            raise RuntimeError('candidate was not received incrementally from exact parent')
        return {'schema': 1, 'host': 'backup', 'status': 'transfer-attested',
                'parent': dict(parent), 'candidate': dict(candidate),
                'state': current, 'verified': [dict(parent), dict(candidate)],
                'receipt': b_receipt, 'state_changed': False,
                'authorizes_transfer': False, 'authorizes_promote': False,
                'authorizes_prune': False, 'authorizes_release': False}


def main():
    parser = argparse.ArgumentParser(description='Read-only A/B Btrfs transfer attestation')
    parser.add_argument('--parent', required=True)
    parser.add_argument('--parent-uuid', required=True)
    parser.add_argument('--candidate', required=True)
    parser.add_argument('--candidate-uuid', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    print(json.dumps(attest({'timestamp': args.parent, 'uuid': args.parent_uuid},
                            {'timestamp': args.candidate, 'uuid': args.candidate_uuid}), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as exc:
        print('transfer attestation refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
