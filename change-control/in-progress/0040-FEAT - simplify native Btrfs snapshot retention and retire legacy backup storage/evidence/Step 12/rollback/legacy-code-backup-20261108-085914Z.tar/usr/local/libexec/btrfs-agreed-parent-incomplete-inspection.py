#!/usr/bin/env python3
"""Read-only receiver-side incident inspection under canonical receiver locks.

No cleanup, fencing assertion, transfer retry, promotion or journal modification.
An acquired flock excludes cooperating receiver processes, but is NOT proof
that all descendants have terminated. The evidence gate must NOT receive
stream_terminated=True from this inspection alone.
"""
import json
from pathlib import Path
import stat


class InspectionRefused(RuntimeError):
    pass


def inspect(parent, candidate, *, state, journal, receipt_absent,
            destination_exists, locks_held, stream_terminated_proven=False):
    """Summarize captured evidence without assigning cleanup authority."""
    if locks_held is not True:
        raise InspectionRefused('canonical receiver locks required')
    if (type(state) is not dict or state.get('schema') != 1 or
            state.get('established') != parent or state.get('pending') != candidate or
            state.get('previous') is not None):
        raise InspectionRefused('receiver not identically prepared')
    if (type(journal) is not dict or journal.get('schema') != 1 or
            journal.get('status') != 'receiving' or journal.get('parent') != parent or
            journal.get('candidate') != candidate):
        raise InspectionRefused('provisional journal mismatch')
    if receipt_absent is not True:
        raise InspectionRefused('receipt present or uncertain')
    if type(destination_exists) is not bool:
        raise InspectionRefused('destination presence uncertain')
    # Do not turn lock acquisition into an assertion that no descendants
    # exist, even when a process inherited flock descriptors.
    return {'schema': 1, 'status': 'incomplete-receive-inspection',
            'parent': parent, 'candidate': candidate,
            'journal_nonce_present': bool(journal.get('nonce')),
            'destination_present': destination_exists,
            'locks_held_during_inspection': True,
            'stream_terminated_independently_proven': stream_terminated_proven is True,
            'cleanup_authorized': False, 'retransmit_authorized': False,
            'prune_authorized': False, 'release_authorized': False}


def inspect_locked(parent, candidate, *, receiver, storage, state_dir,
                   manager_lock, writer_lock, destination_root):
    """Canonical receiver observation; never follows a destination symlink."""
    from contextlib import ExitStack
    path = Path(destination_root) / candidate['timestamp']
    with ExitStack() as stack:
        receiver._lock(stack, manager_lock)
        receiver._lock(stack, writer_lock)
        current = storage.read_state(state_dir)
        pending = storage.read_journal(state_dir)
        absence = storage.receipt_absent(candidate['timestamp'], state_dir)
        exists = path.exists() or path.is_symlink()
        if exists and path.is_symlink():
            raise InspectionRefused('destination is symlink')
        return inspect(parent, candidate, state=current, journal=pending,
                       receipt_absent=absence, destination_exists=exists,
                       locks_held=True)


def inspect_btrfs_destination(candidate, *, destination_root=Path('/@data/mars-received/@data'),
                              runner=None):
    """Read Btrfs destination metadata; never infer journal ownership from it.

    A Btrfs subvolume UUID is useful evidence, but cannot prove which
    provisional journal created it. The result confers no deletion authority.
    """
    import re
    import subprocess
    root = Path(destination_root)
    if str(root) != '/@data/mars-received/@data':
        raise InspectionRefused('noncanonical receiver root')
    stamp = candidate.get('timestamp') if type(candidate) is dict else None
    if type(stamp) is not str or not re.fullmatch(r'[0-9]{8}-[0-9]{6}Z', stamp):
        raise InspectionRefused('invalid candidate timestamp')
    target = root / stamp
    if target.is_symlink():
        raise InspectionRefused('symlinked destination')
    if not target.exists():
        return {'status': 'absent', 'path': str(target), 'cleanup_authorized': False}
    if not target.is_dir():
        raise InspectionRefused('receiver destination not a directory')
    execute = subprocess.run if runner is None else runner
    result = execute(['btrfs', 'subvolume', 'show', '--', str(target)],
                     capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise InspectionRefused('destination Btrfs subvolume identity unverified')
    fields = {}
    for line in result.stdout.splitlines():
        if ':' in line:
            key, value = line.strip().split(':', 1)
            if key in ('UUID', 'Parent UUID', 'Received UUID', 'Flags'):
                if key in fields:
                    raise InspectionRefused('duplicate Btrfs subvolume field')
                fields[key] = value.strip()
    uuid = fields.get('UUID')
    if type(uuid) is not str or not re.fullmatch(
        r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', uuid):
        raise InspectionRefused('missing Btrfs subvolume UUID')
    return {'status': 'btrfs-subvolume-observed', 'path': str(target),
            'subvolume_uuid': uuid, 'flags': fields.get('Flags'),
            'received_uuid': fields.get('Received UUID'),
            'journal_ownership_proven': False, 'process_fencing_proven': False,
            'cleanup_authorized': False}


def inspect_locked_under_existing_locks(parent, candidate, *, storage, state_dir, destination_root):
    """Read canonical evidence while the receiver entry owns both locks.

    This is a diagnostic only, and deliberately does not assert stream fencing.
    """
    path = Path(destination_root) / candidate['timestamp']
    if (str(destination_root) != '/@data/mars-received/@data' or
            type(candidate) is not dict or type(candidate.get('timestamp')) is not str or
            not __import__('re').fullmatch(r'[0-9]{8}-[0-9]{6}Z', candidate['timestamp'])):
        raise InspectionRefused('invalid canonical receiver destination')
    current = storage.read_state(state_dir)
    pending = storage.read_journal(state_dir)
    receipt_absent = storage.receipt_absent(candidate['timestamp'], state_dir)
    exists = path.exists() or path.is_symlink()
    if exists and path.is_symlink():
        raise InspectionRefused('symlinked receiver destination')
    return inspect(parent, candidate, state=current, journal=pending,
                   receipt_absent=receipt_absent, destination_exists=exists,
                   locks_held=True, stream_terminated_proven=False)
