#!/usr/bin/python3
"""0040 Step 12.3 Integration 04I: dormant receiver boundary contract.

Pure validation only. The eventual privileged receive endpoint MUST acquire
manager and writer locks once, verify prepared A/B and absence within the same
critical section, then receive, verify and atomically commit its receipt before
releasing either lock. This module does not invoke Btrfs or change state.
"""

class Refused(RuntimeError):
    pass


def verify_before_receive(state, parent, candidate, destination, *,
                          manager_lock_held=False, writer_lock_held=False):
    """Require complete, lock-held receiver evidence before a single receive."""
    if manager_lock_held is not True or writer_lock_held is not True:
        raise Refused('both receiver locks required for entire receive transaction')
    if type(state) is not dict or set(state) != {'schema', 'established', 'pending', 'previous'} or type(state['schema']) is not int or state['schema'] != 1:
        raise Refused('invalid receiver agreed-parent state')
    for item in (parent, candidate):
        if type(item) is not dict or set(item) != {'timestamp', 'uuid'} or not all(type(v) is str and v for v in item.values()):
            raise Refused('invalid snapshot identity')
    if parent['timestamp'] >= candidate['timestamp'] or state['established'] != parent or state['pending'] != candidate or state['previous'] is not None:
        raise Refused('receiver not in exact prepared A/B state')
    if type(destination) is not dict or set(destination) != {'snapshot_absent', 'receipt_absent', 'partial_artifacts_absent', 'prune_journal_absent'} or any(v is not True for v in destination.values()):
        raise Refused('candidate destination is not clean')
    return {'schema': 1, 'status': 'receiver-boundary-preflight', 'parent': parent,
            'candidate': candidate, 'authorizes_transfer': False,
            'authorizes_promote': False, 'authorizes_prune': False,
            'authorizes_release': False}


def verify_after_receive(before, after, parent, candidate, attested, *,
                         manager_lock_held=False, writer_lock_held=False):
    """Require unchanged A/B and independently attested B before acknowledging."""
    if manager_lock_held is not True or writer_lock_held is not True:
        raise Refused('receiver locks lost before receipt verification')
    if before != after or after.get('established') != parent or after.get('pending') != candidate or after.get('previous') is not None:
        raise Refused('receiver state changed during transfer')
    if (type(attested) is not dict or set(attested) != {'parent', 'candidate', 'receipt_verified', 'received_uuid_verified', 'readonly_verified', 'incremental_parent_verified'} or
            attested['parent'] != parent or attested['candidate'] != candidate or any(attested[k] is not True for k in ('receipt_verified', 'received_uuid_verified', 'readonly_verified', 'incremental_parent_verified'))):
        raise Refused('incomplete receiver transfer attestation')
    return {'schema': 1, 'status': 'receiver-boundary-verified',
            'parent': parent, 'candidate': candidate, 'state_changed': False,
            'authorizes_promote': False, 'authorizes_prune': False, 'authorizes_release': False}
