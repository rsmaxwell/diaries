#!/usr/bin/env python3
"""0040 Step 12.3: dormant, independent receiver promoted-state readback.

No CLI/SSH endpoint. Runtime dependency injection is for regression testing;
production calls acquire the canonical receiver locks and require root.
This module does not promote, prune, release, or alter state.
"""
from contextlib import ExitStack
import importlib.util
import os
from pathlib import Path

LIB = Path('/usr/local/libexec')
STATE = Path('/@data/mars-received/.replication-state')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER = STATE / 'writer.lock'


def _load(name):
    path = LIB / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('receiver_readback_' + name.replace('-', '_'), path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def read_promoted_state(parent, candidate, *, dependencies=None):
    """Independently read the promoted state while holding receiver locks.

    Dependencies, when supplied, are an offline-test seam; never CLI inputs.
    """
    if os.geteuid() != 0 and dependencies is None:
        raise RuntimeError('root required for receiver state readback')
    mods = dependencies if dependencies is not None else {
        'receiver': _load('receiver'), 'state': _load('state')}
    if type(mods) is not dict or set(mods) != {'receiver', 'state'}:
        raise RuntimeError('invalid readback dependencies')
    state_mod = mods['state']
    state_mod.snapshot(parent)
    state_mod.snapshot(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise RuntimeError('invalid parent/candidate ordering')
    with ExitStack() as stack:
        mods['receiver']._lock(stack, MANAGER)
        mods['receiver']._lock(stack, WRITER)
        observed = state_mod.load(STATE / '.agreed-parent.json', require_root=True)
        if (type(observed) is not dict or set(observed) !=
                {'schema', 'established', 'pending', 'previous'} or
                type(observed['schema']) is not int or observed['schema'] != 1 or
                observed['established'] != candidate or
                observed['previous'] != parent or observed['pending'] is not None):
            raise RuntimeError('receiver durable state is not B promoted with A pinned')
        return observed
