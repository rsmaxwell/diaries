#!/usr/bin/env python3
"""0040 Step 12.3: internal authenticated sender-completion evidence.

Protocol primitive only: sender creates evidence AFTER independently observing the
send and ssh exit codes; receiver verifies against its own session nonce and A/B.
Key provisioning, receiver-issued nonce, replay ledger, and CLI remain separate
acceptance gates. A MAC authenticates the sender assertion; it cannot itself
prove what processes actually did on another host.
"""
import hashlib
import hmac
import json
import re

STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')
UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z')
NONCE = re.compile(r'[0-9a-f]{64}\Z')
DOMAIN = b'diaries-0040-step12.3-sender-proof-v1\x00'


class ProofRefused(RuntimeError):
    pass


def _identity(item):
    if (type(item) is not dict or set(item) != {'timestamp', 'uuid'} or
            type(item['timestamp']) is not str or STAMP.fullmatch(item['timestamp']) is None or
            type(item['uuid']) is not str or UUID.fullmatch(item['uuid']) is None):
        raise ProofRefused('invalid snapshot identity')
    return item


def _payload(parent, candidate, nonce, send_exit, ssh_exit, receiver_exit):
    _identity(parent); _identity(candidate)
    if parent['timestamp'] >= candidate['timestamp']:
        raise ProofRefused('invalid A/B order')
    if type(nonce) is not str or NONCE.fullmatch(nonce) is None:
        raise ProofRefused('invalid receiver-issued nonce')
    if any(type(code) is not int or code != 0 for code in (send_exit, ssh_exit, receiver_exit)):
        raise ProofRefused('sender or receiver completion not established')
    return {'schema': 1, 'parent': parent, 'candidate': candidate, 'nonce': nonce,
            'source_send_exit': send_exit, 'ssh_exit': ssh_exit,
            'receiver_receive_exit': receiver_exit}


def _key(key):
    if type(key) is not bytes or len(key) < 32:
        raise ProofRefused('trusted sender key not supplied')
    return key


def _canonical(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')


def create_proof(parent, candidate, nonce, *, key, send_exit, ssh_exit, receiver_exit):
    """Called only by trusted sender after actual process waits, never by remote CLI."""
    data = _payload(parent, candidate, nonce, send_exit, ssh_exit, receiver_exit)
    signature = hmac.new(_key(key), DOMAIN + _canonical(data), hashlib.sha256).hexdigest()
    return {'payload': data, 'mac': signature}


def verify_proof(proof, parent, candidate, expected_nonce, *, key):
    """Authenticate evidence for receiver-owned nonce; journal must be lock-held.

    This does not authenticate key origin, verify receipt or consume nonce;
    the caller must ensure those conditions before authorising finalisation.
    """
    expected = _payload(parent, candidate, expected_nonce, 0, 0, 0)
    if type(proof) is not dict or set(proof) != {'payload', 'mac'}:
        raise ProofRefused('invalid completion proof envelope')
    payload, mac = proof['payload'], proof['mac']
    if payload != expected or type(mac) is not str or re.fullmatch(r'[0-9a-f]{64}', mac) is None:
        raise ProofRefused('completion proof not bound to receiver session')
    calculated = hmac.new(_key(key), DOMAIN + _canonical(expected), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(mac, calculated):
        raise ProofRefused('unauthenticated sender completion')
    return {'authenticated_session': True, 'source_send_exit': 0,
            'ssh_exit': 0, 'receiver_receive_exit': 0,
            'parent': parent, 'candidate': candidate}
