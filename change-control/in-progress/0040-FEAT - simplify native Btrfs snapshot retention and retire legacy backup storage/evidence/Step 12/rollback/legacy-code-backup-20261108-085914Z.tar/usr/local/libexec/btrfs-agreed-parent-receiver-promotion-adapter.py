#!/usr/bin/env python3
"""0040 Step 12.3: internal receiver promotion/readback adapter (NOT deployed).

Only a privileged, already-authenticated receiver runtime may supply the entry
and state reader. This module never exposes CLI, SSH, pruning or release.
"""

class PromotionAdapterRefused(RuntimeError):
    pass


def _state_matches(state, parent, candidate):
    return (type(state) is dict and set(state) ==
            {'schema', 'established', 'pending', 'previous'} and
            type(state['schema']) is int and state['schema'] == 1 and
            state['established'] == candidate and
            state['pending'] is None and state['previous'] == parent)


def promote_and_readback(parent, candidate, *, promote_fixed, read_locked_state):
    """Promote on receiver, then verify state via an independent locked read.

    `promote_fixed` must wrap receiver-entry.promote_receiver_fixed with root,
    canonical receiver locks, committed receipt and Btrfs evidence.
    `read_locked_state` must independently acquire those same receiver locks
    and read the durable agreed-parent state; not reuse promotion's return.
    The caller must not retry an uncertain result blindly.
    """
    if not callable(promote_fixed) or not callable(read_locked_state):
        raise PromotionAdapterRefused('missing trusted receiver runtime')
    if (type(parent) is not dict or type(candidate) is not dict or
            set(parent) != {'timestamp', 'uuid'} or
            set(candidate) != {'timestamp', 'uuid'} or
            any(type(v) is not str or not v for obj in (parent, candidate)
                for v in obj.values()) or parent['timestamp'] >= candidate['timestamp']):
        raise PromotionAdapterRefused('invalid parent/candidate')
    try:
        ack = promote_fixed(parent, candidate)
    except Exception as exc:
        raise PromotionAdapterRefused('receiver promotion uncertain; preserve A') from exc
    if (type(ack) is not dict or ack.get('schema') != 1 or
            ack.get('status') != 'receiver-promoted-previous-pinned' or
            ack.get('parent') != parent or ack.get('candidate') != candidate or
            ack.get('receipt_committed') is not True or
            ack.get('authorizes_prune') is not False or
            ack.get('authorizes_release') is not False or
            not _state_matches(ack.get('state'), parent, candidate)):
        raise PromotionAdapterRefused('receiver promotion acknowledgement refused')
    try:
        observed = read_locked_state(parent, candidate)
    except Exception as exc:
        raise PromotionAdapterRefused('receiver durable state readback uncertain') from exc
    if not _state_matches(observed, parent, candidate):
        raise PromotionAdapterRefused('receiver durable state differs from promotion')
    return observed
