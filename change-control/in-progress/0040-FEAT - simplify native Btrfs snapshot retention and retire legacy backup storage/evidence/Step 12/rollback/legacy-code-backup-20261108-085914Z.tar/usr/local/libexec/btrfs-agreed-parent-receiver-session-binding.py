#!/usr/bin/python3
"""0040 Step 12.3 / 04Q: dormant receiver session-registration core.

This is an in-process coordination contract, NOT an SSH authentication layer.
Only a future privileged receiver runtime may construct TransportProof from
independently verified transport identity. Never accept proofs from client JSON.
No CLI, I/O, persistent state, subprocess or Btrfs execution.
"""
import re
import secrets
import time
from dataclasses import dataclass


class BindingRefused(RuntimeError):
    pass


@dataclass(frozen=True)
class TransportProof:
    """Trusted-adapter-only transport evidence; not a wire message."""
    ssh_principal: str
    connection_id: str
    authenticated: bool
    receiver_lock_owner: str


def _identity(value):
    if (type(value) is not dict or set(value) != {'timestamp', 'uuid'} or
            type(value['timestamp']) is not str or
            re.fullmatch(r'[0-9]{8}-[0-9]{6}Z', value['timestamp']) is None or
            type(value['uuid']) is not str or
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', value['uuid']) is None):
        raise BindingRefused('invalid A/B identity')
    return dict(value)


class ReceiverSession:
    """A single-use, receiver-controlled, lock-scoped binding registry.

    Do not serialize/persist this object and do not substitute a transferred
    session token for proof of SSH principal or receiver-lock ownership.
    """
    def __init__(self, parent, candidate, *, lock_owner, duration=120,
                 clock=time.monotonic, token_factory=lambda: secrets.token_hex(32)):
        self.parent = _identity(parent)
        self.candidate = _identity(candidate)
        if self.parent['timestamp'] >= self.candidate['timestamp']:
            raise BindingRefused('invalid snapshot order')
        if type(lock_owner) is not str or not lock_owner:
            raise BindingRefused('missing receiver lock owner')
        if type(duration) not in (int, float) or not 1 <= duration <= 3600:
            raise BindingRefused('invalid session deadline')
        self.token = token_factory()
        if type(self.token) is not str or re.fullmatch(r'[0-9a-f]{64}', self.token) is None:
            raise BindingRefused('invalid session token')
        self._clock = clock
        self._deadline = clock() + duration
        self._lock_owner = lock_owner
        self._registrations = {}
        self.phase = 'registering'

    def _refuse(self, why):
        self.phase = 'failed'
        raise BindingRefused(why)

    def _check(self, *, locks_held, lock_owner):
        if self.phase != 'registering':
            self._refuse('session not accepting registrations')
        if locks_held is not True or lock_owner != self._lock_owner:
            self._refuse('receiver locks not continuously held by owner')
        if self._clock() >= self._deadline:
            self._refuse('session expired')

    def register(self, channel, *, token, parent, candidate, proof,
                 locks_held=False, lock_owner=None):
        self._check(locks_held=locks_held, lock_owner=lock_owner)
        if channel not in ('data', 'control') or channel in self._registrations:
            self._refuse('invalid or repeated channel')
        if token != self.token or _identity(parent) != self.parent or _identity(candidate) != self.candidate:
            self._refuse('transaction or token mismatch')
        if (type(proof) is not TransportProof or proof.authenticated is not True or
                proof.ssh_principal != 'richard' or not proof.connection_id or
                proof.receiver_lock_owner != self._lock_owner):
            self._refuse('missing independently verified transport evidence')
        if any(p.connection_id == proof.connection_id for p in self._registrations.values()):
            self._refuse('reused connection identity')
        self._registrations[channel] = proof
        if len(self._registrations) == 2:
            self.phase = 'bound'
        return {'schema': 1, 'status': 'receiver-session-bound' if self.phase == 'bound' else 'receiver-session-registering',
                'channels_registered': sorted(self._registrations), 'transfer_executed': False,
                'authorizes_transfer': False, 'authorizes_promote': False,
                'authorizes_prune': False, 'authorizes_release': False}

    def bound(self, *, locks_held=False, lock_owner=None):
        if self.phase != 'bound' or locks_held is not True or lock_owner != self._lock_owner or self._clock() >= self._deadline:
            self.phase = 'failed'
            raise BindingRefused('binding invalid or expired')
        return True

    def close(self):
        self.phase = 'closed'
        self._registrations.clear()
