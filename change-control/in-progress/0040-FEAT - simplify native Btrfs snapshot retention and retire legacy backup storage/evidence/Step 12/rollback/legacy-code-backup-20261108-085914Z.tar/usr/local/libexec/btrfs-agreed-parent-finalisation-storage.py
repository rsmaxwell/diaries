#!/usr/bin/env python3
"""0040 Step 12.3: fixed-path, fail-closed receiver finalisation storage.

Internal adapters only. The caller must hold both receiver locks and separately
verify authenticated sender completion. This module grants no such authority.
An uncertain durable write is never automatically retried or repaired.
"""
import json
import os
from pathlib import Path
import re
import stat

STATE = Path('/@data/mars-received/.replication-state')
JOURNAL = '.agreed-parent-transfer-pending.json'
STAMP = re.compile(r'[0-9]{8}-[0-9]{6}Z\Z')

class StorageRefused(RuntimeError):
    pass


def _directory(directory):
    directory = Path(directory)
    if not directory.is_absolute() or directory.is_symlink() or not directory.is_dir():
        raise StorageRefused('unsafe receiver state directory')
    return directory


def _safe_read(path):
    if path.is_symlink():
        raise StorageRefused('symlinked receiver evidence')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 65536:
            raise StorageRefused('unsafe receiver evidence file')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            payload = stream.read(65537)
        if len(payload) > 65536:
            raise StorageRefused('oversized receiver evidence')
        return json.loads(payload.decode('utf-8'))
    finally:
        os.close(fd)


def read_state(directory=STATE):
    directory = _directory(directory)
    return _safe_read(directory / '.agreed-parent.json')


def read_journal(directory=STATE):
    directory = _directory(directory)
    return _safe_read(directory / JOURNAL)


def receipt_absent(stamp, directory=STATE):
    if type(stamp) is not str or not STAMP.fullmatch(stamp):
        raise StorageRefused('invalid receipt stamp')
    directory = _directory(directory)
    path = directory / (stamp + '.json')
    return not (path.exists() or path.is_symlink())


def commit_receipt(stamp, receipt, *, directory=STATE, locks_held=False):
    """Create final receipt exclusively; never overwrite and never clean on error.

    Expects a validated receipt from finalisation core. The finalisation core
    remains responsible for sender proof, A/B consistency, and Btrfs inspection.
    """
    if locks_held is not True:
        raise StorageRefused('both receiver locks required')
    if type(stamp) is not str or not STAMP.fullmatch(stamp):
        raise StorageRefused('invalid receipt stamp')
    if type(receipt) is not dict or receipt.get('snapshot') != stamp:
        raise StorageRefused('receipt identity mismatch')
    directory = _directory(directory)
    path = directory / (stamp + '.json')
    payload = (json.dumps(receipt, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')
    if len(payload) > 65536:
        raise StorageRefused('receipt too large')
    # No pre-check as authority: O_EXCL prevents overwrite even after a race.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(payload)
            out.flush()
            os.fsync(out.fileno())
        dirfd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(dirfd)
        finally:
            os.close(dirfd)
    except BaseException:
        # A created file may have been partly or fully committed: never auto-remove.
        raise
    return path
