#!/usr/bin/python3
"""0040 Step 12.3 Integration 04J: locked receiver transaction review.

Production CLI is deliberately review-only. A receive callback is injectable
only into the Python transaction core for controlled tests; no live binary
stream, receipt creation, promotion, prune or release is exposed here.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
STATE_DIR = Path('/@data/mars-received/.replication-state')
SNAPSHOTS = Path('/@data/mars-received/@data')
MANAGER = Path('/run/lock/btrfs-snapshot-manager.lock')
WRITER = STATE_DIR / 'writer.lock'
BOUNDARY = Path('/usr/local/libexec/btrfs-agreed-parent-receive-boundary.py')


def load(name, *, base=BASE):
    path = base / ('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('receive04j_' + name.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def transaction(parent, candidate, *, modules=None, receive=None):
    """Own both receiver locks across preflight and the injected test transaction.

    The production CLI cannot provide `receive`. The callback is a test seam,
    NOT a production execution contract or authority to stream data.
    """
    d = modules if modules is not None else {
        name: load(name) for name in ('state', 'receiver', 'endpoint', 'transfer-absence', 'receive-boundary')}
    state = d['state']
    state.snapshot(parent)
    state.snapshot(candidate)
    if not (isinstance(parent, dict) and isinstance(candidate, dict) and
            parent['timestamp'] < candidate['timestamp']):
        raise RuntimeError('invalid exact A/B identities')
    with ExitStack() as stack:
        d['receiver']._lock(stack, MANAGER)
        d['receiver']._lock(stack, WRITER)
        d['endpoint'].validate_filesystem()
        before = state.load(STATE_DIR / '.agreed-parent.json')
        absence = d['transfer-absence'].verify(parent, candidate, before, state=state)
        destination = {
            'snapshot_absent': absence['destination_absent'],
            'receipt_absent': absence['receipt_absent'],
            'partial_artifacts_absent': True,
            'prune_journal_absent': True,
        }
        d['receive-boundary'].verify_before_receive(
            before, parent, candidate, destination,
            manager_lock_held=True, writer_lock_held=True)
        if receive is None:
            return {'schema': 1, 'status': 'receive-transaction-review',
                    'parent': parent, 'candidate': candidate, 'state': before,
                    'both_receiver_locks_held_during_review': True,
                    'destination_absent': True, 'receipt_absent': True,
                    'state_changed': False, 'transfer_executed': False,
                    'authorizes_transfer': False, 'authorizes_promote': False,
                    'authorizes_prune': False, 'authorizes_release': False}
        if not callable(receive):
            raise RuntimeError('invalid test-only receive callback')
        attested = receive(parent, candidate)
        after = state.load(STATE_DIR / '.agreed-parent.json')
        result = d['receive-boundary'].verify_after_receive(
            before, after, parent, candidate, attested,
            manager_lock_held=True, writer_lock_held=True)
        return result


def main():
    parser = argparse.ArgumentParser(description='Locked receiver A/B review; transfer disabled')
    for field in ('parent', 'parent-uuid', 'candidate', 'candidate-uuid'):
        parser.add_argument('--' + field, required=True)
    parser.add_argument('--review-only', action='store_true', required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('root required')
    a = {'timestamp': args.parent, 'uuid': args.parent_uuid}
    b = {'timestamp': args.candidate, 'uuid': args.candidate_uuid}
    print(json.dumps(transaction(a, b), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, KeyError, TypeError, OSError) as exc:
        print('receive transaction review refused: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
