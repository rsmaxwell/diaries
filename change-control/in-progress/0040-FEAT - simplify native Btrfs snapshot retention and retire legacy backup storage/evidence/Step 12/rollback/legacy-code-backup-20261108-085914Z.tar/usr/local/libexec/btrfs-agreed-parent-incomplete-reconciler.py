#!/usr/bin/env python3
"""0040 Step 12.3: fenced provisional receive reconciliation transaction.

Internal trusted dependency boundary, NOT exposed by receiver CLI or installed.
The privileged receiver must construct all evidence locally; never accept sender
assertions of fencing, subvolume ownership or receipt absence.
"""
from pathlib import Path
import re
import importlib.util

STAMP = re.compile(r"[0-9]{8}-[0-9]{6}Z\Z")
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z")

class Refused(RuntimeError):
    pass

def identity(value):
    return (type(value) is dict and set(value) == {'timestamp', 'uuid'}
            and type(value['timestamp']) is str and STAMP.fullmatch(value['timestamp'])
            and type(value['uuid']) is str and UUID.fullmatch(value['uuid']))

def validate_journal(journal, parent, candidate):
    """Accept legacy or fully boot-bound scoped journals; never partial upgrades."""
    base = {'schema', 'status', 'parent', 'candidate', 'nonce'}
    scoped = base | {'scope_unit', 'scope_binding', 'receiver_boot_id'}
    if type(journal) is not dict or set(journal) not in (base, scoped):
        raise Refused('journal fields incomplete or unexpected')
    if (journal['schema'] != 1 or journal['status'] != 'receiving' or
        journal['parent'] != parent or journal['candidate'] != candidate or
        type(journal['nonce']) is not str or
        re.fullmatch(r'[0-9a-f]{64}', journal['nonce']) is None):
        raise Refused('journal identity or nonce mismatch')
    if set(journal) == scoped:
        expected = ('btrfs-agreed-receive-' + candidate['timestamp'] + '-' +
                    journal['nonce'][:16] + '.scope')
        if (journal['scope_unit'] != expected or
            journal['scope_binding'] != 'reserved-not-termination-evidence' or
            type(journal['receiver_boot_id']) is not str or
            UUID.fullmatch(journal['receiver_boot_id']) is None):
            raise Refused('scoped journal binding mismatch')
        return 'scoped'
    return 'legacy'


def fence_previous_boot(journal, *, boot_id_reader):
    """Process termination only; no deletion authority or same-boot fallback."""
    if type(journal) is not dict:
        raise Refused('invalid journal')
    if not all(k in journal for k in ('parent', 'candidate')):
        raise Refused('journal identity missing')
    kind = validate_journal(journal, journal['parent'], journal['candidate'])
    if kind != 'scoped':
        raise Refused('legacy journal has no boot fence')
    current = boot_id_reader()
    if type(current) is not str or UUID.fullmatch(current) is None:
        raise Refused('invalid receiver boot identity')
    if current == journal['receiver_boot_id']:
        raise Refused('same boot requires independent process fencing')
    return {'schema': 1, 'termination_proven': True,
            'fencing': 'receiver-reboot', 'scope_unit': journal['scope_unit'],
            'nonce': journal['nonce'], 'cleanup_authorized': False,
            'destination_ownership_proven': False, 'retransmit_authorized': False}


def reconcile(parent, candidate, *, capture, fence, inspect_destination,
              delete_subvolume, remove_journal, readback, locks_held=False,
              destination_root='/@data/mars-received/@data'):
    """Reconcile one *uncommitted* provisional receive with fail-closed checks.

    Caller owns canonical manager then writer locks over this entire operation.
    The fence callback must independently establish process-group and descendant
    termination, including escaped processes, without trusting absence of flock.
    Destructive callbacks are trusted privileged receiver-side implementations,
    not user/SSH supplied values. No automatic retry here.

    Once deletion succeeds but journal removal fails, re-entry is refused; an
    operator must reconcile evidence. This is deliberate crash consistency.
    """
    if locks_held is not True or not identity(parent) or not identity(candidate):
        raise Refused('canonical locks and A/B identities required')
    if parent['timestamp'] >= candidate['timestamp']:
        raise Refused('invalid candidate order')
    if destination_root != '/@data/mars-received/@data':
        raise Refused('noncanonical destination root')
    expected = str(Path(destination_root) / candidate['timestamp'])
    before = capture()
    if (type(before) is not dict or set(before) !=
        {'state', 'journal', 'receipt_absent', 'destination'}):
        raise Refused('incomplete trusted observation')
    state, journal = before['state'], before['journal']
    if (type(state) is not dict or state.get('schema') != 1 or
        state.get('established') != parent or state.get('pending') != candidate or
        state.get('previous') is not None):
        raise Refused('receiver state mismatch')
    journal_kind = validate_journal(journal, parent, candidate)
    if before['receipt_absent'] is not True:
        raise Refused('committed or uncertain receipt')
    if before['destination'] != expected:
        raise Refused('unrecognised destination')
    # Both callbacks run while canonical locks are retained. A plain proc scan
    # without a reliable process/namespace fence is not sufficient.
    if (fence(parent, candidate, journal if journal_kind == 'scoped' else journal['nonce']) is not True):
        raise Refused('stream termination not independently proven')
    proof = inspect_destination(expected)
    if (type(proof) is not dict or proof.get('path') != expected or
        proof.get('kind') != 'btrfs-subvolume' or
        proof.get('read_only') is not False or
        proof.get('committed') is not False or
        proof.get('owner_nonce') != journal['nonce'] or
        proof.get('exact_identity_proven') is not True):
        raise Refused('unowned, readonly, or uncertain destination')
    # Re-observe after fencing to prevent stale receipt and state evidence.
    if capture() != before:
        raise Refused('state changed before deletion')
    if delete_subvolume(expected) is not True:
        raise Refused('destination deletion not confirmed; journal retained')
    if remove_journal(journal['nonce']) is not True:
        raise Refused('journal cleanup failed after deletion; manual recovery required')
    after = readback()
    if (type(after) is not dict or after.get('destination_absent') is not True or
        after.get('journal_absent') is not True or
        after.get('receipt_absent') is not True or
        after.get('state') != state):
        raise Refused('post-reconciliation durability not verified')
    return {'schema': 1, 'status': 'receiver-provisional-reconciled',
            'parent': parent, 'candidate': candidate,
            'transfer_retried': False, 'prune_authorized': False,
            'previous_released': False}
