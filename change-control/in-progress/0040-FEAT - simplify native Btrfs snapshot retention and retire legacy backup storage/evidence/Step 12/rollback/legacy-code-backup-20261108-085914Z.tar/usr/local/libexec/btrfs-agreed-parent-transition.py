#!/usr/bin/python3
"""0040 3H.2: dormant receiver transition core; not a privileged CLI.

The caller MUST supply a trusted evidence verifier that checks the receiver
filesystem, Btrfs read-only snapshot identity and durable replication receipt
while both receiver locks are held. No SSH or untrusted command execution here.
"""
from contextlib import ExitStack
import importlib.util
import json
from pathlib import Path


def _load(name):
    path = Path(__file__).with_name('btrfs-agreed-parent-' + name + '.py')
    spec = importlib.util.spec_from_file_location('agreed_parent_3h2_' + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


state = _load('state')
receiver = _load('receiver')
OPS = frozenset(('get-state', 'prepare', 'promote', 'acknowledge-previous'))


def transition(*, operation, transaction_id, expected_before, candidate,
               state_path, receipt_dir, snapshot_dir, manager_lock, writer_lock,
               verify, lock=receiver._lock):
    """Return success only after durable readback. Never blindly retry after SSH loss.

    verify(snapshot, receipt_dir, snapshot_dir) must fail closed on invalid
    receiver receipt, filesystem identity or read-only Btrfs identity.
    Caller must also ensure source-side coordination and peer postconditions.
    """
    if operation not in OPS:
        raise state.StateError('unsupported receiver transition')
    import re
    if not isinstance(transaction_id, str) or not re.fullmatch(r'[0-9]{8}-[0-9]{6}Z', transaction_id):
        raise state.StateError('invalid transaction ID')
    if operation == 'get-state':
        if expected_before is not None:
            state.validate(expected_before)
    else:
        state.validate(expected_before)
    if operation in ('prepare', 'promote'):
        state.snapshot(candidate)
        if candidate['timestamp'] != transaction_id:
            raise state.StateError('transaction/candidate mismatch')
    elif candidate is not None:
        raise state.StateError('unexpected candidate')
    if any(not isinstance(p, Path) or not p.is_absolute() for p in
           (state_path, receipt_dir, snapshot_dir, manager_lock, writer_lock)):
        raise state.StateError('absolute receiver paths required')
    if (state_path != receipt_dir / '.agreed-parent.json' or
            writer_lock != receipt_dir / 'writer.lock' or manager_lock == writer_lock or
            receipt_dir.is_symlink() or snapshot_dir.is_symlink() or
            not receipt_dir.is_dir() or not snapshot_dir.is_dir()):
        raise state.StateError('unsafe receiver configuration')
    if not callable(verify):
        raise state.StateError('receiver evidence verifier required')
    with ExitStack() as stack:
        lock(stack, manager_lock)
        lock(stack, writer_lock)
        journal = receipt_dir / '.receiver-prune-pending.json'
        if journal.exists() or journal.is_symlink():
            raise state.StateError('receiver deletion in progress')
        before = state.load(state_path, require_root=True)
        if operation == 'get-state':
            if expected_before is not None and before != expected_before:
                raise state.StateError('unexpected receiver state')
            after = before
        else:
            if operation == 'prepare':
                after = state.prepare(expected_before, candidate)
            elif operation == 'promote':
                if expected_before['pending'] != candidate:
                    raise state.StateError('pending candidate mismatch')
                after = state.promote(expected_before)
            else:
                if expected_before['previous'] is None:
                    raise state.StateError('no previous parent')
                after = state.acknowledge_previous(expected_before)
            # Exact current or exact expected poststate: idempotent retry.
            if before != expected_before and before != after:
                raise state.StateError('unexpected receiver state')
        # During prepare, B has not been transferred yet: validate the
        # established source parent, not the not-yet-received candidate.
        # Promotion requires the B receipt to be present and verified.
        evidence_state = expected_before if operation == 'prepare' else after
        for timestamp, uuid in state.protected(evidence_state).items():
            verify({'timestamp': timestamp, 'uuid': uuid}, receipt_dir, snapshot_dir)
        if before != after:
            state.save(state_path, after, require_root=True)
        persisted = state.load(state_path, require_root=True)
        if persisted != after:
            raise state.StateError('durable receiver postcondition mismatch')
        return {'schema': 1, 'operation': operation, 'transaction_id': transaction_id,
                'status': 'success', 'state': persisted}


def encode(response):
    return json.dumps(response, separators=(',', ':'), sort_keys=True)
